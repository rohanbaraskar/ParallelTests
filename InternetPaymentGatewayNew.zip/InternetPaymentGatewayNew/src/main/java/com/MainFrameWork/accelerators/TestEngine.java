package com.MainFrameWork.accelerators;       
import org.testng.annotations.AfterMethod;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.apache.log4j.Logger;
//import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.firefox.FirefoxProfile;
//import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.ITestContext;
//import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.MainFrameWork.support.ActionEngineSupport;
import com.MainFrameWork.support.ConfiguratorSupport;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.support.ReportStampSupport;
import com.MainFrameWork.utilities.Reporter;
public class TestEngine extends HtmlReportSupport {
	public static Logger logger = Logger.getLogger(TestEngine.class.getName());
	public static ConfiguratorSupport configProps = new ConfiguratorSupport(
			"config.properties");
	//public static ConfiguratorSupport counterProp = new ConfiguratorSupport(
		//	configProps.getProperty("counterPath"));
	public static ConfiguratorSupport counterProp = new ConfiguratorSupport(
			"counter.properties");
	public static String currentSuite = "";
	public static String method = "";
	public static String timeStamp = ReportStampSupport.timeStamp()
			.replace(" ", "_").replace(":", "_").replace(".", "_");
	public static boolean flag = false;
	public static WebDriver webDriver = null;
	public static EventFiringWebDriver driver=null;
	public static int stepNum = 0;
	public static int PassNum =0;
	public static int FailNum =0;
	public static int passCounter =0;
	public static int failCounter =0;
	public static String testName = "";
	public static String testCaseExecutionTime = "";
	public static StringBuffer x=new StringBuffer();
	public static String finalTime = "";
	public static boolean isSuiteRunning=false;
	public static Map<String, String> testDescription = new LinkedHashMap<String, String>();
	public static Map<String, String> testResults = new LinkedHashMap<String, String>();
	public static String url=null;
	public static String fileDownloadPath = configProps.getProperty("fileDownloadPath");
	static ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"),configProps.getProperty("sheetName0"));
	/*
	 * public static Screen s; public static String url =
	 * "jdbc:mysql://172.16.6.121/"; public static String dbName = "test";
	 * public static String userName = "root"; public static Connection conn =
	 * null; public static Statement stmt = null; public static
	 * PreparedStatement pstmt = null; public static ResultSet rs = null;
	 */
	public static int countcompare = 0;
	public static String browser = null;
	static int len = 0;
	static int i = 0;
	public static ITestContext itc;
	public static String groupNames = null;
	//---------------NETWORK PANEL VARIABLES AND OBJECTS--------------
	public static LoggingPreferences logPrefs = new LoggingPreferences();
	/**
	 * Initializing browser requirements, Test Results file path and Database
	 * requirements from the configuration file
	 * 
	 * @Date 19/02/2013
	 * @Revision History
	 * 
	 */
	@BeforeSuite(alwaysRun = true)
	public static void setupSuite(ITestContext ctx) throws Throwable {
		itc = ctx;
		groupNames = ctx.getCurrentXmlTest().getIncludedGroups().toString();

		String strBrowserType[];

		ReportStampSupport.calculateSuiteStartTime();
		try{
				logger.info("Starting browser : "
						+ configProps.getProperty("browserType"));

				browser = configProps.getProperty("browserType");
		
		} catch (Exception e1) {
			e1.printStackTrace();
			System.out.println(e1);
		}
		// browser = configProps.getProperty("browserType");
		if (browser.toString().contains(",")) {
			strBrowserType = browser.split("\\,");

		} else {
			strBrowserType = new String[] { browser };
		}
		if (browser.toString().contains(",")) {
			strBrowserType = browser.split("\\,");
		} else {
			strBrowserType = new String[] { browser };
		}
		len = strBrowserType.length;
		while (i < len) {

			if (strBrowserType[i].toString().equalsIgnoreCase("firefox")) {
				/*
				ProfilesIni profileini = new ProfilesIni() {
			        @Override
			        public FirefoxProfile getProfile(String profileName) {
			                File appData = locateAppDataDirectory(Platform.WINDOWS);
			                Map<String, File> profiles = readProfiles(appData);
			                File profileDir = profiles.get("D:\\worldline\\InsightPlus_Automation\\firefoxProfile_silverlight");
			                if (profileDir == null)
			                  return null;
			                return new FirefoxProfile(profileDir);
			         }
			    };*/
			    
			    
				//ProfilesIni profile = new ProfilesIni();
				//File profileDirectory = new File("D:\\worldline\\InsightPlus_Automation\\firefoxProfile_silverlight");

				//FirefoxProfile ffprofile = new FirefoxProfile(profileDirectory);
				
				//ffprofile.setEnableNativeEvents(true);

				//webDriver = new FirefoxDriver(ffprofile);
				webDriver = new FirefoxDriver();
				i = i + 1;
				break;

			} else if (strBrowserType[i].toString().equalsIgnoreCase("ie")) {
				File file = new File("Drivers\\IEDriverServer.exe");
				System.setProperty("webdriver.ie.driver",
						file.getAbsolutePath());

				webDriver = new InternetExplorerDriver();
				i = i + 1;
				if (configProps.getProperty("browserType").equals("ie")) {
					
					DesiredCapabilities capabilities =
							DesiredCapabilities.internetExplorer();
							capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
							
							/*
					Process p = Runtime
							.getRuntime()
							.exec("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 255");
					p.waitFor();*/
					Thread.sleep(1000);
				}
				break;

			} else if (strBrowserType[i].toString().equalsIgnoreCase("chrome")) {
				logPrefs.enable(LogType.PERFORMANCE, Level.ALL);   
				System.setProperty("webdriver.chrome.driver",
						"Drivers\\chromedriver.exe");
				//////////////////////////////////////////////////////////////////////////
				HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
				chromePrefs.put("profile.default_content_settings.popups", 0);
				chromePrefs.put("download.default_directory", fileDownloadPath);
				//////////////////////////////////////////////////////////////////////////
				DesiredCapabilities capabilities = new DesiredCapabilities();
				capabilities.setCapability(CapabilityType.LOGGING_PREFS, logPrefs); 
				ChromeOptions options = new ChromeOptions();
				
				options.setExperimentalOption("prefs", chromePrefs);
				
				options.addArguments("test-type");
		    	 capabilities.setCapability(ChromeOptions.CAPABILITY, options);				
				
				webDriver = new ChromeDriver(capabilities);
				
				i = i + 1;
				break;

			}

		}
		driver = new EventFiringWebDriver(webDriver);

		ActionEngineSupport myListener = new ActionEngineSupport();
		driver.register(myListener);
		//nz_region url
				try {
				
						url = (configProps.getProperty("URL"));
				System.out.println("url "+url);

		} catch (Exception e1) {
			e1.printStackTrace();
			System.out.println(e1);
		}
		//driver.manage().deleteAllCookies();		
		driver.manage().window().maximize();
		//driver.get(url);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Reporter.reportCreater();
		HtmlReportSupport.currentSuit = ctx.getCurrentXmlTest().getSuite()
				.getName();
	}

	

	/**
	 * De-Initializing and closing all the connections
	 * 
	 * @throws Throwable
	 */
	
/*
	//AfterMethod
	*/
	@AfterSuite(alwaysRun = true)
	public void tearDown(ITestContext ctx) throws Throwable {
		
		ReportStampSupport.calculateSuiteExecutionTime();
		
		HtmlReportSupport.createHtmlSummaryReport(browser, url);
		//System.out.println("########################### Inside After Suite");

		//com.IpgTransAdminPortal.workflows.HomePage hp = new com.IpgTransAdminPortal.workflows.HomePage();
		//hp.logOut();
		
		if(driver.getCurrentUrl().contains("MerchantPortal")){
			com.IpgMerchantPortal.workflows.MerchantHomePage mhp = new com.IpgMerchantPortal.workflows.MerchantHomePage();
			try{
				mhp.logOut();
			}catch(Throwable e){
				
			}
		}else if(driver.getCurrentUrl().contains("TransactAdminPortal")){
		
			com.IpgTransAdminPortal.workflows.HomePage hp = new com.IpgTransAdminPortal.workflows.HomePage();
			try{
				hp.logOut();
			}catch(Throwable e){		
			}
		}
		
		driver.quit();
		closeSummaryReport();
		try {
			killChromeDirver();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	/**
	 * Write results to Browser specific path
	 * 
	 * @Date 19/02/2013
	 * @Revision History
	 * 
	 */
	// @Parameters({"browserType"})
	public static String filePath() {
		String strDirectoy = "";
		
			if (browser.equalsIgnoreCase("ie")) {
				strDirectoy = "IE\\IE";

			} else if (browser.equalsIgnoreCase("firefox")) {
				strDirectoy = "Firefox\\Firefox";

			} else {
				strDirectoy = "Chrome\\Chrome";
				
			}

		if (strDirectoy != "") {
			new File(configProps.getProperty("screenShotPath") + strDirectoy
					+ "_" + timeStamp).mkdirs();
		}
	
		File results = new File(configProps.getProperty("screenShotPath") + strDirectoy
			+ "_" + timeStamp+"\\"+"Screenshots");
		if(!results.exists())
		{
			results.mkdir();
			HtmlReportSupport.copyLogos();
		}

		return configProps.getProperty("screenShotPath") + strDirectoy + "_"
				+ timeStamp + "\\";

	}

	/**
	 * Browser type prefix for Run ID
	 * 
	 * @Date 19/02/2013
	 * @Revision History
	 * 
	 */
	public static String result_browser() {
		if (groupNames.equals("[]")) {
			if (configProps.getProperty("browserType").equals("ie")) {
				return "IE";
			} else if (configProps.getProperty("browserType").equals("firefox")) {
				return "Firefox";
			} else {
				return "Chrome";
			}
		} else {
			if (browser.equalsIgnoreCase("ie")) {
				return "IE";

			} else if (browser.equalsIgnoreCase("firefox")) {
				return "Firefox";

			} else {
				return "Chrome";

			}
		}
	}

	/**
	 * Related to Xpath
	 * 
	 * @Date 19/02/2013
	 * @Revision History
	 * 
	 */
	public static String methodName() {
		
			if (browser.equals("ie")) {
				return "post";
			} else {
				return "POST";
			}
		}
	@BeforeMethod(alwaysRun = true)
	public void reportHeader(Method method, ITestContext ctx) throws Throwable {
		itc = ctx;
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd_MMM_yyyy hh mm ss SSS");
		String formattedDate = sdf.format(date);
		ReportStampSupport.calculateTestCaseStartTime();

		flag = false;

		HtmlReportSupport.tc_name = method.getName().toString() + "-"
				+ formattedDate;
		String[] ts_Name = this.getClass().getName().toString().split("\\.");
		HtmlReportSupport.packageName = ts_Name[0] + "." + ts_Name[1] + "."
				+ ts_Name[2];


			HtmlReportSupport.testHeader(HtmlReportSupport.tc_name, browser);

		stepNum = 0;
		PassNum = 0;
		FailNum = 0;
		testName = method.getName();

	}
	
		
	
	@AfterMethod(alwaysRun = true)
	public static void tearDown()
	{
		ReportStampSupport.calculateTestCaseExecutionTime();
		closeDetailedReport();
		//System.out.println("########################### Inside After Method");
		String currUrl = driver.getCurrentUrl();
		if(driver.getCurrentUrl().contains("MerchantPortal")){
			com.IpgMerchantPortal.workflows.MerchantHomePage mhp = new com.IpgMerchantPortal.workflows.MerchantHomePage();
			try{
				mhp.logOut();
			}catch(Throwable e){
				
			}
		}else if(driver.getCurrentUrl().contains("TransactAdminPortal")){
		
			com.IpgTransAdminPortal.workflows.HomePage hp = new com.IpgTransAdminPortal.workflows.HomePage();
			try{
				hp.logOut();
			}catch(Throwable e){		
			}
		}
		
		if(FailNum!=0)
		{
			failCounter=failCounter+1;
			testResults.put(HtmlReportSupport.tc_name, "FAIL");
		}
		else
		{
			testResults.put(HtmlReportSupport.tc_name, "PASS");
			passCounter=passCounter+1;
		}
	}
	
	public static void killChromeDirver() throws InterruptedException, IOException{
		try {

		//	Thread.sleep(minutes % 60 * 60L * 1000L);
			Runtime.getRuntime().exec("taskkill /f /im chromedriver.exe");
			System.exit(0);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
