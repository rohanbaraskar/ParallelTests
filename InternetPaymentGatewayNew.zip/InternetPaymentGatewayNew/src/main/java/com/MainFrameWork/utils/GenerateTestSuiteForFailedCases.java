package com.MainFrameWork.utils;

import java.text.ParseException;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.server.handler.FindElements;
import org.testng.annotations.Test;

import com.MainFrameWork.accelerators.ActionEngine;

public class GenerateTestSuiteForFailedCases extends ActionEngine {
	public static String url;

	@Test(groups = { "smoke", "functional" })
	public void generateTestSuite() throws Throwable {
		url = "file:///D:/Worldline/IPG%20Backup/Reports/Chrome_2017-02-15_16_19_40_438/SummaryResults_2017-02-15_16_19_40_438.html";
		String packName ="<class name=\"com.IpgTransAdminPortal.testScripts."; 
				
		driver.get(url);
		Thread.sleep(5000);
		int noOfFailures = getElementsSize(
				By.xpath("//td[@class='fail']/..//a"), "failed cases");
		String sample = getText(By.xpath("//td[@class='fail']/..//a"), "");
		System.out.println("##############################################################################################");
		for (WebElement failedCase : getElements(By
				.xpath("//td[@class='fail']/..//a"))) {
			sample = failedCase.getText();
			sample = sample.trim();
			sample = packName + sample + "\" />";
			System.out.println(sample);
			
		}
		System.out.println("##############################################################################################");

	}


}