package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.AddSchemePage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class AddScheme_Test extends AddSchemePage{
	
	Logger logger = Logger.getLogger(AddSchemePage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "AddScheme");
	@Test(groups= {"smoke", "functional"})
	public void addScheme_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		setSchemeName(xlsrdr.getCellValue("schemeName", "value"));
		String schemeCode = RandomTextUtils.getRandomText(6);
		setSchemeCode(schemeCode);
		setSchemeTypeCC(xlsrdr.getCellValue("schemeTypeCC", "value"));
		setSchemeTypeDC(xlsrdr.getCellValue("schemeTypeDC", "value"));
		setSchemeTypeCUG(xlsrdr.getCellValue("schemeTypeCUG", "value"));
		setSchemeTypeLoyaltyCard(xlsrdr.getCellValue("schemeTypeLoyaltyCard", "value"));
		setCcSaleWithCashbackLimit(xlsrdr.getCellValue("ccSaleWithCashbackLimit", "value"));
		setDcSaleWithCashbackLimit(xlsrdr.getCellValue("dcSaleWithCashbackLimit", "value"));
		setDccDisclaimer(xlsrdr.getCellValue("dccDisclaimer", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Add Scheme");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToSchemeRegistrationPage();
			result = addScheme();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Add Scheme", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Add Scheme ","Successful for user: " + UserName);
			} 
			else{
				//Reporter.failureReport("Add ME Profile ", "Add ME profile verification failed for user: "+ UserName);
				Assert.assertTrue(result == false, "Add Scheme Test Failed");
			}
	}
}
