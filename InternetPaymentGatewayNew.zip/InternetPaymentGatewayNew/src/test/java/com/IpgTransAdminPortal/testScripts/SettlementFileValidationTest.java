package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.IpgTransAdminPortal.workflows.SettlementFileValidation;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;

public class SettlementFileValidationTest extends SettlementFileValidation{
	
	Logger logger = Logger.getLogger(SettlementFileValidation.class.getName());
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "settlementFileValidation");

	public String settlementFileNameAndPath = xlsrdr.getCellValue("settlementFileNamePath", "value");
	
	@Test(groups= {"smoke", "functional"})
	public void settlementFileValidation_Test() throws Throwable 
	{
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Settlement File Validation Test");
			setSettlementBatchFileNameAndPath(settlementFileNameAndPath);
			result = validateSettlementFile();
			
		} catch (Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Settlement File Validation Test Failed");
		}
		
			if (result){	
				HtmlReportSupport.onSuccess("IPG - Settlement File","Settlement File Validation Test Successful ");
			} 
			else{
				HtmlReportSupport.onWarning(settlementFileNameAndPath,"Settlement File Validation Test Failed");
				Assert.assertTrue(result == false, "Settlement File Validation Test Failed");
			}
	}
}
