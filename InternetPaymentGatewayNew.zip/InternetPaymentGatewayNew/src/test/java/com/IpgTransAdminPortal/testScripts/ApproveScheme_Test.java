package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.AddSchemePage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class ApproveScheme_Test extends AddSchemePage{
	
	Logger logger = Logger.getLogger(AddSchemePage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "ApproveScheme");
	@Test(groups= {"smoke", "functional"})
	public void approveScheme_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		String schemeName = xlsrdr.getCellValue("schemeName", "value");
		schemeName = schemeName + RandomTextUtils.getRandomText(6);
		String UserName = xls.getCellValue("userid", "value");
		String Password = xls.getCellValue("password", "value");	
		setSchemeName(schemeName);
		String schemeCode = RandomTextUtils.getRandomText(5);
		//setSchemeCode(xlsrdr.getCellValue("schemeCode", "value"));
		setSchemeCode(schemeCode);
		setSchemeTypeCC(xlsrdr.getCellValue("schemeTypeCC", "value"));
		setSchemeTypeDC(xlsrdr.getCellValue("schemeTypeDC", "value"));
		setSchemeTypeCUG(xlsrdr.getCellValue("schemeTypeCUG", "value"));
		setSchemeTypeLoyaltyCard(xlsrdr.getCellValue("schemeTypeLoyaltyCard", "value"));
		setCcSaleWithCashbackLimit(xlsrdr.getCellValue("ccSaleWithCashbackLimit", "value"));
		setDcSaleWithCashbackLimit(xlsrdr.getCellValue("dcSaleWithCashbackLimit", "value"));
		setDccDisclaimer(xlsrdr.getCellValue("dccDisclaimer", "value"));
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Verification of Approve Scheme");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToSchemeRegistrationPage();
			result = addScheme();
			home.logOut();
			UserName = xls.getCellValue("approverId", "value");
			Password = xls.getCellValue("approverPwd", "value");	
			
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			result = approveScheme(schemeName);
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Approve Scheme Verification", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Approve Scheme Verification","Successful for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Approve Scheme Verification Failed");
			}
	}
}
