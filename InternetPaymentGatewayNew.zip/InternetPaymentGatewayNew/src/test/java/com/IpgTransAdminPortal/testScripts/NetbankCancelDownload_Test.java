package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.NetbankCancelDownloadPage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class NetbankCancelDownload_Test extends NetbankCancelDownloadPage{
	
	Logger logger = Logger.getLogger(NetbankCancelDownloadPage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "netbankCancelDownload");
	ExcelReader xls1 = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	
	String UserName = xls1.getCellValue("userid", "value");
	String Password = xls1.getCellValue("password", "value");
	
	@Test(groups= {"smoke", "functional"})
	public void netbankCancelDownload_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		
		NetbankCancelDownloadPage ncdp = new NetbankCancelDownloadPage();
		
		ncdp.setLvId(xls.getCellValue("legalVehicle", "value"));
		ncdp.setBankName(xls.getCellValue("netbankName", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Netbank Cancel/Refund Download");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToNetbankCancelDownloadPage();
			
			result = ncdp.netbankCancelDownload();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Netbank Cancel/Refund Download", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
		if (result){	
			Reporter.SuccessReport("Netbank Cancel/Refund Download","Successful for user: " + UserName);
		} 
		else{
			Assert.assertTrue(result == false, "Netbank Cancel/Refund Download Failed");
		}
	}
}
