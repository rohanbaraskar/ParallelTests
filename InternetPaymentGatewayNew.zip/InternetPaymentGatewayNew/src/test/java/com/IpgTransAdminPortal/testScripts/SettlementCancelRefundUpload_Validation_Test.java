package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.SettlementCancelUploadPage;
import com.IpgTransAdminPortal.workflows.SettlementFileGenerationPage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class SettlementCancelRefundUpload_Validation_Test extends SettlementCancelUploadPage{
	
	Logger logger = Logger.getLogger(SettlementFileGenerationPage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "settlementCancelUpload");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	@Test(groups= {"smoke", "functional"})
	public void settlementCancelUpload_validation_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		
		SettlementCancelUploadPage scup = new SettlementCancelUploadPage();
		
		scup.setMeBusinessName(xls.getCellValue("legalMerchantName", "value"));
		scup.setUploadType(xls.getCellValue("uploadType", "value"));
		scup.setUploadFile(xls.getCellValue("uploadFile", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Settlement Cancel/Refund Upload Validation");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToCancelRefundUploadPage();
			
			result = scup.settlementCancelUpload_Validation();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Settlement Cancel/Refund Upload Validation", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
		if (result){	
			Reporter.SuccessReport("Settlement Cancel/Refund Upload Validation","Successful for user: " + UserName);
		} 
		else{
			Assert.assertTrue(result == false, "Settlement Cancel/Refund Upload Validation Failed");
		}
	}
}