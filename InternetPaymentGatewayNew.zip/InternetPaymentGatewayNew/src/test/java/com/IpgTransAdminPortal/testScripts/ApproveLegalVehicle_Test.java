package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.AddLegalVehiclePage;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class ApproveLegalVehicle_Test extends AddLegalVehiclePage{
	
	Logger logger = Logger.getLogger(AddLegalVehiclePage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "ApproveLegalVehicle");
	@Test(groups= {"smoke", "functional"})
	public void approveLegalVehicle_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		String UserName = xls.getCellValue("userid", "value");
		String Password = xls.getCellValue("password", "value");
		String lvName = RandomTextUtils.getRandomText(15);
		setLegalVehicleName(lvName);
		String lvCode = RandomTextUtils.getRandomText(8);
		setLegalVehicleCode(lvCode);
		setLegalVehicleType(xlsrdr.getCellValue("legalVehicleType", "value"));
		setChannelsAvailableIPG(xlsrdr.getCellValue("channelsAvailableIPG", "value"));
		setChannelsAvailablePCPOS(xlsrdr.getCellValue("channelsAvailablePCPOS", "value"));
		setVehicleSchemeMappingChannel(xlsrdr.getCellValue("vehicleSchemeMappingChannel", "value"));
		setVehicleSchemeMappingScheme(xlsrdr.getCellValue("vehicleSchemeMappingScheme", "value"));
		setVehiclePaymentMappingChannel(xlsrdr.getCellValue("vehiclePaymentMappingChannel", "value"));
		setVehiclePaymentMappingPayType(xlsrdr.getCellValue("vehiclePaymentMappingPayType", "value"));
		setProdTypeRecurrPayUpload(xlsrdr.getCellValue("prodTypeRecurrPayUpload", "value"));
		setProdTypePreAuth(xlsrdr.getCellValue("prodTypePreAuth", "value"));
		setProdTypeEmailInvoice(xlsrdr.getCellValue("prodTypeEmailInvoice", "value"));
		setProdTypeRecurrPayOnline(xlsrdr.getCellValue("prodTypeRecurrPayOnline", "value"));
		setProdTypeHostedPages(xlsrdr.getCellValue("prodTypeHostedPages", "value"));
		setProdTypeSmsInvoice(xlsrdr.getCellValue("prodTypeSmsInvoice", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Add Legal Vehicle");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToAddLegalVehiclePage();
			result = addLegalVehicle();
			home.logOut();
			UserName = xls.getCellValue("approverId", "value");
			Password = xls.getCellValue("approverPwd", "value");	
			
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = approveLegalVehicle(lvName);
			home.logOut();
			
			
		
		} catch (Exception e) {
			Reporter.failureReport("Approve Legal Vehicle", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Approve Legal Vehicle ","Successful for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Approve Legal Vehicle Test Failed");
			}
	}
}
