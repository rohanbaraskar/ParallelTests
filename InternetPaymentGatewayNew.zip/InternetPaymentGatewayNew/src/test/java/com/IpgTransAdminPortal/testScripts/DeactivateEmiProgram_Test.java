package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.AddEmiProgramPage;
import com.IpgTransAdminPortal.workflows.AddLegalVehiclePage;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.AddSchemePage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class DeactivateEmiProgram_Test extends AddEmiProgramPage{
	
	Logger logger = Logger.getLogger(AddEmiProgramPage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "DeactivateEmiProgram");
	@Test(groups= {"smoke", "functional"})
	public void deactivateEmiProgram_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		String UserName = xls.getCellValue("userid", "value");
		String Password = xls.getCellValue("password", "value");
		setLvName(xlsrdr.getCellValue("lvName", "value"));
		String programCode = RandomTextUtils.getRandomNumberInRange(11111, 999999999) + "";
		setProgramCode(programCode);
		setProgramDescription(xlsrdr.getCellValue("programDescription", "value"));
		setInterestRate(xlsrdr.getCellValue("interestRate", "value"));
		setProcessFeePercent(xlsrdr.getCellValue("processFeePercent", "value"));
		setProcessFeeFix(xlsrdr.getCellValue("processFeeFix", "value"));
		setValidFrom(xlsrdr.getCellValue("validFrom", "value"));
		setValidTo(xlsrdr.getCellValue("validTo", "value"));
		setMinAmount(xlsrdr.getCellValue("minAmount", "value"));
		setMaxAmount(xlsrdr.getCellValue("maxAmount", "value"));
		setEmiDiscType(xlsrdr.getCellValue("emiDiscType", "value"));
		setEmiDiscPercentFixed(xlsrdr.getCellValue("emiDiscPercentFixed", "value"));
		setEmiAddDiscAmount(xlsrdr.getCellValue("emiAddDiscAmount", "value"));
		setMaxCapAmount(xlsrdr.getCellValue("maxCapAmount", "value"));
		setTaxCode(xlsrdr.getCellValue("taxCode", "value"));
		setTaxFor(xlsrdr.getCellValue("taxFor", "value"));
		setTenure(xlsrdr.getCellValue("tenure", "value"));
		setProgramMapChannel(xlsrdr.getCellValue("programMapChannel", "value"));
		setIssuerBank(xlsrdr.getCellValue("issuerBank", "value"));
		setAcqBank(xlsrdr.getCellValue("acqBank", "value"));
		setMerchName(xlsrdr.getCellValue("merchName", "value"));
		setManufacturerName(xlsrdr.getCellValue("manufacturerName", "value"));
		setProdName(xlsrdr.getCellValue("prodName", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Deactivate EMI Program");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToAddEmiProgram();
			result = addEmiProgram();
			home.logOut();
			
			UserName = xls.getCellValue("approverId", "value");
			Password = xls.getCellValue("approverPwd", "value");	
			
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = approveEmiProgram(programCode);
			home.logOut();
			
			UserName = xls.getCellValue("userid", "value");
			Password = xls.getCellValue("password", "value");
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = deactivateEmiProgram(programCode);
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Deactivate EMI Program", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Deactivate EMI Program ","Successful for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Deactivate EMI Program Test Failed");
			}
	}
}
