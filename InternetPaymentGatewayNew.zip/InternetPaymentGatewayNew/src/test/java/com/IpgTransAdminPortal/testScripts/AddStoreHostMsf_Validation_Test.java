package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.AddStorePage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class AddStoreHostMsf_Validation_Test extends AddStorePage{
	
	Logger logger = Logger.getLogger(AddStorePage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	@Test(groups= {"smoke", "functional"})
	public void addStoreHostMsf_Validation_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
					
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Add Store");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			result = validateStore("addStoreHostMSF_mid");		
			home.logOut();
		
		} catch (Exception e) {
			Reporter.failureReport("Add Store Host MSF - Validation", "Test Failed"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Add Store Host MSF - Validation","Successfully onboarded Merchant for user: " + UserName);
			} 
			else{
				//Reporter.failureReport("Add ME Profile ", "Add ME profile verification failed for user: "+ UserName);
				Assert.assertTrue(result == false, "Add Store Host MSF - Validation - Test Failed");
			}
	}
}
