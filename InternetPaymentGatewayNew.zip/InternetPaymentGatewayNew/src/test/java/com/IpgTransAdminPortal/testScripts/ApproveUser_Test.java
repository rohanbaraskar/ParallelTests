package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.ReportWorkflows;
import com.IpgTransAdminPortal.workflows.UserAccountWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class ApproveUser_Test extends UserAccountWorkflows{
	Logger logger = Logger.getLogger(ReportWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "ApproveUser");
	String UserName = xls.getCellValue("approverId", "value");
	String Password = xls.getCellValue("approverPwd", "value");	
	
	@Test(groups= {"smoke", "functional"})
	public void approveUser_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		//xlsrdr.getCellValue("", "value")s
	
		setRemarks(xlsrdr.getCellValue("remarks", "value"));
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Approve User Test from User Account Module");
            
			LoginPage login = new LoginPage();
			HomePage home = new HomePage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = approveUser();
			home.logOut();
		
			
		} catch (Exception e) {
			Reporter.failureReport("Approve User", "Test Failed"+ UserName);
			e.printStackTrace();
		}
			if (result){	
				Reporter.SuccessReport("Approve User","Successfully Created New User for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Approve User Test Failed");
     	}
	}

}
