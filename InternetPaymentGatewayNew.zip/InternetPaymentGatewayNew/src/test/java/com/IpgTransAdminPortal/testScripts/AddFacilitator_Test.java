package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.IpgTransAdminPortal.workflows.AddFacilitatorPage;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class AddFacilitator_Test extends AddFacilitatorPage{
	
	Logger logger = Logger.getLogger(AddFacilitatorPage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "AddFacilitator");
	@Test(groups= {"smoke", "functional"})
	public void addFacilitator_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		setFacilitatorName(xlsrdr.getCellValue("facilitatorName", "value"));
		String facilitatorCode = RandomTextUtils.getRandomNumberInRange(1111, 99999999) +"";
		setFacilitatorCode(facilitatorCode);
		setScheme(xlsrdr.getCellValue("scheme", "value"));
		setAssCode(xlsrdr.getCellValue("assCode", "value"));
		setAssFclCode(xlsrdr.getCellValue("assFclCode", "value"));
						
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Add Facilitator");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToAddFacilitatorPage();
			result = addFacilitator();
			home.logOut();
		
		} catch (Exception e) {
			Reporter.failureReport("Add Facilitator ", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
		if (result){	
			Reporter.SuccessReport("Add Facilitator ","Successful for user: " + UserName);
		} 
		else{
			Assert.assertTrue(result == false, "Add Facilitator Test Failed");
		}
	}
}
