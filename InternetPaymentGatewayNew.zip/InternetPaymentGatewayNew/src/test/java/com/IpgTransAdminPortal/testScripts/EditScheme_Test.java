package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.AddSchemePage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class EditScheme_Test extends AddSchemePage{
	
	Logger logger = Logger.getLogger(AddSchemePage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "EditScheme");
	@Test(groups= {"smoke", "functional"})
	public void editScheme_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		String schemeName = xlsrdr.getCellValue("schemeName", "value");
		schemeName = schemeName + RandomTextUtils.getRandomText(6);
		setSchemeName(schemeName);
		String schemeCode = RandomTextUtils.getRandomText(6);
		setSchemeCode(schemeCode);
		setSchemeTypeCC(xlsrdr.getCellValue("schemeTypeCC", "value"));
		setSchemeTypeDC(xlsrdr.getCellValue("schemeTypeDC", "value"));
		setSchemeTypeCUG(xlsrdr.getCellValue("schemeTypeCUG", "value"));
		setSchemeTypeLoyaltyCard(xlsrdr.getCellValue("schemeTypeLoyaltyCard", "value"));
		setCcSaleWithCashbackLimit(xlsrdr.getCellValue("ccSaleWithCashbackLimit", "value"));
		setDcSaleWithCashbackLimit(xlsrdr.getCellValue("dcSaleWithCashbackLimit", "value"));
		setDccDisclaimer(xlsrdr.getCellValue("dccDisclaimer", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Verification of Edit Scheme");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToSchemeRegistrationPage();
			result = addScheme();
			home.logOut();
			
			String apprUserName = xls.getCellValue("approverId", "value");
			String apprPassword = xls.getCellValue("approverPwd", "value");	
			
			login.setUserName(apprUserName);
			login.setPassword(apprPassword);
			login.login();
			
			result = approveScheme(schemeName);
			home.logOut();
			
			HtmlReportSupport.reportStep("EDIT SCHEME");
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			setSchemeTypeCC(xlsrdr.getCellValue("editSchemeTypeCC", "value"));
			setSchemeTypeDC(xlsrdr.getCellValue("editSchemeTypeDC", "value"));
			setSchemeTypeCUG(xlsrdr.getCellValue("editSchemeTypeCUG", "value"));
			setSchemeTypeLoyaltyCard(xlsrdr.getCellValue("editSchemeTypeLoyaltyCard", "value"));
			
			result = home.viewScheme(schemeName);
			result = addScheme();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Edit Scheme Verification", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Edit Scheme Verification","Successful for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Edit Scheme Verification Failed");
			}
	}
}
