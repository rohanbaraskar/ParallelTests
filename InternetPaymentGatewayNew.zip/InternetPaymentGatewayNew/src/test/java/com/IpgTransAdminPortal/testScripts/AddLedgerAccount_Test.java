package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.AddLedgerAccountPage;
import com.IpgTransAdminPortal.workflows.AddTaxPage;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class AddLedgerAccount_Test extends AddLedgerAccountPage{
	
	Logger logger = Logger.getLogger(AddLedgerAccountPage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "AddLedgerAccount");
	@Test(groups= {"smoke", "functional"})
	public void addLedgerAccount_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		setLvName(xlsrdr.getCellValue("lvName", "value"));
		String ledgerAccNumber = "WL00" + RandomTextUtils.getRandomNumberInRange(11111, 99999999);
		setLedgerAccNumber(ledgerAccNumber);
		setAccHead(xlsrdr.getCellValue("accHead", "value"));
		setAccPurpose(xlsrdr.getCellValue("accPurpose", "value"));
		setRemarks(xlsrdr.getCellValue("remarks", "value"));
		setAccFor(xlsrdr.getCellValue("accFor", "value"));
		setAccRefNumber(xlsrdr.getCellValue("accRefNumber", "value"));
		setNessieGlCode(xlsrdr.getCellValue("nessieGlCode", "value"));
		setAccName(xlsrdr.getCellValue("accName", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Add Ledger Account");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToAddLedgerAccountPage();
			result = addLedgerAccount();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Add Ledger Account", "Test Failed"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Add Ledger Account","Successfully added Ledger Account for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Add Ledger Account Test Failed");
			}
	}
}