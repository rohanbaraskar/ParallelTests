package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.ReportWorkflows;
import com.IpgTransAdminPortal.workflows.UserAccountWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class ChangePassword_Test extends UserAccountWorkflows{
	
	Logger logger = Logger.getLogger(ReportWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "ChangePassword");
	
	@Test(groups= {"smoke", "functional"})
	public void changePassword_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		
		setOldPwd(xlsrdr.getCellValue("oldPwd", "value"));
		setNewPwd(xlsrdr.getCellValue("newPwd", "value"));
		setConfrmNewPwd(xlsrdr.getCellValue("confirmNewPwd", "value"));
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Change Password Test from User Transactions Portal");
			
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = changePassword();
			HomePage home = new HomePage();
			home.logOut();
		
			
		} catch (Exception e) {
			Reporter.failureReport("Change Password ", "Test Failed"+ UserName);
			e.printStackTrace();
		}
			if (result){	
				Reporter.SuccessReport("Change Password ","Successfully Change Passwrd for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Change Password Test Failed");
     	}
	}
}
