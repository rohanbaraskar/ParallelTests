package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.ReportWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class TransactionSearchReport_Test extends ReportWorkflows{
	
	Logger logger = Logger.getLogger(ReportWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "transactionSearchReport");
	@Test(groups= {"smoke", "functional"})
	public void transactionSearchResults_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		//xlsrdr.getCellValue("", "value")
		setPgMerchId(xlsrdr.getCellValue("pgMerchId", "value"));
		setOrderId(xlsrdr.getCellValue("orderId", "value"));
		setRrn(xlsrdr.getCellValue("rrn", "value"));
		setTransRefNo(xlsrdr.getCellValue("transRefNo", "value"));
		setFromDate(xlsrdr.getCellValue("fromDate", "value"));
		setToDate(xlsrdr.getCellValue("toDate", "value"));
		setChannel(xlsrdr.getCellValue("channel", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Add Tax");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			result = transactionSearchReport();
			
			HomePage home = new HomePage();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Transaction Search Report", "Test Failed"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Transaction Search Report","Successfully got transaction search results for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Transaction Search Report Test Failed");
			}
	}
}