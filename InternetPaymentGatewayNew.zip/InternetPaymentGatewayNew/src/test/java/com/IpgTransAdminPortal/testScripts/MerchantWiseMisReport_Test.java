package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.ReportWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class MerchantWiseMisReport_Test extends ReportWorkflows{
	
	Logger logger = Logger.getLogger(ReportWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "merchwiseMisReport");
	@Test(groups= {"smoke", "functional"})
	public void merchantwiseMISReport_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		setFromDate(xlsrdr.getCellValue("fromDate", "value"));
		setToDate(xlsrdr.getCellValue("toDate", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Merchant Wise MIS Report");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = merchantWiseMisReport();
			
			HomePage home = new HomePage();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Merchant Wise MIS Report", "Test Failed"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Merchant Wise MIS Report","Successfully got search results for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Merchant Wise MIS Report Test Failed");
			}
	}
}