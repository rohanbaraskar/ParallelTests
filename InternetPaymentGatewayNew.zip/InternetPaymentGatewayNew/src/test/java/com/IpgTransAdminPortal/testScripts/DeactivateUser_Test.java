package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.ReportWorkflows;
import com.IpgTransAdminPortal.workflows.UserAccountWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class DeactivateUser_Test extends UserAccountWorkflows {
	Logger logger = Logger.getLogger(ReportWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "DeactivateUser");
	
	@Test(groups= {"smoke", "functional"})
	public void deactivateUser_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		//xlsrdr.getCellValue("", "value")
		String loginid=xlsrdr.getCellValue("loginid", "value");
		loginid = loginid + RandomTextUtils.getRandomText(8);
		setLoginId(loginid);
		setFirstName(xlsrdr.getCellValue("firstname", "value"));
		setLastName(xlsrdr.getCellValue("lastname", "value"));
		setDisplayName(xlsrdr.getCellValue("displayname", "value"));
		setEmailId(xlsrdr.getCellValue("emailid", "value"));
		setMobileNo(xlsrdr.getCellValue("mobileno", "value"));
		setLandlineNo(xlsrdr.getCellValue("landlineno", "value"));
		setStreetAddress(xlsrdr.getCellValue("streetaddress", "value"));
		setCity(xlsrdr.getCellValue("city", "value"));
		setState(xlsrdr.getCellValue("state", "value"));
		setZipCode(xlsrdr.getCellValue("zipcode", "value"));
		setEmployeeId(xlsrdr.getCellValue("employeeid", "value"));
		setEntityType(xlsrdr.getCellValue("entitytype", "value"));
		setLvName(xlsrdr.getCellValue("lvname", "value"));
		setRemarks(xlsrdr.getCellValue("remarks", "value"));
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Deactivate User Test from User Account Module");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = createNewUser();
			HomePage home = new HomePage();
			home.logOut();
			
			UserName = xls.getCellValue("approverId", "value");
			Password = xls.getCellValue("approverPwd", "value");	
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = approveUser();
			home.logOut();
			
			UserName = xls.getCellValue("super_user", "value");
			Password = xls.getCellValue("super_pwd", "value");	
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = deactivateUser();
			home.logOut();
		
			
		} catch (Exception e) {
			Reporter.failureReport("Deactivate User", "Test Failed"+ UserName);
			e.printStackTrace();
		}
			if (result){	
				Reporter.SuccessReport("Deactivate User","Successfully Deactivate User for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Deactivate User Test Failed");
     	}
	}
}
