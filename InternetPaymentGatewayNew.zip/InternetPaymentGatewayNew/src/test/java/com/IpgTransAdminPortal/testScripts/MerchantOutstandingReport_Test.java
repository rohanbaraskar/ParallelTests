package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.ReportWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class MerchantOutstandingReport_Test extends ReportWorkflows{
	Logger logger = Logger.getLogger(ReportWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "MerchantOutstandingReport");
	@Test(groups= {"smoke", "functional"})
	public void merchantOutStandingReport_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		//xlsrdr.getCellValue("", "value")
		setreportType(xlsrdr.getCellValue("reporttype", "value"));
		setPgMerchId(xlsrdr.getCellValue("pgMerchId", "value"));
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Merchant Outstanding Report from Reports Module");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			result = merchantOutstandingReport();
			
			HomePage home = new HomePage();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Merchant Outstanding Report", "Test Failed"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Merchant Outstanding Report","Successfully got Merchant Outstanding Report results for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Merchant Outstanding Report Test Failed");
			}
	}
}

