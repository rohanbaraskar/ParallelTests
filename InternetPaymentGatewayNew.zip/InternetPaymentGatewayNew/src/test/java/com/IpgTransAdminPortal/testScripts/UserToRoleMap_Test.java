package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.ReportWorkflows;
import com.IpgTransAdminPortal.workflows.UserAccountWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class UserToRoleMap_Test extends UserAccountWorkflows {
	Logger logger = Logger.getLogger(ReportWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "UserToRoleMap");
	
	@Test(groups= {"smoke", "functional"})
	public void userToRoleMap_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		String roleName=xlsrdr.getCellValue("roleName", "value");
		roleName=roleName+RandomTextUtils.getRandomText(5);
		
		String roleDescription=xlsrdr.getCellValue("roleDescription", "value");
		roleDescription=roleDescription+RandomTextUtils.getRandomText(5);
		setRemarks(xlsrdr.getCellValue("remarks", "value"));
		setRoleName(roleName);
		setRoleDescription(roleDescription);
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "User To Role Map Test from User Account Module");
			
            LoginPage login = new LoginPage();
			HomePage home = new HomePage();
			UserName = xls.getCellValue("super_user", "value");
			Password = xls.getCellValue("super_pwd", "value");	
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = createRole();
			home.logOut();
		
			UserName = xls.getCellValue("approverId", "value");
			Password = xls.getCellValue("approverPwd", "value");	
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = approveRole();
			home.logOut();
			
			UserName = xls.getCellValue("super_user", "value");
			Password = xls.getCellValue("super_pwd", "value");	
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = userToRoleMap();
			home.logOut();
			
			
		} catch (Exception e) {
			Reporter.failureReport("User To Role Map", "Test Failed"+ UserName);
			e.printStackTrace();
		}
			if (result){	
				Reporter.SuccessReport("User To Role Map","Successfully User To Role Map for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "User To Role Map Test Failed");
     	}
	}
}