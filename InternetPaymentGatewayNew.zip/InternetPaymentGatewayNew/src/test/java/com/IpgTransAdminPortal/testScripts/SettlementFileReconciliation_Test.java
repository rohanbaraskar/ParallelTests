package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.DisputeManagementPage;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.SettlementFileGenerationPage;
import com.IpgTransAdminPortal.workflows.SettlementFileReconPage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class SettlementFileReconciliation_Test extends SettlementFileReconPage{
	
	Logger logger = Logger.getLogger(SettlementFileGenerationPage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "settleFileRecon");
	ExcelReader xls1 = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls1.getCellValue("userid", "value");
	String Password = xls1.getCellValue("password", "value");
	
	@Test(groups= {"smoke", "functional"})
	public void settleFileReconciliation_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		
		SettlementFileGenerationPage sfgp = new SettlementFileGenerationPage();
		
	//	sfgp.setLegalVehicle(xls.getCellValue("legalVehicle","value"));
	//	sfgp.setAcqBank(xls.getCellValue("acqBank", "value"));
		ExcelReader bufferxls = new ExcelReader(configProps.getProperty("TempData"), "buffer");

				
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Settlement File Reconciliation");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToSettleFileGenPage();
			String batchRnId = bufferxls.getCellData("buffer", "settlementFileGen_batchRunId", 2);
			
			//result = sfgp.settlementFileGenerationForRecon();
			home.navigateToSettleFileReconPage();
			setBatchRunId(batchRnId);
			result = settlementFileReconciliation();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Settlement File Reconciliation", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
		if (result){	
			Reporter.SuccessReport("Settlement File Reconciliation","Successful for user: " + UserName);
		} 
		else{
			Assert.assertTrue(result == false, "Settlement File Reconciliation Test Failed");
		}
	}
}
