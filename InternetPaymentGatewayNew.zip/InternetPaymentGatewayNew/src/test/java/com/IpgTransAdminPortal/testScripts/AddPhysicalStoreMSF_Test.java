package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.AddStorePage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class AddPhysicalStoreMSF_Test extends AddStorePage{
	
	Logger logger = Logger.getLogger(AddStorePage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "AddPhysicalStore");
	@Test(groups= {"smoke", "functional"})
	public void addPhysicalStoreMSF_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		setSourcingChannel(xlsrdr.getCellValue("sourcingChannel", "value"));
		setStoreType_web(xlsrdr.getCellValue("storeType_web", "value"));
		
		setStoreInfo_Channel_webpos(xlsrdr.getCellValue("storeInfo_Channel_webpos", "value"));
		setFeeType(xlsrdr.getCellValue("feeType", "value"));
		String storeName = xlsrdr.getCellValue("storeName", "value");
		storeName = storeName + RandomTextUtils.getRandomNumberInRange(9, 99999);
		setStoreName(storeName);
		setLegalName(xlsrdr.getCellValue("legalName", "value"));
		setPanNumber(xlsrdr.getCellValue("panNumber", "value"));
		setCategory(xlsrdr.getCellValue("category", "value"));
		setAwlMcc(xlsrdr.getCellValue("awlMcc", "value"));
		setPremisesType(xlsrdr.getCellValue("premisesType", "value"));
		setVintageType(xlsrdr.getCellValue("vintageType", "value"));
		setMerchantBusinessType(xlsrdr.getCellValue("merchantBusinesstype", "value"));
		setMerchantWebUrl(xlsrdr.getCellValue("merchantWebUrl", "value"));
		setApplicationNo(xlsrdr.getCellValue("applicationNo", "value"));
		setCorpId(xlsrdr.getCellValue("corpId", "value"));
		setYearsInBusiness(xlsrdr.getCellValue("yearsInBusiness", "value"));
		setBusinessCompetitor(xlsrdr.getCellValue("businessCompetitor", "value"));
		setTotalShops(xlsrdr.getCellValue("totalShops", "value"));
		setAvgTicketSize(xlsrdr.getCellValue("avgTicketSize", "value"));
		setDefineBusinessMature(xlsrdr.getCellValue("defineBusinessMature", "value"));
		setAddress1(xlsrdr.getCellValue("address1", "value"));
		setAddress2(xlsrdr.getCellValue("address2", "value"));
		setAddress3(xlsrdr.getCellValue("address3", "value"));
		setCountry(xlsrdr.getCellValue("country", "value"));
		setState(xlsrdr.getCellValue("state", "value"));
		setCity(xlsrdr.getCellValue("city", "value"));
		setLocationId(xlsrdr.getCellValue("locationId", "value"));
		setRegion(xlsrdr.getCellValue("region", "value"));
		setSubregion(xlsrdr.getCellValue("subregion", "value"));
		setZipCode(xlsrdr.getCellValue("zipCode", "value"));
		setFullName(xlsrdr.getCellValue("fullName", "value"));
		setPhone(xlsrdr.getCellValue("phone", "value"));
		setMobile(xlsrdr.getCellValue("mobile", "value"));
		setFax(xlsrdr.getCellValue("fax", "value"));
		String emailId = RandomTextUtils.getRandomEmailId();
		setEmailId(emailId);
		setBillingAddress_Same(xlsrdr.getCellValue("billingAddress_Same", "value"));
		setRmName(xlsrdr.getCellValue("rmName", "value"));
		setRmMobile(xlsrdr.getCellValue("rmMobile", "value"));
		setRmEmailId(xlsrdr.getCellValue("rmEmailId", "value"));
		setHoldPayment(xlsrdr.getCellValue("holdPayment", "value"));
		setPartialSettlement(xlsrdr.getCellValue("partialSettlement", "value"));
		setSettlementAgainstDelivery(xlsrdr.getCellValue("settlementAgainstDelivery", "value"));
		setAgreementDate(xlsrdr.getCellValue("agreementDate", "value"));
		setAgreementExpiryDate(xlsrdr.getCellValue("agreementExpiryDate", "value"));
		setAgreementNo(xlsrdr.getCellValue("agreementNo", "value"));
		setMerchantClassification(xlsrdr.getCellValue("merchantClassification", "value"));
		setMerchantSegment(xlsrdr.getCellValue("merchantSegment", "value"));
		setBranchOffDesg(xlsrdr.getCellValue("branchOffDesg", "value"));
		setBranchOffMobile(xlsrdr.getCellValue("branchOffMobile", "value"));
		setBranchOffName(xlsrdr.getCellValue("branchOffName", "value"));
		setBranchSolId(xlsrdr.getCellValue("branchSolId", "value"));
		setBranchStaffName(xlsrdr.getCellValue("branchStaffName", "value"));
		setBranchStaffPfi(xlsrdr.getCellValue("branchStaffPfi", "value"));
		setBranchStaffSv(xlsrdr.getCellValue("branchStaffSv", "value"));
		setChequeNo(xlsrdr.getCellValue("chequeNo", "value"));
		setChqDate(xlsrdr.getCellValue("chqDate", "value"));
		setChqAmount(xlsrdr.getCellValue("chqAmount", "value"));
		setChqRemarks(xlsrdr.getCellValue("chqRemarks", "value"));
		///////////////////////////////////////////////////////
		
		setRegistrationDate(xlsrdr.getCellValue("registrationDate", "value"));
		setFacilitator(xlsrdr.getCellValue("facilitator", "value"));
		setBillingAddress1(xlsrdr.getCellValue("billingAddress1", "value"));
		setBillingAddress2(xlsrdr.getCellValue("billingAddress2", "value"));
		setBillingAddress3(xlsrdr.getCellValue("billingAddress3", "value"));
		setBillingCountry(xlsrdr.getCellValue("billingCountry", "value"));
		setBillingState(xlsrdr.getCellValue("billingState", "value"));
		setBillingCity(xlsrdr.getCellValue("billingCity", "value"));
		setBillingPhone1(xlsrdr.getCellValue("billingPhone1", "value"));
		setBillingMobile(xlsrdr.getCellValue("billingMobile", "value"));
		setBillingFax(xlsrdr.getCellValue("billingFax", "value"));
		setBillingZipcode(xlsrdr.getCellValue("billingZipcode", "value"));
		//////////////////////////////////////////////////////
		
		//GROUP DETAILS
				setGroupName(xlsrdr.getCellValue("groupName", "value"));
				setContactName(xlsrdr.getCellValue("contactName", "value"));
				setContactPhone(xlsrdr.getCellValue("contactPhone", "value"));
				setContactMobile(xlsrdr.getCellValue("contactMobile", "value"));
				setContactAddress1(xlsrdr.getCellValue("contactAddress1", "value"));
				setContactAddress2(xlsrdr.getCellValue("contactAddress2", "value"));
				setContactAddress3(xlsrdr.getCellValue("contactAddress3", "value"));
				setContactCountry(xlsrdr.getCellValue("contactCountry", "value"));
				setContactState(xlsrdr.getCellValue("contactState", "value"));
				setContactCity(xlsrdr.getCellValue("contactCity", "value"));
				setContactZipcode(xlsrdr.getCellValue("contactZipcode", "value"));
				setContactEmail(xlsrdr.getCellValue("contactEmail", "value"));
			
				setPrimaryOwnerFirstName(xlsrdr.getCellValue("primaryOwnerFirstName", "value"));
				setPrimaryOwnerMiddleName(xlsrdr.getCellValue("primaryOwnerMiddleName", "value"));
				setPrimaryOwnerLastName(xlsrdr.getCellValue("primaryOwnerLastName", "value"));
				setPrimaryOwnerPhone(xlsrdr.getCellValue("primaryOwnerPhone", "value"));
				setPrimaryOwnerMobile(xlsrdr.getCellValue("primaryOwnerMobile", "value"));
				setPrimaryOwnerZipcode(xlsrdr.getCellValue("primaryOwnerZipcode", "value"));
				setPrimaryOwnerAddress1(xlsrdr.getCellValue("primaryOwnerAddress1", "value"));
				setPrimaryOwnerAddress2(xlsrdr.getCellValue("primaryOwnerAddress2", "value"));
				setPrimaryOwnerFax(xlsrdr.getCellValue("primaryOwnerFax", "value"));
				
				setSecondaryOwnerFirstName(xlsrdr.getCellValue("secondaryOwnerFirstName", "value"));
				setSecondaryOwnerMiddleName(xlsrdr.getCellValue("secondaryOwnerMiddleName", "value"));
				setSecondaryOwnerLastName(xlsrdr.getCellValue("secondaryOwnerLastName", "value"));
				setSecondaryOwnerPhone(xlsrdr.getCellValue("secondaryOwnerPhone", "value"));
				setSecondaryOwnerMobile(xlsrdr.getCellValue("secondaryOwnerMobile", "value"));
				setSecondaryOwnerZipcode(xlsrdr.getCellValue("secondaryOwnerZipcode", "value"));
				setSecondaryOwnerAddress1(xlsrdr.getCellValue("secondaryOwnerAddress1", "value"));
				setSecondaryOwnerAddress2(xlsrdr.getCellValue("secondaryOwnerAddress2", "value"));
				setSecondaryOwnerFax(xlsrdr.getCellValue("secondaryOwnerFax", "value"));
		
		//WEBSITE SUMMARY
				
				setCorporateInfo(xlsrdr.getCellValue("corporateInfo", "value"));
				setComprehensiveBackground(xlsrdr.getCellValue("comprehensiveBackground", "value"));
				setMeBusinessModelDesc(xlsrdr.getCellValue("meBusinessModelDesc", "value"));
				setGoodsServicesDesc(xlsrdr.getCellValue("goodsServicesDesc", "value"));
				setReturnPolicies(xlsrdr.getCellValue("returnPolicies", "value"));
				setMeCustServiceContactInfo(xlsrdr.getCellValue("meCustServiceContactInfo", "value"));
				setTransactionCurrency(xlsrdr.getCellValue("transactionCurrency", "value"));
				setDeliveryPolicy(xlsrdr.getCellValue("deliveryPolicy", "value"));
				setDataPrivacyPolicy(xlsrdr.getCellValue("dataPrivacyPolicy", "value"));
				setRecurringTransDetails(xlsrdr.getCellValue("recurringTransDetails", "value"));
				setShipDetails(xlsrdr.getCellValue("shipDetails", "value"));
				setInfoMethodTransSecurity(xlsrdr.getCellValue("infoMethodTransSecurity", "value"));
				setTransTermsConditions(xlsrdr.getCellValue("transTermsConditions", "value"));
				setMerchWebsite(xlsrdr.getCellValue("merchWebsite", "value"));
				setBriefSummaryGoods(xlsrdr.getCellValue("briefSummaryGoods", "value"));
				setNeedInternCardAcceptance(xlsrdr.getCellValue("needInternCardAcceptance", "value"));
				setPayChannelsVolumeSplit_Internet(xlsrdr.getCellValue("payChannelsVolumeSplit_Internet", "value"));
				setPayChannelsVolumeSplit_Mail(xlsrdr.getCellValue("payChannelsVolumeSplit_Mail", "value"));
				setPayChannelsVolumeSplit_PosCC(xlsrdr.getCellValue("payChannelsVolumeSplit_PosCC", "value"));
				setPayChannelsVolumeSplit_PosDC(xlsrdr.getCellValue("payChannelsVolumeSplit_PosDC", "value"));
				setBusChannelPayVolSplit_B2B(xlsrdr.getCellValue("busChannelPayVolSplit_B2B", "value"));
				setBusChannelPayVolSplit_B2C(xlsrdr.getCellValue("busChannelPayVolSplit_B2C", "value"));
				setAcceptONlinePay(xlsrdr.getCellValue("acceptONlinePay", "value"));
				setProcessorBankName(xlsrdr.getCellValue("processorBankName", "value"));
				setHowLongWithProcess(xlsrdr.getCellValue("howLongWithProcess", "value"));
				setAnnualOnlineTurnover(xlsrdr.getCellValue("annualOnlineTurnover", "value"));
				setAnnualOfflineTurnover(xlsrdr.getCellValue("annualOfflineTurnover", "value"));
				setMinTicketSize(xlsrdr.getCellValue("minTicketSize", "value"));
				setMaxTicketSize(xlsrdr.getCellValue("maxTicketSize", "value"));
				setTimeFrames0(xlsrdr.getCellValue("timeFrames0", "value"));
				setTimeFrames1_3(xlsrdr.getCellValue("timeFrames1_3", "value"));
				setTimeFrames4_7(xlsrdr.getCellValue("timeFrames4_7", "value"));
				setTimeFrames8_14(xlsrdr.getCellValue("timeFrames8_14", "value"));
				setTimeFrames15_30(xlsrdr.getCellValue("timeFrames15_30", "value"));
				setDeposite(xlsrdr.getCellValue("deposit", "value"));
				setAutoRenewals(xlsrdr.getCellValue("autoRenewals", "value"));
				setRefundPolicyFull(xlsrdr.getCellValue("refundPolicyFull", "value"));
				setRefundDays(xlsrdr.getCellValue("refundDays", "value"));
				setRiskChecks(xlsrdr.getCellValue("riskChecks", "value"));
				setSendEmail(xlsrdr.getCellValue("sendEmail", "value"));
				setTimeBtwnPayDelivery(xlsrdr.getCellValue("timeBtwnPayDelivery", "value"));
				setDiwali(xlsrdr.getCellValue("diwali", "value"));
				setChristmas(xlsrdr.getCellValue("christmas", "value"));
				setEaster(xlsrdr.getCellValue("easter", "value"));
				setSummerSales(xlsrdr.getCellValue("summerSales", "value"));
				setChargeBackVol(xlsrdr.getCellValue("chargeBackVol", "value"));
				setNoOfFunds(xlsrdr.getCellValue("NoOfFunds", "value"));
				setNoOfTrans(xlsrdr.getCellValue("NoOfTrans", "value"));
				setRefundVolume(xlsrdr.getCellValue("refundVolume", "value"));
				setSalesVolume(xlsrdr.getCellValue("salesVolume", "value"));
				
		//ADD ACQUIRING BANK
				setLvId(xlsrdr.getCellValue("lvId", "value"));
				setBankName(xlsrdr.getCellValue("bankName", "value"));
				setZone(xlsrdr.getCellValue("zone", "value"));
				setBranch(xlsrdr.getCellValue("branch", "value"));
				setOneTimeFixedFee(xlsrdr.getCellValue("oneTimeFixedFee", "value"));
				setStatementFee(xlsrdr.getCellValue("statementFee", "value"));
				setTerminalFee(xlsrdr.getCellValue("terminalFee", "value"));
				setMinimumUsage(xlsrdr.getCellValue("minimumUsage", "value"));
				setMinTransAmt(xlsrdr.getCellValue("minTransAmt", "value"));
				setMinUsageFee(xlsrdr.getCellValue("minUsageFee", "value"));
				setAmcType(xlsrdr.getCellValue("amcType", "value"));
				setAmcAmount(xlsrdr.getCellValue("amcAmount", "value"));
				setNonUsage(xlsrdr.getCellValue("nonUsage", "value"));
				setNonUsageFee(xlsrdr.getCellValue("nonUsageFee", "value"));
				setSettlementType(xlsrdr.getCellValue("settlementType", "value"));
				setPaymentBy(xlsrdr.getCellValue("paymentBy", "value"));
				setPaymentAdvice(xlsrdr.getCellValue("paymentAdvice", "value"));
				
				setMerchAccNumber(xlsrdr.getCellValue("merchAccNumber", "value"));
				setMerchBankName(xlsrdr.getCellValue("merchBankName", "value"));
				setMerchAccOpenDate(xlsrdr.getCellValue("merchAccOpenDate", "value"));
				setMerchAccState(xlsrdr.getCellValue("merchAccState", "value"));
				setMerchAccCity(xlsrdr.getCellValue("merchAccCity", "value"));
				setMerchAccPhone(xlsrdr.getCellValue("merchAccPhone", "value"));
				setMerchAccMobile(xlsrdr.getCellValue("merchAccMobile", "value"));
				setMerchAccAddress1(xlsrdr.getCellValue("merchAccAddress1", "value"));
				setMerchAccAddress2(xlsrdr.getCellValue("merchAccAddress2", "value"));

				setDailyTransLimit(xlsrdr.getCellValue("dailyTransLimit", "value"));
				setFirc(xlsrdr.getCellValue("firc", "value"));
				
				//ACQ BANK - PCPOS
				setTccDescriptor(xlsrdr.getCellValue("tccDescriptor", "value"));
				setProjectedAvgTicketSize(xlsrdr.getCellValue("projectedAvgTicketSize", "value"));
				setNewPayAdviceValue(xlsrdr.getCellValue("newPayAdviceValue", "value"));
				setRental(xlsrdr.getCellValue("rental", "value"));
				setRentalFrequencyValue(xlsrdr.getCellValue("rentalFrequencyValue", "value"));
				setAdvanceRent(xlsrdr.getCellValue("advanceRent", "value"));
				setAdvanceRentalFrequency(xlsrdr.getCellValue("advanceRentalFrequency", "value"));
				setAdvanceRentalAmount(xlsrdr.getCellValue("advanceRentalAmount", "value"));
				setAdvanceSetup(xlsrdr.getCellValue("advanceSetup", "value"));
				setAdvanceSetupFee(xlsrdr.getCellValue("advanceSetupFee", "value"));
				setMsfIncentive(xlsrdr.getCellValue("msfIncentive", "value"));
				setMerchantIncentive(xlsrdr.getCellValue("merchantIncentive", "value"));
				setTipPercent(xlsrdr.getCellValue("tipPercent", "value"));
				setCashPOS(xlsrdr.getCellValue("cashPOS", "value"));
				setSaleWithCashBack(xlsrdr.getCellValue("saleWithCashBack", "value"));
				//ACQ BANK - MID SETUP
				setMerchIdType(xlsrdr.getCellValue("merchIdType", "value"));
				setCurrency(xlsrdr.getCellValue("currency", "value"));
				//String mid = xlsrdr.getCellValue("mid", "value") + RandomTextUtils.getRandomNumberInRange(999999, 999999999);
				String mid = xlsrdr.getCellValue("mid", "value");
				setMid(mid);
				setApplicationMode(xlsrdr.getCellValue("applicationMode", "value"));
				setTransactionMode(xlsrdr.getCellValue("transactionMode", "value"));
				setFircFrequency(xlsrdr.getCellValue("fircFrequency", "value"));
				setFuelAssociation(xlsrdr.getCellValue("fuelAssociation", "value"));
				setFuelRemark(xlsrdr.getCellValue("fuelRemark", "value"));
				setCallCharges(xlsrdr.getCellValue("callCharges", "value"));
				setSecretKey(xlsrdr.getCellValue("secretKey", "value"));
				setDocumentRequired(xlsrdr.getCellValue("documentRequired", "value"));
				setDocumentPending(xlsrdr.getCellValue("documentPending", "value"));
				setMerchReimbursement(xlsrdr.getCellValue("merchReimbursement", "value"));
				setCustomerId(xlsrdr.getCellValue("customerId", "value"));
				setTid(xlsrdr.getCellValue("tid", "value"));
				setAmexMaId(xlsrdr.getCellValue("amexMaId", "value"));
				setAmexMaPassword(xlsrdr.getCellValue("amexMaPassword", "value"));
				setAmexAmaId(xlsrdr.getCellValue("amexAmaId", "value"));
				setAmexAmaPassword(xlsrdr.getCellValue("amexAmaPassword", "value"));
				setAmexAccessCode(xlsrdr.getCellValue("amexAccessCode", "value"));
				setAmexSecureSecret(xlsrdr.getCellValue("amexSecureSecret", "value"));
				
		//PAYMENT TYPE
				setPaymentTypeCreditCard(xlsrdr.getCellValue("paymentTypeCreditCard", "value"));
				setAmexDomesticCc(xlsrdr.getCellValue("amexDomesticCc", "value"));
				setAmexInternationalCc(xlsrdr.getCellValue("amexInternationalCc", "value"));
				setMastDomCc(xlsrdr.getCellValue("mastDomCc", "value"));
				setMastIntCc(xlsrdr.getCellValue("mastIntCc", "value"));
				setRupayDomCc(xlsrdr.getCellValue("rupayDomCc", "value"));
				setRupayIntCc(xlsrdr.getCellValue("rupayIntCc", "value"));
				setVisaDomCc(xlsrdr.getCellValue("visaDomCc", "value"));
				setVisaIntCc(xlsrdr.getCellValue("visaIntCc", "value"));
				setPaymentTypeDebitCard(xlsrdr.getCellValue("paymentTypeDebitCard", "value"));
				setMastDomDc(xlsrdr.getCellValue("mastDomDc", "value"));
				setMastIntDc(xlsrdr.getCellValue("mastIntDc", "value"));
				setVisaDomDc(xlsrdr.getCellValue("visaDomDc", "value"));
				setVisaIntDc(xlsrdr.getCellValue("visaIntDc", "value"));
				setRupayDomDc(xlsrdr.getCellValue("rupayDomDc", "value"));
				setRupayIntDc(xlsrdr.getCellValue("rupayIntDc", "value"));
				setPaymentTypeInternetBank(xlsrdr.getCellValue("paymentTypeInternetBank", "value"));
				setInternetBankLv(xlsrdr.getCellValue("internetBankLv", "value"));
				setInternetBankSelectBank(xlsrdr.getCellValue("internetBankSelectBank", "value"));
				setInternetBankEffectDate(xlsrdr.getCellValue("internetBankEffectDate", "value"));
				setInternetBankStatus(xlsrdr.getCellValue("internetBankStatus", "value"));
				setInternetBankSortOrder(xlsrdr.getCellValue("internetBankSortOrder", "value"));
				setInternetBankNetBankAccId(xlsrdr.getCellValue("internetBankNetBankAccId", "value"));
				setInternetBankSecretKey(xlsrdr.getCellValue("internetBankSecretKey", "value"));
				setInternetBankPerTransLimit(xlsrdr.getCellValue("internetBankPerTransLimit", "value"));
				setPaymentTypeCug(xlsrdr.getCellValue("paymentTypeCug", "value"));
				setCugFromBin(xlsrdr.getCellValue("cugFromBin", "value"));
				setCugToBin(xlsrdr.getCellValue("cugToBin", "value"));
				setPaymentTypeImps(xlsrdr.getCellValue("paymentTypeImps", "value"));
				setImpsMmid(xlsrdr.getCellValue("impsMmid", "value"));
				setImpsMobileNo(xlsrdr.getCellValue("impsMobileNo", "value"));
				setIpgRefund(xlsrdr.getCellValue("ipgRefund", "value"));
				setIpgCancellation(xlsrdr.getCellValue("ipgCancellation", "value"));
				setIpgRecurPayUpload(xlsrdr.getCellValue("ipgRecurPayUpload", "value"));
				setIpgRecurPayOnline(xlsrdr.getCellValue("ipgRecurPayOnline", "value"));
				setIpgPreauth(xlsrdr.getCellValue("ipgPreauth", "value"));
				setIpgHostedPages(xlsrdr.getCellValue("ipgHostedPages", "value"));
				setIpgEmailInvoice(xlsrdr.getCellValue("ipgEmailInvoice", "value"));
				setIpgSmsInvoice(xlsrdr.getCellValue("ipgSmsInvoice", "value"));
			
		//MSF/CONVENIENCE FEE TAB	
				setMsfAcqBankNameCc(xlsrdr.getCellValue("msfAcqBankNameCc", "value"));
				setMsfMidCc(xlsrdr.getCellValue("msfMidCc", "value"));
				setMsfSchemeCc(xlsrdr.getCellValue("msfSchemeCc", "value"));
				setSlabUptoCc(xlsrdr.getCellValue("slabUptoCc", "value"));
				setInterFixedCc(xlsrdr.getCellValue("interFixedCc", "value"));
				setInterPerCc(xlsrdr.getCellValue("interPerCc", "value"));
				setDomesticOnusFixedCc(xlsrdr.getCellValue("domesticOnusFixedCc", "value"));
				setDomesticOnusPerCc(xlsrdr.getCellValue("domesticOnusPerCc", "value"));
				setDomesticOffusFixedCc(xlsrdr.getCellValue("domesticOffusFixedCc", "value"));
				setDomesticOffusPerCc(xlsrdr.getCellValue("domesticOffusPerCc", "value"));
				setChargeTypeCc(xlsrdr.getCellValue("chargeTypeCc", "value"));
				setMsfAcqBankNameDc(xlsrdr.getCellValue("msfAcqBankNameDc", "value"));
				setMsfMidDc(xlsrdr.getCellValue("msfMidDc", "value"));
				setMsfSchemeDc(xlsrdr.getCellValue("msfSchemeDc", "value"));
				setSlabUptoDc(xlsrdr.getCellValue("slabUptoDc", "value"));
				setInterFixedDc(xlsrdr.getCellValue("interFixedDc", "value"));
				setInterPerDc(xlsrdr.getCellValue("interPerDc", "value"));
				setDomesticOnusFixedDc(xlsrdr.getCellValue("domesticOnusFixedDc", "value"));
				setDomesticOnusPerDc(xlsrdr.getCellValue("domesticOnusPerDc", "value"));
				setDomesticOffusFixedDc(xlsrdr.getCellValue("domesticOffusFixedDc", "value"));
				setDomesticOffusPerDc(xlsrdr.getCellValue("domesticOffusPerDc", "value"));
				setChargeTypeDc(xlsrdr.getCellValue("chargeTypeDc", "value"));			
				setIntBankBankName(xlsrdr.getCellValue("intBankBankName", "value"));
				setIntBankSlabUpto(xlsrdr.getCellValue("intBankSlabUpto", "value"));
				setIntBankFixed(xlsrdr.getCellValue("intBankFixed", "value"));
				setIntBankPercent(xlsrdr.getCellValue("intBankPercent", "value"));
				setIntBankEffectiveFrom(xlsrdr.getCellValue("intBankEffectiveFrom", "value"));
				setIntBankChargeType(xlsrdr.getCellValue("intBankChargeType", "value"));
				setCugBankName(xlsrdr.getCellValue("cugBankName", "value"));
				setCugSlabUpto(xlsrdr.getCellValue("cugSlabUpto", "value"));
				setCugFixed(xlsrdr.getCellValue("cugFixed", "value"));
				setCugPercent(xlsrdr.getCellValue("cugPercent", "value"));
				setCugEffectiveFrom(xlsrdr.getCellValue("cugEffectiveFrom", "value"));
				setCugChargeType(xlsrdr.getCellValue("cugChargeType", "value"));
				setImpsSlabUpto(xlsrdr.getCellValue("impsSlabUpto", "value"));
				setImpsFixed(xlsrdr.getCellValue("impsFixed", "value"));
				setImpsPercent(xlsrdr.getCellValue("impsPercent", "value"));
				setImpsEffectiveFrom(xlsrdr.getCellValue("impsEffectiveFrom", "value"));
				setImpsChargeType(xlsrdr.getCellValue("impsChargeType", "value"));

			//CHECKLIST
				setExistingRelationship(xlsrdr.getCellValue("existingRelationship", "value"));
				setPaymentHoldover(xlsrdr.getCellValue("paymentHoldover", "value"));
				setChecklistMsf(xlsrdr.getCellValue("checklistMsf", "value"));
				setCrossborderTransaction(xlsrdr.getCellValue("crossborderTransaction", "value"));
				setSecure3D(xlsrdr.getCellValue("secure3D", "value"));
				setDomesticUserTransLimit(xlsrdr.getCellValue("domesticUserTransLimit", "value"));
				setSecureCrossborderLimit(xlsrdr.getCellValue("secureCrossborderLimit", "value"));
				setUnsecureTransLimit(xlsrdr.getCellValue("unsecureTransLimit", "value"));
				setChargeBackRecover(xlsrdr.getCellValue("chargeBackRecover", "value"));
				setFinancialStatementSubmit(xlsrdr.getCellValue("financialStatementSubmit", "value"));
				setFinancialStatementSubmitRemark(xlsrdr.getCellValue("financialStatementSubmitRemark", "value"));
				setWebsiteCheck(xlsrdr.getCellValue("websiteCheck", "value"));
				setWebsiteCheckRemark(xlsrdr.getCellValue("websiteCheckRemark", "value"));
				setMerchantRating(xlsrdr.getCellValue("merchantRating", "value"));
				setMerchantRatingRemark(xlsrdr.getCellValue("merchantRatingRemark", "value"));
				setSiteInspection(xlsrdr.getCellValue("siteInspection", "value"));
				setSiteInspectionRemark(xlsrdr.getCellValue("siteInspectionRemark", "value"));
				setBusinessApproval(xlsrdr.getCellValue("businessApproval", "value"));
				setBusinessApprovalRemark(xlsrdr.getCellValue("businessApprovalRemark", "value"));
				setCibilChecks(xlsrdr.getCellValue("cibilChecks", "value"));
				setCibilChecksRemark(xlsrdr.getCellValue("cibilChecksRemark", "value"));
				setKycDocVerify(xlsrdr.getCellValue("kycDocVerify", "value"));
				setKycDocVerifyRemark(xlsrdr.getCellValue("kycDocVerifyRemark", "value"));
				
			//MERCHANT RATING				
				setMerchRatingLocation(xlsrdr.getCellValue("merchRatingLocation", "value"));
				setMerchRatingFinancial(xlsrdr.getCellValue("merchRatingFinancial", "value"));
				setMerchRatingMCategory(xlsrdr.getCellValue("merchRatingMCategory", "value"));
				setMerchRatingDeliveryTimeline(xlsrdr.getCellValue("merchRatingDeliveryTimeline", "value"));
				setMerchRatingOpsSecurity(xlsrdr.getCellValue("merchRatingOpsSecurity", "value"));
				setMerchRatingWebSecurity(xlsrdr.getCellValue("merchRatingWebSecurity", "value"));
				setMerchRatingVmts(xlsrdr.getCellValue("merchRatingVmts", "value"));
				setMerchRatingMatch(xlsrdr.getCellValue("merchRatingMatch", "value"));
				setMerchRatingCibil(xlsrdr.getCellValue("merchRatingCibil", "value"));
				setMerchRatingVmtsCheckbox(xlsrdr.getCellValue("merchRatingVmtsCheckbox", "value"));
				setMerchRatingMatchCheckbox(xlsrdr.getCellValue("merchRatingMatchCheckbox", "value"));
				setMerchRatingPostFacto(xlsrdr.getCellValue("merchRatingPostFacto", "value"));
				setMerchRatingWaiver(xlsrdr.getCellValue("merchRatingWaiver", "value"));
				setMerchRatingEnterRemark(xlsrdr.getCellValue("merchRatingEnterRemark", "value"));

			//UPLOAD DOCUMENTS
				setUploadValidLicense(xlsrdr.getCellValue("uploadValidLicense", "value"));
				setUploadValidLicenseRemark(xlsrdr.getCellValue("uploadValidLicenseRemark", "value"));
				setUploadPancard(xlsrdr.getCellValue("uploadPancard", "value"));
				setUploadPancardRemark(xlsrdr.getCellValue("uploadPancardRemark", "value"));
				setUploadAddressProof(xlsrdr.getCellValue("uploadAddressProof", "value"));
				setUploadAddressProofRemark(xlsrdr.getCellValue("uploadAddressProofRemark", "value"));
				setUploadIncomeTax(xlsrdr.getCellValue("uploadIncomeTax", "value"));
				setUploadIncomeTaxRemark(xlsrdr.getCellValue("uploadIncomeTaxRemark", "value"));
				setUploadStatementOfAcc(xlsrdr.getCellValue("uploadStatementOfAcc", "value"));
				setUploadStatementOfAccRemark(xlsrdr.getCellValue("uploadStatementOfAccRemark", "value"));
				setUploadCancelChq(xlsrdr.getCellValue("uploadCancelChq", "value"));
				setUploadCancelChqRemark(xlsrdr.getCellValue("uploadCancelChqRemark", "value"));
				setUploadMerchEstAgg(xlsrdr.getCellValue("uploadMerchEstAgg", "value"));
				setUploadMerchEstAggRemark(xlsrdr.getCellValue("uploadMerchEstAggRemark", "value"));
				setUploadCpLicenseShops(xlsrdr.getCellValue("uploadCpLicenseShops", "value"));
				setUploadCpLicenseShopsRemark(xlsrdr.getCellValue("uploadCpLicenseShopsRemark", "value"));
				setUploadIDproof(xlsrdr.getCellValue("uploadIDproof", "value"));
				setUploadIDproofRemark(xlsrdr.getCellValue("uploadIDproofRemark", "value"));

			//URLs
				setIsWebsiteOnInternet(xlsrdr.getCellValue("isWebsiteOnInternet", "value"));
				setMerchWebsiteUrl(xlsrdr.getCellValue("merchWebsiteUrl", "value"));
				setCancelRefundPolicy(xlsrdr.getCellValue("cancelRefundPolicy", "value"));
				setPrivacyPolicy(xlsrdr.getCellValue("privacyPolicy", "value"));
				setTermsCondPolicy(xlsrdr.getCellValue("termsCondPolicy", "value"));
				setContactUsInfo(xlsrdr.getCellValue("contactUsInfo", "value"));
				setFaqPage(xlsrdr.getCellValue("faqPage", "value"));
				setOneProdPage(xlsrdr.getCellValue("oneProdPage", "value"));
				setAboutUs(xlsrdr.getCellValue("aboutUs", "value"));
				setHowWebsiteManaged(xlsrdr.getCellValue("howWebsiteManaged", "value"));
				setWhichCompOwnsWebsite(xlsrdr.getCellValue("whichCompOwnsWebsite", "value"));
				setOutsourcedForSolution(xlsrdr.getCellValue("outsourcedForSolution", "value"));
				setWhichSolutionWebsiteOn(xlsrdr.getCellValue("whichSolutionWebsiteOn", "value"));
				setEcommStrategy(xlsrdr.getCellValue("ecommStrategy", "value"));
				setEcommTargetUtility(xlsrdr.getCellValue("ecommTargetUtility", "value"));
				setEcommTargetTravel(xlsrdr.getCellValue("ecommTargetTravel", "value"));
				setEcommTargetRetail(xlsrdr.getCellValue("ecommTargetRetail", "value"));
				setEcommTargetEducation(xlsrdr.getCellValue("ecommTargetEducation", "value"));
				setCharityOrg(xlsrdr.getCellValue("charityOrg", "value"));
				setHostelsMotels(xlsrdr.getCellValue("hostelsMotels", "value"));
				setOther(xlsrdr.getCellValue("other", "value"));
				setPleaseSpecify(xlsrdr.getCellValue("pleaseSpecify", "value"));

			//BLACKLIST/WHITE LIST
				String listType = xlsrdr.getCellValue("blListType", "value");
				setBlListType(listType);
				setBlSchemeName(xlsrdr.getCellValue("blSchemeName", "value"));
				setBlFromBin(xlsrdr.getCellValue("blFromBin", "value"));
				setBlToBin(xlsrdr.getCellValue("blToBin", "value"));

			//IPG
				setEciValueVisa(xlsrdr.getCellValue("eciValueVisa", "value"));
				setEciValueMaster(xlsrdr.getCellValue("eciValueMaster", "value"));
				setEciValueMaestro(xlsrdr.getCellValue("eciValueMaestro", "value"));
				String integrationApproach = xlsrdr.getCellValue("integrationApproach", "value");
				setIntegrationApproach(integrationApproach);
				setPciDssCertificate(xlsrdr.getCellValue("pciDssCertificate", "value"));
				setPciDssExpDate(xlsrdr.getCellValue("pciDssExpDate", "value"));
				setEbsChecksumKey(xlsrdr.getCellValue("ebsChecksumKey", "value"));
				setMpiIntegration(xlsrdr.getCellValue("mpiIntegration", "value"));
				setMpiChecksumKey(xlsrdr.getCellValue("mpiChecksumKey", "value"));
				setLyraCertificate(xlsrdr.getCellValue("lyraCertificate", "value"));
				setLyraShopId(xlsrdr.getCellValue("lyraShopId", "value"));
				setConvFeeMsfCheckValue(xlsrdr.getCellValue("convFeeMsfCheckValue", "value"));
				setMerchEmailConfirmForTrans(xlsrdr.getCellValue("merchEmailConfirmForTrans", "value"));
				setReqUrl1(xlsrdr.getCellValue("reqUrl1", "value"));
				setReqUrl2(xlsrdr.getCellValue("reqUrl2", "value"));

			//PCPOS
				String trainingSchedule = xlsrdr.getCellValue("trainingSchedule", "value"); 
				setTrainingSchedule(trainingSchedule);
				setSeId(xlsrdr.getCellValue("seId", "value"));
				setSeRemarks(xlsrdr.getCellValue("seRemarks", "value"));
				setOwnership(xlsrdr.getCellValue("ownership", "value"));
				setMeChargeSlipName(xlsrdr.getCellValue("meChargeSlipName", "value"));
				setPcposVersion(xlsrdr.getCellValue("pcposVersion", "value"));
				setPromptProcessFlag(xlsrdr.getCellValue("promptProcessFlag", "value"));
				setMaxCashPos(xlsrdr.getCellValue("maxCashPos", "value"));
				setMaxPreauthPercent(xlsrdr.getCellValue("maxPreauthPercent", "value"));
				setContentDisclaimer(xlsrdr.getCellValue("contentDisclaimer", "value"));
				setInstrumentDisclaimer(xlsrdr.getCellValue("instrumentDisclaimer", "value"));
				setProgramDisclaimer(xlsrdr.getCellValue("programDisclaimer", "value"));
				setTotalNoOfTerminals(xlsrdr.getCellValue("totalNoOfTerminals", "value"));
				setModelNo(xlsrdr.getCellValue("modelNo", "value"));
				setEdcVersion(xlsrdr.getCellValue("edcVersion", "value"));
				setNoOfTerminals(xlsrdr.getCellValue("noOfTerminals", "value"));
				
				
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Add Store");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
		
			home.navigateToAddStorePage();
			result = addStore();
			result = fillGroupDetails();
			result = fillWebsiteSummary();
			result = addAcquiringBank();
			result = addPaymentType();
			Thread.sleep(3000);
			result = addMsfConvDetails();
			result = addAcquiringRule();
			if((listType != null)&&(listType != "")&&(listType != "value")){
				result = fillBlackList();
			}
			result = fillChecklist();
			result = fillMerchantRating();
			result = fillUploadDocuments();
			result = fillUrlsPage();
			if((integrationApproach != null)&&(integrationApproach != "")&&(integrationApproach != "value"))
				result = fillIpgPage();
			
			if((trainingSchedule != null)&&(trainingSchedule != "")&&(trainingSchedule != "value"))
				result = fillPcPos();
			
			Thread.sleep(5000);
			result = sendForApproval(storeName);
			//home.logOut();
		/*
			UserName = xls.getCellValue("approverId", "value");
			Password = xls.getCellValue("approverPwd", "value");	
			
			login.setUserName(UserName);
			login.setPassword(Password);
			
			login.login();
			*/
			//OPS APPROVAL
			result = home.navigateToOperationsApprovalListPage();
			result = operationsApproval(storeName);
			//BUSINESS APPROVAL
			result = home.navigateToBusinessApprovalListPage();
			result = businessApproval(storeName);
			//RISK APPROVAL
			result = home.navigateToRiskApprovalListPage();
			result = riskApproval(storeName);
			result = writePgMerchIdToBuffer("addPhysicalStore_mid", storeName);
			
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Add Physical Store - MSF", "Test Failed"+ UserName);
				e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Add Physical Store - MSF","Successfully onboarded Merchant for user: " + UserName);
			} 
			else{
				//Reporter.failureReport("Add ME Profile ", "Add ME profile verification failed for user: "+ UserName);
				Assert.assertTrue(result == false, "Add Physical Store - MSF - Test Failed");
			}
	}
}
