package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.IpgTransAdminPortal.workflows.DisputeManagementPage;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class DisputeManagement_Test extends DisputeManagementPage{
	
	Logger logger = Logger.getLogger(DisputeManagementPage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "disputeManagement");
	ExcelReader xls1 = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls1.getCellValue("super_user", "value");
	String Password = xls1.getCellValue("super_pwd", "value");
	
	@Test(groups= {"smoke", "functional"})
	public void disputeManagement_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		
		setCategory(xls.getCellValue("category","value"));
		setStatus(xls.getCellValue("status", "value"));
		String comment = xls.getCellValue("comment", "value");
		comment = comment + RandomTextUtils.getRandomText(6);
		setComment(comment);
		setFromDate(xls.getCellValue("fromDate", "value"));
		setToDate(xls.getCellValue("toDate", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Dispute Management");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToDisputeManagementPage();
			result = disputeManagement();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Dispute Management", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
		if (result){	
			Reporter.SuccessReport("Dispute Management","Successful for user: " + UserName);
		} 
		else{
			Assert.assertTrue(result == false, "Dispute Management Test Failed");
		}
	}
}