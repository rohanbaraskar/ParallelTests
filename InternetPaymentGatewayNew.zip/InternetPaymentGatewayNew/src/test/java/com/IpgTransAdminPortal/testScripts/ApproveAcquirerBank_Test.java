package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.AddAcquirerPage;
import com.IpgTransAdminPortal.workflows.AddLegalVehiclePage;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.AddSchemePage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class ApproveAcquirerBank_Test extends AddAcquirerPage{
	
	Logger logger = Logger.getLogger(AddAcquirerPage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "ApproveAcquirer");
	@Test(groups= {"smoke", "functional"})
	public void approveAcquirerBank_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		setLegalVehicleName(xlsrdr.getCellValue("legalVehicleName", "value"));
		String acqBankName = xlsrdr.getCellValue("acqBankName", "value");
		setAcqBankName(acqBankName);
		
		String acqBankCode = RandomTextUtils.getRandomText(10);
		setAcqBankCode(acqBankCode);
		setAcqBankFor(xlsrdr.getCellValue("acqBankFor", "value"));
		setBankAggFlag(xlsrdr.getCellValue("bankAggFlag", "value"));
		setAcqBankType(xlsrdr.getCellValue("acqBankType", "value"));
		setPartnerLvId(xlsrdr.getCellValue("partnerLvId", "value"));
		setMerchIdGenBy(xlsrdr.getCellValue("merchIdGenBy", "value"));
		setMerchIdType(xlsrdr.getCellValue("merchIdType", "value"));
		setSuperMerchMid(xlsrdr.getCellValue("superMerchMid", "value"));
		setSuperMerchTid(xlsrdr.getCellValue("superMerchTid", "value"));
		setSuperMerchMidCurrCode(xlsrdr.getCellValue("superMerchMidCurrCode", "value"));
		setSuperMerchDccMid(xlsrdr.getCellValue("superMerchDccMid", "value"));
		setSuperMerchDccTid(xlsrdr.getCellValue("superMerchDccTid", "value"));
		setSuperMerchDccCode(xlsrdr.getCellValue("superMerchDccCode", "value"));
		setAcqBankUserName(xlsrdr.getCellValue("acqBankUserName", "value"));
		setAcqPassword(xlsrdr.getCellValue("acqPassword", "value"));
		setDailyTransCount(xlsrdr.getCellValue("dailyTransCount", "value"));
		setDailyTransVolume(xlsrdr.getCellValue("dailyTransVolume", "value"));
		setPerTransLimit(xlsrdr.getCellValue("perTransLimit", "value"));
		setAnnualCharges(xlsrdr.getCellValue("annualCharges", "value"));
		setMaxRetryCount(xlsrdr.getCellValue("maxRetryCount", "value"));
		setSettlementFlag(xlsrdr.getCellValue("settlementFlag", "value"));
		setDccAcceptFlag(xlsrdr.getCellValue("dccAcceptFlag", "value"));
		setIca(xlsrdr.getCellValue("ica", "value"));
		setAcqDisclaimer(xlsrdr.getCellValue("acqDisclaimer", "value"));
		setInrDisclaimer(xlsrdr.getCellValue("inrDisclaimer", "value"));
		setPreauthDisclaimer(xlsrdr.getCellValue("preauthDisclaimer", "value"));
		setChannelsAvailableIPG(xlsrdr.getCellValue("channelsAvailableIPG", "value"));
		setChannelsAvailablePCPOS(xlsrdr.getCellValue("channelsAvailablePCPOS", "value"));
		setAcqSchemeMapChannel(xlsrdr.getCellValue("acqSchemeMapChannel", "value"));
		setAcqSchemeMapPayType(xlsrdr.getCellValue("acqSchemeMapPayType", "value"));
		setAcqSchemeMapScheme(xlsrdr.getCellValue("acqSchemeMapScheme", "value"));
		setAcqAuthenticationType(xlsrdr.getCellValue("acqAuthenticationType", "value"));
		setAcqAuthorizationType(xlsrdr.getCellValue("acqAuthorizationType", "value"));
		setSettlementType(xlsrdr.getCellValue("settlementType", "value"));
		setAccessCode(xlsrdr.getCellValue("accessCode", "value"));
		setSecureSecret(xlsrdr.getCellValue("secureSecret", "value"));
		setAuthenticationURL(xlsrdr.getCellValue("authenticationURL", "value"));
		setAuthorizationURL(xlsrdr.getCellValue("authorizationURL", "value"));
		
		String UserName = xls.getCellValue("userid", "value");
		String Password = xls.getCellValue("password", "value");
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Approve Acquirer Bank");
			
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();			
			HomePage home = new HomePage();
			home.navigateToAddAcquirerPage();
			result = addAcquirerBank();
			home.logOut();
			Thread.sleep(2000);
			UserName = xls.getCellValue("approverId", "value");
			Password = xls.getCellValue("approverPwd", "value");	
			
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			result = approveAcquirer(acqBankName);
		
			home.logOut();
		} catch (Exception e) {
			Reporter.failureReport("Approve Acquirer Bank", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
		if (result){	
			Reporter.SuccessReport("Approve Acquirer Bank ","Successful for user: " + UserName);
		} 
		else{
			Assert.assertTrue(result == false, "Approve Acquirer Bank Test Failed");
		}
	}
}
