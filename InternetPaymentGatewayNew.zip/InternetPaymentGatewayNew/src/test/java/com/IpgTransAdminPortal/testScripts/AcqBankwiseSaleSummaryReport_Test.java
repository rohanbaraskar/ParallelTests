package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.ReportWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class AcqBankwiseSaleSummaryReport_Test extends ReportWorkflows{
	
	Logger logger = Logger.getLogger(ReportWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "acqBankwiseSalesSummary");
	@Test(groups= {"smoke", "functional"})
	public void acqBankwiseSalesSummaryReport_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		setLvName(xlsrdr.getCellValue("lvName", "value"));
		setAcqBank(xlsrdr.getCellValue("acqBank", "value"));
		setFromDate(xlsrdr.getCellValue("fromDate", "value"));
		setToDate(xlsrdr.getCellValue("toDate", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Acquiring Bankwise Sales Summary Report");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			result = acqBankwiseSalesSummaryReport();
			
			HomePage home = new HomePage();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Acquiring Bankwise Sales Summary Report", "Test Failed"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Acquiring Bankwise Sales Summary Report","Successfully got report search results for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Acquiring Bankwise Sales Summary Report Test Failed");
			}
	}
}