package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.DisputeManagementPage;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.SettlementFileGenerationPage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class SettlementFileGeneration_Test extends SettlementFileGenerationPage{
	
	Logger logger = Logger.getLogger(SettlementFileGenerationPage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "settleFileGen");
	ExcelReader xls1 = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	
	String UserName = xls1.getCellValue("userid", "value");
	String Password = xls1.getCellValue("password", "value");
	
	@Test(groups= {"smoke", "functional"})
	public void settleFileGeneration_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		
		setLegalVehicle(xls.getCellValue("legalVehicle","value"));
		setAcqBank(xls.getCellValue("acqBank", "value"));
		setFromDate(xls.getCellValue("fromDate", "value"));
		setToDate(xls.getCellValue("toDate", "value"));
		
		boolean result = false;
		try
		{
			
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Settlement File Generation");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToSettleFileGenPage();
			result = settlementFileGeneration();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Settlement File Generation", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
		if (result){	
			Reporter.SuccessReport("Settlement File Generation","Successful for user: " + UserName);
		} 
		else{
			Assert.assertTrue(result == false, "Settlement File Generation Test Failed");
		}
	}
}
