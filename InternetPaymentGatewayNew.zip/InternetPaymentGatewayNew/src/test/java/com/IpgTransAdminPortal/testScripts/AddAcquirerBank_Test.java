package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.AddAcquirerPage;
import com.IpgTransAdminPortal.workflows.AddLegalVehiclePage;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.AddSchemePage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class AddAcquirerBank_Test extends AddAcquirerPage{
	
	Logger logger = Logger.getLogger(AddAcquirerPage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "AddAcquirer");
	@Test(groups= {"smoke", "functional"})
	public void addAcquirerBank_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		setLegalVehicleName(xlsrdr.getCellValue("legalVehicleName", "value"));
		setAcqBankName(xlsrdr.getCellValue("acqBankName", "value"));
		String acqBankCode = RandomTextUtils.getRandomText(10);
		setAcqBankCode(acqBankCode);
		setAcqBankFor(xlsrdr.getCellValue("acqBankFor", "value"));
		setBankAggFlag(xlsrdr.getCellValue("bankAggFlag", "value"));
		setAcqBankType(xlsrdr.getCellValue("acqBankType", "value"));
		setPartnerLvId(xlsrdr.getCellValue("partnerLvId", "value"));
		setMerchIdGenBy(xlsrdr.getCellValue("merchIdGenBy", "value"));
		setMerchIdType(xlsrdr.getCellValue("merchIdType", "value"));
		setSuperMerchMid(xlsrdr.getCellValue("superMerchMid", "value"));
		setSuperMerchTid(xlsrdr.getCellValue("superMerchTid", "value"));
		setSuperMerchMidCurrCode(xlsrdr.getCellValue("superMerchMidCurrCode", "value"));
		setSuperMerchDccMid(xlsrdr.getCellValue("superMerchDccMid", "value"));
		setSuperMerchDccTid(xlsrdr.getCellValue("superMerchDccTid", "value"));
		setSuperMerchDccCode(xlsrdr.getCellValue("superMerchDccCode", "value"));
		setAcqBankUserName(xlsrdr.getCellValue("acqBankUserName", "value"));
		setAcqPassword(xlsrdr.getCellValue("acqPassword", "value"));
		setDailyTransCount(xlsrdr.getCellValue("dailyTransCount", "value"));
		setDailyTransVolume(xlsrdr.getCellValue("dailyTransVolume", "value"));
		setPerTransLimit(xlsrdr.getCellValue("perTransLimit", "value"));
		setAnnualCharges(xlsrdr.getCellValue("annualCharges", "value"));
		setMaxRetryCount(xlsrdr.getCellValue("maxRetryCount", "value"));
		setSettlementFlag(xlsrdr.getCellValue("settlementFlag", "value"));
		setDccAcceptFlag(xlsrdr.getCellValue("dccAcceptFlag", "value"));
		setIca(xlsrdr.getCellValue("ica", "value"));
		setAcqDisclaimer(xlsrdr.getCellValue("acqDisclaimer", "value"));
		setInrDisclaimer(xlsrdr.getCellValue("inrDisclaimer", "value"));
		setPreauthDisclaimer(xlsrdr.getCellValue("preauthDisclaimer", "value"));
		setChannelsAvailableIPG(xlsrdr.getCellValue("channelsAvailableIPG", "value"));
		setChannelsAvailablePCPOS(xlsrdr.getCellValue("channelsAvailablePCPOS", "value"));
		setAcqSchemeMapChannel(xlsrdr.getCellValue("acqSchemeMapChannel", "value"));
		setAcqSchemeMapPayType(xlsrdr.getCellValue("acqSchemeMapPayType", "value"));
		setAcqSchemeMapScheme(xlsrdr.getCellValue("acqSchemeMapScheme", "value"));
		setAcqAuthenticationType(xlsrdr.getCellValue("acqAuthenticationType", "value"));
		setAcqAuthorizationType(xlsrdr.getCellValue("acqAuthorizationType", "value"));
		setSettlementType(xlsrdr.getCellValue("settlementType", "value"));
		setAccessCode(xlsrdr.getCellValue("accessCode", "value"));
		setSecureSecret(xlsrdr.getCellValue("secureSecret", "value"));
		setAuthenticationURL(xlsrdr.getCellValue("authenticationURL", "value"));
		setAuthorizationURL(xlsrdr.getCellValue("authorizationURL", "value"));
				
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Add Acquirer Bank");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToAddAcquirerPage();
			result = addAcquirerBank();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Add Acquirer Bank", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
		if (result){	
			Reporter.SuccessReport("Add Acquirer Bank ","Successful for user: " + UserName);
		} 
		else{
			//Reporter.failureReport("Add ME Profile ", "Add ME profile verification failed for user: "+ UserName);
			Assert.assertTrue(result == false, "Add Acquirer Bank Test Failed");
		}
	}
}
