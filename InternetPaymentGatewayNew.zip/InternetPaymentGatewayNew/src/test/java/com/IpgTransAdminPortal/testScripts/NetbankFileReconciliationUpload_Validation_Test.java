package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgTransAdminPortal.workflows.DisputeManagementPage;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.IpgTransAdminPortal.workflows.NetbankReconUploadPage;
import com.IpgTransAdminPortal.workflows.SettlementFileGenerationPage;
import com.IpgTransAdminPortal.workflows.SettlementFileReconPage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class NetbankFileReconciliationUpload_Validation_Test extends NetbankReconUploadPage{
	
	Logger logger = Logger.getLogger(NetbankReconUploadPage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "netbankFileRecon");
	ExcelReader xls1 = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls1.getCellValue("userid", "value");
	String Password = xls1.getCellValue("password", "value");
	
	@Test(groups= {"smoke", "functional"})
	public void netbankReconciliationUpload_Validation_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		
		//NetbankReconUploadPage nrup = new NetbankReconUploadPage();
		/*
		nrup.setLvId(xls.getCellValue("legalVehicle", "value"));
		nrup.setBankName(xls.getCellValue("netbankName", "value"));
		nrup.setInputFilePath(xls.getCellValue("inputFilePath", "value"));
		*/
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Netbank Reconciliation Upload - Validation");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToNetbankReconUploadPage();
			
			result = netbankReconUploadValidation();
			
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Netbank Reconciliation Upload - Validation", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
		if (result){	
			Reporter.SuccessReport("Netbank Reconciliation Upload - Validation","Successful for user: " + UserName);
		} 
		else{
			Assert.assertTrue(result == false, "Netbank Reconciliation Upload - Validation Failed");
		}
	}
}
