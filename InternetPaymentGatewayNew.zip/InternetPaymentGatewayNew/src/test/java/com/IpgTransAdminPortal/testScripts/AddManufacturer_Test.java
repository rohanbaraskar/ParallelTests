package com.IpgTransAdminPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.IpgTransAdminPortal.workflows.AddManufacturerPage;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.IpgTransAdminPortal.workflows.LoginPage;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;

public class AddManufacturer_Test extends AddManufacturerPage{
	
	Logger logger = Logger.getLogger(AddManufacturerPage.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("TestData"), "AddManufacturer");
	@Test(groups= {"smoke", "functional"})
	public void addManufacturer_Test() throws Throwable 
	{
		url=configProps.getProperty("URL");
		driver.get(url);
		setManufactName(xlsrdr.getCellValue("manufactName", "value"));
		String manufactCode = RandomTextUtils.getRandomNumberInRange(1111, 99999999) +"";
		setManufactCode(manufactCode);
		//setManufactCode(xlsrdr.getCellValue("manufactCode", "value"));
		setProdName(xlsrdr.getCellValue("prodName", "value"));
		setEmiProdCode(xlsrdr.getCellValue("emiProdCode", "value"));
		setItemCode(xlsrdr.getCellValue("itemCode", "value"));
				
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Add Manufacturer");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            LoginPage login = new LoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			HomePage home = new HomePage();
			home.navigateToAddManufacturerPage();
			result = addManufacturer();
			home.logOut();
		
		} catch (Exception e) {
			Reporter.failureReport("Add Manufacturer ", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
		if (result){	
			Reporter.SuccessReport("Add Manufacturer ","Successful for user: " + UserName);
		} 
		else{
			Assert.assertTrue(result == false, "Add Manufacturer Test Failed");
		}
	}
}
