package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;

import com.IpgTransAdminPortal.testObjects.AddFacilitatorPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;

public class AddFacilitatorPage extends ActionEngine {

	public String facilitatorName;
	public String facilitatorCode;
	public String scheme;
	public String assCode;
	public String assFclCode;
	
	static Logger logger = Logger.getLogger(AddFacilitatorPage.class.getName());
	public boolean addFacilitator() throws Throwable {
		HtmlReportSupport.reportStep("Add Facilitator");
		boolean result = false;
		HtmlReportSupport.reportStep("FACILITATOR BASIC DETAILS");
		type(AddFacilitatorPageLocators.facilitatorName_txt, facilitatorName, "Facilitator Name");
		type(AddFacilitatorPageLocators.facilitatorCode_txt, facilitatorCode, "Facilitator Code");
		selectByVisibleText(AddFacilitatorPageLocators.scheme_select, scheme, "Scheme");
		type(AddFacilitatorPageLocators.assCode_txt, assCode, "ASS Code");
		type(AddFacilitatorPageLocators.assFclCode_txt, assFclCode, "ASSFCL Code");
		click(AddFacilitatorPageLocators.add_btn, "Add button");
		Thread.sleep(2000);
		click(AddFacilitatorPageLocators.submit_btn, "Submit button");
		
		//VALIDATION OF NEW FACILITATOR
		HtmlReportSupport.reportStep("VALIDATION of FACILITATOR");
		if(isElementPresent(AddFacilitatorPageLocators.facilitatorSuccessful_mg, "Add Facilitator Successful - Message")){
			result = true;
		}
		return result;
	}
	
	public void setFacilitatorName(String facilitatorName) {
		this.facilitatorName = facilitatorName;
	}
	public void setFacilitatorCode(String facilitatorCode) {
		this.facilitatorCode = facilitatorCode;
	}
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}
	public void setAssCode(String assCode) {
		this.assCode = assCode;
	}
	public void setAssFclCode(String assFclCode) {
		this.assFclCode = assFclCode;
	}
	
}