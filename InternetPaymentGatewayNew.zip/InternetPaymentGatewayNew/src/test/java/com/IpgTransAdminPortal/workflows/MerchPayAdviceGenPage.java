package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.IpgTransAdminPortal.testObjects.MerchantPayAdvicePageLocators;
import com.IpgTransAdminPortal.testObjects.NetbankReconUploadPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class MerchPayAdviceGenPage extends ActionEngine {

	public String lvId;
	public String batchRunId;
	
	static Logger logger = Logger.getLogger(MerchPayAdviceGenPage.class.getName());
	ExcelReader bufferxls = new ExcelReader(configProps.getProperty("TempData"), "buffer");
	
	public boolean merchPayAdviceGeneration() throws Throwable {
		HtmlReportSupport.reportStep("Merchant Payment Advice Generation");
		boolean result = false;
		//boolean successFlag = false;
		selectByVisibleText(MerchantPayAdvicePageLocators.lvId_select, lvId, "Legal Vehicle - Select");
		click(MerchantPayAdvicePageLocators.generate_btn, "Generate button");
		waitForElementPresent(MerchantPayAdvicePageLocators.fileGenSuccessConfirm_msg, "File Generation Successful - Message");
		/*
		Thread.sleep(10000);
		
		while(isElementDisplayed(MerchantPayAdvicePageLocators.fileGenPending_row, "Pending Status")){
			Thread.sleep(10000);
			click(MerchantPayAdvicePageLocators.refresh_btn, "Refresh button");
			Thread.sleep(10000);
			if(isElementDisplayed(MerchantPayAdvicePageLocators.fileGenSuccess_row, "File Generation Success Status")){
				successFlag = true;
			}			
		}
		if (successFlag)
			result = true;
		else if(!successFlag)
			Reporter.failureReport("File Generation", "FAILED");
			*/
		batchRunId = getText(MerchantPayAdvicePageLocators.firstRow_batchRunId, "Batch Run ID");
		result = bufferxls.setCellData("buffer", "merchantPayAdviceGen_batchRunId", 2, batchRunId);
		return result;
	}
	
	public boolean merchPayAdviceGenerationValidation() throws Throwable {
		HtmlReportSupport.reportStep("Merchant Pay Advice Generation Validation");
		boolean result = false;
		
		batchRunId = bufferxls.getCellData("buffer", "merchantPayAdviceGen_batchRunId", 2);
		type(MerchantPayAdvicePageLocators.search_txt, batchRunId, "Search");
		
		if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'Pending')]"), "Batch RUN - PENDING")){
			Reporter.failureReport("Batch Run Status/ME Pay Advice Generation", "PENDING");
		}else if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'In Progress')]"), "Batch RUN - In Progress")){
			Reporter.failureReport("Batch Run Status/ME Pay Advice Generation", "In Progress");
		}else if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'FAILED')]"), "Batch RUN - FAILED")){
			Reporter.failureReport("Batch Run Status/ME Pay Advice Generation", "FAILED");
		}else if(isElementDisplayed(By.xpath("//a[contains(text(), '" + batchRunId + "')]/ancestor::tr//td[contains(text(),'SUCCESS')]"), "Batch RUN - SUCCESS")){
			Reporter.SuccessReport("Batch Run Status/ME Pay Advice Generation", "SUCCESS");
			result = true;
		}
		
		return result;
	}

	public void setLvId(String lvId) {
		this.lvId = lvId;
	}

	public void setBatchRunId(String batchRunId) {
		this.batchRunId = batchRunId;
	}
	
}
