package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.server.handler.interactions.touch.Scroll;

import com.IpgTransAdminPortal.testObjects.HomePageLocators;
import com.IpgTransAdminPortal.testObjects.UserAccountLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
//import com.thoughtworks.selenium.webdriven.commands.Click;

public class UserAccountWorkflows extends ActionEngine{
	public String loginid;
	public String firstname;
	public String lastname;
	public String displayname;
	public String emailid;
	public String mobileno;
	public String landlineno;
	public String streetaddress;
	public String city;
	public String state;
	public String zipcode;
	public String employeeid;
	public String entitytype;
	public String lvname;
	public String remarks;
public static String legalVehicleName;
 public String roleName;
public String roleDescription;
public String oldPwd;
public String newPwd;
public String confirmNewPwd;

ExcelReader bufferxls = new ExcelReader(configProps.getProperty("TempData"), "buffer");
	static Logger logger = Logger.getLogger(UserAccountWorkflows.class.getName());
	public boolean createNewUser() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Create New User from User Account");
		waitForElementPresent(UserAccountLocators.userAccount_menu, "User Account Menu");
		click(UserAccountLocators.userAccount_menu, "User Account Menu");
		waitForElementPresent(UserAccountLocators.user_menu, "User Menu");
		click(UserAccountLocators.user_menu, "User Menu");
		waitForElementPresent(UserAccountLocators.addUser_btn, "Add User");
		click(UserAccountLocators.addUser_btn, "Add User");
		HtmlReportSupport.reportStep("Navigate to User Registration Page");
		waitForElementPresent(UserAccountLocators.userRegistration_Text, "User Registration Text");
		verifyText(UserAccountLocators.userRegistration_Text, "User Registration", "User Registration Text");	
		type(UserAccountLocators.loginId_txt, loginid, "Login ID");
		type(UserAccountLocators.firstName_txt, firstname, "First Name");
		type(UserAccountLocators.lastName_txt, lastname, "Last Name");
		type(UserAccountLocators.displayName_txt, displayname, "Display Name");
		type(UserAccountLocators.emailId_txt, emailid, "Email ID");
		
		if((mobileno!=null)&&(mobileno!="")){
		    type(UserAccountLocators.mobileNo_txt, mobileno, "Mobile No");
		if((landlineno!=null)&&(landlineno!=""))
			type(UserAccountLocators.landlineNo_txt, landlineno, "Landline No");
		if((streetaddress!=null)&&(streetaddress!=""))
			type(UserAccountLocators.streetAddress_txt, streetaddress, "Street Address");
		if((city!=null)&&(city!=""))
			type(UserAccountLocators.city_txt, city, "City");
		if((state!=null)&&(state!=""))
			type(UserAccountLocators.state_txt, state, "State");
		if((zipcode!=null)&&(zipcode!=""))
			type(UserAccountLocators.zipCode_txt, zipcode, "Zip Code");
		if((employeeid!=null)&&(employeeid!=""))
			type(UserAccountLocators.employeeId_txt, employeeid, "Employee ID");
		}
		click(UserAccountLocators.entityType_select, "Entity Type");
		selectByVisibleText(UserAccountLocators.entityType_select, entitytype, "Entity Type");
		if((lvname!=null)&&(lvname!="")){
			waitForElementPresent(UserAccountLocators.worldline_Text, "Legal Vehicle Name");
			legalVehicleName=getText(UserAccountLocators.worldline_Text, "Legal Vehicle Name");
			if(lvname.equals(legalVehicleName))
			click(UserAccountLocators.worldline_btn, "Legal Vehicle Worldline");
			verifyText(UserAccountLocators.worldline_Text, legalVehicleName, "Legal Vehicle Name Worldline");
			Reporter.SuccessReport("LegalVehicleName Verification "," Sucessfully Verified LegalVehicleName " + legalVehicleName);
		}else{
			Reporter.SuccessReport("LegalVehicleName Verification "," Not able to Verified LegalVehicleName " + legalVehicleName);	
		}
		  waitForElementPresent(UserAccountLocators.submit_btn,"Submit Button");
	      click(UserAccountLocators.submit_btn,"Submit Button");
	      waitForElementPresent(UserAccountLocators.approvalMessage_Text, "User is sent for approval Message");
	      verifyText(UserAccountLocators.approvalMessage_Text,"User is sent for approval.", "User is sent for approval Message");
	      result=result = bufferxls.setCellData("buffer", "loginid", 2, loginid);//Writing the Merchant ID to TempData.xls file
	      result = true;
			return result;
	}
	
	public boolean approveUser() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Approve New User from User Account");
		waitForElementPresent(UserAccountLocators.userAccount_menu, "User Account Menu");
		click(UserAccountLocators.userAccount_menu, "User Account Menu");
		waitForElementPresent(UserAccountLocators.user_menu, "User Menu");
		click(UserAccountLocators.user_menu, "User Menu");
		HtmlReportSupport.reportStep("Navigate to Approve Page for User");
		waitForElementPresent(UserAccountLocators.approve_btn, "Approve Button");
		click(UserAccountLocators.approve_btn, "Approve Button");
		loginid=bufferxls.getCellData("buffer", "loginid", 2);
		System.out.println("loginid "+loginid);
		waitForElementPresent(UserAccountLocators.search_txt, "Search box");
		type(UserAccountLocators.search_txt, loginid, "Search");
		
		String actloginid=getText(UserAccountLocators.approveLoginId, "Approve Login ID");
		
		if(loginid.toLowerCase().contains(actloginid)){
			Reporter.SuccessReport("Login ID Verification"," Sucessfully Verify for Approve User Login ID" + actloginid);
			click(UserAccountLocators.view_lnk, "View Link");
			//click, "View Link");
		}else{
			Reporter.failureReport("Login ID Verification"," Not able to Verify for Approve User Login ID" + actloginid);
		}
		waitForElementPresent(UserAccountLocators.approveORReject_select, "Approve/Reject Dropdown");
	    selectByVisibleText(UserAccountLocators.approveORReject_select, "Approve", "Approve/Reject Dropdown");
		type(UserAccountLocators.remarks_txt,remarks, "Remarks");
		click(UserAccountLocators.approveSubmit_btn, "Submit Button");
		waitForElementPresent(UserAccountLocators.approvedMessage_Text, "Approved Message Text");
		verifyText(UserAccountLocators.approvedMessage_Text, "User has been successfully approved.", "Approved Message Text");
		
		//result = bufferxls.setCellData("buffer", "loginid", 2, loginid);	//Writing the Merchant ID to TempData.xls file
		result = true;
		return result;
	}
	
	
	public boolean editActivatedUser() throws Throwable{
		
		boolean result = false;
		HtmlReportSupport.reportStep("Edit Activated User from User Account");
		waitForElementPresent(UserAccountLocators.userAccount_menu, "User Account Menu");
		click(UserAccountLocators.userAccount_menu, "User Account Menu");
		waitForElementPresent(UserAccountLocators.user_menu, "User Menu");
		click(UserAccountLocators.user_menu, "User Menu");
		String editActivatedloginid=getText(UserAccountLocators.approvedLoginId, "Approved Login ID");
		loginid=bufferxls.getCellData("buffer", "loginid", 2);
		System.out.println("loginid "+loginid);
		waitForElementPresent(UserAccountLocators.search_txt, "Search box");
		type(UserAccountLocators.search_txt, loginid, "Search");
		
		HtmlReportSupport.reportStep("Navigate to Edit Activated User Page");
		
		if(loginid.toLowerCase().contains(editActivatedloginid)){
			Reporter.SuccessReport("Login ID Verification"," Sucessfully Verify for Approved User Login ID" + editActivatedloginid);
			click(UserAccountLocators.view_lnk, "View Link");
		}else{
			Reporter.failureReport("Login ID Verification"," Not able to Verify for Approved User Login ID" + editActivatedloginid);
		}
		waitForElementVisibility(UserAccountLocators.accountStatus_Text, "Account Status");
	verifyText(UserAccountLocators.accountStatus_Text, "Active", "Account Status");
	click(UserAccountLocators.editUser_btn, "Edit User Button");
	type(UserAccountLocators.firstName_txt, firstname, "First Name");
	type(UserAccountLocators.lastName_txt, lastname, "Last Name");
	type(UserAccountLocators.displayName_txt, displayname, "Display Name");
	type(UserAccountLocators.emailId_txt, emailid, "Email ID");
	
	if((mobileno!=null)&&(mobileno!="")){
	    type(UserAccountLocators.mobileNo_txt, mobileno, "Mobile No");
	if((landlineno!=null)&&(landlineno!=""))
		type(UserAccountLocators.landlineNo_txt, landlineno, "Landline No");
	if((streetaddress!=null)&&(streetaddress!=""))
		type(UserAccountLocators.streetAddress_txt, streetaddress, "Street Address");
	if((city!=null)&&(city!=""))
		type(UserAccountLocators.city_txt, city, "City");
	if((state!=null)&&(state!=""))
		type(UserAccountLocators.state_txt, state, "State");
	if((zipcode!=null)&&(zipcode!=""))
		type(UserAccountLocators.zipCode_txt, zipcode, "Zip Code");
	if((employeeid!=null)&&(employeeid!=""))
		type(UserAccountLocators.employeeId_txt, employeeid, "Employee ID");
	}
	//click(UserAccountLocators.entityType_select, "Entity Type");
	selectByVisibleText(UserAccountLocators.entityType_select, entitytype, "Entity Type");
	click(UserAccountLocators.update_btn, "Update Button");
	waitForElementVisibility(UserAccountLocators.updatedMsg_Text, "Updated Successful Message");
	verifyText(UserAccountLocators.updatedMsg_Text,"User has been successfully updated.", "Updated Successful Message");
	

	result = true;
	return result;
	
	}
	
	public boolean resetPassword() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Reset Password from User Account");
		waitForElementPresent(UserAccountLocators.userAccount_menu, "User Account Menu");
		click(UserAccountLocators.userAccount_menu, "User Account Menu");
		waitForElementPresent(UserAccountLocators.user_menu, "User Menu");
		click(UserAccountLocators.user_menu, "User Menu");
		String editActivatedloginid=getText(UserAccountLocators.approvedLoginId, "Approved Login ID");
		System.out.println("loginid "+loginid);
		HtmlReportSupport.reportStep("Navigate to Reset Password Page");
		if(loginid.toLowerCase().contains(editActivatedloginid)){
			Reporter.SuccessReport("Login ID Verification"," Sucessfully Verify for Approved User Login ID" + editActivatedloginid);
			click(UserAccountLocators.view_lnk, "View Link");
		}else{
			Reporter.failureReport("Login ID Verification"," Not able to Verify for Approved User Login ID" + editActivatedloginid);
		}
		waitForElementVisibility(UserAccountLocators.accountStatus_Text, "Account Status");
	verifyText(UserAccountLocators.accountStatus_Text, "Active", "Account Status");
	click(UserAccountLocators.resetPassword_btn, "Reset Password");
	waitForElementVisibility(UserAccountLocators.resetPasswordMsg_Text, "Reset Password Message");
	verifyText(UserAccountLocators.resetPasswordMsg_Text, "Password is reset for user.", "Reset Password Message");
	result = true;
	return result;
	}
	
	public boolean deactivateUser() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Deactivate User from User Account");
		waitForElementPresent(UserAccountLocators.userAccount_menu, "User Account Menu");
		click(UserAccountLocators.userAccount_menu, "User Account Menu");
		waitForElementPresent(UserAccountLocators.user_menu, "User Menu");
		click(UserAccountLocators.user_menu, "User Menu");
		waitForElementPresent(UserAccountLocators.search_txt, "Search box");
		type(UserAccountLocators.search_txt, loginid, "Search");
		String editActivatedloginid=getText(UserAccountLocators.approvedLoginId, "Approved Login ID");
		System.out.println("loginid "+loginid);		
		HtmlReportSupport.reportStep("Navigate to Deactivate User Page");
		if(loginid.toLowerCase().contains(editActivatedloginid)){
			Reporter.SuccessReport("Login ID Verification"," Sucessfully Verify for Approved User Login ID" + editActivatedloginid);
			click(UserAccountLocators.view_lnk, "View Link");
		}else{
			Reporter.failureReport("Login ID Verification"," Not able to Verify for Approved User Login ID" + editActivatedloginid);
		}
		waitForElementVisibility(UserAccountLocators.accountStatus_Text, "Account Status");
	verifyText(UserAccountLocators.accountStatus_Text, "Active", "Account Status");
	click(UserAccountLocators.deactivateUser_btn, "Deactivate User");
	waitForElementVisibility(UserAccountLocators.deactivateUserMsg_Text, "Deactivate Message");
	verifyText(UserAccountLocators.deactivateUserMsg_Text,"User account deactivation request sent for approval.", "Deactivate Message");
	result = true;
	return result;
	
	}
	
	public boolean createRole() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Create a Role from User Account");
		waitForElementPresent(UserAccountLocators.userAccount_menu, "User Account Menu");
		click(UserAccountLocators.userAccount_menu, "User Account Menu");
		waitForElementVisibility(UserAccountLocators.role_menu, "Role Menu");
		click(UserAccountLocators.role_menu, "Role Menu");
		waitForElementVisibility(UserAccountLocators.addRole_btn, "Add Role Button");
		click(UserAccountLocators.addRole_btn, "Add Role Button");
		waitForElementVisibility(UserAccountLocators.roleName_txt, "Role Name");
		type(UserAccountLocators.roleName_txt,roleName,"Role Name");
		type(UserAccountLocators.roleDescription_txt,roleDescription,"Role Description");
		click(UserAccountLocators.submit_btn, "Submit Button");
		waitForElementVisibility(UserAccountLocators.roleMsg_Text, "Successful Role Message");
		verifyText(UserAccountLocators.roleMsg_Text, "Request sent for approval.", "Successful Role Message");
		result = true;
		return result;
		
	}
	
	public boolean approveRole() throws Throwable{
		boolean result = false;
		waitForElementPresent(UserAccountLocators.userAccount_menu, "User Account Menu");
		click(UserAccountLocators.userAccount_menu, "User Account Menu");
		waitForElementVisibility(UserAccountLocators.role_menu, "Role Menu");
		click(UserAccountLocators.role_menu, "Role Menu");
		HtmlReportSupport.reportStep("Navigate to Approve Page for Role");
		waitForElementPresent(UserAccountLocators.roleApprove_btn, "Approve Button for Role");
		click(UserAccountLocators.roleApprove_btn, "Approve Button for Role");
		String actRoleName=getText(UserAccountLocators.roleName_column, "Role Name");
		if(roleName.contains(actRoleName)){
			Reporter.SuccessReport("Created Role Name Verification"," Sucessfully Verify for Created Role Name " + actRoleName);
			click(UserAccountLocators.view_lnk, "View Link");
		}else{
			Reporter.failureReport("Created Role Name Verification"," Not able to Verify for Created Role Name " + actRoleName);
		}
		waitForElementPresent(UserAccountLocators.approveORReject_select, "Approve/Reject Dropdown");
	    selectByVisibleText(UserAccountLocators.approveORReject_select, "Approve", "Approve/Reject Dropdown");
		type(UserAccountLocators.remarks_txt,remarks, "Remarks");
		click(UserAccountLocators.approveRole_btn, "Submit Button for Role");
		waitForElementPresent(UserAccountLocators.sucessRoleMsg_Text, "Role Approved Message");
		verifyText(UserAccountLocators.sucessRoleMsg_Text, "Role approved successfully.", "Role Approved Message");
		
		result = true;
		return result;
		
	}
	
	public boolean userToRoleMap() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("User To Role Map from User Account");
		waitForElementPresent(UserAccountLocators.userAccount_menu, "User Account Menu");
		click(UserAccountLocators.userAccount_menu, "User Account Menu");
		waitForElementPresent(UserAccountLocators.user_menu, "User Menu");
		click(UserAccountLocators.user_menu, "User Menu");
		waitForElementVisibility(UserAccountLocators.approvedLoginId, "Approve Login Id");
		String actLoginId=getText(UserAccountLocators.approvedLoginId, "Approve Login Id");
		loginid=bufferxls.getCellData("buffer", "loginid", 2);
		System.out.println("loginid "+loginid);
		
		if(loginid.toLowerCase().contains(actLoginId)){
			Reporter.SuccessReport("Login ID Verification"," Sucessfully Verify for Approved User Login ID " + actLoginId);
		    click(UserAccountLocators.view_lnk, "View Link");
	}else{
		Reporter.failureReport("Login ID Verification"," Not able to Verify for Approved User Login ID " + actLoginId);
	
	}
		waitForElementVisibility(UserAccountLocators.userToRoleMap_btn, "User to Role Map Button");
		click(UserAccountLocators.userToRoleMap_btn, "User to Role Map Button");
		waitForElementPresent(UserAccountLocators.userToRoleMap_Text, "User To Role MaP");
		verifyText(UserAccountLocators.userToRoleMap_Text,"User To Role Mapping", "User To Role MaP");
		
		//verifyAndClickTableData(UserAccountLocators.roleNameTable, roleName, UserAccountLocators.roleAdd_btns, UserAccountLocators.roleNameTables);
		// ELEMRNT IS PRESENT IN TABLE 
		click(By.xpath("//td[contains(text(),'"+roleName+"')]/following-sibling::td/i"), "Role Name");
		
		waitForElementVisibility(UserAccountLocators.selectedRoleName, "Selected Role Name");
		verifyText(UserAccountLocators.selectedRoleName, roleName, "Selected Role Name");
		click(UserAccountLocators.roleMapSubmit_btn, "Submit Button for Role Map");
		waitForElementPresent(UserAccountLocators.roleMapMsg_Text, "Success Message for Role Map");
		verifyText(UserAccountLocators.roleMapMsg_Text, "Request submitted for approval.","Success Message for Role Map");
		result = true;
		return result;
	}                        
	
	public boolean changePassword() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Change Password from Transactions Admin Portal");
		waitForElementPresent(HomePageLocators.loggedInAs_lnk, "LoggedIn As Lnk");
		click(HomePageLocators.loggedInAs_lnk, "LoggedIn As Lnk");
		click(UserAccountLocators.changePassword, "Change Password");
		HtmlReportSupport.reportStep("Navigate to Change Password Page");
		waitForElementVisibility(UserAccountLocators.changePassword_Text, "Change Password Text");
		verifyText(UserAccountLocators.changePassword_Text, "Change Password", "Change Password Text");
		type(UserAccountLocators.oldPassword_txt, oldPwd, "Old Password");
		type(UserAccountLocators.newPassword_txt, newPwd, "New Password");
		type(UserAccountLocators.confirmNewPassword_txt, confirmNewPwd, "Confirm New Password");		
		
		result = true;
		return result;
	}
	public void setLoginId(String loginid) {
		this.loginid = loginid;
	}
	public void setFirstName(String firstname) {
		this.firstname = firstname;
	}
	public void setLastName(String lastname) {
		this.lastname = lastname;
	}
	public void setDisplayName(String displayname) {
		this.displayname = displayname;
	}
	public void setEmailId(String emailid) {
		this.emailid = emailid;
	}
	public void setMobileNo(String mobileno) {
		this.mobileno = mobileno;
	}
	public void setLandlineNo(String landlineno) {
		this.landlineno = landlineno;
	}
	public void setStreetAddress(String streetaddress) {
		this.streetaddress = streetaddress;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setZipCode(String zipcode) {
		this.zipcode = zipcode;
	}
	public void setEmployeeId(String employeeid) {
		this.employeeid = employeeid;
	}
	public void setEntityType(String entitytype) {
		this.entitytype = entitytype;
	}	
	public void setLvName(String lvname) {
		this.lvname = lvname;
	}
	public void setRemarks(String remarks){
		this.remarks=remarks;
	}
public void setRoleName(String roleName){
	this.roleName=roleName;
}
public void setRoleDescription(String roleDescription){
	this.roleDescription=roleDescription;
}
public void setOldPwd(String oldPwd){
	this.oldPwd=oldPwd;
}
public void setNewPwd(String newPwd){
	this.newPwd=newPwd;
}
public void setConfrmNewPwd(String confirmNewPwd){
	this.confirmNewPwd=confirmNewPwd;
}
}
