package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.IpgTransAdminPortal.testObjects.AddSchemePageLocators;
import com.IpgTransAdminPortal.testObjects.HomePageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;

public class AddSchemePage extends ActionEngine {

	public String schemeName;
	public String schemeCode;
	public String schemeTypeCC;
	public String schemeTypeDC;
	public String schemeTypeCUG;
	public String schemeTypeLoyaltyCard;
	public String ccSaleWithCashbackLimit;
	public String dcSaleWithCashbackLimit;
	public String dccDisclaimer;
	
	static Logger logger = Logger.getLogger(AddSchemePage.class.getName());
	public boolean addScheme() throws Throwable {
		HtmlReportSupport.reportStep("Add Scheme");
		boolean result = false;
		
		type(AddSchemePageLocators.schemeName, schemeName, "Scheme Name");
		type(AddSchemePageLocators.schemeCode, schemeCode, "Scheme Code");
		if(schemeTypeCC.equalsIgnoreCase("Y"))
			click(AddSchemePageLocators.schemeTypeCC_chk, "Scheme Type - Credit Card");
		if(schemeTypeDC.equalsIgnoreCase("Y"))
			click(AddSchemePageLocators.schemeTypeDC_chk, "Scheme Type - Debit Card");
		if(schemeTypeCUG.equalsIgnoreCase("Y"))
			click(AddSchemePageLocators.schemeTypeCUG_chk, "Scheme Type - CUG/CASH Card");
		if(schemeTypeLoyaltyCard.equalsIgnoreCase("Y"))
			click(AddSchemePageLocators.schemeTypeLoyaltyC_chk, "Scheme Type - Loyalty Card");
		type(AddSchemePageLocators.ccSaleWithCashbackLimit, ccSaleWithCashbackLimit, "Sale with CashBack Limit (Credit Card)");
		type(AddSchemePageLocators.dcSaleWithCashbackLimit, dcSaleWithCashbackLimit, "Sale with CashBack Limit (Debit Card)");
		type(AddSchemePageLocators.dccDisclaimer, dccDisclaimer, "DCC Disclaimer");
		click(AddSchemePageLocators.submit_btn, "Submit Button");
		//VALIDATION OF SCHEME
		HtmlReportSupport.reportStep("VALIDATION of Scheme");
		if(isElementPresent(AddSchemePageLocators.schemeSuccessMessage, "Scheme Added Successfully")){
			result = true;
		}
		return result;
	}	
	
	public boolean approveScheme(String schemeName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View Scheme Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.scheme_mnu, "Scheme SubMenu");
		waitForElementPresent(AddSchemePageLocators.approval_tab, "Approval Tab");
		click(AddSchemePageLocators.approval_tab, "Approval Tab");
		waitForElementPresent(HomePageLocators.search_txt, "Search Scheme box");
		type(HomePageLocators.search_txt, schemeName, "Scheme Search box");
		waitForElementPresent(AddSchemePageLocators.viewScheme_lnk, "View Scheme Link");
		click(AddSchemePageLocators.viewScheme_lnk, "View Scheme Link");
		HtmlReportSupport.reportStep("Scheme Approval");
		waitForElementPresent(AddSchemePageLocators.schemeInformation, "Scheme Information Page");
		waitForElementPresent(By.xpath("//td[contains(text(),'"+ schemeName +"')]"), "SchemeName: " + schemeName);
		waitForElementPresent(HomePageLocators.appReject_select, "Approve/Reject Select");
		selectByContainsVisibleText(HomePageLocators.appReject_select, "Approve", "Approve/Reject Select");
		type(HomePageLocators.remarks_txtarea, "Test Scheme Approval Remarks", "Approval Remarks");
		click(AddSchemePageLocators.approval_submit_btn, "Submit Button");
		waitForElementPresent(AddSchemePageLocators.approveSchemeSuccess_mg, "Scheme Approval Success Message");
		result = true;
		return result;
	}
	
	public boolean deactivateScheme(String schemeName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View Scheme Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.scheme_mnu, "Scheme SubMenu");
		waitForElementPresent(HomePageLocators.search_txt, "Search Scheme box");
		type(HomePageLocators.search_txt, schemeName, "Scheme Search box");
		waitForElementPresent(AddSchemePageLocators.viewScheme_lnk, "View Scheme Link");
		click(AddSchemePageLocators.viewScheme_lnk, "View Scheme Link");
		HtmlReportSupport.reportStep("Deactivate Scheme");
		waitForElementPresent(AddSchemePageLocators.schemeInformation, "Scheme Information Page");
		waitForElementPresent(By.xpath("//td[contains(text(),'"+ schemeName +"')]"), "SchemeName: " + schemeName);		
		waitForElementPresent(AddSchemePageLocators.deactivateScheme_btn, "Deactivate Scheme button");
		click(AddSchemePageLocators.deactivateScheme_btn, "Deactivate Scheme button");
		waitForElementPresent(AddSchemePageLocators.approveSchemeSuccess_mg, "Scheme Deactivation Success Message");
		result = true;
		return result;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public void setSchemeCode(String schemeCode) {
		this.schemeCode = schemeCode;
	}
	public void setSchemeTypeCC(String schemeTypeCC) {
		this.schemeTypeCC = schemeTypeCC;
	}
	public void setSchemeTypeDC(String schemeTypeDC) {
		this.schemeTypeDC = schemeTypeDC;
	}
	public void setSchemeTypeCUG(String schemeTypeCUG) {
		this.schemeTypeCUG = schemeTypeCUG;
	}
	public void setSchemeTypeLoyaltyCard(String schemeTypeLoyaltyCard) {
		this.schemeTypeLoyaltyCard = schemeTypeLoyaltyCard;
	}
	public void setCcSaleWithCashbackLimit(String ccSaleWithCashbackLimit) {
		this.ccSaleWithCashbackLimit = ccSaleWithCashbackLimit;
	}
	public void setDcSaleWithCashbackLimit(String dcSaleWithCashbackLimit) {
		this.dcSaleWithCashbackLimit = dcSaleWithCashbackLimit;
	}
	public void setDccDisclaimer(String dccDisclaimer) {
		this.dccDisclaimer = dccDisclaimer;
	}
	
}