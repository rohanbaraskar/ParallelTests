package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.IpgTransAdminPortal.testObjects.AddFacilitatorPageLocators;
import com.IpgTransAdminPortal.testObjects.DisputeManagementPageLocators;
import com.IpgTransAdminPortal.testObjects.NetbankCancelDownloadPageLocators;
import com.IpgTransAdminPortal.testObjects.NetbankReconUploadPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementFileGenPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementFileReconPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementMarkingPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class SettlementMarkingPage extends ActionEngine {

	public String legalMerchantName;
	public String dateFrom;
	public String dateTo;
	public String transRefNo;
	public String filter;
	
	static Logger logger = Logger.getLogger(SettlementMarkingPage.class.getName());
	
	public boolean settlementMarking() throws Throwable {
		HtmlReportSupport.reportStep("Settlement Marking");
		boolean result = false;
		
		type(SettlementMarkingPageLocators.legalMerchantName, legalMerchantName, "Legal Merchant Name");
		js_type(SettlementMarkingPageLocators.dateFrom, dateFrom, "Date From");
		if((dateTo != null)&&(dateTo != "")){
			js_type(SettlementMarkingPageLocators.dateTo, dateTo, "Date To");
		}else{
				click(SettlementMarkingPageLocators.dateTo, "Date To");
				hitKey(SettlementMarkingPageLocators.dateTo, Keys.ENTER, "Date To");
		}
		Thread.sleep(2000);
		click(SettlementMarkingPageLocators.search_btn, "Search button");
		waitForElementPresent(SettlementMarkingPageLocators.select_chkbox, "select checkbox");
		click(SettlementMarkingPageLocators.select_chkbox, "select checkbox");
		click(SettlementMarkingPageLocators.submit_btn, "Submit button");
		waitForElementPresent(SettlementMarkingPageLocators.confirm_btn, "Confirm button");
		click(SettlementMarkingPageLocators.confirm_btn, "Confirm button");
		waitForElementPresent(SettlementMarkingPageLocators.settleReqSubmitSuccess_msg, "Settlement Request Submit Success");
		
		result = true;
		return result;
	}
	
	public boolean cancelMarking() throws Throwable{
		HtmlReportSupport.reportStep("Cancel/Refund Marking");
		boolean result = false;
		
		type(SettlementMarkingPageLocators.legalMerchantName, legalMerchantName, "Legal Merchant Name");
		selectByVisibleText(SettlementMarkingPageLocators.filter_select, filter, "Filter select");
		
		js_type(SettlementMarkingPageLocators.dateFrom2, dateFrom, "Date From");
		if((dateTo != null)&&(dateTo != ""))
			js_type(SettlementMarkingPageLocators.dateTo2, dateTo, "Date To");
		else{
			click(SettlementMarkingPageLocators.dateTo2, "Date To");
			hitKey(SettlementMarkingPageLocators.dateTo2, Keys.ENTER, "Date To");
		}
		Thread.sleep(2000);
		click(SettlementMarkingPageLocators.searchBtn, "Search button");
		waitForElementPresent(SettlementMarkingPageLocators.select_chkbox, "select checkbox");
		click(SettlementMarkingPageLocators.select_chkbox, "select checkbox");
		click(SettlementMarkingPageLocators.submit_btn, "Submit button");
		waitForElementPresent(SettlementMarkingPageLocators.cancelMarking_confirmBtn, "Confirm button");
		click(SettlementMarkingPageLocators.cancelMarking_confirmBtn, "Confirm button");
		waitForElementPresent(SettlementMarkingPageLocators.cancelMarking_SuccessMsg, "Cancel Settlement Marking Request Submit Success");
		
		result = true;
		return result;
	}

	public void setLegalMerchantName(String legalMerchantName) {
		this.legalMerchantName = legalMerchantName;
	}

	public void setDateFrom(String dateFrom) {
		this.dateFrom = dateFrom;
	}

	public void setTransRefNo(String transRefNo) {
		this.transRefNo = transRefNo;
	}

	public void setFilter(String filter) {
		this.filter = filter;
	}

	public void setDateTo(String dateTo) {
		this.dateTo = dateTo;
	}

	
}
