package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.IpgTransAdminPortal.testObjects.AddAcquirerPageLocators;
import com.IpgTransAdminPortal.testObjects.AddEmiProgramPageLocators;
import com.IpgTransAdminPortal.testObjects.AddFacilitatorPageLocators;
import com.IpgTransAdminPortal.testObjects.AddLedgerAccountPageLocators;
import com.IpgTransAdminPortal.testObjects.AddLegalVehiclePageLocators;
import com.IpgTransAdminPortal.testObjects.AddManufacturerPageLocators;
import com.IpgTransAdminPortal.testObjects.AddSchemePageLocators;
import com.IpgTransAdminPortal.testObjects.AddStorePageLocators;
import com.IpgTransAdminPortal.testObjects.AddTaxPageLocators;
import com.IpgTransAdminPortal.testObjects.HomePageLocators;
import com.IpgTransAdminPortal.testObjects.LoginLocators;
import com.IpgTransAdminPortal.testObjects.MerchantPayAdvicePageLocators;
import com.IpgTransAdminPortal.testObjects.NetbankCancelDownloadPageLocators;
import com.IpgTransAdminPortal.testObjects.NetbankReconUploadPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementFileGenPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementFileReconPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementMarkingPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementRefundCancelUploadPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;

public class HomePage extends ActionEngine{
	
	static Logger logger = Logger.getLogger(HomePage.class.getName());
	
	/**
	 * Sign in to Transaction Admin Portal
	 * @return
	 * @throws Throwable
	 */
	public boolean logOut() throws Throwable{
		boolean result = false;
		ImplicitWait();		
		HtmlReportSupport.reportStep("Logout");
		Thread.sleep(3000);
		//if(waitForElementPresent(HomePageLocators.loggedInAs_lnk, "Logout button"))
		if(isElementDisplayed(HomePageLocators.loggedInAs_lnk, "Logout button"))
		{
			click(HomePageLocators.loggedInAs_lnk, "Logged As Link");
			click(HomePageLocators.logout_lnk, "Logout Link");
			waitForElementPresent(LoginLocators.userId_txt, "Logout Successful");
			result = true;
		}
		return result;
	}	
	
	public boolean navigateToAddStorePage() throws Throwable{
		try{
		HtmlReportSupport.reportStep("Navigate to Add Store Page");
		click(HomePageLocators.merchManagement_mnu,"Merchant Management Menu");
		click(HomePageLocators.merchOnboarding_mnu, "Merchant Onboarding SubMenu");
		click(HomePageLocators.addStore_btn, "Add Store button");
		waitForElementPresent(AddStorePageLocators.sourcingChannel_select, "Add Store Page");
		}
		catch(Exception e){
			
		}
		return true;
	}
	//ADD SCHEME
	public boolean navigateToSchemeRegistrationPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Scheme Registration Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.scheme_mnu, "Scheme SubMenu");
		click(HomePageLocators.addScheme_btn, "Add Scheme button");
		waitForElementPresent(AddSchemePageLocators.schemeName, "Add Scheme/Scheme Registration Page");
		return true;
	}
	
	//ADD LEGAL VEHICLE
	public boolean navigateToAddLegalVehiclePage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Add Legal Vehicle Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.legalVehicle_mnu, "Legal Vehicle SubMenu");
		click(HomePageLocators.addLegalVehicle_btn, "Add Legal Vehicle button");
		waitForElementPresent(AddLegalVehiclePageLocators.legalVehicleName_txt, "Add Legal Vehicle Page");
		return true;
	}
	
	//ADD ACQUIRER
	public boolean navigateToAddAcquirerPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Add Acquirer Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.acquirerBank_mnu, "Add Acquirer SubMenu");
		click(HomePageLocators.addacquirer_btn, "Add Acquirer button");
		waitForElementPresent(AddAcquirerPageLocators.legalVehicleName_select, "Add Acquirer Page");
		return true;
	}
	
	//EMI PROGRAM
	public boolean navigateToAddEmiProgram() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Add EMI Program Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.emiProgram_mnu, "EMI Program SubMenu");
		click(HomePageLocators.addEmi_btn, "Add EMI button");
		waitForElementPresent(AddEmiProgramPageLocators.lvName_select, "Add EMI Program Page");
		return true;
	}
	
	//ADD MANUFACTURER
	public boolean navigateToAddManufacturerPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Add Manufacturer Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.manufacturer_mnu, "Manufacturer SubMenu");
		click(HomePageLocators.addManufacturer_btn, "Add Manufacturer button");
		waitForElementPresent(AddManufacturerPageLocators.manufactName_txt, "Add Manufacturer Page");
		return true;
	}
	
	//ADD FACILITATOR
	public boolean navigateToAddFacilitatorPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Add Facilitator Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.facilitator_mnu, "Facilitator SubMenu");
		click(HomePageLocators.addFacilitator_btn, "Add Facilitator button");
		waitForElementPresent(AddFacilitatorPageLocators.facilitatorName_txt, "Add Facilitator Page");
		return true;
	}
	
	//ADD TAX
	public boolean navigateToAddTaxPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Add Tax Page");
		click(HomePageLocators.finance_mnu,"Finance Menu");
		click(HomePageLocators.tax_submnu, "Tax SubMenu");
		click(HomePageLocators.addTax_btn, "Add Tax button");
		waitForElementPresent(AddTaxPageLocators.lv_select, "Add Tax Page");
		return true;
	}
	
	//ADD LEDGER ACCOUNT
	public boolean navigateToAddLedgerAccountPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Add Ledger Account Page");
		click(HomePageLocators.finance_mnu,"Finance Menu");
		click(HomePageLocators.ledgerAccount_submnu, "Ledger Account SubMenu");
		click(HomePageLocators.addLedgerAccount_btn, "Add Ledger Account button");
		waitForElementPresent(AddLedgerAccountPageLocators.lvName_select, "Add Ledger Account Page");
		return true;
	}
	
	//VIEW SCHEME
	public boolean viewScheme(String schemeName) throws Throwable{
		HtmlReportSupport.reportStep("Navigate to View Scheme Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.scheme_mnu, "Scheme SubMenu");
		waitForElementPresent(HomePageLocators.search_txt, "Search Scheme box");
		type(HomePageLocators.search_txt, schemeName, "Scheme Search box");
		waitForElementPresent(HomePageLocators.viewScheme_lnk, "View Scheme Link");
		click(HomePageLocators.viewScheme_lnk, "View Scheme Link");
		waitForElementPresent(AddSchemePageLocators.schemeInformation, "Scheme Information Page");
		waitForElementPresent(AddSchemePageLocators.editScheme_btn, "Edit Scheme Button");
		click(AddSchemePageLocators.editScheme_btn, "Edit Scheme Button");
		waitForElementPresent(AddSchemePageLocators.schemeRegistration, "Edit Scheme/Scheme Registration Page");
		waitForElementPresent(By.xpath("//input[contains(@value,'"+ schemeName +"')]"), "SchemeName: " + schemeName);
		/*
		waitForElementPresent(AddSchemePageLocators.schemeCode, "Scheme Code");
		waitForElementPresent(AddSchemePageLocators.ccSaleWithCashbackLimit, "Credit Card CashBack Limit");
		waitForElementPresent(AddSchemePageLocators.dcSaleWithCashbackLimit, "Debit Card CashBack Limit");
		waitForElementPresent(AddSchemePageLocators.submit_btn, "Submit Button");
		*/
		return true;
	}

	//VIEW ACQUIRER
	public boolean viewAcquirer(String acquirerBankName) throws Throwable{
		HtmlReportSupport.reportStep("Edit Acquiring Bank Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.acquirerBank_mnu, "Acquirer SubMenu");
		waitForElementPresent(HomePageLocators.search_txt, "Search Scheme box");
		type(HomePageLocators.search_txt, acquirerBankName, "Acquirer Search box");
		waitForElementPresent(HomePageLocators.editAcquirer_lnk, "Edit Acquirer Link");
		click(HomePageLocators.editAcquirer_lnk, "Edit Acquirer Link");
		waitForElementPresent(AddAcquirerPageLocators.acqBankName_txt, "Acquiring Bank Basic Details Page");
		waitForElementPresent(By.xpath("//input[contains(@value,'"+ acquirerBankName +"')]"), "Acquirer Bank Name: " + acquirerBankName);
		//waitForElementPresent(AddAcquirerPageLocators.submit_btn, "Submit Button");
			
		return true;
	}	
	
	//ACQUIRER INFORMATION
	public boolean navigateToAcquirerInfo(String acquirerBankName) throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Acquiring Bank Information Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.acquirerBank_mnu, "Acquirer SubMenu");
		waitForElementPresent(HomePageLocators.search_txt, "Search Scheme box");
		type(HomePageLocators.search_txt, acquirerBankName, "Acquirer Search box");
		waitForElementPresent(HomePageLocators.viewAcquirer_lnk, "View Acquirer Link");
		click(HomePageLocators.viewAcquirer_lnk, "View Acquirer Link");
		HtmlReportSupport.reportStep("Acquirer Information Page");
		waitForElementPresent(AddAcquirerPageLocators.acqInfo_lbl, "Acquirer Information Page");
		waitForElementPresent(By.xpath("//td[contains(text(),'"+ acquirerBankName +"')]"), "Acquirer Bank Name: " + acquirerBankName);
		//waitForElementPresent(AddAcquirerPageLocators.submit_btn, "Submit Button");			
		return true;
	}

	//EDIT LEGAL VEHICLE
	public boolean viewLegalVehicle(String lvName) throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Edit Legal Vehicle Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.legalVehicle_mnu, "Legal Vehicle SubMenu");
		waitForElementPresent(HomePageLocators.search_txt, "Search Scheme box");
		type(HomePageLocators.search_txt, lvName, "Legal Vehicle Search box");
		waitForElementPresent(HomePageLocators.editLegalVehicle_lnk, "Edit Legal Vehicle Link");
		click(HomePageLocators.editLegalVehicle_lnk, "Edit Legal Vehicle Link");
		HtmlReportSupport.reportStep("Edit Legal Vehicle Page");
		waitForElementPresent(By.xpath("//input[contains(@value,'"+ lvName +"')]"), "Edit Legal Vehicle Page");
		waitForElementPresent(By.xpath("//input[contains(@value,'"+ lvName +"')]"), "Legal Vehicle Name: " + lvName);
		return true;
	}
	
	//OPERATIONS APPROVAL
	public boolean navigateToOperationsApprovalListPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Operations Approval Page");
		click(HomePageLocators.merchManagement_mnu,"Merchant Management Menu");
		waitForElementPresent(HomePageLocators.operationsApproval_mnu, "Operations Approval SubMenu");
		click(HomePageLocators.operationsApproval_mnu, "Operations Approval SubMenu");
		waitForElementPresent(HomePageLocators.search_txt, "Search Store");
		return true;
	}
	
	//BUSINESS APPROVAL
	public boolean navigateToBusinessApprovalListPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Business Approval Page");
		click(HomePageLocators.merchManagement_mnu,"Merchant Management Menu");
		waitForElementPresent(HomePageLocators.businessApproval_mnu, "Business Approval SubMenu");
		click(HomePageLocators.businessApproval_mnu, "Business Approval SubMenu");
		waitForElementPresent(HomePageLocators.search_txt, "Search Business Store");
		return true;
	}
	
	//RISK APPROVAL
	public boolean navigateToRiskApprovalListPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Risk Approval Page");
		click(HomePageLocators.merchManagement_mnu,"Merchant Management Menu");
		waitForElementPresent(HomePageLocators.riskApproval_mnu, "Risk Approval SubMenu");
		click(HomePageLocators.riskApproval_mnu, "Risk Approval SubMenu");
		waitForElementPresent(HomePageLocators.search_txt, "Search Risk Approval Store");
		return true;
	}
	
	//FINANCE APPROVAL
	public boolean navigateToFinanceApprovalListPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Finance Approval Page");
		click(HomePageLocators.merchManagement_mnu,"Merchant Management Menu");
		waitForElementPresent(HomePageLocators.financeApproval_mnu, "Finance Approval SubMenu");
		click(HomePageLocators.financeApproval_mnu, "Finance Approval SubMenu");
		waitForElementPresent(HomePageLocators.search_txt, "Search Store for Finance Approval");
		return true;
	}
	
	//DISPUTE MANAGEMENT
	public boolean navigateToDisputeManagementPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Dispute Management Page");
		click(HomePageLocators.merchManagement_mnu,"Merchant Management Menu");
		waitForElementPresent(HomePageLocators.disputeManagement_mnu, "Disputes Management Menu");
		click(HomePageLocators.disputeManagement_mnu, "Disputes Management Menu");
		waitForElementPresent(HomePageLocators.disputesList, "Disputes List Page");
		return true;
	}
	
	//SETTLEMENT FILE GENERATION
	public boolean navigateToSettleFileGenPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Settlement File Generation Page");
		click(HomePageLocators.settlement_mnu,"Settlement Menu");
		waitForElementPresent(HomePageLocators.settleFileGen_mnu, "Settlement File Generation Menu");
		click(HomePageLocators.settleFileGen_mnu, "Settlement File Generation Menu");
		waitForElementPresent(SettlementFileGenPageLocators.settleLv, "Settlement File Generation Page");
		return true;
	}
	
	//SETTLEMENT FILE RECONCILIATION DETAILS
	public boolean navigateToSettleFileReconPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Settlement File Reconciliation Page");
		click(HomePageLocators.settlement_mnu,"Settlement Menu");
		waitForElementPresent(HomePageLocators.settleFileRecon_mnu, "Settlement File Reconciliation Menu");
		click(HomePageLocators.settleFileRecon_mnu, "Settlement File Reconciliation Menu");
		waitForElementPresent(SettlementFileReconPageLocators.search_txt, "Settlement File Reconciliation Page");
		return true;
	}
	
	//NETBANK RECONCILIATION UPLOAD
	public boolean navigateToNetbankReconUploadPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Netbank Reconciliation Upload Page");
		click(HomePageLocators.settlement_mnu,"Settlement Menu");
		waitForElementPresent(HomePageLocators.netbankFileRecon_mnu, "Netbank Reconciliation Upload Menu");
		click(HomePageLocators.netbankFileRecon_mnu, "Netbank Reconciliation Upload Menu");
		waitForElementPresent(NetbankReconUploadPageLocators.netbankReconUploadList, "Netbank Reconciliation Upload List Page");
		return true;
	}
	
	//MERCHANT PAYMENT ADVICE GENERATION
	public boolean navigateToMerchPayAdviceGenPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Merchant Payment Advice Generation Page");
		click(HomePageLocators.settlement_mnu,"Settlement Menu");
		waitForElementPresent(HomePageLocators.merchPayAdvice_mnu, "Merchant Payment Advice Menu");
		click(HomePageLocators.merchPayAdvice_mnu, "Merchant Payment Advice Menu");
		waitForElementPresent(MerchantPayAdvicePageLocators.lvId_select, "Merchant Payment Advice Generation Page");
		return true;
	}
	
	//NETBANK CANCEL/REFUND DOWNLOAD
	public boolean navigateToNetbankCancelDownloadPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Netbank Cancel/Refund Download Page");
		click(HomePageLocators.settlement_mnu,"Settlement Menu");
		waitForElementPresent(HomePageLocators.netbankCancelDownload_mnu, "Netbank Cancel/Refund Download");
		click(HomePageLocators.netbankCancelDownload_mnu, "Netbank Cancel/Refund Download");
		waitForElementPresent(NetbankCancelDownloadPageLocators.lvId_select, "Netbank Cancel Download Page");
		return true;
	}
	
	//SETTLEMENT MARKING
	public boolean navigateToSettlementMarkingPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Settlement Marking Page");
		click(HomePageLocators.settlement_mnu,"Settlement Menu");
		waitForElementPresent(HomePageLocators.settlementMarking_mnu, "Settlement Marking");
		click(HomePageLocators.settlementMarking_mnu, "Settlement Marking");
		waitForElementPresent(SettlementMarkingPageLocators.legalMerchantName, "Settlement Marking Page");
		return true;
	}
	
	//CANCEL MARKING
	public boolean navigateToCancelMarkingPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Cancel Marking Page");
		click(HomePageLocators.settlement_mnu,"Settlement Menu");
		waitForElementPresent(HomePageLocators.cancelMarking_mnu, "Cancel/Refund Marking");
		click(HomePageLocators.cancelMarking_mnu, "Cancel/Refund Marking");
		waitForElementPresent(SettlementMarkingPageLocators.filter_select, "Cancel/Refund Marking Page");
		return true;
	}
	
	//SETTLEMENT CANCEL/REFUND UPLOAD
	public boolean navigateToCancelRefundUploadPage() throws Throwable{
		HtmlReportSupport.reportStep("Navigate to Cancel/Refund Upload Page");
		click(HomePageLocators.settlement_mnu,"Settlement Menu");
		waitForElementPresent(HomePageLocators.settlementRefundCancelUpload_mnu, "Settlment Cancel/Refund Upload");
		click(HomePageLocators.settlementRefundCancelUpload_mnu, "Settlment Cancel/Refund Upload");
		waitForElementPresent(SettlementRefundCancelUploadPageLocators.upload_btn, "Settlement Cancel/Refund Upload Page");
		return true;
	}
}