package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.IpgTransAdminPortal.testObjects.AddFacilitatorPageLocators;
import com.IpgTransAdminPortal.testObjects.DisputeManagementPageLocators;
import com.IpgTransAdminPortal.testObjects.NetbankReconUploadPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementFileGenPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementFileReconPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class NetbankReconUploadPage extends ActionEngine {

	public String lvId;
	public String bankName;
	public String inputFilePath;
	public String batchRunId;
	
	static Logger logger = Logger.getLogger(NetbankReconUploadPage.class.getName());
	ExcelReader bufferxls = new ExcelReader(configProps.getProperty("TempData"), "buffer");
	
	public boolean netbankReconUpload() throws Throwable {
		HtmlReportSupport.reportStep("Netbank Reconciliation Upload");
		boolean result = false;
		
		click(NetbankReconUploadPageLocators.upload_btn, "Upload button");		
		waitForElementPresent(NetbankReconUploadPageLocators.lvId_select, "Legal Vehicle - Select");
		selectByVisibleText(NetbankReconUploadPageLocators.lvId_select, lvId, "Legal Vehicle - Select");
		Thread.sleep(1000);
		waitForElementPresent(NetbankReconUploadPageLocators.netbankName_select, "Netbank Name - Select");
		selectByVisibleText(NetbankReconUploadPageLocators.netbankName_select, bankName, "Netbank Name - Select");
		driver.findElement(NetbankReconUploadPageLocators.inputFilePath).sendKeys(inputFilePath);
		Reporter.SuccessReport("Browse Upload File Path: " , inputFilePath);
		//type(NetbankReconUploadPageLocators.inputFilePath, inputFilePath, "Input File Path");
		click(NetbankReconUploadPageLocators.uploadFile_btn, "Upload File button");
		waitForElementPresent(NetbankReconUploadPageLocators.uploadFileSuccessConfirm_msg, "Netbank Reconciliation File Upload Successful Message");
		
		/*
		Thread.sleep(10000);
		while(isElementDisplayed(SettlementFileGenPageLocators.fileGenPending_row, "Pending Status")||isElementDisplayed(SettlementFileGenPageLocators.fileGenInProgress_row, "In Progress Status")){
			Thread.sleep(10000);
			click(SettlementFileGenPageLocators.refresh_btn, "Refresh button");
			Thread.sleep(10000);
			if(isElementDisplayed(SettlementFileGenPageLocators.fileGenSuccess_row, "File Generation Success Status")){
				successFlag = true;
			}			
		}
		
		if (successFlag)
			result = true;
		else if(!successFlag)
			Reporter.failureReport("File Generation", "FAILED");
		*/
		batchRunId = getText(NetbankReconUploadPageLocators.firstRow_batchRunId, "Batch Run ID");
		result = bufferxls.setCellData("buffer", "netbankReconFileUpload_batchRunId", 2, batchRunId);
		
		return result;
	}

	public boolean netbankReconUploadValidation() throws Throwable {
		HtmlReportSupport.reportStep("Netbank Reconciliation Upload Validation");
		boolean result = false;
		
		batchRunId = bufferxls.getCellData("buffer", "netbankReconFileUpload_batchRunId", 2);
		type(NetbankReconUploadPageLocators.search_txt, batchRunId, "Search");
		
		if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'PENDING')]"), "Batch RUN - PENDING")){
			Reporter.failureReport("Batch Run Status/File upload", "PENDING");
		}else if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'In Progress')]"), "Batch RUN - In Progress")){
			Reporter.failureReport("Batch Run Status/File upload", "In Progress");
		}else if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'FAILED')]"), "Batch RUN - FAILED")){
			Reporter.failureReport("Batch Run Status/File upload", "FAILED");
		}else if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'SUCCESS')]"), "Batch RUN - SUCCESS")){
			Reporter.SuccessReport("Batch Run Status/File upload", "SUCCESS");
			result = true;
		}
		
		return result;
	}
	public void setLvId(String lvId) {
		this.lvId = lvId;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public void setInputFilePath(String inputFilePath) {
		this.inputFilePath = inputFilePath;
	}

	public void setBatchRunId(String batchRunId) {
		this.batchRunId = batchRunId;
	}
	
	
	
}
