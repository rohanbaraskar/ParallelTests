package com.IpgTransAdminPortal.workflows;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import net.lightbody.bmp.core.har.Har;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Proxy;

import com.IpgTransAdminPortal.testObjects.ReportsLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.ExcelReader2;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

import net.lightbody.bmp.core.har.Har;
import net.lightbody.bmp.proxy.ProxyServer;
import edu.umass.cs.benchlab.har.HarEntries;
import edu.umass.cs.benchlab.har.HarLog;
import edu.umass.cs.benchlab.har.HarWarning;
import edu.umass.cs.benchlab.har.tools.HarFileReader;

public class ReportWorkflows extends ActionEngine {

	public String pgMerchId;
	public String orderId;
	public String rrn;
	public String transRefNo;
	public String fromDate;
	public String toDate;
	public String channel;
	public String lvName;
	public String legalName;
	public String dbaName;
	public String status;
	public String mid;
	public String acqBank;
	public String monthYear;
	public String cardType;
	public String date;
	public String reporttype;
	
	static Logger logger = Logger.getLogger(ReportWorkflows.class.getName());
	public boolean transactionSearchReport() throws Throwable {
		HtmlReportSupport.reportStep("Transaction Search Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Transaction Search Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.transactionSearch_menu, "Transaction Search Menu");
		click(ReportsLocators.transactionSearch_menu, "Transaction Search Menu");
		waitForElementPresent(ReportsLocators.pgMerchId_txt, "Transaction Search Report Page");
		if((pgMerchId != null)&&(pgMerchId != ""))
			type(ReportsLocators.pgMerchId_txt, pgMerchId, "PG Merchant ID");
		if((orderId != null)&&(orderId != ""))
			type(ReportsLocators.orderId_txt, orderId, "Order Id");
		if((rrn != null)&&(rrn != ""))
			type(ReportsLocators.rrn_txt, rrn, "RRN");
		if((transRefNo != null)&&(transRefNo != ""))
			type(ReportsLocators.trnRefNo_txt, transRefNo, "Transaction Reference Number");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
		else{
			click(ReportsLocators.toDate_txt, "To Date");
			hitKey(ReportsLocators.toDate_txt, Keys.ENTER, "To Date");
		}			
		if((channel != null)&&(channel != ""))
			selectByVisibleText(ReportsLocators.channel_select, channel, "Channel");
		
		click(ReportsLocators.showReport_btn, "Show Report button");
		
		
		HtmlReportSupport.reportStep("VALIDATION of Transaction Search Report");
		waitForElementPresent(ReportsLocators.transactionSearchResults, "Transaction Search Results");
		click(ReportsLocators.ts_viewDetails_lnk, "Search Results of Transaction - View Details");
		waitForElementPresent(ReportsLocators.meRequestDetails_lbl, "Merchant Request Details Page");
		if(waitForElementPresent(By.xpath("//td[contains(text(),'"+pgMerchId+"')]"),"PG Merchant ID"))
			result = true;
		
		return result;
	}

	public boolean allTransactionReport() throws Throwable {
		
		HtmlReportSupport.reportStep("All Transaction Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to All Transaction Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.allTransaction_menu, "All Transaction Menu");
		click(ReportsLocators.allTransaction_menu, "All Transaction Menu");
		waitForElementPresent(ReportsLocators.lv_select, "All Transaction Report Page");
		if((lvName != null)&&(lvName != ""))
			selectByVisibleText(ReportsLocators.lv_select, lvName, "Legal Vehicle");
		if((pgMerchId != null)&&(pgMerchId != "")){
			type(ReportsLocators.allTrans_pgMerchId_txt, pgMerchId, "PG Merchant ID");
		}
		if((legalName != null)&&(legalName != ""))
			type(ReportsLocators.legalName_txt, legalName, "Legal Name");
		if((dbaName != null)&&(dbaName != ""))
			type(ReportsLocators.dbaName_txt, dbaName, "DBA Name");
		if((channel != null)&&(channel != ""))
			selectByVisibleText(ReportsLocators.channel_select, channel, "Channel");
		if((status != null)&&(status != ""))
			selectByVisibleText(ReportsLocators.status_select, status, "Status");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
		else{
			click(ReportsLocators.toDate_txt, "To Date");
			hitKey(ReportsLocators.toDate_txt, Keys.ENTER, "To Date");
		}			
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
		String reportFileName = ActionEngine.filename + "x";
		result = validateDownloadedReport(reportFileName, "PG Merchant ID", pgMerchId);
		//result = true;
		return result;
	}
	
	public boolean validateDownloadedReport(String fileName, String fieldName, String value) throws Throwable{
		boolean result = false;
		fileName = configProps.getProperty("fileDownloadPath") + fileName;
		ExcelReader2 xls = new ExcelReader2(fileName, "Report");
		String sheetName = xls.workbook.getSheetName(0);
		String tempS = xls.getCellData(sheetName, fieldName, 2);
		if(tempS.contains(value)){
			result = true;
			Reporter.SuccessReport("The value of the Search Field " + fieldName + " in downloaded Report matches with the value in Test Data", tempS);
		}else{
			Reporter.failureReport("The value of the Search Field " + fieldName + " in downloaded Report does not match with the value in Test Data", tempS);
		}
		
		return result;
	}
	
	public boolean validateDownloadedReportXls(String fileName, String fieldName, String value) throws Throwable{
		boolean result = false;
		fileName = configProps.getProperty("fileDownloadPath") + fileName;
		
		ExcelReader xls = new ExcelReader(fileName, "Report");
		String sheetName = xls.workbook.getSheetName(0);
		
		String tempS = xls.getCellData(sheetName, fieldName, 2);
		if(tempS.contains(value)){
			result = true;
			Reporter.SuccessReport("The value of the Search Field " + fieldName + " in downloaded Report matches with the value in Test Data", tempS);
		}else{
			Reporter.failureReport("The value of the Search Field " + fieldName + " in downloaded Report does not match with the value in Test Data", tempS);
		}
		
		return result;
	}
	
	public boolean merchantVolumeReport() throws Throwable {
		HtmlReportSupport.reportStep("Merchant Volume Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Merchant Volume Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.merchVolumentReport_menu, "Merchant Volume Report Menu");
		click(ReportsLocators.merchVolumentReport_menu, "Merchant Volume Report Menu");
		waitForElementPresent(ReportsLocators.merchVolume_pgMerchId_txt, "Merchant Volume Report Page");
		
		if((pgMerchId != null)&&(pgMerchId != "")){
			type(ReportsLocators.merchVolume_pgMerchId_txt, pgMerchId, "PG Merchant ID");
		}
		if((mid != null)&&(mid != ""))
			type(ReportsLocators.merchVol_mid_txt, mid, "MID");
		if((legalName != null)&&(legalName != ""))
			type(ReportsLocators.legalName_txt, legalName, "Legal Name");
		if((dbaName != null)&&(dbaName != ""))
			type(ReportsLocators.dbaName_txt, dbaName, "DBA Name");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
		else{
			click(ReportsLocators.toDate_txt, "To Date");
			hitKey(ReportsLocators.toDate_txt, Keys.ENTER, "To Date");
		}			
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.merchVolReportSearchResults, "Merchant Volume Report - Search Results");
		if(waitForElementPresent(By.xpath("//td[contains(text(),'"+pgMerchId+"')]"), "PG Merchant ID: " + pgMerchId + " in Search Results"))
			Reporter.SuccessReport("Verification for PG Merchant ID on UI report: Success", pgMerchId);
		
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
		result = validateDownloadedReportXls(ActionEngine.filename, "PG Merchant ID", pgMerchId);
		
		
		return result;
	}
	
	public boolean acqBankwiseUnsettledTransactionReport() throws Throwable {
		HtmlReportSupport.reportStep("ACQUIRER BANKWISE UNSETTLED TRANSACTION Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Acquirer Bankwise Unsettled Transaction Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.acqBankwiseUnsettledTransReport_menu, "Acq Bankwise Unsettled Transaction Report Menu");
		click(ReportsLocators.acqBankwiseUnsettledTransReport_menu, "Acq Bankwise Unsettled Transaction Report Menu");
		waitForElementPresent(ReportsLocators.lv_select, "Acq Bankwise Unsettled Transaction Report Page");
		
		selectByVisibleText(ReportsLocators.lv_select, lvName, "Legal Vehicle");
		selectByVisibleText(ReportsLocators.acqBankName_select, acqBank, "Acquiring Bank");
		if((mid != null)&&(mid != ""))
			type(ReportsLocators.pgMerchId_txt, mid, "MID");		
		if((pgMerchId != null)&&(pgMerchId != "")){
			type(ReportsLocators.acqBankUnsetTrans_pgMerchId_txt, pgMerchId, "PG Merchant ID");
		}

		if((legalName != null)&&(legalName != ""))
			type(ReportsLocators.legalName_txt, legalName, "Legal Name");
		if((dbaName != null)&&(dbaName != ""))
			type(ReportsLocators.dbaName_txt, dbaName, "DBA Name");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
					
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.merchVolReportSearchResults, "Acq Bankwise Unsettled Transaction Report - Search Results");
		if(waitForElementPresent(By.xpath("//td[contains(text(),'"+pgMerchId+"')]"), "PG Merchant ID: " + pgMerchId + " in Search Results"))
			Reporter.SuccessReport("Verification for PG Merchant ID on UI report: Success", pgMerchId);
		
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
		result = validateDownloadedReportXls(ActionEngine.filename, "PG Merchant ID", pgMerchId);
		
		
		return result;
	}
	
	public boolean acqBankwiseSalesSummaryReport() throws Throwable {
		HtmlReportSupport.reportStep("Acquiring Bankwise Sales Summary Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Acquiring Bankwise Sales Summary Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.acqBankwiseSaleSummaryReport_menu, "Acq Bankwise Sales Summary Report Menu");
		click(ReportsLocators.acqBankwiseSaleSummaryReport_menu, "Acq Bankwise Sales Summary Report Menu");
		waitForElementPresent(ReportsLocators.lv_select, "Acq Bankwise Unsettled Transaction Report Page");
		
		selectByVisibleText(ReportsLocators.lv_select, lvName, "Legal Vehicle");
		selectByVisibleText(ReportsLocators.acqBankName_select, acqBank, "Acquiring Bank");
		
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
					
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.acqBankwiseSaleSummaryReportSearchResults, "Acquiring Bankwise Sales Summary Report - Search Results");
		if(waitForElementPresent(By.xpath("//td[contains(text(),'"+acqBank+"')]"), "Acquiring Bank: " + acqBank + " in Search Results"))
			Reporter.SuccessReport("Verification for Aquirer Bank on UI report: Success", acqBank);
		
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
		result = validateDownloadedReportXls(ActionEngine.filename, "Acquiring Bank Name Code", acqBank);
		return result;
	}
	
	public boolean frmAlertReport() throws Throwable {
		HtmlReportSupport.reportStep("FRM Alert Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to FRM Alert Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.frmAlertReport_menu, "FRM Alert Report Menu");
		click(ReportsLocators.frmAlertReport_menu, "FRM Alert Report Menu");
		waitForElementPresent(ReportsLocators.fromDate_txt, "FRM Alert Report Page");
		
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
					
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.merchVolReportSearchResults, "FRM Alert Report - Search Results");
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
			result = captureNetworkPanel();
		
		return result;
	}
	
	public boolean mePaymentAdviceReport() throws Throwable {
		HtmlReportSupport.reportStep("Merchant Payment Advice Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Merchant Payment Advice Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.mePaymentAdviceReport_menu, "Merchant Payment Advice Report Menu");
		click(ReportsLocators.mePaymentAdviceReport_menu, "Merchant Payment Advice Report Menu");
		waitForElementPresent(ReportsLocators.fromDate_txt, "Merchant Payment Advice Report Page");
		if((pgMerchId != null)&&(pgMerchId != ""))
			type(ReportsLocators.pgMerchantId_txt, pgMerchId, "PG Merchant ID");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
		
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
		result = validateDownloadedReportXls(ActionEngine.filename, "PG Merchant ID", pgMerchId);
		
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.merchVolReportSearchResults, "Merchant Payment Advice Report - Search Results");
		if(waitForElementPresent(By.xpath("//td[contains(text(),'"+pgMerchId+"')]"), "PG Merchant ID: " + pgMerchId + " in Search Results"))
			Reporter.SuccessReport("Verification for PG Merchant ID on UI report: Success", pgMerchId);
		
		return result;
	}
	
	public boolean monthlyInvoicingReport() throws Throwable {
		HtmlReportSupport.reportStep("Monthly Invoicing Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Monthly Invoicing Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.monthlyInvoicingReport_menu, "Monthly Invoicing Report Menu");
		click(ReportsLocators.monthlyInvoicingReport_menu, "Monthly Invoicing Report Menu");
		waitForElementPresent(ReportsLocators.monthYear_txt, "Monthly Invoicing Report Page");
		selectByVisibleText(ReportsLocators.lv_select, lvName, "Legal Vehicle");
		
		if((monthYear != null)&&(monthYear != ""))
			js_type(ReportsLocators.monthYear_txt, monthYear, "Month & Year");
					
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.merchVolReportSearchResults, "Monthly Invoicing Report - Search Results");
		//if(waitForElementPresent(By.xpath("//td[contains(text(),'"+lvName+"')]"), "Legal Vehicle: " + lvName + " in Search Results"))
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
		
		return result;
	}
	
	public boolean merchantWiseMisReport() throws Throwable {
		HtmlReportSupport.reportStep("Merchant Wise MIS Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Merchant Wise MIS Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.merchantWiseMisReport_menu, "Merchant Wise MIS Report Menu");
		click(ReportsLocators.merchantWiseMisReport_menu, "Merchant Wise MIS Report Menu");
		waitForElementPresent(ReportsLocators.fromDate_txt, "Merchant Wise MIS Report Page");
		
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
					
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.merchVolReportSearchResults, "Merchant Wise MIS Report - Search Results");
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
		
		result = true;
		return result;
	}
	
	public boolean misTransactionReport() throws Throwable {
		HtmlReportSupport.reportStep("MIS Transaction Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to MIS Transaction Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.misTransReport_menu, "MIS Transaction Report Menu");
		click(ReportsLocators.misTransReport_menu, "MIS Transaction Report Menu");
		waitForElementPresent(ReportsLocators.pgMerchantId_txt, "MIS Transaction Report Page");
		
		if((pgMerchId != null)&&(pgMerchId != "")){
			type(ReportsLocators.pgMerchantId_txt, pgMerchId, "PG Merchant ID");
		}
		if((mid != null)&&(mid != ""))
			type(ReportsLocators.merchVol_mid_txt, mid, "MID");
		if((legalName != null)&&(legalName != ""))
			type(ReportsLocators.legalName_txt, legalName, "Legal Name");
		if((cardType != null)&&(cardType != ""))
			selectByVisibleText(ReportsLocators.cardType_select, cardType, "Card Type");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
		else{
			click(ReportsLocators.toDate_txt, "To Date");
			hitKey(ReportsLocators.toDate_txt, Keys.ENTER, "To Date");
		}			
		if((channel != null)&&(channel != ""))
			selectByVisibleText(ReportsLocators.channel_select, channel, "Channel");
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.misTransReportSearchResults_success, "MIS Transaction Report - Search Results");
		result = true;
		return result;
	}
	
	public boolean profitLossAccReport() throws Throwable {
		HtmlReportSupport.reportStep("Profit & Loss Account Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Profit & Loss Account Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.profitLossAccReport_menu, "Profit & Loss Account Report Menu");
		click(ReportsLocators.profitLossAccReport_menu, "Profit & Loss Account Report Menu");
		
		waitForElementPresent(ReportsLocators.fromDate_txt, "Profit & Loss Account Report Page");
		if((pgMerchId != null)&&(pgMerchId != ""))
			type(ReportsLocators.pgMerchantId_txt, pgMerchId, "PG Merchant ID");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
					
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.merchVolReportSearchResults, "Profit & Loss Account Report - Search Results");
		if(waitForElementPresent(By.xpath("//td[contains(text(),'"+pgMerchId+"')]"), "PG Merchant ID: " + pgMerchId + " in Search Results"))
			Reporter.SuccessReport("Verification for PG Merchant ID on UI report: Success", pgMerchId);
		
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
		result = validateDownloadedReportXls(ActionEngine.filename, "PG Merchant ID", pgMerchId);
		
		return result;
	}
	
	public boolean chargebackToSalesRatioReport() throws Throwable {
		HtmlReportSupport.reportStep("Chargebacks to Sales Ratio Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Chargebacks to Sales Ratio Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.chargebackSalesRatioReport_menu, "Chargebacks to Sales Ratio Report Menu");
		click(ReportsLocators.chargebackSalesRatioReport_menu, "Chargebacks to Sales Ratio Report Menu");
		
		waitForElementPresent(ReportsLocators.lv_select, "Chargebacks to Sales Ratio Report Page");
		if((pgMerchId != null)&&(pgMerchId != ""))
			type(ReportsLocators.pgMerchantId_txt, pgMerchId, "PG Merchant ID");
		if((lvName != null)&&(lvName != ""))
			selectByVisibleText(ReportsLocators.lv_select, lvName, "Legal Vehicle");
		if((acqBank != null)&&(acqBank != ""))
			selectByVisibleText(ReportsLocators.acqBankName_select, acqBank, "Acquiring Bank");
		
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.merchVolReportSearchResults, "Chargebacks to Sales Ratio Report - Search Results");
		if(waitForElementPresent(By.xpath("//td[contains(text(),'"+pgMerchId+"')]"), "PG Merchant ID: " + pgMerchId + " in Search Results"))
			Reporter.SuccessReport("Verification for PG Merchant ID on UI report: Success", pgMerchId);
		
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
		result = validateDownloadedReportXls(ActionEngine.filename, "PG Merchant ID", pgMerchId);
		
		return result;
	}
	
	public boolean chargebackDailyAgingReport() throws Throwable {
		HtmlReportSupport.reportStep("Chargebacks - Daily Aging Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Chargebacks - Daily Aging Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.chargebackDailyAgingReport_menu, "Chargebacks - Daily Aging Report Menu");
		click(ReportsLocators.chargebackDailyAgingReport_menu, "Chargebacks - Daily Aging Report Menu");
		waitForElementPresent(ReportsLocators.monthYear_txt, "Chargebacks - Daily Aging Report Page");
		if((date != null)&&(date != ""))
			js_type(ReportsLocators.monthYear_txt, date, "Date");
		
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.meDetailsSearchResults_success, "Chargebacks - Daily Aging Report - Search Results");
		
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
		
		return result;
	}
	
	public boolean chargebacksDetailedTransReport() throws Throwable {
		HtmlReportSupport.reportStep("Chargebacks - Detailed Transaction Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Chargebacks - Detailed Transaction Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.chargebackDetailTransReport_menu, "Chargebacks - Detailed Transaction Report Menu");
		click(ReportsLocators.chargebackDetailTransReport_menu, "Chargebacks - Detailed Transaction Report Menu");
		
		waitForElementPresent(ReportsLocators.fromDate_txt, "Chargebacks - Detailed Transaction Report Page");
		if((pgMerchId != null)&&(pgMerchId != ""))
			type(ReportsLocators.pgMerchantId_txt, pgMerchId, "PG Merchant ID");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
					
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.merchVolReportSearchResults, "Chargebacks - Detailed Transaction Report - Search Results");
		if(waitForElementPresent(By.xpath("//td[contains(text(),'"+pgMerchId+"')]"), "PG Merchant ID: " + pgMerchId + " in Search Results"))
			Reporter.SuccessReport("Verification for PG Merchant ID on UI report: Success", pgMerchId);
		
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
		result = validateDownloadedReportXls(ActionEngine.filename, "PG Merchant ID", pgMerchId);
		
		return result;
	}
	
	public boolean profitabilityReport() throws Throwable {
		HtmlReportSupport.reportStep("Profitability Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Profitability Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.profitabilityReport_menu, "Profitability Report Menu");
		click(ReportsLocators.profitabilityReport_menu, "Profitability Report Menu");
		waitForElementPresent(ReportsLocators.fromDate_txt, "Profitability Report Page");
		selectByVisibleText(ReportsLocators.lv_select, lvName, "Legal Vehicle");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
					
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.profitabilityReportSearchResults_success, "Profitability Report - Search Results");
		
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
	
		result = true;
		return result;
	}
	
	public boolean merchantDetailsReport() throws Throwable {
		HtmlReportSupport.reportStep("Merchant Details Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Merchant Details Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.meDetailsReport_menu, "Merchant Details Report Menu");
		click(ReportsLocators.meDetailsReport_menu, "Merchant Details Report Menu");
		waitForElementPresent(ReportsLocators.fromDate_txt, "Merchant Details Report Page");
		
		if((mid != null)&&(mid != ""))
			type(ReportsLocators.pgMerchId_txt, mid, "MID");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
					
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.meDetailsSearchResults_success, "Merchant Details Report - Search Results");
		
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
	
		return result;
	}
	
	public boolean inactiveMerchantReport() throws Throwable {
		HtmlReportSupport.reportStep("Deactive Merchant Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Deactive Merchant Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.deactiveMerchantReport_menu, "Deactive Merchant Report Menu");
		click(ReportsLocators.deactiveMerchantReport_menu, "Deactive Merchant Report Menu");
		waitForElementPresent(ReportsLocators.fromDate_txt, "Deactive Merchant Report Page");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
		
		if((channel != null)&&(channel != ""))
			selectByVisibleText(ReportsLocators.channel_select, channel, "Channel");
					
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.deactiveMerchantReportSearchResults_success, "Deactive Merchant Report - Search Results");
		
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
	
		result = true;
		return result;
	}
	
	public boolean selfRegistrationReport() throws Throwable {
		HtmlReportSupport.reportStep("Self Registration Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Self Registration Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.selfRegistrationReport_menu, "Self Registration Report Menu");
		click(ReportsLocators.selfRegistrationReport_menu, "Self Registration Report Menu");
		waitForElementPresent(ReportsLocators.fromDate_txt, "Self Registration Report Page");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
					
		click(ReportsLocators.showReport_btn, "Show Report button");
		waitForElementPresent(ReportsLocators.selfRegistrationReportSearchResults_success, "Self Registration Report - Search Results");
		
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		result = captureNetworkPanel();
	
		return result;
	}
	
	public boolean varianceReport() throws Throwable {
		HtmlReportSupport.reportStep("Variance Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Variance Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.varianceReport_menu, "Variance Report Menu");
		click(ReportsLocators.varianceReport_menu, "Variance Report Menu");
		waitForElementPresent(ReportsLocators.monthYear_txt, "Variance Report Page");
		selectByVisibleText(ReportsLocators.lv_select, lvName, "Legal Vehicle");
		if((acqBank != null)&&(acqBank != ""))
			selectByVisibleText(ReportsLocators.acqBankName_select, acqBank, "Acquiring Bank");
		if((date != null)&&(date != ""))
			js_type(ReportsLocators.monthYear_txt, date, "Date");			
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		Thread.sleep(10000);
		result = captureNetworkPanel();
		//result = true;
		return result;
	}
	
	public boolean dailySalesReport() throws Throwable {
		HtmlReportSupport.reportStep("Daily Sales Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Daily Sales Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.dsrReport_menu, "DSR Report Menu");
		click(ReportsLocators.dsrReport_menu, "DSR Report Menu");
		waitForElementPresent(ReportsLocators.monthYear_txt, "Variance Report Page");
		if((date != null)&&(date != ""))
			js_type(ReportsLocators.monthYear_txt, date, "Date");			
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		
		if(isElementDisplayed(ReportsLocators.noRecordFound_msg,"No Record Found - message"))
			Reporter.failureReport("DSR Report Search Results", "Not Found");
		//Thread.sleep(10000);
		result = captureNetworkPanel();
		//result = true;
		return result;
	}
	
	public boolean trialBalanceReport() throws Throwable {
		HtmlReportSupport.reportStep("Trial Balance Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Trial Balance Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.trialBalanceReport_menu, "Trial Balance Report Menu");
		click(ReportsLocators.trialBalanceReport_menu, "Trial Balance Report Menu");
		waitForElementPresent(ReportsLocators.monthYear_txt, "Trial Balance Report Page");
		if((date != null)&&(date != ""))
			js_type(ReportsLocators.monthYear_txt, date, "Date");			
		click(ReportsLocators.downloadReport_btn, "Download as Excel button");
		
		if(isElementDisplayed(ReportsLocators.noRecordFound_msg,"No Record Found - message"))
			Reporter.failureReport("DSR Report Search Results", "Not Found");
		else
			result = captureNetworkPanel();
		return result;
	}
	
	public boolean merchStatusReport() throws Throwable {
		HtmlReportSupport.reportStep("Merchant Status Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Merchant Status Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.meStatusReport_menu, "Merchant Status Report Menu");
		click(ReportsLocators.meStatusReport_menu, "Merchant Status Report Menu");
		
		waitForElementPresent(ReportsLocators.fromDate_txt, "Merchant Status Report Page");
		if((lvName != null)&&(lvName != ""))
			selectByVisibleText(ReportsLocators.lv_select, lvName, "Legal Vehicle");
		if((fromDate != null)&&(fromDate != ""))
			js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
		if((toDate != null)&&(toDate != ""))
			js_type(ReportsLocators.toDate_txt, toDate, "To Date");
					
		click(ReportsLocators.downloadReport_btn, "Download Report button");
		
		if(isElementDisplayed(ReportsLocators.noRecordFound_msg,"No Record Found - message"))
			Reporter.failureReport("Merchant Status Report Search Results", "Not Found");
		else
			result = captureNetworkPanel();
		return result;
	}
	
	public boolean riskScoringReport() throws Throwable{
		HtmlReportSupport.reportStep("Risk Scoring Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Risk Scoring Report Page");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.riskScoringReport_menu, "Risk Scoring Report Menu");
		click(ReportsLocators.riskScoringReport_menu, "Risk Scoring Report Menu");
		waitForElementPresent(ReportsLocators.riskScoringReport_Text, "Risk Scoring Report Text");
		verifyText(ReportsLocators.riskScoringReport_Text, "Risk Scoring Report", "Risk Scoring Report Text");
     	selectByVisibleText(ReportsLocators.lv_select, lvName, "Legal Vehicle");
	         if((fromDate != null)&&(fromDate != "")){
				js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
			if((toDate != null)&&(toDate != ""))
				js_type(ReportsLocators.toDate_txt, toDate, "To Date");
			}else{
				click(ReportsLocators.toDate_txt, "To Date");
				hitKey(ReportsLocators.toDate_txt, Keys.ENTER, "To Date");
			}			
	         click(ReportsLocators.downloadReport_btn, "Download as Excel button");
	 		
			result = captureNetworkPanel();
			return result;	
		}
	
	public boolean merchantOutstandingReport()throws Throwable{
		HtmlReportSupport.reportStep("Merchant Outstanding Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Merchant Outstanding Report");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.merchantOutstandingReport_menu, "Merchant Outstanding Report Menu");
		click(ReportsLocators.merchantOutstandingReport_menu, "Merchant Outstanding Report");
		waitForElementPresent(ReportsLocators.merchantOutstandingReport_Text, "Merchant Outstanding Report Text");
		verifyText(ReportsLocators.merchantOutstandingReport_Text, "Merchant Outstand Report", "Merchant Outstanding Report Text");
     	
		selectByVisibleText(ReportsLocators.reportType_select, reporttype, "Legal Vehicle");
	         if((pgMerchId != null)&&(pgMerchId != "")){
				type(ReportsLocators.pgMerchantId_txt, pgMerchId, "PG Merchant ID");
			}			
	         click(ReportsLocators.downloadReport_btn, "Download as Excel button");
	 		
			result = captureNetworkPanel();
			return result;	
		}
	public boolean emiRegistrationReport() throws Throwable{
		HtmlReportSupport.reportStep("Emi Registration Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Emi Registration Report");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.emiRegistrationReport_menu, "Emi Registration Report Menu");
		click(ReportsLocators.emiRegistrationReport_menu, "Emi Registration Report Menu");
		waitForElementPresent(ReportsLocators.emiRegistrationReport_Text, "Emi Registration Report Text");
		verifyText(ReportsLocators.emiRegistrationReport_Text, "Emi Registration Report", "Emi Registration Report Text");
     	
		   if((fromDate != null)&&(fromDate != "")){
				js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
			if((toDate != null)&&(toDate != ""))
				js_type(ReportsLocators.toDate_txt, toDate, "To Date");
			}else{
				click(ReportsLocators.toDate_txt, "To Date");
				hitKey(ReportsLocators.toDate_txt, Keys.ENTER, "To Date");
			}			
		   click(ReportsLocators.downloadReport_btn, "Download as Excel button");
	 		
			result = captureNetworkPanel();
			return result;
	}
	public boolean smartCheckoutReport() throws Throwable{
		HtmlReportSupport.reportStep("Smart Checkout Report");
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to Smart Checkout Report");
		waitForElementPresent(ReportsLocators.reports_menu, "Reports Menu");
		click(ReportsLocators.reports_menu, "Reports Menu");
		waitForElementPresent(ReportsLocators.smartCheckoutReport_menu, "Smart Checkout Report Menu");
		click(ReportsLocators.smartCheckoutReport_menu, "Smart Checkout Report Menu");
		waitForElementPresent(ReportsLocators.smartCheckoutReport_Text, "Smart Checkout Report Text");
		verifyText(ReportsLocators.smartCheckoutReport_Text, "Smart Checkout Report", "Smart Checkout Report Text");
     	
		   if((fromDate != null)&&(fromDate != "")){
				js_type(ReportsLocators.fromDate_txt, fromDate, "From Date");
			if((toDate != null)&&(toDate != ""))
				js_type(ReportsLocators.toDate_txt, toDate, "To Date");
			}else{
				click(ReportsLocators.toDate_txt, "To Date");
				hitKey(ReportsLocators.toDate_txt, Keys.ENTER, "To Date");
			}			
		   click(ReportsLocators.downloadReport_btn, "Download as Excel button");
	 	
			result = captureNetworkPanel();
			return result;
	}
	
	
	public void setPgMerchId(String pgMerchId) {
		this.pgMerchId = pgMerchId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public void setRrn(String rrn) {
		this.rrn = rrn;
	}
	public void setTransRefNo(String transRefNo) {
		this.transRefNo = transRefNo;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}

	public void setLvName(String lvName) {
		this.lvName = lvName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

	public void setDbaName(String dbaName) {
		this.dbaName = dbaName;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public void setAcqBank(String acqBank) {
		this.acqBank = acqBank;
	}

	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	public void setreportType(String reporttype){
		this.reporttype=reporttype;
	}	
	
}