package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.IpgTransAdminPortal.testObjects.AddFacilitatorPageLocators;
import com.IpgTransAdminPortal.testObjects.DisputeManagementPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;

public class DisputeManagementPage extends ActionEngine {

	public String category;
	public String status;
	public String comment;
	public String fromDate;
	public String toDate;
	
	static Logger logger = Logger.getLogger(DisputeManagementPage.class.getName());
	public boolean disputeManagement() throws Throwable {
		HtmlReportSupport.reportStep("Dispute Management");
		boolean result = false;
		HtmlReportSupport.reportStep("Disputes List Page");
		if((fromDate != null)&&(fromDate != ""))
			js_type(DisputeManagementPageLocators.fromDate_txt, fromDate, "FROM DATE");
		else{
			click(DisputeManagementPageLocators.fromDate_txt, "From Date");
			hitKey(DisputeManagementPageLocators.fromDate_txt, Keys.ENTER, "From Date");
		}
		if((toDate != null)&&(toDate != ""))
			js_type(DisputeManagementPageLocators.toDate_txt, toDate, "TO DATE");
		
		selectByVisibleText(DisputeManagementPageLocators.category_select, category, "Category Select");
		selectByVisibleText(DisputeManagementPageLocators.status_select, status, "Status Select");
		JSClick(DisputeManagementPageLocators.submit_btn, "Search button");
		waitForElementPresent(DisputeManagementPageLocators.viewDispute_lnk, "View Dispute");
		click(DisputeManagementPageLocators.viewDispute_lnk, "View Dispute");
		waitForElementPresent(DisputeManagementPageLocators.dispDetail_lbl, "Dispute Details Page");
		
		type(DisputeManagementPageLocators.addComment_txtarea, comment, "Add Comment");
		click(DisputeManagementPageLocators.respond_btn, "Respond button");
		waitForElementPresent(By.xpath("//textarea[contains(@placeholder,'"+comment+"')]"), "Add Comment Successful");
		result = true;
		return result;
	}
	
	public void setCategory(String category) {
		this.category = category;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}	
	
}