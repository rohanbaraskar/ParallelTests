package com.IpgTransAdminPortal.workflows;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import org.apache.log4j.Logger;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.StringUtils;

public class SettlementFileValidation extends ActionEngine{
	
	public String settlementBatchFileNameAndPath;
	
	public void setSettlementBatchFileNameAndPath(
			String settlementBatchFileNameAndPath) {
		this.settlementBatchFileNameAndPath = settlementBatchFileNameAndPath;
	}

	static Logger logger = Logger.getLogger(SettlementFileValidation.class.getName());
	
	public boolean validateSettlementFile() throws Throwable{
		boolean result = false;
		
		HtmlReportSupport.reportStep("Validation of Raw Batch File: "+settlementBatchFileNameAndPath);
		File file = new File(settlementBatchFileNameAndPath);
	    BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
	    String line = null;
	    String headerId = null;
	    int batchHeaderRowCount=0;
	    int transactionDetailRowCount=0;
	    int batchTrailerRowCount=0;
	    boolean flag = true;
	    while( (line = br.readLine())!= null){
	        headerId=line.substring(0, 4);
	        
	    	if(headerId.contains("1000")){
	    		
	    		HtmlReportSupport.reportStep("Validation of BATCH HEADER");
	    		result = validateBatchHeader(line);
	    		batchHeaderRowCount=batchHeaderRowCount+1;
	    		if(result==false){
	    			Reporter.warningReport("Batch Header Validation failed for: ",line);
	    			flag=false;
	    		}
	    	}else if(headerId.contains("1001")){
	    		HtmlReportSupport.reportStep("Validation of TRANSACTION DETAILS");
	    		result = validateTransactionDetails(line);
	    		transactionDetailRowCount=transactionDetailRowCount+1;
	    		if(result==false){
	    			Reporter.warningReport("Transaction Details Validation failed for: ",line);
	    			flag=false;
	    		}
	    	}else if(headerId.contains("1002")){
	    		HtmlReportSupport.reportStep("Validation of BATCH TRAILER");
	    		result = validateBatchTrailer(line);
	    		batchTrailerRowCount=batchTrailerRowCount+1;
	    		if(result==false){
	    			Reporter.warningReport("Batch Trailer Validation failed for: ",line);
	    			flag=false;
	    		}
	    	}
	    }
	    HtmlReportSupport.reportStep("Total Number of Batch Header Rows:" + batchHeaderRowCount);
	    HtmlReportSupport.reportStep("Total Number of Transaction Detail Rows:" + transactionDetailRowCount);
	    HtmlReportSupport.reportStep("Total Number of Batch Trailer Rows:" + batchTrailerRowCount);
	    br.close();
	    return flag;
	}	


	public static boolean validateBatchHeader(String batchHeader) throws Throwable{
		boolean flag = true;
		//INTERFACE ID @ POSITION 5 -- EXPECTED [left padded with "0"]
		String interfaceId = batchHeader.substring(4, 9);
		if(!StringUtils.validateStringWithNumbers(interfaceId)){
			Reporter.failureReport("Interface ID at Position 5: 5 digits left padded with 0", interfaceId);
			flag = false;
		}
		//BATCH NUMBER @ POSITION 10 -- EXPECTED [6-digit batch number]
		String batchNumber = batchHeader.substring(9, 15);
		if(!StringUtils.validateStringWithNumbers(batchNumber)){
			Reporter.failureReport("Batch Number at Position 10: 6 digits number", batchNumber);
			flag = false;
		}
		
		//TRANSMISSION DATE @16 LENGTH 6 -- EXPECTED [DDMMYY]
		String transmissionDate = batchHeader.substring(15, 21);
		if(!StringUtils.validateStringWithNumbers(transmissionDate)){
			Reporter.failureReport("Transmission Date at Position 16: DDMMYY", transmissionDate);
			flag = false;
		}else{
			Reporter.warningReport("Batch Date at Position 16: DDMMYY", transmissionDate);
		}
		
		//TRANSMISSION TIME @22 LENGTH 6 -- EXPECTED [HHMMSS]
		String transmissionTime = batchHeader.substring(21, 27);
		if(!StringUtils.validateStringWithNumbers(transmissionTime)){
			Reporter.failureReport("Transmission Time at Position 22: HHMMSS", transmissionTime);
			flag = false;
		}

		//CUT OFF DATE @28 LENGTH 6 -- EXPECTED [DDMMYY]
		String cutoffDate = batchHeader.substring(27, 33);
		if(!StringUtils.validateStringWithNumbers(cutoffDate)){
			Reporter.failureReport("Cutoff Date at Position 28: DDMMYY", cutoffDate);
			flag = false;
		}
		
		//CUTOFF TIME @34 LENGTH 6 -- EXPECTED [HHMMSS]
		String cutoffTime = batchHeader.substring(33, 39);
		if(!StringUtils.validateStringWithNumbers(cutoffTime)){
			Reporter.failureReport("Cutoff Time at Position 34: HHMMSS", cutoffTime);
			flag = false;
		}
		
		//BATCH TYPE @ POSITION 40 -- EXPECTED '0'
		if(batchHeader.charAt(39)!='0'){
			Reporter.failureReport("Batch Type at Position 40: 0", batchHeader.charAt(39)+"");
			flag = false;
		}
		
		//FILLER SPACES @41 LENGTH 416 -- EXPECTED [699 spaces]
		String filler41 = batchHeader.substring(40, 739);
		if(!StringUtils.validateStringWithSpaces(filler41)){
			Reporter.failureReport("Filler at Position 41: 699 spaces", filler41);
			flag = false;
		}
		return flag;
	}
	
	public static boolean validateTransactionDetails(String transactionDetail) throws Throwable{
		boolean flag = true;
		
		//AUTHORISATION HOST INDICATOR @5 LENGTH 1 -- EXPECTED [D-Authorisation by Magnus, O-Authorisation not by Magnus]
		String authHostIndicator = transactionDetail.substring(4, 5);
		if(!authHostIndicator.contentEquals("M") && !authHostIndicator.contentEquals("O")){
			Reporter.failureReport("AUTHORISATION HOST INDICATOR at Position 5: M-Magnus Authorisation, O-Authorisation not by Magnus", authHostIndicator);
			flag = false;
		}

		//MERCHANT ID @6 LENGTH 15 -- EXPECTED [15 digit number]
		String merchId = transactionDetail.substring(5, 20);
		if(!StringUtils.validateStringWithNumbers(merchId)){
			Reporter.failureReport("Merchant ID at Position 6: 15 digits Merchant ID", merchId);
			flag = false;
		}

		//TERMINAL NUMBER @21 LENGTH 8 -- EXPECTED [8 digit Terminal ID]
		String terminalNumber = transactionDetail.substring(20, 28);
		if(!StringUtils.validateStringWithNumbers(terminalNumber)){
			Reporter.failureReport("Terminal Number at Position 21: 8 digits Terminal ID", terminalNumber);
			flag = false;
		}

		//RRN NUMBER @29 LENGTH 12 -- EXPECTED [12 digit RRN]
		String rrnNumber = transactionDetail.substring(28, 40);
		if(!StringUtils.validateStringWithNumbers(rrnNumber)){
			Reporter.failureReport("RRN Number at Position 29: 12 digits RRN number", rrnNumber);
			flag = false;
		}

		//TRANSACTION TYPE @41 LENGTH 2 -- EXPECTED [00-Purchase, 09-purchase with cashback, 20-refund/reload, 27-card Sale]
		String transactionType = transactionDetail.substring(40, 42);
		if(!transactionType.contentEquals("00") && !transactionType.contentEquals("O9") && !transactionType.contentEquals("20") && !transactionType.contentEquals("27")){
			Reporter.failureReport("TRANSACTION TYPE at Position 41: 00-Purchase, 09-purchase with cashback, 20-refund/reload, 27-card Sale", transactionType);
			flag = false;
		}

		//TRANSACTION DATE @43 LENGTH 6 -- EXPECTED [DDMMYY]
		String transDate = transactionDetail.substring(42, 48);
		if(!StringUtils.validateStringWithNumbersAndSpaces(transDate)){
			Reporter.failureReport("Transaction Date at Position 43: DDMMYY", transDate);
			flag = false;
		}

		//TRANSACTION TIME @49 LENGTH 6 -- EXPECTED [HHMMSS]
		String transTime = transactionDetail.substring(48, 54);
		if(!StringUtils.validateStringWithNumbersAndSpaces(transTime)){
			Reporter.failureReport("Transaction Time at Position 49: HHMMSS", transTime);
			flag = false;
		}
		
		//STAN NUMBER @55 LENGTH 6 -- EXPECTED [6 digit number]
		String stanNumber = transactionDetail.substring(54, 60);
		if(!StringUtils.validateStringWithNumbers(transTime)){
			Reporter.failureReport("Stan Number at Position 55: 6-digit number", stanNumber);
			flag = false;
		}
		
		//AUTHORISATION CODE @61 LENGTH 6 -- EXPECTED [6 digit number]
		String authCode = transactionDetail.substring(60, 66);
		if(!StringUtils.validateStringWithNumbers(authCode)){
			Reporter.failureReport("Authorisation Code at Position 61: 6-digit number", authCode);
			flag = false;
		}
		
		//AUTHORIZATION SOURCE @67 LENGTH 1 -- EXPECTED [V,M,P,D,A,E,O,S,I, space-not defined]
		String authSource = transactionDetail.substring(66, 67);
		if(!authSource.contentEquals("V") && !transactionType.contentEquals(" ") && !authSource.contentEquals("M")
				&& !authSource.contentEquals("P") && !authSource.contentEquals("D") && !authSource.contentEquals("A")
				&& !authSource.contentEquals("E") && !authSource.contentEquals("O") && !authSource.contentEquals("S") && !authSource.contentEquals("I")){
			Reporter.failureReport("Authorization Source at Position 100: V,M,P,D,A,E,O,S,I, space for not defined", authSource);
			flag = false;
		}
		
		//RESPONSE CODE @68 LENGTH 3 -- EXPECTED [3-digit number or spaces]
		String responseCode = transactionDetail.substring(67, 70);
		if(!StringUtils.validateStringWithNumbersAndSpaces(responseCode)){
			Reporter.failureReport("Response Code at Position 68: 3-digit number or spaces", responseCode);
			flag = false;
		}

		//INVOICE NUMBER @71 LENGTH 6 -- EXPECTED [6-digit number]
		String invoiceNumber = transactionDetail.substring(70, 76);
		if(!StringUtils.validateStringWithNumbers(invoiceNumber)){
			Reporter.failureReport("Invoice Number at Position 71: 6-digit number", invoiceNumber);
			flag = false;
		}
		
		//TRANSACTION ID @77 LENGTH 15 -- EXPECTED [15-digit alphanumeric or spaces]
		String transactionId = transactionDetail.substring(76, 91);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(transactionId)){
			Reporter.failureReport("Transaction ID at Position 77: 15-digit alphanumeric or spaces", transactionId);
			flag = false;
		}

		//AMOUNT IN TRANSACTION CURRENCY @92 LENGTH 12 -- EXPECTED [12-digit number, In paise left padded with 0]
		String transactionAmount = transactionDetail.substring(91, 103);
		if(!StringUtils.validateStringWithNumbers(transactionAmount)){
			Reporter.failureReport("TRANSACTION AMOUNT at Position 92: 12-digits left padded with 0", transactionAmount);
			flag = false;
		}

		//CURRENCY CODE @104 LENGTH 3 -- EXPECTED [3-digit number]
		String currencyCode = transactionDetail.substring(103, 106);
		if(!StringUtils.validateStringWithNumbers(currencyCode)){
			Reporter.failureReport("Currency Code at Position 104: 3-digit number or spaces", currencyCode);
			flag = false;
		}

		//CASH BACK AMOUNT @107 LENGTH 12 -- EXPECTED [12-digit number or zeros]
		String cashbackAmount = transactionDetail.substring(106, 118);
		if(!StringUtils.validateStringWithNumbers(cashbackAmount)){
			Reporter.failureReport("Cashback Amount at Position 107: 12-digit number", cashbackAmount);
			flag = false;
		}
		
		//TIP AMOUNT @119 LENGTH 12 -- EXPECTED [12-digit number]
		String tipAmount = transactionDetail.substring(118, 130);
		if(!StringUtils.validateStringWithNumbers(tipAmount)){
			Reporter.failureReport("Tip Amount at Position 119: 12-digit number", tipAmount);
			flag = false;
		}

		//PAN NUMBER @131 LENGTH 19 -- EXPECTED [19-digit alphanumeric number with spaces]
		String panNumber = transactionDetail.substring(130, 149);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(panNumber)){
			Reporter.failureReport("PAN Number at Position 130: 19-digit number or spaces", panNumber);
			flag = false;
		}

		//PAN SEQUENCE NUMBER @150 LENGTH 3 -- EXPECTED [3-digit number with spaces]
		String panSeqNumber = transactionDetail.substring(149, 152);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(panSeqNumber)){
			Reporter.failureReport("PAN Sequence Number at Position 150: 3-digit number or spaces", panSeqNumber);
			flag = false;
		}

		//EXPIRY DATE @153 LENGTH 4 -- EXPECTED [YYMM]
		String expiryDate = transactionDetail.substring(152, 156);
		if(!StringUtils.validateStringWithNumbers(expiryDate)){
			Reporter.failureReport("Expiry Date at Position 153: 4 digits (YYMM)", expiryDate);
			flag = false;
		}

		//SERVICE CODE @157 LENGTH 3 -- EXPECTED [3-digit number with spaces]
		String serviceCode = transactionDetail.substring(156, 159);
		if(!StringUtils.validateStringWithNumbersAndSpaces(serviceCode)){
			Reporter.failureReport("Service Code at Position 156: 3-digit number or spaces", serviceCode);
			flag = false;
		}

		//POS ENTRY MODE @160 LENGTH 3 -- EXPECTED [010, 020, 030, 070, 900, 050, 800, 810, 910, 950]
		String posEntryMode = transactionDetail.substring(159, 162);
		if(!posEntryMode.contentEquals("010") && !posEntryMode.contentEquals("020") && !posEntryMode.contentEquals("030") && !posEntryMode.contentEquals("070")
				&& !posEntryMode.contentEquals("900") && !posEntryMode.contentEquals("050") && !posEntryMode.contentEquals("800") && !posEntryMode.contentEquals("810") 
				&& !posEntryMode.contentEquals("910") && !posEntryMode.contentEquals("950")){
			Reporter.failureReport("POS ENTRY MODE at Position 160: 010, 020, 030, 070, 900, 050, 800, 810, 910, 950", posEntryMode);
			flag = false;
		}

		//POS CONDITION CODE @163 LENGTH 2 -- EXPECTED [00, 01, 02, 03, 05, 08, 59, 71]
		String posConditionCode = transactionDetail.substring(162, 164);
		if(!posConditionCode.contentEquals("00") && !posConditionCode.contentEquals("01") && !posConditionCode.contentEquals("02") && !posConditionCode.contentEquals("03")
				&& !posConditionCode.contentEquals("05") && !posConditionCode.contentEquals("08") && !posConditionCode.contentEquals("59") && !posConditionCode.contentEquals("71")){
			Reporter.failureReport("POS CONDITION CODE at Position 163: 00, 01, 02, 03, 05, 08, 59, 71", posConditionCode);
			flag = false;
		}

		//ECI INDICATOR @165 LENGTH 1 -- EXPECTED [1-digit number]
		String eciIndicator = transactionDetail.substring(164, 165);
		if(!StringUtils.validateStringWithNumbers(eciIndicator)){
			Reporter.failureReport("ECI Indicator at Position 165: 1-digit number", eciIndicator);
			flag = false;
		}

		//APPLICATION CRYPTOGRAM @166 LENGTH 16 -- EXPECTED [16-digit alphanumeric number with spaces]
		String appCryptogram = transactionDetail.substring(165, 181);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(appCryptogram)){
			Reporter.failureReport("Application Cryptogram at Position 166: 16-digit alphanumeric or spaces", appCryptogram);
			flag = false;
		}
		
		//CRYPTOGRAM Information Data @182 LENGTH 2 -- EXPECTED [2-digit alphanumeric number with spaces]
		String cryptogramInfoData = transactionDetail.substring(181, 183);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(cryptogramInfoData)){
			Reporter.failureReport("Cryptogram Information Data at Position 182: 2-digit alphanumeric or spaces", cryptogramInfoData);
			flag = false;
		}

		//ISSUER APPLICATION DATA @184 LENGTH 64 -- EXPECTED [64-digit alphanumeric number with spaces]
		String issuerAppData = transactionDetail.substring(183, 247);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(issuerAppData)){
			Reporter.failureReport("Issuer Application Data at Position 184: 64-digit alphanumeric or spaces", issuerAppData);
			flag = false;
		}

		//UNPREDICTABLE NUMBER @248 LENGTH 8 -- EXPECTED [8-digit alphanumeric number with spaces]
		String unpredictableNumber = transactionDetail.substring(247, 255);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(unpredictableNumber)){
			Reporter.failureReport("Unpredictable Number at Position 248: 8-digit alphanumeric or spaces", unpredictableNumber);
			flag = false;
		}

		//APPLICATION TRANSACTION COUNTER @256 LENGTH 4 -- EXPECTED [4-digit alphanumeric number with spaces]
		String appTransCounter = transactionDetail.substring(255, 259);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(appTransCounter)){
			Reporter.failureReport("Application Transaction Counter at Position 256: 4-digit alphanumeric or spaces", appTransCounter);
			flag = false;
		}
		
		//TERMINAL VERIFICATION RESULTS @260 LENGTH 10 -- EXPECTED [10-digit alphanumeric number with spaces]
		String terminalVerificationResults = transactionDetail.substring(259, 269);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(terminalVerificationResults)){
			Reporter.failureReport("Terminal Verification Results at Position 259: 10-digit alphanumeric or spaces", terminalVerificationResults);
			flag = false;
		}

		//TRANSACTION TYPE @270 LENGTH 2 -- EXPECTED [2-digit alphanumeric number with spaces]
		transactionType = transactionDetail.substring(269, 271);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(transactionType)){
			Reporter.failureReport("Transaction Type at Position 270: 2-digit alphanumeric or spaces", transactionType);
			flag = false;
		}
		
		//TRANSACTION CURRENCY CODE @272 LENGTH 3 -- EXPECTED [3-digit alphanumeric number with spaces]
		String transactionCurrencyCode = transactionDetail.substring(271, 274);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(transactionCurrencyCode)){
			Reporter.failureReport("Transaction Currency Code at Position 272: 3-digit alphanumeric or spaces", transactionCurrencyCode);
			flag = false;
		}
		
		//APPLICATION INTERCHANGE PROFILE @275 LENGTH 4 -- EXPECTED [4-digit alphanumeric number with spaces]
		String appInterchangeProfile = transactionDetail.substring(274, 278);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(appInterchangeProfile)){
			Reporter.failureReport("Application Interchange Profile at Position 275: 4-digit alphanumeric or spaces", appInterchangeProfile);
			flag = false;
		}

		//TERMINAL COUNTRY CODE @279 LENGTH 4 -- EXPECTED [4-digit alphanumeric number with spaces]
		String terminalCountryCode = transactionDetail.substring(278, 282);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(terminalCountryCode)){
			Reporter.failureReport("Terminal Country Code at Position 279: 4-digit alphanumeric or spaces", terminalCountryCode);
			flag = false;
		}

		//CVM RESULTS @283 LENGTH 6 -- EXPECTED [6-digit alphanumeric number with spaces]
		String cvmResults = transactionDetail.substring(282, 288);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(cvmResults)){
			Reporter.failureReport("CVM Results at Position 283: 6-digit alphanumeric or spaces", cvmResults);
			flag = false;
		}
		
		//TERMINAL CAPABILITIES @289 LENGTH 10 -- EXPECTED [10-digit alphanumeric number with spaces]
		String terminalCapabilities = transactionDetail.substring(288, 298);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(terminalCapabilities)){
			Reporter.failureReport("Terminal Capabilities at Position 289: 10-digit alphanumeric or spaces", terminalCapabilities);
			flag = false;
		}
		
		//TERMINAL TYPE @299 LENGTH 2 -- EXPECTED [2-digit alphanumeric number with spaces]
		String terminalType = transactionDetail.substring(298, 300);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(terminalType)){
			Reporter.failureReport("Terminal Type at Position 299: 2-digit alphanumeric or spaces", terminalType);
			flag = false;
		}
		
		//IFD SERIAL NUMBER @301 LENGTH 8 -- EXPECTED [8-digit alphanumeric number with spaces]
		String ifdSerialNumber = transactionDetail.substring(300, 308);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(ifdSerialNumber)){
			Reporter.failureReport("IFD Serial Number at Position 301: 8-digit alphanumeric or spaces", ifdSerialNumber);
			flag = false;
		}

		//APPLICATION VERSION NUMBER @309 LENGTH 4 -- EXPECTED [4-digit alphanumeric number with spaces]
		String appVersionNumber = transactionDetail.substring(308, 312);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(appVersionNumber)){
			Reporter.failureReport("Application Version Number at Position 309: 4-digit alphanumeric or spaces", appVersionNumber);
			flag = false;
		}

		//TRANSACTION SEQUENCE NUMBER @313 LENGTH 8 -- EXPECTED [8-digit alphanumeric number with spaces]
		String transSeqNumber = transactionDetail.substring(312, 320);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(transSeqNumber)){
			Reporter.failureReport("Transaction Sequence Number at Position 313: 8-digit alphanumeric or spaces", transSeqNumber);
			flag = false;
		}

		//ISSUER SCRIPT RESULTS @321 LENGTH 10 -- EXPECTED [10-digit alphanumeric number with spaces]
		String issuerScriptResults = transactionDetail.substring(320, 330);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(issuerScriptResults)){
			Reporter.failureReport("Issuer Script Results at Position 321: 10-digit alphanumeric or spaces", issuerScriptResults);
			flag = false;
		}

		//OTHER AMOUNT @331 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String otherAmount = transactionDetail.substring(330, 342);
		if(!StringUtils.validateStringWithNumbersAndSpaces(otherAmount)){
			Reporter.failureReport("Other Amount at Position 331: 12-digit number or spaces", otherAmount);
			flag = false;
		}

		//CRYPTOGRAM AMOUNT @343 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String cryptogramAmount = transactionDetail.substring(342, 354);
		if(!StringUtils.validateStringWithNumbersAndSpaces(cryptogramAmount)){
			Reporter.failureReport("Cryptogram Amount at Position 343: 12-digit number or spaces", cryptogramAmount);
			flag = false;
		}

		//DCC EXCHANGE RATE @355 LENGTH 7 -- EXPECTED [7-digit number with spaces]
		String dccExchangeRate = transactionDetail.substring(354, 361);
		if(!StringUtils.validateStringWithNumbersAndSpaces(dccExchangeRate)){
			Reporter.failureReport("DCC Exchange Rate at Position 355: 7-digit number or spaces", dccExchangeRate);
			flag = false;
		}

		//AMOUNT IN INR @362 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String inrAmount = transactionDetail.substring(361, 373);
		if(!StringUtils.validateStringWithNumbersAndSpaces(inrAmount)){
		Reporter.failureReport("Amount In INR at Position 362: 12-digit number or spaces", inrAmount);
			flag = false;
		}

		//EMI PROGRAM CODE @374 LENGTH 6 -- EXPECTED [6-digit alphanumeric with spaces]
		String emiProgramCode = transactionDetail.substring(373, 379);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(emiProgramCode)){
		Reporter.failureReport("EMI Program Code at Position 374: 6-digit alphanumeric or spaces", emiProgramCode);
			flag = false;
		}

		//EMI PRODUCT CODE @380 LENGTH 15 -- EXPECTED [15-digit alphanumeric with spaces]
		String emiProductCode = transactionDetail.substring(379, 394);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(emiProductCode)){
		Reporter.failureReport("EMI Product Code at Position 380: 15-digit alphanumeric or spaces", emiProductCode);
			flag = false;
		}

		//EMI TENURE @395 LENGTH 2 -- EXPECTED [2-digit number with spaces]
		String emiTenure = transactionDetail.substring(394, 396);
		if(!StringUtils.validateStringWithNumbersAndSpaces(emiTenure)){
		Reporter.failureReport("EMI Tenure at Position 395: 2-digit number or spaces", emiTenure);
			flag = false;
		}

		//EMI DISC FLAG TYPE @397 LENGTH 1 -- EXPECTED [1-digit number with spaces]
		String emiDiscFlagType = transactionDetail.substring(396, 397);
		if(!StringUtils.validateStringWithNumbersAndSpaces(emiDiscFlagType)){
		Reporter.failureReport("EMI Disc Flag Type at Position 397: 1-digit number or spaces", emiDiscFlagType);
			flag = false;
		}

		//EMI AMOUNT @398 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String emiAmount = transactionDetail.substring(397, 409);
		if(!StringUtils.validateStringWithNumbersAndSpaces(emiAmount)){
		Reporter.failureReport("Amount In INR at Position 398: 12-digit number or spaces", emiAmount);
			flag = false;
		}

		//EMI ROI @410 LENGTH 4 -- EXPECTED [4-digit number with spaces]
		String emiRoi = transactionDetail.substring(409, 413);
		if(!StringUtils.validateStringWithNumbersAndSpaces(emiRoi)){
		Reporter.failureReport("EMI ROI at Position 410: 4-digit number or spaces", emiRoi);
			flag = false;
		}

		//EMI PERCENTAGE @414 LENGTH 4 -- EXPECTED [4-digit number with spaces]
		String emiPercentage = transactionDetail.substring(413, 417);
		if(!StringUtils.validateStringWithNumbersAndSpaces(emiPercentage)){
		Reporter.failureReport("EMI Percentage at Position 414: 4-digit number or spaces", emiPercentage);
			flag = false;
		}

		//EMI DISCOUNT AMOUNT @418 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String emiDiscountAmount = transactionDetail.substring(417, 429);
		if(!StringUtils.validateStringWithNumbersAndSpaces(emiDiscountAmount)){
		Reporter.failureReport("EMI Discount Amount at Position 418: 12-digit number or spaces", emiDiscountAmount);
			flag = false;
		}
		
		//EMI FIXED AMOUNT @430 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String emiFixedAmount = transactionDetail.substring(429, 441);
		if(!StringUtils.validateStringWithNumbersAndSpaces(emiFixedAmount)){
		Reporter.failureReport("EMI Fixed Amount at Position 430: 12-digit number or spaces", emiFixedAmount);
			flag = false;
		}
		
		//EMI CAP AMOUNT @442 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String emiCapAmount = transactionDetail.substring(441, 453);
		if(!StringUtils.validateStringWithNumbersAndSpaces(emiCapAmount)){
		Reporter.failureReport("EMI Cap Amount at Position 442: 12-digit number or spaces", emiCapAmount);
			flag = false;
		}
		
		//PROC FEE PERCENTAGE @454 LENGTH 4 -- EXPECTED [4-digit number with spaces]
		String procFeePercentage = transactionDetail.substring(453, 457);
		if(!StringUtils.validateStringWithNumbersAndSpaces(procFeePercentage)){
		Reporter.failureReport("PROC Fee Percentage at Position 454: 4-digit number or spaces", procFeePercentage);
			flag = false;
		}

		//EMI TOTAL AMOUNT @458 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String emiTotalAmount = transactionDetail.substring(457, 469);
		if(!StringUtils.validateStringWithNumbersAndSpaces(emiTotalAmount)){
		Reporter.failureReport("EMI Total Amount at Position 458: 12-digit number or spaces", emiTotalAmount);
			flag = false;
		}
		
		//EFF COST CUSTOMER @470 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String effCostCustomer = transactionDetail.substring(469, 481);
		if(!StringUtils.validateStringWithNumbersAndSpaces(effCostCustomer)){
		Reporter.failureReport("EFF Cost Customer at Position 470: 12-digit number or spaces", effCostCustomer);
			flag = false;
		}

		//PASS TICKET INDICATOR @482 LENGTH 1 -- EXPECTED [P-Pass, T-Ticket, Space for non-Lodha transaction]
		String passTicketIndicator = transactionDetail.substring(481, 482);
		if(!passTicketIndicator.contentEquals("P") && !passTicketIndicator.contentEquals("T") && !passTicketIndicator.contentEquals(" ")){
			Reporter.failureReport("Pass - Ticket Indicator at Position 482: P-Pass, T-Ticket, Space for non-Lodha transaction", passTicketIndicator);
			flag = false;
		}

		//AGGREGATOR TRANSACTION IDENTIFIER @483 LENGTH 2 -- EXPECTED [MA-MASTER, VA-VISA, AA-AMEX, RA-RUPAY]
		String aggTransId = transactionDetail.substring(482, 484);
		if(!aggTransId.contentEquals("MA") && !aggTransId.contentEquals("VA") && !aggTransId.contentEquals("AA") && !aggTransId.contentEquals("RA") && !aggTransId.contentEquals("  ")){
			Reporter.failureReport("Aggregator Transaction Identifier at Position 483: MA-MASTER, VA-VISA, AA-AMEX, RA-RUPAY", aggTransId);
			flag = false;
		}

		//PROCESSING CODE @485 LENGTH 6 -- EXPECTED [6-digit alphanumeric with spaces]
		String processingCode  = transactionDetail.substring(484, 490);
		if(!StringUtils.validateStringWithNumbersAndSpaces(processingCode)){
		Reporter.failureReport("Processing Code at Position 485: 6-digit number or spaces", processingCode);
			flag = false;
		}

		//MERCHANT CATEGORY CODE @491 LENGTH 4 -- EXPECTED [4-digit alphanumeric with spaces]
		String merchCategoryCode = transactionDetail.substring(490, 494);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(merchCategoryCode)){
		Reporter.failureReport("Merchant Category Code at Position 491: 4-digit alphanumeric or spaces", merchCategoryCode);
			flag = false;
		}
		
		//PAYMENT AGGREGATOR ID @495 LENGTH 15 -- EXPECTED [15-digit alphanumeric with spaces]
		String paymentAggregatorId = transactionDetail.substring(494, 509);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(paymentAggregatorId)){
		Reporter.failureReport("Payment Aggregator ID at Position 495: 15-digit alphanumeric or spaces", paymentAggregatorId);
			flag = false;
		}
		
		//AGGREGATOR SUB-MERCHANT NAME @510 LENGTH 30 -- EXPECTED [30-digit alphanumeric with spaces]
		String aggSubMerchantName = transactionDetail.substring(509, 539);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(aggSubMerchantName)){
		Reporter.failureReport("Aggregator Submerchant Name at Position 510: 30-digit alphanumeric or spaces", aggSubMerchantName);
			flag = false;
		}
		
		//CONVENIENCE FEE/MSF FLAG @540 LENGTH 1 -- EXPECTED [C-CONVENIENCE, M-MSF]
		String convMsfFlag = transactionDetail.substring(539, 540);
		if(!convMsfFlag.contentEquals("C") && !convMsfFlag.contentEquals("M")){
			Reporter.failureReport("Convenience/MSF Flag at Position 540: C-CONVENIENCE, M-MSF", convMsfFlag);
			flag = false;
		}

		//MSF AMOUNT @541 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String msfAmount = transactionDetail.substring(540, 552);
		if(!StringUtils.validateStringWithNumbersAndSpaces(msfAmount)){
		Reporter.failureReport("MSF Amount at Position 541: 12-digit number or spaces", msfAmount);
			flag = false;
		}

		//TAX AMOUNT 1 @553 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String taxAmount1 = transactionDetail.substring(552, 564);
		if(!StringUtils.validateStringWithNumbersAndSpaces(taxAmount1)){
		Reporter.failureReport("Tax Amount 1 at Position 553: 12-digit number or spaces", taxAmount1);
			flag = false;
		}
		
		//TAX AMOUNT 2 @565 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String taxAmount2 = transactionDetail.substring(564, 576);
		if(!StringUtils.validateStringWithNumbersAndSpaces(taxAmount2)){
		Reporter.failureReport("Tax Amount 2 at Position 565: 12-digit number or spaces", taxAmount2);
			flag = false;
		}

		//SURCHARGE AMOUNT @577 LENGTH 12 -- EXPECTED [12-digit number with spaces]
		String surchargeAmount = transactionDetail.substring(576, 588);
		if(!StringUtils.validateStringWithNumbersAndSpaces(surchargeAmount)){
		Reporter.failureReport("Surcharge Amount at Position 577: 12-digit number or spaces", surchargeAmount);
			flag = false;
		}
		
		//FILLER @589 LENGTH 161 -- EXPECTED [161 spaces]
		String filler = transactionDetail.substring(588, 749);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(filler)){
			Reporter.failureReport("Filler at Position 589: 161 spaces", filler);
			flag = false;
		}

		return flag;
	}

	public static boolean validateBatchTrailer(String batchTrailer) throws Throwable{
		boolean flag = true;

		//BATCH NUMBER @5 LENGTH 6 -- EXPECTED [batch number left padded with "0"]
		String batchNumber = batchTrailer.substring(4, 10);
		if(!StringUtils.validateStringWithNumbers(batchNumber)){
			Reporter.failureReport("Batch Number at Position 5: 6 digits left padded with 0", batchNumber);
			flag = false;
		}

		//RECORD COUNT @11 LENGTH 12 -- EXPECTED [record count left padded with "0"]
		String recordCount = batchTrailer.substring(10, 22);
		if(!StringUtils.validateStringWithNumbers(recordCount)){
			Reporter.failureReport("Record Count at Position 11: 12 digits left padded with 0", recordCount);
			flag = false;
		}

		//CREDIT TRANSACTION COUNT @23 LENGTH 8 -- EXPECTED [credit transaction count left padded with "0"]
		String creditTransCount = batchTrailer.substring(22, 30);
		if(!StringUtils.validateStringWithNumbers(creditTransCount)){
			Reporter.failureReport("Credit Transaction Count at Position 23: 8 digits left padded with 0", creditTransCount);
			flag = false;
		}

		//CREDIT TRANSACTION AMOUNT @31 LENGTH 16 -- EXPECTED [credit transaction amount left padded with "0"]
		String creditTransAmount = batchTrailer.substring(30, 46);
		if(!StringUtils.validateStringWithNumbers(creditTransAmount)){
			Reporter.failureReport("Credit Transaction Amount at Position 31: 16 digits left padded with 0", creditTransAmount);
			flag = false;
		}
		
		//DEBIT TRANSACTION COUNT @47 LENGTH 8 -- EXPECTED [debit transaction count left padded with "0"]
		String debitTransCount = batchTrailer.substring(46, 54);
		if(!StringUtils.validateStringWithNumbers(debitTransCount)){
			Reporter.failureReport("Debit Transaction Count at Position 47: 8 digits left padded with 0", debitTransCount);
			flag = false;
		}

		//DEBIT TRANSACTION AMOUNT @55 LENGTH 16 -- EXPECTED [debit transaction amount left padded with "0"]
		String debitTransAmount = batchTrailer.substring(54, 70);
		if(!StringUtils.validateStringWithNumbers(debitTransAmount)){
			Reporter.failureReport("Credit Transaction Amount at Position 55: 16 digits left padded with 0", debitTransAmount);
			flag = false;
		}

		//TOTAL TIP AMOUNT @71 LENGTH 16 -- EXPECTED [total tip amount left padded with "0"]
		String totalTipAmount = batchTrailer.substring(70, 86);
		if(!StringUtils.validateStringWithNumbers(totalTipAmount)){
			Reporter.failureReport("Total Tip Amount at Position 71: 16 digits left padded with 0", totalTipAmount);
			flag = false;
		}

		//TOTAL CASHBACK AMOUNT @87 LENGTH 16 -- EXPECTED [Total Cashback amount left padded with "0"]
		String totalCashbackAmount = batchTrailer.substring(86, 102);
		if(!StringUtils.validateStringWithNumbers(totalCashbackAmount)){
			Reporter.failureReport("Total Cashback Amount at Position 87: 16 digits left padded with 0", totalCashbackAmount);
			flag = false;
		}
		
		//ECOM TRANSACTION COUNT @103 LENGTH 8 -- EXPECTED [ecom transaction count left padded with "0"]
		String ecomTransCount = batchTrailer.substring(102, 110);
		if(!StringUtils.validateStringWithNumbers(ecomTransCount)){
			Reporter.failureReport("ECOM Transaction Count at Position 103: 8 digits left padded with 0", ecomTransCount);
			flag = false;
		}

		//ECOM TRANSACTION AMOUNT @111 LENGTH 16 -- EXPECTED [ecom transaction amount left padded with "0"]
		String ecomTransAmount = batchTrailer.substring(110, 126);
		if(!StringUtils.validateStringWithNumbers(ecomTransAmount)){
			Reporter.failureReport("ECOM Transaction Amount at Position 111: 16 digits left padded with 0", ecomTransAmount);
			flag = false;
		}
		
		//Other CNP TRANSACTION COUNT @127 LENGTH 8 -- EXPECTED [other CNP transaction count left padded with "0"]
		String otherCnpTransCount = batchTrailer.substring(126, 134);
		if(!StringUtils.validateStringWithNumbers(otherCnpTransCount)){
			Reporter.failureReport("Other CNP Transaction Count at Position 127: 8 digits left padded with 0", otherCnpTransCount);
			flag = false;
		}

		//Other CNP TRANSACTION AMOUNT @135 LENGTH 16 -- EXPECTED [other CNP transaction amount left padded with "0"]
		String otherCnpTransAmount = batchTrailer.substring(134, 150);
		if(!StringUtils.validateStringWithNumbers(otherCnpTransAmount)){
			Reporter.failureReport("Other CNP Transaction Amount at Position 135: 16 digits left padded with 0", otherCnpTransAmount);
			flag = false;
		}
		
		//PCPOS TRANSACTION COUNT @151 LENGTH 8 -- EXPECTED [PCPOS transaction count left padded with "0"]
		String pcposTransCount = batchTrailer.substring(150, 158);
		if(!StringUtils.validateStringWithNumbers(pcposTransCount)){
			Reporter.failureReport("PCPOS Transaction Count at Position 151: 8 digits left padded with 0", pcposTransCount);
			flag = false;
		}

		//PCPOS TRANSACTION AMOUNT @159 LENGTH 16 -- EXPECTED [PCPOS transaction amount left padded with "0"]
		String pcposTransAmount = batchTrailer.substring(158, 174);
		if(!StringUtils.validateStringWithNumbers(pcposTransAmount)){
			Reporter.failureReport("PCPOS Transaction Amount at Position 159: 16 digits left padded with 0", pcposTransAmount);
			flag = false;
		}

		//FILLER @175 LENGTH 575 -- EXPECTED [575-length alphanumeric]
		String filler = batchTrailer.substring(174, 749);
		if(!StringUtils.validateStringWithLettersNumbersAndSpaces(filler)){
			Reporter.failureReport("Filler at Position 175: 575-length alphanumeric with spaces", filler);
			flag = false;
		}
		return flag;
	}
}
	
	
