package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;

import com.IpgTransAdminPortal.testObjects.AddLedgerAccountPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;

public class AddLedgerAccountPage extends ActionEngine {

	public String lvName;
	public String ledgerAccNumber;
	public String accHead;
	public String accPurpose;
	public String remarks;
	public String accFor;
	public String accRefNumber;
	public String nessieGlCode;
	public String accName;
	
	static Logger logger = Logger.getLogger(AddLedgerAccountPage.class.getName());
	public boolean addLedgerAccount() throws Throwable {
		HtmlReportSupport.reportStep("Add Ledger Account");
		boolean result = false;
		HtmlReportSupport.reportStep("Fill Add Ledger Account Form");
		selectByVisibleText(AddLedgerAccountPageLocators.lvName_select, lvName, "Legal Vehicle Name");
		type(AddLedgerAccountPageLocators.ledgerAcNo_txt, ledgerAccNumber, "Ledger Account Number");
		type(AddLedgerAccountPageLocators.accHead_txt, accHead, "Account Head");
		type(AddLedgerAccountPageLocators.accPurpose_txt, accPurpose, "Account Purpose");
		type(AddLedgerAccountPageLocators.remarks_txt, remarks, "Remarks");
		selectByVisibleText(AddLedgerAccountPageLocators.accFor_select, accFor, "Account For");
		if(accRefNumber!="" && accRefNumber!=null){
			selectByVisibleText(AddLedgerAccountPageLocators.accRefNo_select, accRefNumber, "Account Reference Number");
		}
		type(AddLedgerAccountPageLocators.nessieGlCode_txt, nessieGlCode, "Nessie GL Code");
		type(AddLedgerAccountPageLocators.accName_txt, accName, "Account Name");
		click(AddLedgerAccountPageLocators.submit_btn, "Submit button");
		
		//VALIDATION OF NEW TAX
		HtmlReportSupport.reportStep("VALIDATION of LEDGER ACCOUNT");
		if(isElementPresent(AddLedgerAccountPageLocators.ledgerAccSuccess_msg, "Ledger Account Successful - Message")){
			result = true;
		}
		return result;
	}
	
	public void setLvName(String lvName) {
		this.lvName = lvName;
	}
	public void setLedgerAccNumber(String ledgerAccNumber) {
		this.ledgerAccNumber = ledgerAccNumber;
	}
	public void setAccHead(String accHead) {
		this.accHead = accHead;
	}
	public void setAccPurpose(String accPurpose) {
		this.accPurpose = accPurpose;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public void setAccFor(String accFor) {
		this.accFor = accFor;
	}
	public void setAccRefNumber(String accRefNumber) {
		this.accRefNumber = accRefNumber;
	}
	public void setNessieGlCode(String nessieGlCode) {
		this.nessieGlCode = nessieGlCode;
	}
	public void setAccName(String accName) {
		this.accName = accName;
	}
	
}