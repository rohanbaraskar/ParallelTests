package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.IpgTransAdminPortal.testObjects.AddFacilitatorPageLocators;
import com.IpgTransAdminPortal.testObjects.DisputeManagementPageLocators;
import com.IpgTransAdminPortal.testObjects.MerchantPayAdvicePageLocators;
import com.IpgTransAdminPortal.testObjects.NetbankCancelDownloadPageLocators;
import com.IpgTransAdminPortal.testObjects.NetbankReconUploadPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementFileGenPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementFileReconPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class NetbankCancelDownloadPage extends ActionEngine {

	public String lvId;
	public String bankName;
	public String batchRunId;
	
	static Logger logger = Logger.getLogger(NetbankCancelDownloadPage.class.getName());
	ExcelReader bufferxls = new ExcelReader(configProps.getProperty("TempData"), "buffer");
	
	public boolean netbankCancelDownload() throws Throwable {
		HtmlReportSupport.reportStep("Netbank Cancel/Refund Download");
		boolean result = false;
		//boolean successFlag = false;
		
		selectByVisibleText(NetbankCancelDownloadPageLocators.lvId_select, lvId, "Legal Vehicle - Select");
		Thread.sleep(3000);
		waitForElementPresent(NetbankCancelDownloadPageLocators.netbankName_select, "Netbank Name - Select");
		selectByVisibleText(NetbankCancelDownloadPageLocators.netbankName_select, bankName, "Netbank Name - Select");
		Thread.sleep(2000);
		click(NetbankCancelDownloadPageLocators.generate_btn, "Generate button");
		waitForElementPresent(NetbankCancelDownloadPageLocators.netbankCancelDownloadSuccessConfirm_msg, "Netbank File Request Generated Successfully - Message");
		/*
		Thread.sleep(10000);
		while(isElementDisplayed(NetbankCancelDownloadPageLocators.fileGenPending_row, "Pending Status")||isElementDisplayed(NetbankCancelDownloadPageLocators.fileGenInProgress_row, "In Progress Status")){
			Thread.sleep(10000);
			click(NetbankCancelDownloadPageLocators.refresh_btn, "Refresh button");
			Thread.sleep(10000);
			if(isElementDisplayed(NetbankCancelDownloadPageLocators.fileGenSuccess_row, "File Generation Success Status")){
				successFlag = true;
			}			
		}
		
		if (successFlag)
			result = true;
		else if(!successFlag)
			Reporter.failureReport("File Generation", "FAILED");
		*/
		batchRunId = getText(NetbankCancelDownloadPageLocators.firstRow_batchRunId, "Batch Run ID");
		result = bufferxls.setCellData("buffer", "netbankRefundCancelDownload_batchRunId", 2, batchRunId);
		
		return result;
	}

	public boolean netbankCancelDownload_Validation() throws Throwable {
		HtmlReportSupport.reportStep("Netbank Refund/Cancel Download Validation");
		boolean result = false;
		
		batchRunId = bufferxls.getCellData("buffer", "netbankRefundCancelDownload_batchRunId", 2);
		type(NetbankCancelDownloadPageLocators.search_txt, batchRunId, "Search");
		
		if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'Pending')]"), "Batch RUN - PENDING")){
			Reporter.failureReport("Batch Run Status/Netbank Refund Cancel Download Status", "PENDING");
		}else if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'In Progress')]"), "Batch RUN - In Progress")){
			Reporter.failureReport("Batch Run Status/Netbank Refund Cancel Download Status", "In Progress");
		}else if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'FAILED')]"), "Batch RUN - FAILED")){
			Reporter.failureReport("Batch Run Status/Netbank Refund Cancel Download Status", "FAILED");
		}else if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'SUCCESS')]"), "Batch RUN - SUCCESS")){
			Reporter.SuccessReport("Batch Run Status/Netbank Refund Cancel Download Status", "SUCCESS");
			result = true;
		}
		
		return result;
	}
	
	public void setLvId(String lvId) {
		this.lvId = lvId;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
}