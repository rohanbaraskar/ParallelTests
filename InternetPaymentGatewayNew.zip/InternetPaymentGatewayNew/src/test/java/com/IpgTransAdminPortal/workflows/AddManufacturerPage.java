package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import com.IpgTransAdminPortal.testObjects.AddManufacturerPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;

public class AddManufacturerPage extends ActionEngine {

	public String manufactName;
	public String manufactCode;
	public String prodName;
	public String emiProdCode;
	public String itemCode;
	
	static Logger logger = Logger.getLogger(AddManufacturerPage.class.getName());
	public boolean addManufacturer() throws Throwable {
		HtmlReportSupport.reportStep("Add Manufacturer");
		boolean result = false;
		HtmlReportSupport.reportStep("MANUFACTURER DETAILS");
		type(AddManufacturerPageLocators.manufactName_txt, manufactName, "Manufacturer Name");
		type(AddManufacturerPageLocators.manufactCode_txt, manufactCode, "Manufacturer Code");
		type(AddManufacturerPageLocators.prodName_txt, prodName, "Product Name");
		type(AddManufacturerPageLocators.emiProdCode_txt, emiProdCode, "EMI Product Code");
		type(AddManufacturerPageLocators.itemCode_txt, itemCode, "Item Code");
		click(AddManufacturerPageLocators.add_btn, "Add button");
		Thread.sleep(2000);
		click(AddManufacturerPageLocators.submit_btn, "Submit button");
		//VALIDATION OF NEW MANUFACTURER
		HtmlReportSupport.reportStep("VALIDATION of NEW MANUFACTURER");
		if(isElementPresent(AddManufacturerPageLocators.manufactSuccessful_mg, "Add Manufacturer Successful - Message")){
			result = true;
		}
		return result;
	}
	public void setManufactName(String manufactName) {
		this.manufactName = manufactName;
	}
	public void setManufactCode(String manufactCode) {
		this.manufactCode = manufactCode;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public void setEmiProdCode(String emiProdCode) {
		this.emiProdCode = emiProdCode;
	}
	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}
	
}