package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;

import com.IpgTransAdminPortal.testObjects.HomePageLocators;
import com.IpgTransAdminPortal.testObjects.LoginLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class LoginPage extends ActionEngine{
	
	public String UserName;
	public String Password;
	
	public void setUserName(String userName) {
		UserName = userName;
	}
	public void setPassword(String password) {
		Password = password;
	}

	static Logger logger = Logger.getLogger(LoginPage.class.getName());
	
	/**
	 * Sign in to IPD Transaction Admin Portal
	 * @return
	 * @throws Throwable
	 */
	public boolean login() throws Throwable{
		boolean result = false;
		ImplicitWait();		
		HtmlReportSupport.reportStep("Login Credentials_Entry");
		
		if(waitForElementPresent(LoginLocators.userId_txt, "Login Page"))
		{
			Reporter.SuccessReport("IPG Admin Portal","Login Page loaded succesfully");
			type(LoginLocators.userId_txt, UserName, "Username Field");
			type(LoginLocators.password,Password, "Password Field");
			click(LoginLocators.login_btn, "Login Button");
			waitForElementPresent(HomePageLocators.merchManagement_mnu, "Home Page");
			result = true;
		}
		return result;
	}	
}