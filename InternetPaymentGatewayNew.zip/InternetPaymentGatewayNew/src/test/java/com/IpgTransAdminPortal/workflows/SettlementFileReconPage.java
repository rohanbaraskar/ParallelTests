package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.IpgTransAdminPortal.testObjects.AddFacilitatorPageLocators;
import com.IpgTransAdminPortal.testObjects.DisputeManagementPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementFileGenPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementFileReconPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;

public class SettlementFileReconPage extends ActionEngine {

	public String batchRunId;
	
	public void setBatchRunId(String batchRunId) {
		this.batchRunId = batchRunId;
	}
	
	static Logger logger = Logger.getLogger(SettlementFileReconPage.class.getName());
	public boolean settlementFileReconciliation() throws Throwable {
		HtmlReportSupport.reportStep("Settlement File Reconciliation");
		boolean result = false;
		type(SettlementFileReconPageLocators.search_txt, batchRunId, "search");
		click(By.xpath("//a[contains(text(),'"+batchRunId+"')]"), "Batch Run Id");		
		waitForElementPresent(SettlementFileReconPageLocators.settleFileReconDetails_lbl, "Settlement File Reconciliation Details");
		click(SettlementFileReconPageLocators.confirm_btn, "Confirm button");
		waitForElementPresent(SettlementFileReconPageLocators.settleFileConfirm_msg, "Settlement File Confirmation Message");
				
		result = true;
		return result;
	}
		
}
