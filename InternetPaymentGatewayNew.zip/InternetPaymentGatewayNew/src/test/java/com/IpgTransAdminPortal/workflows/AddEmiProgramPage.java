package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.IpgTransAdminPortal.testObjects.AddEmiProgramPageLocators;
import com.IpgTransAdminPortal.testObjects.AddLegalVehiclePageLocators;
import com.IpgTransAdminPortal.testObjects.HomePageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;

public class AddEmiProgramPage extends ActionEngine {

	public String lvName;
	public String programCode;
	public String programDescription;
	public String interestRate;
	public String processFeePercent;
	public String processFeeFix;
	public String validFrom;
	public String validTo;
	public String minAmount;
	public String maxAmount;
	public String emiDiscType;
	public String emiDiscPercentFixed;
	public String emiAddDiscAmount;
	public String maxCapAmount;
	public String taxCode;
	public String taxFor;
	public String tenure;
	public String programMapChannel;
	public String issuerBank;
	public String acqBank;
	public String merchName;
	public String manufacturerName;
	public String prodName;
	
	static Logger logger = Logger.getLogger(AddEmiProgramPage.class.getName());
	public boolean addEmiProgram() throws Throwable {
		HtmlReportSupport.reportStep("Add EMI Program");
		boolean result = false;
		HtmlReportSupport.reportStep("EMI BASIC DETAILS");
		selectByVisibleText(AddEmiProgramPageLocators.lvName_select, lvName, "Legal Vehicle Name");
		type(AddEmiProgramPageLocators.programCode_txt, programCode, "Program Code");
		type(AddEmiProgramPageLocators.programDescription_txt, programDescription, "Program Description");
		type(AddEmiProgramPageLocators.interestRate_txt, interestRate, "Interest Rate");
		if(!processFeePercent.contentEquals(""))
			type(AddEmiProgramPageLocators.processFeePercent_txt, processFeePercent, "Process Fee Percentage");
		if(!processFeeFix.contentEquals(""))
			type(AddEmiProgramPageLocators.processFeeFix_txt, processFeeFix, "Process Fee Fix");
		////////////////////////////////////////////////////////////////////////////////////////////////////
		//need to cover "VALID FROM" AND "VALID TO"
		if((validFrom != null)&&(validFrom != ""))
			js_type(AddEmiProgramPageLocators.validFrom_txt, validFrom, "Valid From");
		else{
			click(AddEmiProgramPageLocators.validFrom_txt, "Valid From");		
			hitKey(AddEmiProgramPageLocators.validFrom_txt, Keys.ENTER, "Valid From");
		}
		//click(AddEmiProgramPageLocators.validFromToday_lnk, "Valid From - Today");
		if((validTo != null)&&(validTo != ""))
			js_type(AddEmiProgramPageLocators.validTo_txt, validTo, "Valid To");
		else{
			click(AddEmiProgramPageLocators.validTo_txt, "Valid To");
			selectByIndex(AddEmiProgramPageLocators.datePickerYear_select, 2, "DatePicker - Year");
			click(AddEmiProgramPageLocators.datePickerDay_link, "Day 1");
		}
		
		////////////////////////////////////////////////////////////////////////////////////////////////////
		type(AddEmiProgramPageLocators.minAmount_txt, minAmount, "Minimum Amount");
		type(AddEmiProgramPageLocators.maxAmount_txt, maxAmount, "Maximum Amount");
		selectByVisibleText(AddEmiProgramPageLocators.emiDiscountType_txt, emiDiscType, "EMI Discount Type");
		if(!emiDiscPercentFixed.contentEquals(""))
			type(AddEmiProgramPageLocators.emiDiscPercentFixed_txt, emiDiscPercentFixed, "EMI Discount Percent Fixed");
		if(!emiAddDiscAmount.contentEquals(""))
			type(AddEmiProgramPageLocators.emiAddDiscAmount_txt, emiAddDiscAmount, "EMI Additional Discount Amount");
		if(!maxCapAmount.contentEquals(""))
			type(AddEmiProgramPageLocators.maxCapAmount_txt, maxCapAmount, "Max CAP Amount");
		
		//TAX MAP
		if(!taxCode.contentEquals("")){
			HtmlReportSupport.reportStep("Add Tax Map");
			selectByVisibleText(AddEmiProgramPageLocators.taxCode_select, taxCode, "Tax Code");
		if(!taxFor.contentEquals(""))
			selectByVisibleText(AddEmiProgramPageLocators.taxFor_select, taxFor, "Tax For");
			click(AddEmiProgramPageLocators.add_btn, "Tax Map - Add Button");
		}
		
		//TENURE
		type(AddEmiProgramPageLocators.tenure_txt, tenure, "Tenure");
		click(AddEmiProgramPageLocators.tenureAdd_btn, "Tenure - Add Button");
		
		//PROGRAM MAP
		selectByVisibleText(AddEmiProgramPageLocators.proMapChannel_select, programMapChannel, "Program Map - Channel");
		selectByVisibleText(AddEmiProgramPageLocators.issuerBank_select, issuerBank, "Program Map - Issuer Bank");
		selectByVisibleText(AddEmiProgramPageLocators.acqBank_select, acqBank, "Program Map - Acquirer Bank");
		type(AddEmiProgramPageLocators.merchName_txt, merchName, "Program Map - Merchant Name");
		if(!manufacturerName.contentEquals(""))
			selectByVisibleText(AddEmiProgramPageLocators.manufacturerName_txt, manufacturerName, "Program Map - Manufacturer Name");
		if(!prodName.contentEquals(""))
			selectByVisibleText(AddEmiProgramPageLocators.prodName_select, prodName, "Program Map - Product Name");
		click(AddEmiProgramPageLocators.programMapAdd_btn, "Program Map - Add Button");
		click(AddEmiProgramPageLocators.submit_btn, "Submit button");
		Thread.sleep(2000);
		//VALIDATION OF NEW EMI PROGRAM
		HtmlReportSupport.reportStep("VALIDATION of NEW EMI PROGRAM");
		if(isElementPresent(AddEmiProgramPageLocators.emiSuccessful_msg, "Add EMI Program Successful - Message")){
			result = true;
		}
		return result;
	}
	
	public boolean approveEmiProgram(String programCode) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View EMI Program Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.emiProgram_mnu, "EMI Program SubMenu");
		
		waitForElementPresent(AddEmiProgramPageLocators.approval_tab, "Approval Tab");
		click(AddEmiProgramPageLocators.approval_tab, "Approval Tab");
		
		waitForElementPresent(HomePageLocators.search_txt, "Search Emi Program box");
		type(HomePageLocators.search_txt, programCode, "Emi Program Search box");
		waitForElementPresent(AddEmiProgramPageLocators.viewEmiProgram_lnk, "View EMI Program Link");
		click(AddEmiProgramPageLocators.viewEmiProgram_lnk, "View EMI Program Link");
		HtmlReportSupport.reportStep("EMI Program Approval");
		waitForElementPresent(AddEmiProgramPageLocators.emiInfoScreen_lbl, "EMI Program Information Page");
		waitForElementPresent(By.xpath("//td[contains(text(),'"+ programCode +"')]"), "EMI Program Code: " + programCode);
		waitForElementPresent(HomePageLocators.appReject_select, "Approve/Reject Select");
		selectByContainsVisibleText(HomePageLocators.appReject_select, "Approve", "Approve/Reject Select");
		type(HomePageLocators.remarks_txtarea, "Test EMI Program Approval Remarks", "Approval Remarks");
		click(AddEmiProgramPageLocators.approval_submit_btn, "Submit Button");
		waitForElementPresent(AddEmiProgramPageLocators.approveEmiProgramSuccess_mg, "EMI Program Approval Success Message");
		result = true;
		return result;
	}
	
	public boolean deactivateEmiProgram(String programCode) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View EMI Program Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.emiProgram_mnu, "EMI Program SubMenu");
		waitForElementPresent(HomePageLocators.search_txt, "Search Emi Program box");
		type(HomePageLocators.search_txt, programCode, "Emi Program Search box");
		waitForElementPresent(AddEmiProgramPageLocators.viewEmiProgram_lnk, "View EMI Program Link");
		click(AddEmiProgramPageLocators.viewEmiProgram_lnk, "View EMI Program Link");
		HtmlReportSupport.reportStep("Deactivate EMI Program");
		waitForElementPresent(AddEmiProgramPageLocators.emiInfoScreen_lbl, "EMI Program Information Page");
		waitForElementPresent(By.xpath("//td[contains(text(),'"+ programCode +"')]"), "EMI Program Code: " + programCode);
		waitForElementPresent(AddEmiProgramPageLocators.deactivateEmiProgram_btn, "Deactivate EMI Button");
		click(AddEmiProgramPageLocators.deactivateEmiProgram_btn, "Deactivate EMI Button");
		waitForElementPresent(AddEmiProgramPageLocators.approveEmiProgramSuccess_mg, "EMI Program Deactivation Success Message");
		result = true;
		return result;
	}
	
	public void setLvName(String lvName) {
		this.lvName = lvName;
	}
	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}
	public void setProgramDescription(String programDescription) {
		this.programDescription = programDescription;
	}
	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}
	public void setProcessFeePercent(String processFeePercent) {
		this.processFeePercent = processFeePercent;
	}
	public void setProcessFeeFix(String processFeeFix) {
		this.processFeeFix = processFeeFix;
	}
	public void setValidFrom(String validFrom) {
		this.validFrom = validFrom;
	}
	public void setValidTo(String validTo) {
		this.validTo = validTo;
	}
	public void setMinAmount(String minAmount) {
		this.minAmount = minAmount;
	}
	public void setMaxAmount(String maxAmount) {
		this.maxAmount = maxAmount;
	}
	public void setEmiDiscType(String emiDiscType) {
		this.emiDiscType = emiDiscType;
	}
	public void setEmiDiscPercentFixed(String emiDiscPercentFixed) {
		this.emiDiscPercentFixed = emiDiscPercentFixed;
	}
	public void setEmiAddDiscAmount(String emiAddDiscAmount) {
		this.emiAddDiscAmount = emiAddDiscAmount;
	}
	public void setMaxCapAmount(String maxCapAmount) {
		this.maxCapAmount = maxCapAmount;
	}
	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}
	public void setTaxFor(String taxFor) {
		this.taxFor = taxFor;
	}
	public void setTenure(String tenure) {
		this.tenure = tenure;
	}
	public void setProgramMapChannel(String programMapChannel) {
		this.programMapChannel = programMapChannel;
	}
	public void setIssuerBank(String issuerBank) {
		this.issuerBank = issuerBank;
	}
	public void setAcqBank(String acqBank) {
		this.acqBank = acqBank;
	}
	public void setMerchName(String merchName) {
		this.merchName = merchName;
	}
	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	
	
}