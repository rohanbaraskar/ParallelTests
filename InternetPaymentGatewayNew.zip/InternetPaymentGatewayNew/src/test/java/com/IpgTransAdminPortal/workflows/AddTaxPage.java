package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import com.IpgTransAdminPortal.testObjects.AddTaxPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;

public class AddTaxPage extends ActionEngine {

	public String legalVehicle;
	public String taxCode;
	public String taxName;
	public String taxPercent;
	public String effectiveFrom;
	public String effectiveTill;
	
	static Logger logger = Logger.getLogger(AddTaxPage.class.getName());
	public boolean addTax() throws Throwable {
		HtmlReportSupport.reportStep("Add Tax");
		boolean result = false;
		HtmlReportSupport.reportStep("Fix Add Tax form");
		selectByVisibleText(AddTaxPageLocators.lv_select, legalVehicle, "Legal Vehicle");
		type(AddTaxPageLocators.taxCode_txt, taxCode, "Tax Code");
		type(AddTaxPageLocators.taxName_txt, taxName, "Tax Name");
		type(AddTaxPageLocators.taxPercent_txt, taxPercent, "Tax Percentage");
		click(AddTaxPageLocators.effectFrom_txt, "Effect From");
		click(AddTaxPageLocators.todayDate_txt, "Current Date");
		click(AddTaxPageLocators.submit_btn, "Submit button");
		
		//VALIDATION OF NEW TAX
		HtmlReportSupport.reportStep("VALIDATION of TAX");
		if(isElementPresent(AddTaxPageLocators.taxSuccess_msg, "Add Tax Successful - Message")){
			result = true;
		}
		return result;
	}
	
	public void setLegalVehicle(String legalVehicle) {
		this.legalVehicle = legalVehicle;
	}
	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}
	public void setTaxName(String taxName) {
		this.taxName = taxName;
	}
	public void setTaxPercent(String taxPercent) {
		this.taxPercent = taxPercent;
	}
	public void setEffectiveFrom(String effectiveFrom) {
		this.effectiveFrom = effectiveFrom;
	}
	public void setEffectiveTill(String effectiveTill) {
		this.effectiveTill = effectiveTill;
	}
	
}