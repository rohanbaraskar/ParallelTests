package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.IpgTransAdminPortal.testObjects.AddAcquirerPageLocators;
import com.IpgTransAdminPortal.testObjects.AddLegalVehiclePageLocators;
import com.IpgTransAdminPortal.testObjects.AddSchemePageLocators;
import com.IpgTransAdminPortal.testObjects.HomePageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;

public class AddLegalVehiclePage extends ActionEngine {

	public String legalVehicleName;
	public String legalVehicleCode;
	public String legalVehicleType;
	public String channelsAvailableIPG;
	public String channelsAvailablePCPOS;
	public String vehicleSchemeMappingChannel;
	public String vehicleSchemeMappingScheme;
	public String vehiclePaymentMappingChannel;
	public String vehiclePaymentMappingPayType;
	public String prodTypeRecurrPayUpload;
	public String prodTypePreAuth;
	public String prodTypeEmailInvoice;
	
	
	public String prodTypeRecurrPayOnline;
	public String prodTypeHostedPages;
	public String prodTypeSmsInvoice;
	
	public String netBankName;
	public String netBankCode;
	public String netBankMerchantId;
	public String transactionUrl;
	public String statusUrl;
	public String netBankingKey;
	public String partnerChannel;


	
	static Logger logger = Logger.getLogger(AddLegalVehiclePage.class.getName());
	public boolean addLegalVehicle() throws Throwable {
		HtmlReportSupport.reportStep("Add Legal Vehicle");
		boolean result = false;
		
		type(AddLegalVehiclePageLocators.legalVehicleName_txt, legalVehicleName, "Legal Vehicle Name");
		type(AddLegalVehiclePageLocators.legalVehicleCode_txt, legalVehicleCode, "Legal Vehicle Code");
		selectByVisibleText(AddLegalVehiclePageLocators.legalVehicleType_select, legalVehicleType, "Legal Vehicle Type");
		
		if(channelsAvailableIPG.equalsIgnoreCase("Y"))
			click(AddLegalVehiclePageLocators.channelsAvailableIPG_chk, "Channels Available - IPG");
		if(channelsAvailablePCPOS.equalsIgnoreCase("Y"))
			click(AddLegalVehiclePageLocators.channelsAvailablePCPOS_chk, "Channels Available - PCPOS");
		
		selectByVisibleText(AddLegalVehiclePageLocators.vehicleSchemeMappingChannel_select, vehicleSchemeMappingChannel,"Legal Vehicle Scheme Mapping - Channel");
		selectByVisibleText(AddLegalVehiclePageLocators.vehicleSchemeMappingScheme_select, vehicleSchemeMappingScheme,"Legal Vehicle Scheme Mapping - Scheme");
		click(AddLegalVehiclePageLocators.vehicleSchemeMappingAdd_btn, "Vehicle Scheme Mapping - Add button");
		Thread.sleep(2000);
		selectByVisibleText(AddLegalVehiclePageLocators.vehiclePaymentMappingChannel_select, vehiclePaymentMappingChannel,"Legal Vehicle Payment Mapping - Channel");
		selectByVisibleText(AddLegalVehiclePageLocators.vehiclePaymentMappingPayType_select, vehiclePaymentMappingPayType,"Legal Vehicle Payment Mapping - Payment Type");
		click(AddLegalVehiclePageLocators.vehiclePayMappingAdd_btn, "Vehicle Payment Mapping - Add button");
		Thread.sleep(2000);
		if(prodTypeRecurrPayUpload.equalsIgnoreCase("Y"))
			click(AddLegalVehiclePageLocators.prodTypeRecurrPayUpload_chk, "Product Type - Recurring Payments Upload");
		if(prodTypePreAuth.equalsIgnoreCase("Y"))
			click(AddLegalVehiclePageLocators.prodTypePreAuth_chk, "Product Type - Pre-Auth");
		if(prodTypeEmailInvoice.equalsIgnoreCase("Y"))
			click(AddLegalVehiclePageLocators.emailInvoice_chk, "Product Type - Email Invoice");
		if(prodTypeRecurrPayOnline.equalsIgnoreCase("Y"))
			click(AddLegalVehiclePageLocators.recurrPayOnline_chk, "Product Type - Recurring Payments Online");
		if(prodTypeHostedPages.equalsIgnoreCase("Y"))
			click(AddLegalVehiclePageLocators.hostedPages_chk, "Product Type - Hosted Pages");
		if(prodTypeSmsInvoice.equalsIgnoreCase("Y"))
			click(AddLegalVehiclePageLocators.smsInvoice_chk, "Product Type - SMS Invoice");
		click(AddLegalVehiclePageLocators.submit_btn, "Submit button");
		//VALIDATION OF SCHEME
		HtmlReportSupport.reportStep("VALIDATION of Legal Vehicle");
		if(isElementPresent(AddLegalVehiclePageLocators.addVehicleSuccess_msg, "Legal Vehicle Added Successfully - Message")){
			result = true;
		}
		return result;
	}
	
	
	public boolean approveLegalVehicle(String lvName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View Legal Vehicle Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.legalVehicle_mnu, "Legal Vehicle SubMenu");
		
		waitForElementPresent(AddLegalVehiclePageLocators.approval_tab, "Approval Tab");
		click(AddLegalVehiclePageLocators.approval_tab, "Approval Tab");
		
		waitForElementPresent(HomePageLocators.search_txt, "Search Scheme box");
		type(HomePageLocators.search_txt, lvName, "Legal Vehicle Search box");
		waitForElementPresent(AddLegalVehiclePageLocators.viewLegalVehicle_lnk, "View Legal Vehicle Link");
		click(AddLegalVehiclePageLocators.viewLegalVehicle_lnk, "View Legal Vehicle Link");
		HtmlReportSupport.reportStep("Legal Vehicle Approval");
		waitForElementPresent(AddLegalVehiclePageLocators.legalVehicleInfoScreen_lbl, "Legal Vehicle Information Page");
		waitForElementPresent(By.xpath("//td[contains(text(),'"+ lvName +"')]"), "Legal Vehicle Name: " + lvName);
		waitForElementPresent(HomePageLocators.appReject_select, "Approve/Reject Select");
		selectByContainsVisibleText(HomePageLocators.appReject_select, "Approve", "Approve/Reject Select");
		type(HomePageLocators.remarks_txtarea, "Test Scheme Approval Remarks", "Approval Remarks");
		click(AddLegalVehiclePageLocators.approval_submit_btn, "Submit Button");
		waitForElementPresent(AddLegalVehiclePageLocators.approveLegalVehicleSuccess_mg, "Legal Vehicle Approval Success Message");
		result = true;
		return result;
	}
	
	public boolean deactivateLegalVehicle(String lvName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View Legal Vehicle Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.legalVehicle_mnu, "Legal Vehicle SubMenu");
		
		waitForElementPresent(HomePageLocators.search_txt, "Search Scheme box");
		type(HomePageLocators.search_txt, lvName, "Legal Vehicle Search box");
		waitForElementPresent(AddLegalVehiclePageLocators.viewLegalVehicle_lnk, "View Legal Vehicle Link");
		click(AddLegalVehiclePageLocators.viewLegalVehicle_lnk, "View Legal Vehicle Link");
		HtmlReportSupport.reportStep("Deactivate Legal Vehicle");
		
		waitForElementPresent(AddLegalVehiclePageLocators.legalVehicleInfoScreen_lbl, "Legal Vehicle Information Page");
		waitForElementPresent(By.xpath("//td[contains(text(),'"+ lvName +"')]"), "Legal Vehicle Name: " + lvName);
		waitForElementPresent(AddLegalVehiclePageLocators.deactivateLegalVehicle_btn, "Deactivate Legal Vehicle button");
		click(AddLegalVehiclePageLocators.deactivateLegalVehicle_btn, "Deactivate Legal Vehicle button");
		waitForElementPresent(AddLegalVehiclePageLocators.deactivateConfirmationYes_btn, "Deactivate Legal Vehicle Confirmation - Yes - button");
		click(AddLegalVehiclePageLocators.deactivateConfirmationYes_btn, "Deactivate Legal Vehicle Confirmation - Yes - button");
		waitForElementPresent(AddLegalVehiclePageLocators.approveLegalVehicleSuccess_mg, "Legal Vehicle Approval Success Message");
		
		result = true;
		return result;
	}
	
	public boolean addNetBankingLegalVehicle(String lvName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View Legal Vehicle Page");
		click(HomePageLocators.cgMasters_mnu,"CG Masters Menu");
		click(HomePageLocators.legalVehicle_mnu, "Legal Vehicle SubMenu");		
		waitForElementPresent(HomePageLocators.search_txt, "Search Scheme box");
		type(HomePageLocators.search_txt, lvName, "Legal Vehicle Search box");
		waitForElementPresent(AddLegalVehiclePageLocators.viewLegalVehicle_lnk, "View Legal Vehicle Link");
		click(AddLegalVehiclePageLocators.viewLegalVehicle_lnk, "View Legal Vehicle Link");
		HtmlReportSupport.reportStep("Add NetBanking - Legal Vehicle");
		waitForElementPresent(AddLegalVehiclePageLocators.legalVehicleInfoScreen_lbl, "Legal Vehicle Information Page");
		waitForElementPresent(By.xpath("//td[contains(text(),'"+ lvName +"')]"), "Legal Vehicle Name: " + lvName);
		waitForElementPresent(AddLegalVehiclePageLocators.addNetBankingLegalVehicle_btn, "Add NetBanking - Legal Vehicle button");
		click(AddLegalVehiclePageLocators.addNetBankingLegalVehicle_btn, "Add NetBanking - Legal Vehicle button");		
		HtmlReportSupport.reportStep("Net Banking Details Page");
		waitForElementPresent(AddLegalVehiclePageLocators.netBankName_txt, "Net Banking Details Page");
		type(AddLegalVehiclePageLocators.netBankName_txt, netBankName, "Net Bank Name");
		type(AddLegalVehiclePageLocators.netBankCode_txt, netBankCode, "Net Bank Code");
		type(AddLegalVehiclePageLocators.netBankMeId_txt, netBankMerchantId, "Net Bank Merchant ID");
		type(AddLegalVehiclePageLocators.transactionUrl_txt, transactionUrl, "Transaction URL");
		type(AddLegalVehiclePageLocators.statusUrl_txt, statusUrl, "Status URL");
		type(AddLegalVehiclePageLocators.netBankKey_txt, netBankingKey, "Net Banking Key");
		selectByVisibleText(AddLegalVehiclePageLocators.partnerChannel_txt, partnerChannel, "Partner Channel");
		click(AddLegalVehiclePageLocators.submit_btn, "Submit button");
		waitForElementPresent(AddLegalVehiclePageLocators.netBankingSuccess_msg, "Net Banking - Success Message");
		
		result = true;
		return result;
	}
	public void setLegalVehicleName(String legalVehicleName) {
		this.legalVehicleName = legalVehicleName;
	}
	public void setLegalVehicleCode(String legalVehicleCode) {
		this.legalVehicleCode = legalVehicleCode;
	}
	public void setLegalVehicleType(String legalVehicleType) {
		this.legalVehicleType = legalVehicleType;
	}
	public void setChannelsAvailableIPG(String channelsAvailableIPG) {
		this.channelsAvailableIPG = channelsAvailableIPG;
	}
	public void setChannelsAvailablePCPOS(String channelsAvailablePCPOS) {
		this.channelsAvailablePCPOS = channelsAvailablePCPOS;
	}
	public void setVehicleSchemeMappingChannel(String vehicleSchemeMappingChannel) {
		this.vehicleSchemeMappingChannel = vehicleSchemeMappingChannel;
	}
	public void setVehicleSchemeMappingScheme(String vehicleSchemeMappingScheme) {
		this.vehicleSchemeMappingScheme = vehicleSchemeMappingScheme;
	}
	public void setVehiclePaymentMappingChannel(String vehiclePaymentMappingChannel) {
		this.vehiclePaymentMappingChannel = vehiclePaymentMappingChannel;
	}
	public void setVehiclePaymentMappingPayType(String vehiclePaymentMappingPayType) {
		this.vehiclePaymentMappingPayType = vehiclePaymentMappingPayType;
	}
	public void setProdTypeRecurrPayUpload(String prodTypeRecurrPayUpload) {
		this.prodTypeRecurrPayUpload = prodTypeRecurrPayUpload;
	}
	public void setProdTypePreAuth(String prodTypePreAuth) {
		this.prodTypePreAuth = prodTypePreAuth;
	}
	public void setProdTypeEmailInvoice(String prodTypeEmailInvoice) {
		this.prodTypeEmailInvoice = prodTypeEmailInvoice;
	}
	public void setProdTypeRecurrPayOnline(String prodTypeRecurrPayOnline) {
		this.prodTypeRecurrPayOnline = prodTypeRecurrPayOnline;
	}
	public void setProdTypeHostedPages(String prodTypeHostedPages) {
		this.prodTypeHostedPages = prodTypeHostedPages;
	}
	public void setProdTypeSmsInvoice(String prodTypeSmsInvoice) {
		this.prodTypeSmsInvoice = prodTypeSmsInvoice;
	}	
	public void setNetBankName(String netBankName) {
		this.netBankName = netBankName;
	}
	public void setNetBankCode(String netBankCode) {
		this.netBankCode = netBankCode;
	}
	public void setNetBankMerchantId(String netBankMerchantId) {
		this.netBankMerchantId = netBankMerchantId;
	}
	public void setTransactionUrl(String transactionUrl) {
		this.transactionUrl = transactionUrl;
	}
	public void setStatusUrl(String statusUrl) {
		this.statusUrl = statusUrl;
	}
	public void setNetBankingKey(String netBankingKey) {
		this.netBankingKey = netBankingKey;
	}
	public void setPartnerChannel(String partnerChannel) {
		this.partnerChannel = partnerChannel;
	}	
	
}