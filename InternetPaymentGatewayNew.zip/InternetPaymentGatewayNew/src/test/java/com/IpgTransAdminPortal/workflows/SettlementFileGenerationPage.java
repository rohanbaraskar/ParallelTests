package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.IpgTransAdminPortal.testObjects.AddFacilitatorPageLocators;
import com.IpgTransAdminPortal.testObjects.DisputeManagementPageLocators;
import com.IpgTransAdminPortal.testObjects.MerchantPayAdvicePageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementFileGenPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class SettlementFileGenerationPage extends ActionEngine {

	public String legalVehicle;
	public String acqBank;
	public String batchRunId;
	public String fromDate;
	public String toDate;
	
	ExcelReader bufferxls = new ExcelReader(configProps.getProperty("TempData"), "buffer");
	
	static Logger logger = Logger.getLogger(SettlementFileGenerationPage.class.getName());
	public boolean settlementFileGeneration() throws Throwable {
		HtmlReportSupport.reportStep("Settlement File Generation");
		boolean result = false;
		//boolean successFlag = false;
		HtmlReportSupport.reportStep("Settlement File Generation Page");
		selectByVisibleText(SettlementFileGenPageLocators.settleLv, legalVehicle, "Legal Vehicle Select");
		selectByVisibleText(SettlementFileGenPageLocators.settleAcqBank, acqBank, "Acquirer Bank");
		if((fromDate != null)&&(fromDate != ""))
			js_type(SettlementFileGenPageLocators.fromDate, fromDate, "From Date");
		else{
			click(SettlementFileGenPageLocators.fromDate, "From Date");
			click(SettlementFileGenPageLocators.datepickerPrev, "From Date - Prev");
			click(SettlementFileGenPageLocators.datepickerSelectDay, "From Date - Select Day");
		}
		if((toDate != null)&&(toDate != ""))
			js_type(SettlementFileGenPageLocators.toDate, toDate, "To Date");
		else{
			click(SettlementFileGenPageLocators.toDate, "To Date");
			hitKey(SettlementFileGenPageLocators.toDate, Keys.ENTER, "To Date");
		}
		click(SettlementFileGenPageLocators.generate_btn, "Generate button");
		waitForElementPresent(SettlementFileGenPageLocators.submitSuccess_msg, "Settlement file generated Request Submitted successfully");
		
		waitForElementPresent(By.xpath("//table[contains(@id,'tabnew')]//tr/td[contains(text(),'"+legalVehicle+"')]"), "Settlement File Generation Details");
		/*
		Thread.sleep(10000);
		while(isElementDisplayed(SettlementFileGenPageLocators.fileGenPending_row, "Pending Status")||isElementDisplayed(SettlementFileGenPageLocators.fileGenInProgress_row, "In Progress Status")){
			Thread.sleep(10000);
			click(SettlementFileGenPageLocators.refresh_btn, "Refresh button");
			Thread.sleep(10000);
			if(isElementDisplayed(SettlementFileGenPageLocators.fileGenSuccess_row, "File Generation Success Status")){
				successFlag = true;
			}			
		}
		
		if (successFlag)
			result = true;
		else if(!successFlag)
			Reporter.failureReport("File Generation", "FAILED");
		*/
		batchRunId = getText(SettlementFileGenPageLocators.batchRunId, "Batch Run ID");
		result = bufferxls.setCellData("buffer", "settlementFileGen_batchRunId", 2, batchRunId);
		return result;
	}
	
	public boolean settlementFileGenValidation() throws Throwable {
		HtmlReportSupport.reportStep("Settlement File Generation Validation");
		boolean result = false;
		
		batchRunId = bufferxls.getCellData("buffer", "settlementFileGen_batchRunId", 2);
		type(SettlementFileGenPageLocators.search_txt, batchRunId, "Search");
		Thread.sleep(2000);
		if(isElementDisplayed(By.xpath("//a[@batchrunid='" + batchRunId + "']/../..//td[contains(text(),'SUCCESS')]"), "Batch RUN - SUCCESS")){
			Reporter.SuccessReport("Batch Run Status/File Generation", "SUCCESS");
			result = true;
		}else if(isElementDisplayed(By.xpath("//a[@batchrunid='" + batchRunId + "']/../..//td[contains(text(),'PENDING')]"), "Batch RUN - PENDING")){
			Reporter.failureReport("Batch Run Status/File Generation", "PENDING");
		}else if(isElementDisplayed(By.xpath("//a[@batchrunid='" + batchRunId + "']/../..//td[contains(text(),'In Progress')]"), "Batch RUN - In Progress")){
			Reporter.failureReport("Batch Run Status/File Generation", "In Progress");
		}else if(isElementDisplayed(By.xpath("//a[@batchrunid='" + batchRunId + "']/../..//td[contains(text(),'FAILED')]"), "Batch RUN - FAILED")){
			Reporter.failureReport("Batch Run Status/File Generation", "FAILED");
		}
		
		return result;
	}
	public boolean settlementFileGenerationForRecon() throws Throwable {
		HtmlReportSupport.reportStep("Settlement File Generation");
		boolean result = false;
		
		HtmlReportSupport.reportStep("Settlement File Generation Page");
		selectByVisibleText(SettlementFileGenPageLocators.settleLv, legalVehicle, "Legal Vehicle Select");
		selectByVisibleText(SettlementFileGenPageLocators.settleAcqBank, acqBank, "Acquirer Bank");
		
		click(SettlementFileGenPageLocators.fromDate, "From Date");
		click(SettlementFileGenPageLocators.datepickerPrev, "From Date - Prev");
		click(SettlementFileGenPageLocators.datepickerSelectDay, "From Date - Select Day");
		click(SettlementFileGenPageLocators.toDate, "To Date");
		hitKey(SettlementFileGenPageLocators.toDate, Keys.ENTER, "To Date");
		click(SettlementFileGenPageLocators.generate_btn, "Generate button");
		waitForElementPresent(By.xpath("//table[contains(@id,'tabnew')]//tr/td[contains(text(),'"+legalVehicle+"')]"), "Settlement File Generation Details");
		
		batchRunId = getText(SettlementFileGenPageLocators.batchRunId, "Batch Run ID");
		result = bufferxls.setCellData("buffer", "settlementFileGenForReconciliation_batchRunId", 2, batchRunId);
		
		return result;
	}
	public void setLegalVehicle(String legalVehicle) {
		this.legalVehicle = legalVehicle;
	}
	public void setAcqBank(String acqBank) {
		this.acqBank = acqBank;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
		
}
