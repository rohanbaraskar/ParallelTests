package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.IpgTransAdminPortal.testObjects.NetbankCancelDownloadPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementFileGenPageLocators;
import com.IpgTransAdminPortal.testObjects.SettlementRefundCancelUploadPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class SettlementCancelUploadPage extends ActionEngine {

	public String meBusinessName;
	public String uploadType;
	public String uploadFile;
	public String batchRunId;
	
	static Logger logger = Logger.getLogger(SettlementCancelUploadPage.class.getName());
	ExcelReader bufferxls = new ExcelReader(configProps.getProperty("TempData"), "buffer");
	
	public boolean settlementCancelUpload() throws Throwable {
		HtmlReportSupport.reportStep("Settlement Cancel/Refund Upload");
		boolean result = false;
		//boolean successFlag = false;
		click(SettlementRefundCancelUploadPageLocators.upload_btn, "Upload button");
		waitForElementPresent(SettlementRefundCancelUploadPageLocators.meBusinessName, "Merchant Business Name");
		type(SettlementRefundCancelUploadPageLocators.meBusinessName, meBusinessName, "Merchant Business Name");
		selectByVisibleText(SettlementRefundCancelUploadPageLocators.uploadType_select, uploadType, "Upload Type");
		js_type(SettlementRefundCancelUploadPageLocators.uploadFile, uploadFile, "Upload File");
		click(SettlementRefundCancelUploadPageLocators.uploadSubmitBtn, "Upload Submit button");
		waitForElementPresent(SettlementRefundCancelUploadPageLocators.confirmYes_btn, "Upload Confirmation - Yes button");
		click(SettlementRefundCancelUploadPageLocators.confirmYes_btn, "Upload Confirmation - Yes button");
		waitForElementPresent(SettlementRefundCancelUploadPageLocators.uploadSuccess_msg, "Upload Success - Message");
		/*
		Thread.sleep(10000);
		while(isElementDisplayed(SettlementRefundCancelUploadPageLocators.fileGenPending_row, "Pending Status")||isElementDisplayed(SettlementRefundCancelUploadPageLocators.fileGenInProgress_row, "In Progress Status")){
			Thread.sleep(10000);
			click(SettlementRefundCancelUploadPageLocators.refresh_btn, "Refresh button");
			Thread.sleep(10000);
			if(isElementDisplayed(SettlementRefundCancelUploadPageLocators.fileGenSuccess_row, "File Generation Success Status")){
				successFlag = true;
			}			
		}
		
		if (successFlag)
			result = true;
		else if(!successFlag)
			Reporter.failureReport("File Generation", "FAILED");
		*/
		batchRunId = getText(SettlementRefundCancelUploadPageLocators.firstRow_batchRunId, "Batch Run ID");
		result = bufferxls.setCellData("buffer", "settlementRefundCancelUpload_batchRunId", 2, batchRunId);
		return result;
	}
	
	public boolean settlementCancelUpload_Validation() throws Throwable {
		HtmlReportSupport.reportStep("Settlement Cancel/Refund Upload Validation");
		boolean result = false;
		batchRunId = bufferxls.getCellData("buffer", "settlementRefundCancelUpload_batchRunId", 2);
		type(SettlementRefundCancelUploadPageLocators.search_txt, batchRunId, "Search");
		if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'Wrong file format')]"), "Batch RUN - Wrong File Format")){
			Reporter.failureReport("Batch Run Status/Settlement Refund Cancel Download Status", "Wrong File Format");
		}		
		else if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'PENDING')]"), "Batch RUN - PENDING")){
			Reporter.failureReport("Batch Run Status/Settlement Refund Cancel Download Status", "PENDING");
		}else if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'In Progress')]"), "Batch RUN - In Progress")){
			Reporter.failureReport("Batch Run Status/Settlement Refund Cancel Download Status", "In Progress");
		}else if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'FAILED')]"), "Batch RUN - FAILED")){
			Reporter.failureReport("Batch Run Status/Settlement Refund Cancel Download Status", "FAILED");
		}else if(isElementDisplayed(By.xpath("//td[contains(text(), '" + batchRunId + "')]/..//td[contains(text(),'SUCCESS')]"), "Batch RUN - SUCCESS")){
			Reporter.SuccessReport("Batch Run Status/Settlement Refund Cancel Download Status", "SUCCESS");
			result = true;
		}
		
		return result;
	}
	public void setMeBusinessName(String meBusinessName) {
		this.meBusinessName = meBusinessName;
	}
	
	public void setUploadType(String uploadType) {
		this.uploadType = uploadType;
	}
	
	public void setUploadFile(String uploadFile) {
		this.uploadFile = uploadFile;
	}
	
}
