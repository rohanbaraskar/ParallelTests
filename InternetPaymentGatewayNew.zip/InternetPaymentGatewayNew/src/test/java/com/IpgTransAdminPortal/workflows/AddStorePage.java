package com.IpgTransAdminPortal.workflows;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.IpgTransAdminPortal.testObjects.AddStorePageLocators;
import com.IpgTransAdminPortal.testObjects.HomePageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;
import com.MainFrameWork.utils.RandomTextUtils;
import com.MainFrameWork.utils.StringUtils;

public class AddStorePage extends ActionEngine {

	//private static final String Title = null;

	//private static final String DOB = null;

	private static final String SelectCategory = null;

	private static final String AddStorePageLocatore = null;

	ExcelReader bufferxls = new ExcelReader(configProps.getProperty("TempData"), "buffer");

	public String sourcingChannel;
	public String facilitator;
	
	//STORE INFORMATION
	public String storeType_web;
	public String storeInfo_Channel_webpos;
	public String feeType;
	public String storeName;
	public String legalName;
	
	public String Turnover_category;
	//BASIC DETAILS
	public String LOR;
	public String panNumber;
	public String category;
	public String awlMcc;
	public String premisesType;
	public String vintageType;
	public String merchantBusinessType;
	public String merchantWebUrl;
	public String registrationDate;
	public String applicationNo;
	public String corpId;
	public String yearsInBusiness;
	public String businessCompetitor;
	public String totalShops;
	public String avgTicketSize;
	public String defineBusinessMature;
	//STORE ADDRESS
	public String address1;
	public String address2;
	public String address3;
	public String country;
	public String state;
	public String city;
	public String locationId;
	public String region;
	public String subregion;
	public String zipCode;
	//CONTACT PERSON DETAILS
	public String fullName;
	public String phone;
	public String mobile;
	public String fax;
	public String emailId;
	public String Title;
	public String DOB;
	//BILLING ADDRESS DETAILS
	public String billingAddress_Same;
	public String billingAddress1;
	public String billingAddress2;
	public String billingAddress3;
	public String billingCountry;
	public String billingState;
	public String billingCity;
	public String billingPhone1;
	public String billingMobile;
	public String billingFax;
	public String billingZipcode;	
	//RELATIONSHIP MANAGER DETAILS
	public String rmName;
	public String rmMobile;
	public String rmEmailId;
	//MISCELLANEOUS DETAILS
	public String holdPayment;
	public String partialSettlement;
	public String settlementAgainstDelivery;
	public String agreementDate;
	public String agreementExpiryDate;
	public String agreementNo;
	public String merchantClassification;
	public String merchantSegment;
	public String branchOffDesg;
	public String branchOffMobile;
	public String branchOffName;
	public String branchSolId;
	public String branchStaffName;
	public String branchStaffPfi;
	public String branchStaffSv;
	//CHEQUE DETAILS
	public String chequeNo;
	public String chqDate;
	public String chqAmount;
	public String chqRemarks;
	//GROUP DETAILS
	public String groupName;
	public String contactName;
	public String contactPhone;
	public String contactMobile;
	public String contactAddress1;
	public String contactAddress2;
	public String contactAddress3;
	public String contactCountry;
	public String contactState;
	public String contactCity;
	public String contactZipcode;
	public String contactEmail;
	public String primaryOwnerFirstName;
	public String primaryOwnerMiddleName;
	public String primaryOwnerLastName;
	public String primaryOwnerPhone;
	public String primaryOwnerMobile;
	public String primaryOwnerZipcode;
	public String primaryOwnerAddress1;
	public String primaryOwnerAddress2;
	public String primaryOwnerFax;
	public String secondaryOwnerFirstName;
	public String secondaryOwnerMiddleName;
	public String secondaryOwnerLastName;
	public String secondaryOwnerPhone;
	public String secondaryOwnerMobile;
	public String secondaryOwnerZipcode;
	public String secondaryOwnerAddress1;
	public String secondaryOwnerAddress2;
	public String secondaryOwnerFax;

	//WEBSITE SUMMARY
	public String corporateInfo;
	public String comprehensiveBackground;
	public String meBusinessModelDesc;
	public String goodsServicesDesc;
	public String returnPolicies;
	public String meCustServiceContactInfo;
	public String transactionCurrency;
	public String deliveryPolicy;
	public String dataPrivacyPolicy;
	public String recurringTransDetails;
	public String shipDetails;
	public String infoMethodTransSecurity;
	public String transTermsConditions;
	public String merchWebsite;
	public String briefSummaryGoods;
	public String needInternCardAcceptance;
	public String payChannelsVolumeSplit_Internet;
	public String payChannelsVolumeSplit_Mail;
	public String payChannelsVolumeSplit_PosCC;
	public String payChannelsVolumeSplit_PosDC;
	public String busChannelPayVolSplit_B2B;
	public String busChannelPayVolSplit_B2C;
	public String acceptONlinePay;
	public String processorBankName;
	public String howLongWithProcess;
	public String annualOnlineTurnover;
	public String annualOfflineTurnover;
	public String minTicketSize;
	public String maxTicketSize;
	public String timeFrames0;
	public String timeFrames1_3;
	public String timeFrames4_7;
	public String timeFrames8_14;
	public String timeFrames15_30;
	public String deposite;
	public String autoRenewals;
	public String refundPolicyFull;
	public String refundDays;
	public String riskChecks;
	public String sendEmail;
	public String timeBtwnPayDelivery;
	public String diwali;
	public String christmas;
	public String easter;
	public String summerSales;
	public String chargeBackVol;
	public String NoOfFunds;
	public String NoOfTrans;
	public String refundVolume;
	public String salesVolume;
	
	//ADD STORE - ADD ACQUIRING BANK
	public String lvId;
	public String bankName;
	public String zone;
	public String branch;
	public String oneTimeFixedFee;
	public String statementFee;
	public String terminalFee;
	public String minimumUsage;
	public String minTransAmt;
	public String minUsageFee;
	public String amcType;
	public String amcAmount;
	public String nonUsage;
	public String nonUsageFee;
	public String settlementCycle;
	public String securityAmount;
	public String settlementType;
	public String paymentBy;
	public String paymentAdvice;
	//public String NodalAccount;
	
	public String merchAccNumber;
	public String merchBankName;
	public String merchAccOpenDate;
	public String merchAccState;
	public String merchAccCity;
	public String merchAccPhone;
	public String merchAccMobile;
	public String merchAccAddress1;
	public String merchAccAddress2;

	//ACQ BANK PCPOS
	public String tccDescriptor;	
	public String projectedAvgTicketSize;
	public String newPayAdviceValue;
	public String rental;
	public String rentalFrequencyValue;
	public String advanceRent;
	public String advanceRentalFrequency;
	public String advanceRentalAmount;
	public String advanceSetup;
	public String advanceSetupFee;
	public String msfIncentive;
	public String merchantIncentive;
	public String tipPercent;
	public String cashPOS;
	public String saleWithCashBack;	
	
	//ACQ BANK MISC DETAILS
	public String dailyTransLimit;
	public String firc;
	public String merchIdType;
	public String currency;
	public String mid;
	public String applicationMode;
	public String transactionMode;
	public String fircFrequency;
	public String fuelAssociation;
	public String fuelRemark;
	public String callCharges;
	public String secretKey;
	public String documentRequired;
	public String documentPending;
	public String merchReimbursement;
	public String customerId;
	public String tid;
	public String amexMaId;
	public String amexMaPassword;
	public String amexAmaId;
	public String amexAmaPassword;
	public String amexAccessCode;
	public String amexSecureSecret;
	
	//PAYMENT TYPE
	public String paymentTypeCreditCard;
	public String paymentTypeDebitCard;
	public String paymentTypeInternetBank;
	public String paymentTypeCug;
	public String paymentTypeImps;
	
	public String amexDomesticCc;
	public String amexInternationalCc;
	public String mastDomCc;
	public String mastIntCc;
	public String rupayDomCc;
	public String rupayIntCc;
	public String visaDomCc;
	public String visaIntCc;
	public String mastDomDc;
	public String mastIntDc;
	public String visaDomDc;
	public String visaIntDc;
	public String rupayDomDc;
	public String rupayIntDc;
	public String internetBankLv;
	public String internetBankSelectBank;
	public String internetBankEffectDate;
	public String internetBankStatus;
	public String internetBankSortOrder;
	public String internetBankNetBankAccId;
	public String internetBankSecretKey;
	public String internetBankPerTransLimit;
	public String cugFromBin;
	public String cugToBin;
	public String impsMmid;
	public String impsMobileNo;
	public String ipgRefund;
	public String ipgCancellation;
	public String ipgRecurPayUpload;
	public String ipgRecurPayOnline;
	public String ipgPreauth;
	public String ipgHostedPages;
	public String ipgEmailInvoice;
	public String ipgSmsInvoice;
	
	//MSF/CONVENIENCE FEE
	public String msfAcqBankNameCc;
	public String msfMidCc;
	public String msfSchemeCc;
	public String slabUptoCc;
	public String interFixedCc;
	public String interPerCc;
	public String domesticOnusFixedCc;
	public String domesticOnusPerCc;
	public String domesticOffusFixedCc;
	public String domesticOffusPerCc;
	public String chargeTypeCc;
	
	//===============================================BSF_CC============
	public String manageBSFCc;
	public String SelectCategory_cc;
	
	public String bsfslabUptoCc;
	public String bsfinterFixedCc;
	public String bsfinterPerCc;
	public String bsfdomesticOnusFixedCc;
	public String bsfdomesticOnusPerCc;
	public String bsfdomesticOffusFixedCc;
	public String bsfdomesticOffusPerCc;
	public String bsfchargeTypeCc;
	
	//=================================================================
	public String msfAcqBankNameDc;
	public String msfMidDc;
	public String msfSchemeDc;
	public String slabUptoDc;
	public String interFixedDc;
	public String interPerDc;
	public String domesticOnusFixedDc;
	public String domesticOnusPerDc;
	public String domesticOffusFixedDc;
	public String domesticOffusPerDc;
	public String chargeTypeDc;
	
	//======================BSF_DC============================
	public String manageBSFDc;
	public String SelectCategory_dc;
	
	public String bsfslabUptoDc;
	public String bsfinterFixedDc;
	public String bsfinterPerDc;
	public String bsfdomesticOnusFixedDc;
	public String bsfdomesticOnusPerDc;
	public String bsfdomesticOffusFixedDc;
	public String bsfdomesticOffusPerDc;
	public String bsfchargeTypeDc;
	
	//======================================================
	
	public String intBankBankName;
	public String intBankSlabUpto;
	public String intBankFixed;
	public String intBankPercent;
	public String intBankEffectiveFrom;
	public String intBankChargeType;

	//================================BSF_NB===================
	public String manageBSFNb;
	public String SelectCategory_nb;
	public String bsfintBankSlabUpto;
	public String bsfintBankFixed;
	public String bsfintBankPercent;
	public String bsfintBankEffectiveFrom;
	public String bsfintBankChargeType;
	
	//=========================================================
	public String cugBankName;
	public String cugSlabUpto;
	public String cugFixed;
	public String cugPercent;
	public String cugEffectiveFrom;
	public String cugChargeType;
	
	
	//=========================BSF_CUG============================
	public String manageBSFCug;
	
	public String bsfcugSlabUpto;
	public String bsfcugFixed;
	public String bsfcugPercent;
	public String bsfcugEffectiveFrom;
	public String bsfcugChargeType;
	
	//===========================================================
	
	//===================IMPS===================================
	public String impsSlabUpto;
	public String impsFixed;
	public String impsPercent;
	public String impsEffectiveFrom;
	public String impsChargeType;

	//==========================================================
	
	//CHECKLIST
	public String existingRelationship;
	public String paymentHoldover;
	public String checklistMsf;
	public String crossborderTransaction;
	public String secure3D;
	public String domesticUserTransLimit;
	public String secureCrossborderLimit;
	public String unsecureTransLimit;
	public String chargeBackRecover;
	public String financialStatementSubmit;
	public String financialStatementSubmitRemark;
	public String websiteCheck;
	public String websiteCheckRemark;
	public String merchantRating;
	public String merchantRatingRemark;
	public String siteInspection;
	public String siteInspectionRemark;
	public String businessApproval;
	public String businessApprovalRemark;
	public String cibilChecks;
	public String cibilChecksRemark;
	public String kycDocVerify;
	public String kycDocVerifyRemark;
 
	//MERCHANT RATING
	public String merchRatingLocation;
	public String merchRatingFinancial;
	public String merchRatingMCategory;
	public String merchRatingDeliveryTimeline;
	public String merchRatingOpsSecurity;
	public String merchRatingWebSecurity;
	public String merchRatingVmts;
	public String merchRatingMatch;
	public String merchRatingCibil;
	public String merchRatingVmtsCheckbox;
	public String merchRatingMatchCheckbox;
	public String merchRatingPostFacto;
	public String merchRatingWaiver;
	public String merchRatingEnterRemark;
	
	//UPLOAD DOCUMENTS
	public String uploadValidLicense;
	public String uploadValidLicenseRemark;
	public String uploadPancard;
	public String uploadPancardRemark;
	public String uploadAddressProof;
	public String uploadAddressProofRemark;
	public String uploadIncomeTax;
	public String uploadIncomeTaxRemark;
	public String uploadStatementOfAcc;
	public String uploadStatementOfAccRemark;
	public String uploadCancelChq;
	public String uploadCancelChqRemark;
	public String uploadMerchEstAgg;
	public String uploadMerchEstAggRemark;
	public String uploadCpLicenseShops;
	public String uploadCpLicenseShopsRemark;
	public String uploadIDproof;
	public String uploadIDproofRemark;

	//URLs
	public String isWebsiteOnInternet;
	public String merchWebsiteUrl;
	public String privacyPolicy;
	public String cancelRefundPolicy;
	public String termsCondPolicy;
	public String contactUsInfo;
	public String faqPage;
	public String oneProdPage;
	public String aboutUs;
	public String howWebsiteManaged;
	public String whichCompOwnsWebsite;
	public String outsourcedForSolution;
	public String whichSolutionWebsiteOn;
	public String ecommStrategy;
	//public String ecommTarget;
	public String ecommTargetUtility;
	public String ecommTargetTravel;
	public String ecommTargetRetail;
	public String ecommTargetEducation;

	public String charityOrg;
	public String hostelsMotels;
	public String other;
	public String pleaseSpecify;
	
	//BLACKLIST/WHITELIST
	public String blListType;
	public String blSchemeName;
	public String blFromBin;
	public String blToBin;
	
	//IPG
	public String eciValueVisa;
	public String eciValueMaster;
	public String eciValueMaestro;
	public String integrationApproach;
	public String pciDssCertificate;
	public String pciDssExpDate;
	public String ebsChecksumKey;
	public String mpiIntegration;
	public String mpiChecksumKey;
	public String lyraCertificate;
	public String lyraShopId;
	public String convFeeMsfCheckValue;
	public String merchEmailConfirmForTrans;
	public String reqUrl1;
	public String reqUrl2;
	
	//PCPOS
	public String trainingSchedule;
	public String seId;
	public String seRemarks;
	public String ownership;
	public String meChargeSlipName;
	public String pcposVersion;
	public String promptProcessFlag;
	public String maxCashPos;
	public String maxPreauthPercent;
	public String contentDisclaimer;
	public String instrumentDisclaimer;
	public String programDisclaimer;
	public String totalNoOfTerminals;
	public String modelNo;
	public String edcVersion;
	public String noOfTerminals;

	public String NodalAccount;

	public String SecurityAmount;

	
	static Logger logger = Logger.getLogger(AddStorePage.class.getName());
	public boolean addStore() throws Throwable {
		HtmlReportSupport.reportStep("Add Store");
		boolean result = false;
		
		selectByVisibleText(AddStorePageLocators.sourcingChannel_select, sourcingChannel, "Sourcing Channel Select");
		if(facilitator != null)
			if(facilitator !="")
				selectByVisibleText(AddStorePageLocators.facilitator_select, facilitator, "Facilitator Select");
		
				
		HtmlReportSupport.reportStep("Store Information");
		if(storeType_web.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.storeType_web_btn, "Store Type Web");
		if(storeInfo_Channel_webpos.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.storeInfo_Channel_webpos, "Store Info - Channel WEB POS");
		
		selectByVisibleText(AddStorePageLocators.Turnover_category_select, Turnover_category, "Turnover_category Select");
	
		waitForElementPresent(AddStorePageLocators.Turnover_category_select, "Select Turnover Category");
		
		if(feeType != null)
			if(feeType!="")
				selectByVisibleText(AddStorePageLocators.feeType_select, feeType, "Fee Type Select");
		type(AddStorePageLocators.storeName_txt, storeName, "Store Name");
		type(AddStorePageLocators.legalName_txt, legalName, "Legal Name");
		
		HtmlReportSupport.reportStep("Basic Details");
		
		selectByVisibleText(AddStorePageLocators.LOR, LOR, "LOR Select");
		
		type(AddStorePageLocators.panNo_txt, panNumber, "PAN Number");
		selectByVisibleText(AddStorePageLocators.category_select, category, "Category Select");
		selectByVisibleText(AddStorePageLocators.awlMcc_select, awlMcc, "AWL MCC Select");
		selectByVisibleText(AddStorePageLocators.premisesType_select, premisesType, "Premises Type Select");
		selectByVisibleText(AddStorePageLocators.vintageType_select, vintageType, "Vintage Type Select");
		selectByVisibleText(AddStorePageLocators.merchantBusinessType_select, merchantBusinessType, "Merchant Business Type Select");
		type(AddStorePageLocators.merchantWebUrl_txt, merchantWebUrl, "Merchant Web URL");
		if(registrationDate != null)
			if(registrationDate!="")
				js_type(AddStorePageLocators.registrationDate_txt, registrationDate, "Registration Date");
		
		
		type(AddStorePageLocators.applicationNo_txt, applicationNo, "Application Number");
		type(AddStorePageLocators.corpId_txt, corpId, "Corporate Identification Number");
		type(AddStorePageLocators.yearsInBusiness_txt, yearsInBusiness, "Years in Business");
		type(AddStorePageLocators.businessCompetitor_txt, businessCompetitor, "Competitor");
		type(AddStorePageLocators.totalShops_txt, totalShops, "Number of shops in the Country");
		selectByVisibleText(AddStorePageLocators.avgTicketSize_select, avgTicketSize, "Average Ticket Size Select");
		if(defineBusinessMature.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.defineBusinessMature_radiobutton, "Define Business - Mature");
		
		HtmlReportSupport.reportStep("Store Address");
		type(AddStorePageLocators.address1_txt, address1, "Address 1");
		type(AddStorePageLocators.address2_txt, address2, "Address 2");
		type(AddStorePageLocators.address3_txt, address3, "Address 3");
		selectByVisibleText(AddStorePageLocators.country_select, country, "Country");
		selectByVisibleText(AddStorePageLocators.state_select, state, "State");
		selectByVisibleText(AddStorePageLocators.city_select, city, "City");
		if(!locationId.equals(""))
			selectByVisibleText(AddStorePageLocators.locationId_select, locationId, "Location ID");
		if(!region.equals(""))
			selectByVisibleText(AddStorePageLocators.region_select, region, "Region");
		if(!subregion.equals(""))
			selectByVisibleText(AddStorePageLocators.subregion_select, subregion, "Sub region");
		type(AddStorePageLocators.zipCode_txt, zipCode, "Zip Code");
		
		HtmlReportSupport.reportStep("Contact Person Details");
		//selectByVisibleText(AddStorePageLocators.country_select, country, "Country");
		selectByVisibleText(AddStorePageLocators.Title, Title, "Title");
		type(AddStorePageLocators.fullName_txt, fullName, "Full Name");
		
		if((DOB !=null)&&(DOB !="")){
			js_type(AddStorePageLocators.dateofbirth, DOB, "Date of Birth");
		}
		
		type(AddStorePageLocators.phone_txt, phone, "Phone Number");
		type(AddStorePageLocators.mobile_txt, mobile, "Mobile Number");
		type(AddStorePageLocators.fax_txt, fax, "Fax");
		type(AddStorePageLocators.emailId_txt, emailId, "Email ID");
		
		
		
		//BILLING ADDRESS
		if(billingAddress_Same.equalsIgnoreCase("Y")){
			click(AddStorePageLocators.billingAddress_Same_checkbox, "Billing Address - Same as above");
		}else{
			if((billingAddress1 != null)&&(billingAddress1 != ""))
			type(AddStorePageLocators.billingAddress1_txt, billingAddress1, "Billing Address 1");
			if((billingAddress2 != null)&&(billingAddress2 != ""))
			type(AddStorePageLocators.billingAddress2_txt, billingAddress2, "Billing Address 2");
			if((billingAddress3 != null)&&(billingAddress3 != ""))
			type(AddStorePageLocators.billingAddress3_txt, billingAddress3, "Billing Address 3");
			if((billingCountry != null)&&(billingCountry != ""))
			selectByVisibleText(AddStorePageLocators.billingCountry_select, billingCountry, "Billing Country");
			if((billingState != null)&&(billingState != ""))
			selectByVisibleText(AddStorePageLocators.billingState_select, billingState, "Billing State");
			if((billingCity != null)&&(billingCity != ""))
			selectByVisibleText(AddStorePageLocators.billingCity_select, billingCity, "Billing City");
			if((billingZipcode != null)&&(billingZipcode != ""))
			type(AddStorePageLocators.billingZipcode_txt, billingZipcode, "Billing Zip Code");
			if((billingPhone1 != null)&&(billingPhone1 != ""))
			type(AddStorePageLocators.billingPhone1_txt, billingPhone1, "Billing Phone 1");
			if((billingMobile != null)&&(billingMobile != ""))
			type(AddStorePageLocators.billingMobile_txt, billingMobile, "Billing Mobile");
			if((billingFax != null)&&(billingFax != ""))
			type(AddStorePageLocators.billingFax_txt, billingFax, "Billing Fax");
		}
		
		HtmlReportSupport.reportStep("Relationship Manager Details");
		selectByIndex(AddStorePageLocators.rmName_select, 1, "RM NameSelect");
		/*
		if((rmName != null)&&(rmName != "")){
			HtmlReportSupport.reportStep("Relationship Manager Details");
			selectByIndex(AddStorePageLocators.rmName_select, 1, "RM NameSelect");
		}
		if((rmMobile != null)&&(rmMobile != ""))
			type(AddStorePageLocators.rmMobile_txt, rmMobile, "RM Mobile");
		if((rmEmailId != null)&&(rmEmailId != ""))
			type(AddStorePageLocators.rmEmailId_txt, rmEmailId, "RM Email ID");
		*/
		
		HtmlReportSupport.reportStep("Miscellaneous Details");
		if(holdPayment.equalsIgnoreCase("Y")){
			click(AddStorePageLocators.holdPayment_checkbox, "Hold Payment Checkbox");
		}
		if(partialSettlement.equalsIgnoreCase("Y")){
			click(AddStorePageLocators.partialSettlement_checkbox, "Partial Settlement Checkbox");
		}
		if(settlementAgainstDelivery.equalsIgnoreCase("Y")){
			click(AddStorePageLocators.settlementAgainstDelivery_chk, "Settlment Against Delivery Checkbox");
		}
		if((agreementDate !=null)&&(agreementDate !="")){
			js_type(AddStorePageLocators.agreementDate_txt, agreementDate, "Agreement Date");
		}
		if((agreementExpiryDate !=null)&&(agreementExpiryDate !="")){
			js_type(AddStorePageLocators.agreementExpiryDate_txt, agreementExpiryDate, "Agreement Expiry Date");
		}
		type(AddStorePageLocators.agreementNo_txt, agreementNo, "Agreement Number");
		if((merchantClassification !=null)&&(merchantClassification !=""))
		selectByVisibleText(AddStorePageLocators.merchantClassification_select, merchantClassification, "Merchant Classification Select");
		if((merchantSegment !=null)&&(merchantSegment !=""))
			selectByVisibleText(AddStorePageLocators.merchantSegment_select, merchantSegment, "Merchant Segment Select");
		type(AddStorePageLocators.branchOffDesg_txt, branchOffDesg, "Branch Official Designation");
		type(AddStorePageLocators.branchOffMobile_txt, branchOffMobile, "Branch Official Mobile Number");
		type(AddStorePageLocators.branchOffName_txt, branchOffName, "Branch Official Name");
		type(AddStorePageLocators.branchSolId_txt, branchSolId, "Branch SOL ID");
		type(AddStorePageLocators.branchStaffName_txt, branchStaffName, "Branch Staff Name");
		type(AddStorePageLocators.branchStaffPfi_txt, branchStaffPfi, "Branch Staff PFI");
		type(AddStorePageLocators.branchStaffSv_txt, branchStaffSv, "Branch Staff SV");
		
		if((chequeNo !=null)&&(chequeNo !="")){
			HtmlReportSupport.reportStep("Cheque Details");		
			type(AddStorePageLocators.chequeNo_txt, chequeNo, "Cheque No");
			if((chqDate != null)&&(chqDate != ""))
				js_type(AddStorePageLocators.chqDate_txt, chqDate, "Cheque Date");
			else{
				click(AddStorePageLocators.chqDate_txt, "Cheque Date");
				click(AddStorePageLocators.chqDate_Now_btn, "Cheque Date - Now button");
				click(AddStorePageLocators.chqDate_Done_btn, "Cheque Date - Done button");
			}
			type(AddStorePageLocators.chqAmount_txt, chqAmount, "Cheque Amount");
			type(AddStorePageLocators.chqRemarks_txt, chqRemarks, "Cheque Remarks");
		}
		
		click(AddStorePageLocators.saveButton_txt, "Save button");
		//VALIDATION OF STORE
		if(isElementPresent(AddStorePageLocators.successAlert_msg, "Store Added Successfully")){
			result = true;
		}
		return result;
	}
	
	public boolean sendForApproval(String storeName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View Store for Approval");
		waitForElementPresent(HomePageLocators.merchManagement_mnu,"Merchant Management Menu");
		click(HomePageLocators.merchManagement_mnu,"Merchant Management Menu");
		click(HomePageLocators.merchOnboarding_mnu, "Merchant Onboarding SubMenu");
		waitForElementPresent(HomePageLocators.search_txt,"Merchant Search Page");
		type(HomePageLocators.search_txt, storeName, "Store Search box");
		waitForElementPresent(AddStorePageLocators.viewStoreForApproval_lnk, "View Store for Approval Link");
		click(AddStorePageLocators.viewStoreForApproval_lnk, "View Store for Approval Link");
		HtmlReportSupport.reportStep("Send Store for Approval");
		waitForElementPresent(By.xpath("//input[contains(@value,'"+ storeName +"')]"), "Store Name: " + storeName);
		waitForElementPresent(AddStorePageLocators.sendForApproval_btn, "Send for Approval button");
		click(AddStorePageLocators.sendForApproval_btn, "Send for Approval button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Send for Approval Success Message");
		result = true;
		return result;
	}
	
	public boolean writePgMerchIdToBuffer(String fieldName, String storeName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View/Edit Merchant");
		waitForElementPresent(HomePageLocators.merchManagement_mnu,"Merchant Management Menu");
		click(HomePageLocators.merchManagement_mnu,"Merchant Management Menu");
		click(HomePageLocators.merchViewEdit_mnu, "Merchant View/Edit SubMenu");
		waitForElementPresent(HomePageLocators.storeType_select,"Merchant View/Edit Search Page");
		selectByVisibleText(HomePageLocators.storeType_select, "Store List", "Store List");
		
		waitForElementPresent(HomePageLocators.search_txt,"Merchant Search Page");
		type(HomePageLocators.search_txt, storeName, "Store Search box");
		
		waitForElementPresent(By.xpath("//td[contains(text(),'"+storeName+"')]"), "View Store in Search Results");
		String pgMerchId = getText(By.xpath("//td[contains(text(),'"+storeName+"')]/..//td[contains(text(),'WL0')]"), "PG Merchant ID");
		/*
		click(AddStorePageLocators.viewStoreForApproval_lnk, "View Store for Approval Link");
		
		HtmlReportSupport.reportStep("Validation of Merchant ActiveStatus, MID, and TID");
		waitForElementPresent(AddStorePageLocators.basicDetails_lnk, "Basic Details Page");
		
		click(AddStorePageLocators.acquiringBankVerification_lnk, "Acquiring Bank Link");
		waitForElementPresent(AddStorePageLocators.statusOnAcqBankList, "Status");
		
		String status = "";
		status = getText(AddStorePageLocators.statusOnAcqBankList, "Status");
		if(status.contains("Inactive")){
			Reporter.failureReport("Verification of Status on Acquiring Bank List Page: ", status);
		}else if(status.contains("Active")){
			Reporter.SuccessReport("Verification of Status on Acquiring Bank List Page: ", status);
			result = true;
		}
		click(AddStorePageLocators.viewLinkOnAcqBankList, "View Link");
		waitForElementPresent(AddStorePageLocators.acqBankListPage, "Acquiring Bank Page");
		
		String mid = "";
		mid = getText(AddStorePageLocators.midOnAcqBankPage, "MID");
		if(!StringUtils.validateStringWithNumbers(mid)){
			Reporter.failureReport("MID Verification on Acquiring Bank Page: ", mid);
			result = false;
		}
		String tid = "";
		tid = getText(AddStorePageLocators.tidOnAcqBankPage, "TID");
		if(!StringUtils.validateStringWithNumbers(tid)){
			Reporter.failureReport("TID Verification on Acquiring Bank Page: ", tid);
			result = false;
		}*/
		
		result = bufferxls.setCellData("buffer", fieldName, 2, pgMerchId);	//Writing the Merchant ID to TempData.xls file
		//result = true;
		return result;
	}
	
	public boolean validateStore(String fieldName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View/Edit Merchant");
		waitForElementPresent(HomePageLocators.merchManagement_mnu,"Merchant Management Menu");
		click(HomePageLocators.merchManagement_mnu,"Merchant Management Menu");
		click(HomePageLocators.merchViewEdit_mnu, "Merchant View/Edit SubMenu");
		waitForElementPresent(HomePageLocators.storeType_select,"Merchant View/Edit Search Page");
		selectByVisibleText(HomePageLocators.storeType_select, "Store List", "Store List");
		
		waitForElementPresent(HomePageLocators.search_txt,"Merchant Search Page");
		String pgMerchantId = bufferxls.getCellData("buffer", fieldName, 2);
		type(HomePageLocators.search_txt, pgMerchantId, "Store Search box");
		waitForElementPresent(By.xpath("//td[contains(text(),'"+pgMerchantId+"')]"), "View Store in Search Results");
		click(AddStorePageLocators.viewStoreForApproval_lnk, "View Store for Approval Link");
		
		HtmlReportSupport.reportStep("Validation of Merchant ActiveStatus, MID, and TID");
		waitForElementPresent(AddStorePageLocators.basicDetails_lnk, "Basic Details Page");
		click(AddStorePageLocators.acquiringBankVerification_lnk, "Acquiring Bank Link");
		waitForElementPresent(AddStorePageLocators.statusOnAcqBankList, "Status");
		
		String status = "";
		status = getText(AddStorePageLocators.statusOnAcqBankList, "Status");
		if(status.contains("Inactive")){
			Reporter.failureReport("Verification of Status on Acquiring Bank List Page: ", status);
		}else if(status.contains("Active")){
			Reporter.SuccessReport("Verification of Status on Acquiring Bank List Page: ", status);
			result = true;
		}
		click(AddStorePageLocators.viewLinkOnAcqBankList, "View Link");
		waitForElementPresent(AddStorePageLocators.acqBankListPage, "Acquiring Bank Page");
		
		String mid = "";
		mid = getText(AddStorePageLocators.midOnAcqBankPage, "MID");
		if(!StringUtils.validateStringWithNumbers(mid)){
			Reporter.failureReport("MID Verification on Acquiring Bank Page: ", mid);
			result = false;
		}
		String tid = "";
		tid = getText(AddStorePageLocators.tidOnAcqBankPage, "TID");
		if(!StringUtils.validateStringWithNumbers(tid)){
			Reporter.failureReport("TID Verification on Acquiring Bank Page: ", tid);
			result = false;
		}
		
		return result;
	}
	
	public boolean operationsApproval(String storeName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View Store for Operations Approval");
		type(HomePageLocators.search_txt, storeName, "Store Search box");
		waitForElementPresent(AddStorePageLocators.viewStore_lnk, "View Store Link");
		click(AddStorePageLocators.viewStore_lnk, "View Store Link");
		HtmlReportSupport.reportStep("Operations Approval");
		//waitForElementPresent(By.xpath("//.[contains(text(),'"+ storeName +"')]"), "Store Name: " + storeName);
		waitForElementPresent(AddStorePageLocators.actionSelect, "OPS approval page");
		waitForElementPresent(AddStorePageLocators.actionSelect, "Action Select");
		//click(By.xpath("//input[@type='checkbox' and @class='acqCheck']"), "Acquirer Bank Checkbox");
		click(By.xpath("//input[@type='checkbox' and @class='checkAll']"), "Acquirer Bank Checkbox");
		selectByContainsVisibleText(AddStorePageLocators.actionSelect, "Approve", "Approve/Reject Select");
		type(AddStorePageLocators.remark_txtarea, "Test Operations Approval Remarks", "Operations Approval Remarks");
		click(AddStorePageLocators.submit_btn, "Submit Button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Operations Approval Success Message");
		result = true;
		return result;
	}
	
	public boolean operationsApprovalForAggregator(String storeName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View Store for Operations Approval");
		type(HomePageLocators.search_txt, storeName, "Store Search box");
		waitForElementPresent(AddStorePageLocators.viewStore_lnk, "View Store Link");
		click(AddStorePageLocators.viewStore_lnk, "View Store Link");
		HtmlReportSupport.reportStep("Operations Approval");
		//waitForElementPresent(By.xpath("//.[contains(text(),'"+ storeName +"')]"), "Store Name: " + storeName);
		waitForElementPresent(AddStorePageLocators.actionSelect, "OPS approval page");
		waitForElementPresent(AddStorePageLocators.actionSelect, "Action Select");
		click(By.xpath("//input[@type='checkbox' and @class='checkAll']"), "Acquirer Bank Checkbox");
		//click(By.xpath("//input[@type='checkbox' and @class='acqCheck']"), "Acquirer Bank Checkbox");
		selectByContainsVisibleText(AddStorePageLocators.actionSelect, "Approve", "Approve/Reject Select");
		type(AddStorePageLocators.remark_txtarea, "Test Operations Approval Remarks", "Operations Approval Remarks");
		click(AddStorePageLocators.submit_btn, "Submit Button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Operations Approval Success Message");
		result = true;
		return result;
	}
	public boolean businessApproval(String storeName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View Store for Business Approval");
		type(HomePageLocators.search_txt, storeName, "Store Search box");
		waitForElementPresent(AddStorePageLocators.viewBusinStore_lnk, "View Business Store Link");
		click(AddStorePageLocators.viewBusinStore_lnk, "View Business Store Link");
		
		HtmlReportSupport.reportStep("Business Approval");
		//waitForElementPresent(By.xpath("//.[contains(text(),'"+ storeName +"')]"), "Store Name: " + storeName);
		waitForElementPresent(AddStorePageLocators.businessApprovActionSelect, "Business Approval Page");
		waitForElementPresent(AddStorePageLocators.businessApprovActionSelect, "Action Select");
		//click(By.xpath("//input[@type='checkbox' and @class='acqCheck']"), "Acquirer Bank Checkbox");
		click(By.xpath("//input[@type='checkbox' and @class='checkAll']"), "Acquirer Bank Checkbox");
		selectByContainsVisibleText(AddStorePageLocators.businessApprovActionSelect, "Approve", "Approve/Reject Select");
		type(AddStorePageLocators.remark_txtarea, "Test Business Approval Remarks", "Business Approval Remarks");
		click(AddStorePageLocators.businessApproval_submit_btn, "Submit Button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Business Approval Success Message");
		result = true;
		return result;
	}
	
	public boolean riskApproval(String storeName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View Store for Risk Approval");
		type(HomePageLocators.search_txt, storeName, "Store Search box");
		waitForElementPresent(AddStorePageLocators.viewStoreForRiskApproval_lnk, "View Store Link");
		click(AddStorePageLocators.viewStoreForRiskApproval_lnk, "View Store Link");
		
		HtmlReportSupport.reportStep("Risk Approval");
		//waitForElementPresent(By.xpath("//.[contains(text(),'"+ storeName +"')]"), "Store Name: " + storeName);
		waitForElementPresent(AddStorePageLocators.riskApprovActionSelect, "Risk Approval Page");
		//click(By.xpath("//input[@type='checkbox' and @class='acqCheck']"), "Acquirer Bank Checkbox");
		click(By.xpath("//input[@type='checkbox' and @class='checkAll']"), "Acquirer Bank Checkbox");
		type(AddStorePageLocators.riskApprovalDailyTransCount_txt, "200000","Daily Transaction Count");
		type(AddStorePageLocators.riskApprovalDailyTransAmt_txt, "30000","Daily Transaction Amount");
		type(AddStorePageLocators.riskApprovalPerTransLimit_txt, "3000","Per Transaction Limit");
		waitForElementPresent(AddStorePageLocators.riskApprovActionSelect, "Action Select");
		selectByContainsVisibleText(AddStorePageLocators.riskApprovActionSelect, "Approve", "Approve/Reject Select");
		type(AddStorePageLocators.remark_txtarea, "Test Risk Approval Remarks", "Risk Approval Remarks");
		click(AddStorePageLocators.riskApproval_submit_btn, "Submit Button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Risk Approval Success Message");
		result = true;
		return result;
	}
	
	public boolean financeApproval(String storeName) throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Navigate to View Store for Finance Approval");
		type(HomePageLocators.search_txt, storeName, "Store Search box");
		waitForElementPresent(AddStorePageLocators.viewFinAppList_lnk, "View Store Link");
		click(AddStorePageLocators.viewFinAppList_lnk, "View Store Link");
		
		HtmlReportSupport.reportStep("Finance Approval");
		//waitForElementPresent(By.xpath("//.[contains(text(),'"+ storeName +"')]"), "Store Name: " + storeName);
		waitForElementPresent(AddStorePageLocators.financeApprovActionSelect, "Action Select");
		click(By.xpath("//input[@type='checkbox' and @class='checkAll']"), "Acquirer Bank Checkbox");
		selectByContainsVisibleText(AddStorePageLocators.financeApprovActionSelect, "Approve", "Approve/Reject Select");
		type(AddStorePageLocators.remark_txtarea, "Test Finance Approval Remarks", "Finance Approval Remarks");
		click(AddStorePageLocators.financeApproval_submit_btn, "Submit Button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Finance Approval Success Message");
		result = true;
		return result;
	}
	
	public boolean fillGroupDetails() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Group Details Page");
		click(AddStorePageLocators.groupDetails_lnk, "Group Details Link");
		type(AddStorePageLocators.groupName_txt, groupName, "Group Name");
		type(AddStorePageLocators.contactName_txt, contactName, "Contact Name");
		type(AddStorePageLocators.phone_txt, contactPhone, "Phone");
		type(AddStorePageLocators.mobile_txt, contactMobile, "Mobile");
		type(AddStorePageLocators.contactAdd1_txt, contactAddress1, "Address1");
		if((contactAddress2 != null)&&(contactAddress2 != ""))
		type(AddStorePageLocators.contactAdd2_txt, contactAddress2, "Address2");
		if((contactAddress3 != null)&&(contactAddress3 != ""))
		type(AddStorePageLocators.contactAdd3_txt, contactAddress3, "Address3");
		selectByVisibleText(AddStorePageLocators.contactCountry_select, contactCountry, "Country");
		selectByVisibleText(AddStorePageLocators.contactState_select, contactState, "State");
		selectByVisibleText(AddStorePageLocators.contactCity_select, contactCity, "City");		
		type(AddStorePageLocators.contactZip_txt, contactZipcode, "Zip Code");
		type(AddStorePageLocators.contactEmail_txt, contactEmail, "Email ID");
		if((primaryOwnerFirstName != null)&&(primaryOwnerFirstName != ""))
		type(AddStorePageLocators.primaryOwnerFname_txt, primaryOwnerFirstName, "Primary Owner First Name");
		if((primaryOwnerMiddleName != null)&&(primaryOwnerMiddleName != ""))
			type(AddStorePageLocators.primaryOwnerMname_txt, primaryOwnerMiddleName, "Primary Owner Middle Name");
		if((primaryOwnerLastName != null)&&(primaryOwnerLastName != ""))
			type(AddStorePageLocators.primaryOwnerLname_txt, primaryOwnerLastName, "Primary Owner Last Name");
		if((primaryOwnerPhone != null)&&(primaryOwnerPhone != ""))
			type(AddStorePageLocators.primaryOwnerPhone_txt, primaryOwnerPhone, "Primary Owner Phone");
		if((primaryOwnerMobile != null)&&(primaryOwnerMobile != ""))
			type(AddStorePageLocators.primaryOwnerMobile_txt, primaryOwnerMobile, "Primary Owner Mobile");
		if((primaryOwnerZipcode != null)&&(primaryOwnerZipcode != ""))
			type(AddStorePageLocators.primaryOwnerZipcode_txt, primaryOwnerZipcode, "Primary Owner Zipcode");
		if((primaryOwnerAddress1 != null)&&(primaryOwnerAddress1 != ""))
			type(AddStorePageLocators.primaryOwnerAdd1_txt, primaryOwnerAddress1, "Primary Owner Address 1");
		if((primaryOwnerAddress2 != null)&&(primaryOwnerAddress2 != ""))
			type(AddStorePageLocators.primaryOwnerAdd2_txt, primaryOwnerAddress2, "Primary Owner Address 2");
		if((primaryOwnerFax != null)&&(primaryOwnerFax != ""))
			type(AddStorePageLocators.primaryOwnerFax_txt, primaryOwnerFax, "Primary Owner Fax");
		
		if((secondaryOwnerFirstName != null)&&(secondaryOwnerFirstName != ""))
			type(AddStorePageLocators.secondaryOwnerFname_txt, secondaryOwnerFirstName, "Secondary Owner First Name");
		if((secondaryOwnerMiddleName != null)&&(secondaryOwnerMiddleName != ""))
			type(AddStorePageLocators.secondaryOwnerMname_txt, secondaryOwnerMiddleName, "Secondary Owner Middle Name");
		if((secondaryOwnerLastName != null)&&(secondaryOwnerLastName != ""))
			type(AddStorePageLocators.secondaryOwnerLname_txt, secondaryOwnerLastName, "Secondary Owner Last Name");
		if((secondaryOwnerPhone != null)&&(secondaryOwnerPhone != ""))
			type(AddStorePageLocators.secondaryOwnerPhone_txt, secondaryOwnerPhone, "Secondary Owner Phone");
		if((secondaryOwnerMobile != null)&&(secondaryOwnerMobile != ""))
			type(AddStorePageLocators.secondaryOwnerMobile_txt, secondaryOwnerMobile, "Secondary Owner Mobile");
		if((secondaryOwnerZipcode != null)&&(secondaryOwnerZipcode != ""))
			type(AddStorePageLocators.secondaryOwnerZipcode_txt, secondaryOwnerZipcode, "Secondary Owner Zipcode");
		if((secondaryOwnerAddress1 != null)&&(secondaryOwnerAddress1 != ""))
			type(AddStorePageLocators.secondaryOwnerAdd1_txt, secondaryOwnerAddress1, "Secondary Owner Address 1");
		if((secondaryOwnerAddress2 != null)&&(secondaryOwnerAddress2 != ""))
			type(AddStorePageLocators.secondaryOwnerAdd2_txt, secondaryOwnerAddress2, "Secondary Owner Address 2");
		if((secondaryOwnerFax != null)&&(secondaryOwnerFax != ""))
			type(AddStorePageLocators.secondaryOwnerFax_txt, secondaryOwnerFax, "Secondary Owner Fax");

		
		click(AddStorePageLocators.save_btn, "Save Button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Group Details Save Successful Message");
		result = true;
		return result;		
	}
	
	public boolean fillWebsiteSummary() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("WebSite Summary Page");
		click(AddStorePageLocators.websiteSummary_lnk, "Web Summary Link");
		waitForElementPresent(AddStorePageLocators.transactionTnC_Yes_btn, "Transaction terms and condition - Yes button");
		
		if((corporateInfo != null)&&(corporateInfo != ""))
			type(AddStorePageLocators.corBussName_txt, corporateInfo, "Corporate Information");
		if((comprehensiveBackground != null)&&(comprehensiveBackground != ""))
			type(AddStorePageLocators.corOwner_txt, comprehensiveBackground, "Comprehensive Background");
		if((meBusinessModelDesc != null)&&(meBusinessModelDesc != ""))
			type(AddStorePageLocators.busModel_txt, meBusinessModelDesc, "Business Model");
		if((goodsServicesDesc != null)&&(goodsServicesDesc != ""))
			type(AddStorePageLocators.goodsServiceOff_txt, goodsServicesDesc, "Goods & Services Description");
		if((returnPolicies != null)&&(returnPolicies != ""))
			type(AddStorePageLocators.rtReFrPCanPol_txt, returnPolicies, "Return Policies");
		if((meCustServiceContactInfo != null)&&(meCustServiceContactInfo != ""))
			type(AddStorePageLocators.srvcNo_txt, meCustServiceContactInfo, "ME Customer Service Contact Info");
		if((transactionCurrency != null)&&(transactionCurrency != ""))
			type(AddStorePageLocators.trnCurr_txt, transactionCurrency, "Transaction Currency");
		if((deliveryPolicy != null)&&(deliveryPolicy != ""))
			type(AddStorePageLocators.delPol_txt, deliveryPolicy, "Delivery Policy");
		if((dataPrivacyPolicy != null)&&(dataPrivacyPolicy != ""))
			type(AddStorePageLocators.dataPrivPol_txt, dataPrivacyPolicy, "Data Privacy Policy");
		if((recurringTransDetails != null)&&(recurringTransDetails != ""))
			type(AddStorePageLocators.recTrnDet_txt, recurringTransDetails, "Recurring Transaction Details");
		if((shipDetails != null)&&(shipDetails != ""))
			type(AddStorePageLocators.shpCostDet_txt, shipDetails, "Shipping Details");
		if((infoMethodTransSecurity != null)&&(infoMethodTransSecurity != ""))
			type(AddStorePageLocators.secMethod_txt, infoMethodTransSecurity, "Info about Transaction Security");
		if(transTermsConditions.contentEquals("Y"))
		click(AddStorePageLocators.transactionTnC_Yes_btn, "Transaction terms and condition - Yes button");
		if(merchWebsite.contentEquals("Y"))
		click(AddStorePageLocators.websiteCond_Yes_btn, "Merchant's web site should not carry a search engine leading to casino - Yes button");
		
		type(AddStorePageLocators.briefSummary_txt, briefSummaryGoods, "Brief Summary of Goods");
		if((needInternCardAcceptance != null)&&(needInternCardAcceptance != ""))
			type(AddStorePageLocators.intCard_txt, needInternCardAcceptance, "Need International Acceptance");
		
		if((payChannelsVolumeSplit_Internet != null)&&(payChannelsVolumeSplit_Internet != ""))
			type(AddStorePageLocators.ipgPayVol_txt, payChannelsVolumeSplit_Internet, "Internet - Pay Volume Split");
		
		if((payChannelsVolumeSplit_Mail != null)&&(payChannelsVolumeSplit_Mail != ""))
			type(AddStorePageLocators.phyOrderVol_txt, payChannelsVolumeSplit_Mail, "Mail - Pay Volume Split");
		if((payChannelsVolumeSplit_PosCC != null)&&(payChannelsVolumeSplit_PosCC != ""))
			type(AddStorePageLocators.posCcVol_txt, payChannelsVolumeSplit_PosCC, "POS CC - Pay Volume Split");
		if((payChannelsVolumeSplit_PosDC != null)&&(payChannelsVolumeSplit_PosDC != ""))
			type(AddStorePageLocators.posDcVol_txt, payChannelsVolumeSplit_PosDC, "POS DC - Pay Volume Split");
		if((busChannelPayVolSplit_B2B != null)&&(busChannelPayVolSplit_B2B != ""))
			type(AddStorePageLocators.b2bVol_txt, busChannelPayVolSplit_B2B, "B2B - Pay Volume Split");
		if((busChannelPayVolSplit_B2C != null)&&(busChannelPayVolSplit_B2C != ""))
			type(AddStorePageLocators.b2cVol_txt, busChannelPayVolSplit_B2C, "B2C - Pay Volume Split");
		if(acceptONlinePay.equalsIgnoreCase("N"))
			click(AddStorePageLocators.onlinePayment_No_btn, "Online Payment - No button");
		else
			click(AddStorePageLocators.onlinePayment_Yes_btn, "Online Payment - Yes button");
		if((processorBankName != null)&&(processorBankName != ""))
			type(AddStorePageLocators.gatewayName_txt, processorBankName, "Processor/Gateway Name");
		if((howLongWithProcess != null)&&(howLongWithProcess != ""))
			selectByVisibleText(AddStorePageLocators.procusedMnths_select, howLongWithProcess, "How long with this process?");
		if((annualOnlineTurnover != null)&&(annualOnlineTurnover != ""))
			type(AddStorePageLocators.annualTurnOver_txt, annualOnlineTurnover, "Annual Online Turnover");
		if((annualOfflineTurnover != null)&&(annualOfflineTurnover != ""))
			type(AddStorePageLocators.offLineTurnOver_txt, annualOfflineTurnover, "Annual Offline Turnover");
		if((minTicketSize != null)&&(minTicketSize != ""))
			type(AddStorePageLocators.minTcktSize_txt, minTicketSize, "Min Ticket Size");
		if((maxTicketSize != null)&&(maxTicketSize != ""))
			type(AddStorePageLocators.maxTcktSize_txt, maxTicketSize, "Max Ticket Size");
		if((timeFrames0 != null)&&(timeFrames0 != ""))
			type(AddStorePageLocators.delper1_txt, timeFrames0, "Timeframe - 0 days");
		if((timeFrames1_3 != null)&&(timeFrames1_3 != ""))
			type(AddStorePageLocators.delper2_txt, timeFrames1_3, "Timeframe 1 - 3 days");
		if((timeFrames4_7 != null)&&(timeFrames4_7 != ""))
			type(AddStorePageLocators.delper3_txt, timeFrames4_7, "Timeframe 4 - 7 days");
		if((timeFrames8_14 != null)&&(timeFrames8_14 != ""))
			type(AddStorePageLocators.delper4_txt, timeFrames8_14, "Timeframe 8 - 14 days");
		if((timeFrames15_30 != null)&&(timeFrames15_30 != ""))
			type(AddStorePageLocators.delper5_txt, timeFrames15_30, "Timeframe 15 - 30 days");
		if(deposite.contentEquals("N"))
			click(AddStorePageLocators.depositFlag_No_btn, "Do you ask customers for deposit before delivering goods - No button");
		else
			click(AddStorePageLocators.depositFlag_Yes_btn, "Do you ask customers for deposit before delivering goods - Yes button");
		
		if(autoRenewals.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.autoRenewalFlag_Yes_btn, "Automatic Renewal - Yes button");
		else
			click(AddStorePageLocators.autoRenewalFlag_No_btn, "Automatic Renewal - No button");
		if(refundPolicyFull.equalsIgnoreCase("F"))
			click(AddStorePageLocators.refundPolicy_Full_btn, "Refund Policy - Full refund");
		else if(refundPolicyFull.equalsIgnoreCase("E"))
			click(AddStorePageLocators.refundPolicy_Exchange_btn, "Refund Policy - Exchange Only");
		else if(refundPolicyFull.equalsIgnoreCase("N"))
			click(AddStorePageLocators.refundPolicy_No_btn, "Refund Policy - No Refund");
		
		if(refundDays.equalsIgnoreCase("0-3"))
			click(AddStorePageLocators.refundProcDays_3_btn, "Refund Procedure Days - 3 button");
		else if(refundDays.equalsIgnoreCase("4-7"))
			click(AddStorePageLocators.refundProcDays_4_btn, "Refund Procedure Days - 4-7 button");
		else if(refundDays.equalsIgnoreCase("8-14"))
			click(AddStorePageLocators.refundProcDays_8_btn, "Refund Procedure Days - 8-14 button");
		else if(refundDays.contains("Over 14"))
			click(AddStorePageLocators.refundProcDays_15_btn, "Refund Procedure Days - Over 14 button");
		if((riskChecks != null)&&(riskChecks != ""))
			type(AddStorePageLocators.riskCheck_txt, riskChecks, "Perform Risk Checks");
		if(sendEmail.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.mailConfirmationFlag_Yes_btn, "Email Confirmation to Customer - Yes button");
		else
			click(AddStorePageLocators.mailConfirmationFlag_No_btn, "Email Confirmation to Customer - No button");
		if((timeBtwnPayDelivery != null)&&(timeBtwnPayDelivery != ""))
			type(AddStorePageLocators.turnAroundTime_txt, timeBtwnPayDelivery, "Chargeback Volume - last month");
		if((diwali != null)&&(diwali != ""))
			click(AddStorePageLocators.diwali_chkbox, "Diwali");
		if((christmas != null)&&(christmas != ""))
			click(AddStorePageLocators.christmas_chkbox, "Christmas");
		if((easter != null)&&(easter != ""))
			click(AddStorePageLocators.easter_chkbox, "Easter");
		if((summerSales != null)&&(summerSales != ""))
			click(AddStorePageLocators.summerSale_chkbox, "Summer Sales");
		
		type(AddStorePageLocators.chargebackVol_txt, chargeBackVol, "Chargeback Volume - last month");
		type(AddStorePageLocators.numberOfRefunds_txt, NoOfFunds, "Number of Refunds - last month");
		type(AddStorePageLocators.numberOfTxns_txt, NoOfTrans, "Number of Transactions - last month");
		type(AddStorePageLocators.refundVol_txt, refundVolume, "Refund Volume - last month");
		type(AddStorePageLocators.salesVol_txt, salesVolume, "Sales Volume - last month");
		click(AddStorePageLocators.saveWebSummary_btn, "Submit button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "WebSite Summary Save Successful Message");
		result = true;
		return result;		
	}
	
	
	//Suresh
	
	public boolean addAcquiringBank_host() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Add Acquiring Bank Page");
		click(AddStorePageLocators.acquiringBank_lnk, "Acquiring Bank Link");
		waitForElementPresent(AddStorePageLocators.addNewAcqBank_btn, "Add New Acquiring Bank");
		click(AddStorePageLocators.addNewAcqBank_btn, "Add New Acquiring Bank - button");
		waitForElementPresent(AddStorePageLocators.legalVehicleName_select, "Acquiring Bank Setup");
		selectByVisibleText(AddStorePageLocators.legalVehicleName_select, lvId, "Legal Vehicle - Select");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.acqBankName_select, bankName, "Bank Name - Select");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.acqBankZone_select, zone, "Zone - Select");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.acqBranch_select, branch, "Branch - Select");
		
		//MERCHANT ACCOUNT DETAILS
		type(AddStorePageLocators.merchAccNo_txt, merchAccNumber, "ME Account Number");
		if((merchAccOpenDate != null)&&(merchAccOpenDate != "")){
			js_type(AddStorePageLocators.accOpenDate_txt, merchAccOpenDate, "Account Open Date");
		}else if(merchAccOpenDate != null){
			click(AddStorePageLocators.accOpenDate_txt, "ME Account Open Date");
			Thread.sleep(2000);
			hitKey(AddStorePageLocators.accOpenDate_txt, Keys.ENTER,"ME Account Open Date");
		}
		type(AddStorePageLocators.merchBankName_txt, merchBankName, "ME Bank Name");
		if((merchAccState != null)&&(merchAccState != ""))
			selectByVisibleText(AddStorePageLocators.meBankState_select, merchAccState, "ME Bank State");
		Thread.sleep(2000);
		if((merchAccCity != null)&&(merchAccCity != ""))
			selectByVisibleText(AddStorePageLocators.meBankCity_select, merchAccCity, "ME Bank City");
		if((merchAccPhone != null)&&(merchAccPhone != ""))
			type(AddStorePageLocators.meAccPhone_txt, merchAccPhone, "ME Account Phone");
		if((merchAccMobile != null)&&(merchAccMobile != ""))
			type(AddStorePageLocators.meAccMobile_txt, merchAccMobile, "ME Account Mobile");
		if((merchAccAddress1 != null)&&(merchAccAddress1 != ""))
			type(AddStorePageLocators.meAccAddress1_txt, merchAccAddress1, "ME Account Address1");
		if((merchAccAddress2 != null)&&(merchAccAddress2 != ""))
			type(AddStorePageLocators.meAccAddress2_txt, merchAccAddress2, "ME Account Address2");
		
		//FEE SETUP
		HtmlReportSupport.reportStep("Fee Setup Section");
		type(AddStorePageLocators.oneTimeFixedFee_txt, oneTimeFixedFee, "One Time Fixed Fee");
		type(AddStorePageLocators.statementFee_txt, statementFee, "Statement Fee");
		type(AddStorePageLocators.terminalFee_txt, terminalFee, "Terminal Fee");
		type(AddStorePageLocators.minimumUsage_txt, minimumUsage, "Minimum Usage");
		type(AddStorePageLocators.minTransAmt_txt, minTransAmt, "Minimum Transaction Amount");
		type(AddStorePageLocators.minUsageFee_txt, minUsageFee, "Minimum Usage Fee");
		selectByVisibleText(AddStorePageLocators.amcType_select, amcType, "AMC Type");
		type(AddStorePageLocators.amcAmount_txt, amcAmount, "AMC Amount");
		type(AddStorePageLocators.nonUsage_txt, nonUsage, "Non Usage");
		type(AddStorePageLocators.nonUsageFee_txt, nonUsageFee, "Non Usage Fee");		
		//Settlement Setup
		HtmlReportSupport.reportStep("Settlement Setup Section");
		if(settlementType.equalsIgnoreCase("manual"))
			click(AddStorePageLocators.settlementTypeManual_btn, "Settlement Type - Manual");
		if(settlementType.equalsIgnoreCase("automatic")){
			click(AddStorePageLocators.settlementTypeAuto_btn, "Settlement Type - Automatic");
			selectByVisibleText(AddStorePageLocators.settleCycle_select, "Daily", "Statement Cycle");
		}
		selectByVisibleText(AddStorePageLocators.paymentBy_select, paymentBy, "Payment By");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.paymentAdvice_select, paymentAdvice, "Payment Advice");
		//Miscellaneous
		HtmlReportSupport.reportStep("Miscellaneous Section");
		type(AddStorePageLocators.dailyTransLimit_txt, dailyTransLimit, "Daily Transaction Limit");
		if(firc.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.firc_yes_radio, "FIRC - Yes - button");
		else if(firc.equalsIgnoreCase("N"))
			click(AddStorePageLocators.firc_no_radio, "FIRC - No - button");
		if((applicationMode != null)&&(applicationMode != ""))
			selectByVisibleText(AddStorePageLocators.applicationMode_select, applicationMode, "Application Mode");
		if((transactionMode != null)&&(transactionMode != ""))
			selectByVisibleText(AddStorePageLocators.transactionMode_select, transactionMode, "Transaction Mode");
		if((fircFrequency != null)&&(fircFrequency != ""))
			selectByVisibleText(AddStorePageLocators.fircFrequency_select, fircFrequency, "FIRC Frequency");
		if((fuelAssociation != null)&&(fuelAssociation != ""))
			selectByVisibleText(AddStorePageLocators.fuelAssociation_select, fuelAssociation, "Fuel Association");
		if((fuelRemark != null)&&(fuelRemark != ""))
			type(AddStorePageLocators.fuelRemarks_txt, fuelRemark, "Fuel Remarks");
		if((callCharges != null)&&(callCharges != ""))
			type(AddStorePageLocators.callCharges_txt, callCharges, "Call Charges");
		if((secretKey != null)&&(secretKey != ""))
			type(AddStorePageLocators.secretKey_txt, secretKey, "Secret Key");
		if((documentRequired != null)&&(documentRequired != "")){
			if(documentRequired.equalsIgnoreCase("Y"))
				click(AddStorePageLocators.documentRequired_Yes_btn, "Document Required - Yes");
			else
				click(AddStorePageLocators.documentRequired_No_btn, "Document Required - No");
		}
		if((documentPending != null)&&(documentPending != "")){
			if(documentPending.equalsIgnoreCase("Y"))
				click(AddStorePageLocators.documentPending_Yes_btn, "Document Pending - Yes");
			else
				click(AddStorePageLocators.documentPending_No_btn, "Document Pending - No");
		}
		if((merchReimbursement != null)&&(merchReimbursement != ""))
			type(AddStorePageLocators.merchantReimbursement_txt, merchReimbursement, "Merchant Reimbursement");
		if((customerId != null)&&(customerId != ""))
			type(AddStorePageLocators.customerId_txt, customerId, "Customer ID");
		
		//PCPOS
		HtmlReportSupport.reportStep("Acquiring Bank - PCPOS Section");
		if((tccDescriptor != null)&&(tccDescriptor != ""))
			selectByVisibleText(AddStorePageLocators.tccDescriptor_select, tccDescriptor, "TCC Descriptor");
		if((projectedAvgTicketSize != null)&&(projectedAvgTicketSize != ""))
			type(AddStorePageLocators.projectedAvgTicketSize_txt, projectedAvgTicketSize, "Projected Average Ticket Size");
		if((newPayAdviceValue != null)&&(newPayAdviceValue.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.nwPaymentAdvice_Yes, "New Payment Advice - Yes");
		else if((newPayAdviceValue != null)&&(newPayAdviceValue.equalsIgnoreCase("N")))
			click(AddStorePageLocators.nwPaymentAdvice_No, "New Payment Advice - No");
		if((rental != null)&&(rental.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.rental_yes, "Rental - Yes");
		else if((rental != null)&&(rental.equalsIgnoreCase("N")))
			click(AddStorePageLocators.rental_no, "Rental - No");
		if((rentalFrequencyValue != null)&&(rentalFrequencyValue != ""))
			selectByVisibleText(AddStorePageLocators.rentalFrequency_select, rentalFrequencyValue, "Rental Frequency Value");
		if((advanceRent != null)&&(advanceRent.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.advRent_yes, "Advance Rent - Yes");
		else if((advanceRent != null)&&(advanceRent.equalsIgnoreCase("N")))
			click(AddStorePageLocators.advRent_no, "Advance Rent - No");
		if((advanceRentalFrequency != null)&&(advanceRentalFrequency != ""))
			type(AddStorePageLocators.advRentalFrequency_txt, advanceRentalFrequency, "advanceRentalFrequency");
		if((advanceRentalAmount != null)&&(advanceRentalAmount != ""))
			type(AddStorePageLocators.advRentalAmt_txt, advanceRentalAmount, "advanceRentalAmount");
		if((advanceSetup != null)&&(advanceSetup.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.advSetup_yes, "Advance Setup - Yes");
		else if((advanceSetup != null)&&(advanceSetup.equalsIgnoreCase("N")))
			click(AddStorePageLocators.advSetup_no, "Advance Setup - No");
		if((advanceSetupFee != null)&&(advanceSetupFee != ""))
			type(AddStorePageLocators.advSetupFee_txt, advanceSetupFee, "advanceSetupFee");
		if((msfIncentive != null)&&(msfIncentive != ""))
			type(AddStorePageLocators.msfIncentive_txt, msfIncentive, "msfIncentive");
		if((merchantIncentive != null)&&(merchantIncentive != ""))
			type(AddStorePageLocators.merchIncentive_txt, merchantIncentive, "merchantIncentive");
		if((tipPercent != null)&&(tipPercent != ""))
			type(AddStorePageLocators.tipPercent_txt, tipPercent, "tipPercent");
		if((cashPOS != null)&&(cashPOS.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.cashPos_yes, "cashPOS - Yes");
		else if((cashPOS != null)&&(cashPOS.equalsIgnoreCase("N")))
			click(AddStorePageLocators.cashPos_no, "cashPOS - No");
		if((saleWithCashBack != null)&&(saleWithCashBack.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.cashBackPur_yes, "saleWithCashBack - Yes");
		else if((saleWithCashBack != null)&&(saleWithCashBack.equalsIgnoreCase("N")))
			click(AddStorePageLocators.cashBackPur_no, "saleWithCashBack - No");
		
		//MID SETUP
		HtmlReportSupport.reportStep("MID SETUP");
		selectByVisibleText(AddStorePageLocators.merchIdType_select, merchIdType, "Merchant ID Type");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.currency_select, currency, "Currency");
		if((mid != null)&&(mid != "")){
			mid = mid + RandomTextUtils.getRandomNumberInRange(111111111, 999999999);
			type(AddStorePageLocators.mid_txt, mid, "MID");
		}
		if((tid != null)&&(tid != ""))
			type(AddStorePageLocators.tid_txt, tid, "TID");
		type(AddStorePageLocators.amexMaId_txt, amexMaId, "Amex MA ID");
		type(AddStorePageLocators.amexMaPwd_txt, amexMaPassword, "Amex MA Password");
		type(AddStorePageLocators.amexAmaId_txt, amexAmaId, "Amex AMA ID");
		type(AddStorePageLocators.amexAmaPassword_txt, amexAmaPassword, "Amex AMA Password");
		type(AddStorePageLocators.amexAccessCode_txt, amexAccessCode, "Amex Access Code");
		type(AddStorePageLocators.amexSecureSecret_txt, amexSecureSecret, "Amex Secure Secret");
		click(AddStorePageLocators.add_btn, "Add MID - button");
		Thread.sleep(3000);
		click(AddStorePageLocators.save_btn, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Add Acquiring Bank Success Message");
		
		//ROUND 2 - Add WLI bank
		HtmlReportSupport.reportStep("Add Acquiring Bank 2 Page");
		click(AddStorePageLocators.acquiringBank_lnk, "Acquiring Bank Link");
		waitForElementPresent(AddStorePageLocators.addNewAcqBank_btn, "Add New Acquiring Bank");
		click(AddStorePageLocators.addNewAcqBank_btn, "Add New Acquiring Bank - button");
		waitForElementPresent(AddStorePageLocators.legalVehicleName_select, "Acquiring Bank Setup");
		selectByVisibleText(AddStorePageLocators.legalVehicleName_select, "Worldline", "Legal Vehicle - Select");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.acqBankName_select, "WLI", "Bank Name - Select");
		Thread.sleep(1000);
		
		
		/*if((zone != null)&&(zone != ""))
			selectByVisibleText(AddStorePageLocators.acqBankZone_select, zone, "Zone - Select");
		Thread.sleep(1000);
		if((branch != null)&&(branch != ""))
			selectByVisibleText(AddStorePageLocators.acqBranch_select, branch, "Branch - Select");*/
		
		//MERCHANT ACCOUNT DETAILS
		if((merchAccNumber != null)&&(merchAccNumber != "")){
			HtmlReportSupport.reportStep("Merchant Account Details Section");
			type(AddStorePageLocators.merchAccNo_txt, merchAccNumber, "ME Account Number");
			if((merchAccOpenDate != null)&&(merchAccOpenDate != "")){
				js_type(AddStorePageLocators.accOpenDate_txt, merchAccOpenDate, "Account Open Date");
			}else if(merchAccOpenDate != null){
				click(AddStorePageLocators.accOpenDate_txt, "ME Account Open Date");
				Thread.sleep(2000);
				hitKey(AddStorePageLocators.accOpenDate_txt, Keys.ENTER,"ME Account Open Date");
			}
			type(AddStorePageLocators.merchBankName_txt, merchBankName, "ME Bank Name");
			if((merchAccState != null)&&(merchAccState != ""))
				selectByVisibleText(AddStorePageLocators.meBankState_select, merchAccState, "ME Bank State");
			Thread.sleep(2000);
			if((merchAccCity != null)&&(merchAccCity != ""))
				selectByVisibleText(AddStorePageLocators.meBankCity_select, merchAccCity, "ME Bank City");
			if((merchAccPhone != null)&&(merchAccPhone != ""))
				type(AddStorePageLocators.meAccPhone_txt, merchAccPhone, "ME Account Phone");
			if((merchAccMobile != null)&&(merchAccMobile != ""))
				type(AddStorePageLocators.meAccMobile_txt, merchAccMobile, "ME Account Mobile");
			if((merchAccAddress1 != null)&&(merchAccAddress1 != ""))
				type(AddStorePageLocators.meAccAddress1_txt, merchAccAddress1, "ME Account Address1");
			if((merchAccAddress2 != null)&&(merchAccAddress2 != ""))
				type(AddStorePageLocators.meAccAddress2_txt, merchAccAddress2, "ME Account Address2");
		}
		
		//FEE SETUP
		if((amcAmount != null)&&(amcAmount != "")){
			HtmlReportSupport.reportStep("Fee Setup Section");
			type(AddStorePageLocators.oneTimeFixedFee_txt, oneTimeFixedFee, "One Time Fixed Fee");
			type(AddStorePageLocators.statementFee_txt, statementFee, "Statement Fee");
			type(AddStorePageLocators.terminalFee_txt, terminalFee, "Terminal Fee");
			type(AddStorePageLocators.minimumUsage_txt, minimumUsage, "Minimum Usage");
			type(AddStorePageLocators.minTransAmt_txt, minTransAmt, "Minimum Transaction Amount");
			type(AddStorePageLocators.minUsageFee_txt, minUsageFee, "Minimum Usage Fee");
			selectByVisibleText(AddStorePageLocators.amcType_select, amcType, "AMC Type");
			type(AddStorePageLocators.amcAmount_txt, amcAmount, "AMC Amount");
			type(AddStorePageLocators.nonUsage_txt, nonUsage, "Non Usage");
			type(AddStorePageLocators.nonUsageFee_txt, nonUsageFee, "Non Usage Fee");
			if((securityAmount != null)&&(securityAmount != ""))
				type(AddStorePageLocators.securityAmt_txt, "8888", "Security Amount");
		}
		//Settlement Setup
		HtmlReportSupport.reportStep("Settlement Setup Section");
		if(settlementType.equalsIgnoreCase("manual"))
			click(AddStorePageLocators.settlementTypeManual_btn, "Settlement Type - Manual");
		if(settlementType.equalsIgnoreCase("automatic")){
			click(AddStorePageLocators.settlementTypeAuto_btn, "Settlement Type - Automatic");
			selectByVisibleText(AddStorePageLocators.settleCycle_select, "Daily", "Statement Cycle");
		}
		if((paymentBy != null)&&(paymentBy != "")){
			selectByVisibleText(AddStorePageLocators.paymentBy_select, paymentBy, "Payment By");
			Thread.sleep(1000);
		}
		if((paymentAdvice != null)&&(paymentAdvice != "")){
			selectByVisibleText(AddStorePageLocators.paymentAdvice_select, paymentAdvice, "Payment Advice");
		}
		//suresh
		if((NodalAccount != null)&&(NodalAccount != "")){
			selectByVisibleText(AddStorePageLocators.NodalAccount_select, "KOTAK", "Nodal Account");
		}
		//Miscellaneous
		HtmlReportSupport.reportStep("Miscellaneous Section");
		type(AddStorePageLocators.dailyTransLimit_txt, dailyTransLimit, "Daily Transaction Limit");
		if(firc.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.firc_yes_radio, "FIRC - Yes - button");
		else if(firc.equalsIgnoreCase("N"))
			click(AddStorePageLocators.firc_no_radio, "FIRC - No - button");
		if((applicationMode != null)&&(applicationMode != ""))
			selectByVisibleText(AddStorePageLocators.applicationMode_select, applicationMode, "Application Mode");
		if((transactionMode != null)&&(transactionMode != ""))
			selectByVisibleText(AddStorePageLocators.transactionMode_select, transactionMode, "Transaction Mode");
		if((fircFrequency != null)&&(fircFrequency != ""))
			selectByVisibleText(AddStorePageLocators.fircFrequency_select, fircFrequency, "FIRC Frequency");
		if((fuelAssociation != null)&&(fuelAssociation != ""))
			selectByVisibleText(AddStorePageLocators.fuelAssociation_select, fuelAssociation, "Fuel Association");
		if((fuelRemark != null)&&(fuelRemark != ""))
			type(AddStorePageLocators.fuelRemarks_txt, fuelRemark, "Fuel Remarks");
		if((callCharges != null)&&(callCharges != ""))
			type(AddStorePageLocators.callCharges_txt, callCharges, "Call Charges");
		if((secretKey != null)&&(secretKey != ""))
			type(AddStorePageLocators.secretKey_txt, secretKey, "Secret Key");
		if((documentRequired != null)&&(documentRequired != "")){
			if(documentRequired.equalsIgnoreCase("Y"))
				click(AddStorePageLocators.documentRequired_Yes_btn, "Document Required - Yes");
			else
				click(AddStorePageLocators.documentRequired_No_btn, "Document Required - No");
		}
		if((documentPending != null)&&(documentPending != "")){
			if(documentPending.equalsIgnoreCase("Y"))
				click(AddStorePageLocators.documentPending_Yes_btn, "Document Pending - Yes");
			else
				click(AddStorePageLocators.documentPending_No_btn, "Document Pending - No");
		}
		if((merchReimbursement != null)&&(merchReimbursement != ""))
			type(AddStorePageLocators.merchantReimbursement_txt, merchReimbursement, "Merchant Reimbursement");
		if((customerId != null)&&(customerId != ""))
			type(AddStorePageLocators.customerId_txt, customerId, "Customer ID");
		
		//PCPOS
		HtmlReportSupport.reportStep("Acquiring Bank - PCPOS Section");
		if((tccDescriptor != null)&&(tccDescriptor != ""))
			selectByVisibleText(AddStorePageLocators.tccDescriptor_select, tccDescriptor, "TCC Descriptor");
		if((projectedAvgTicketSize != null)&&(projectedAvgTicketSize != ""))
			type(AddStorePageLocators.projectedAvgTicketSize_txt, projectedAvgTicketSize, "Projected Average Ticket Size");
		if((newPayAdviceValue != null)&&(newPayAdviceValue.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.nwPaymentAdvice_Yes, "New Payment Advice - Yes");
		else if((newPayAdviceValue != null)&&(newPayAdviceValue.equalsIgnoreCase("N")))
			click(AddStorePageLocators.nwPaymentAdvice_No, "New Payment Advice - No");
		if((rental != null)&&(rental.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.rental_yes, "Rental - Yes");
		else if((rental != null)&&(rental.equalsIgnoreCase("N")))
			click(AddStorePageLocators.rental_no, "Rental - No");
		if((rentalFrequencyValue != null)&&(rentalFrequencyValue != ""))
			selectByVisibleText(AddStorePageLocators.rentalFrequency_select, rentalFrequencyValue, "Rental Frequency Value");
		if((advanceRent != null)&&(advanceRent.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.advRent_yes, "Advance Rent - Yes");
		else if((advanceRent != null)&&(advanceRent.equalsIgnoreCase("N")))
			click(AddStorePageLocators.advRent_no, "Advance Rent - No");
		if((advanceRentalFrequency != null)&&(advanceRentalFrequency != ""))
			type(AddStorePageLocators.advRentalFrequency_txt, advanceRentalFrequency, "advanceRentalFrequency");
		if((advanceRentalAmount != null)&&(advanceRentalAmount != ""))
			type(AddStorePageLocators.advRentalAmt_txt, advanceRentalAmount, "advanceRentalAmount");
		if((advanceSetup != null)&&(advanceSetup.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.advSetup_yes, "Advance Setup - Yes");
		else if((advanceSetup != null)&&(advanceSetup.equalsIgnoreCase("N")))
			click(AddStorePageLocators.advSetup_no, "Advance Setup - No");
		if((advanceSetupFee != null)&&(advanceSetupFee != ""))
			type(AddStorePageLocators.advSetupFee_txt, advanceSetupFee, "advanceSetupFee");
		if((msfIncentive != null)&&(msfIncentive != ""))
			type(AddStorePageLocators.msfIncentive_txt, msfIncentive, "msfIncentive");
		if((merchantIncentive != null)&&(merchantIncentive != ""))
			type(AddStorePageLocators.merchIncentive_txt, merchantIncentive, "merchantIncentive");
		if((tipPercent != null)&&(tipPercent != ""))
			type(AddStorePageLocators.tipPercent_txt, tipPercent, "tipPercent");
		if((cashPOS != null)&&(cashPOS.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.cashPos_yes, "cashPOS - Yes");
		else if((cashPOS != null)&&(cashPOS.equalsIgnoreCase("N")))
			click(AddStorePageLocators.cashPos_no, "cashPOS - No");
		if((saleWithCashBack != null)&&(saleWithCashBack.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.cashBackPur_yes, "saleWithCashBack - Yes");
		else if((saleWithCashBack != null)&&(saleWithCashBack.equalsIgnoreCase("N")))
			click(AddStorePageLocators.cashBackPur_no, "saleWithCashBack - No");
		
		Thread.sleep(3000);
		click(AddStorePageLocators.save_btn, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Add Acquiring Bank Success Message");
		
		result = true;
		return result;
	}
	
	//Suresh
	
	
	public boolean addAcquiringBank() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Add Acquiring Bank Page");
		click(AddStorePageLocators.acquiringBank_lnk, "Acquiring Bank Link");
		waitForElementPresent(AddStorePageLocators.addNewAcqBank_btn, "Add New Acquiring Bank");
		click(AddStorePageLocators.addNewAcqBank_btn, "Add New Acquiring Bank - button");
		waitForElementPresent(AddStorePageLocators.legalVehicleName_select, "Acquiring Bank Setup");
		selectByVisibleText(AddStorePageLocators.legalVehicleName_select, lvId, "Legal Vehicle - Select");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.acqBankName_select, bankName, "Bank Name - Select");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.acqBankZone_select, zone, "Zone - Select");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.acqBranch_select, branch, "Branch - Select");
		
		//MERCHANT ACCOUNT DETAILS
		type(AddStorePageLocators.merchAccNo_txt, merchAccNumber, "ME Account Number");
		if((merchAccOpenDate != null)&&(merchAccOpenDate != "")){
			js_type(AddStorePageLocators.accOpenDate_txt, merchAccOpenDate, "Account Open Date");
		}else if(merchAccOpenDate != null){
			click(AddStorePageLocators.accOpenDate_txt, "ME Account Open Date");
			Thread.sleep(2000);
			hitKey(AddStorePageLocators.accOpenDate_txt, Keys.ENTER,"ME Account Open Date");
		}
		type(AddStorePageLocators.merchBankName_txt, merchBankName, "ME Bank Name");
		if((merchAccState != null)&&(merchAccState != ""))
			selectByVisibleText(AddStorePageLocators.meBankState_select, merchAccState, "ME Bank State");
		Thread.sleep(2000);
		if((merchAccCity != null)&&(merchAccCity != ""))
			selectByVisibleText(AddStorePageLocators.meBankCity_select, merchAccCity, "ME Bank City");
		if((merchAccPhone != null)&&(merchAccPhone != ""))
			type(AddStorePageLocators.meAccPhone_txt, merchAccPhone, "ME Account Phone");
		if((merchAccMobile != null)&&(merchAccMobile != ""))
			type(AddStorePageLocators.meAccMobile_txt, merchAccMobile, "ME Account Mobile");
		if((merchAccAddress1 != null)&&(merchAccAddress1 != ""))
			type(AddStorePageLocators.meAccAddress1_txt, merchAccAddress1, "ME Account Address1");
		if((merchAccAddress2 != null)&&(merchAccAddress2 != ""))
			type(AddStorePageLocators.meAccAddress2_txt, merchAccAddress2, "ME Account Address2");
		
		//FEE SETUP
		HtmlReportSupport.reportStep("Fee Setup Section");
		type(AddStorePageLocators.oneTimeFixedFee_txt, oneTimeFixedFee, "One Time Fixed Fee");
		type(AddStorePageLocators.statementFee_txt, statementFee, "Statement Fee");
		type(AddStorePageLocators.terminalFee_txt, terminalFee, "Terminal Fee");
		type(AddStorePageLocators.minimumUsage_txt, minimumUsage, "Minimum Usage");
		type(AddStorePageLocators.minTransAmt_txt, minTransAmt, "Minimum Transaction Amount");
		type(AddStorePageLocators.minUsageFee_txt, minUsageFee, "Minimum Usage Fee");
		selectByVisibleText(AddStorePageLocators.amcType_select, amcType, "AMC Type");
		type(AddStorePageLocators.amcAmount_txt, amcAmount, "AMC Amount");
		type(AddStorePageLocators.nonUsage_txt, nonUsage, "Non Usage");
		type(AddStorePageLocators.nonUsageFee_txt, nonUsageFee, "Non Usage Fee");		
		//Settlement Setup
		HtmlReportSupport.reportStep("Settlement Setup Section");
		if(settlementType.equalsIgnoreCase("manual"))
			click(AddStorePageLocators.settlementTypeManual_btn, "Settlement Type - Manual");
		if(settlementType.equalsIgnoreCase("automatic")){
			click(AddStorePageLocators.settlementTypeAuto_btn, "Settlement Type - Automatic");
			selectByVisibleText(AddStorePageLocators.settleCycle_select, "Daily", "Statement Cycle");
		}
		selectByVisibleText(AddStorePageLocators.paymentBy_select, paymentBy, "Payment By");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.paymentAdvice_select, paymentAdvice, "Payment Advice");
		//Miscellaneous
		HtmlReportSupport.reportStep("Miscellaneous Section");
		type(AddStorePageLocators.dailyTransLimit_txt, dailyTransLimit, "Daily Transaction Limit");
		if(firc.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.firc_yes_radio, "FIRC - Yes - button");
		else if(firc.equalsIgnoreCase("N"))
			click(AddStorePageLocators.firc_no_radio, "FIRC - No - button");
		if((applicationMode != null)&&(applicationMode != ""))
			selectByVisibleText(AddStorePageLocators.applicationMode_select, applicationMode, "Application Mode");
		if((transactionMode != null)&&(transactionMode != ""))
			selectByVisibleText(AddStorePageLocators.transactionMode_select, transactionMode, "Transaction Mode");
		if((fircFrequency != null)&&(fircFrequency != ""))
			selectByVisibleText(AddStorePageLocators.fircFrequency_select, fircFrequency, "FIRC Frequency");
		if((fuelAssociation != null)&&(fuelAssociation != ""))
			selectByVisibleText(AddStorePageLocators.fuelAssociation_select, fuelAssociation, "Fuel Association");
		if((fuelRemark != null)&&(fuelRemark != ""))
			type(AddStorePageLocators.fuelRemarks_txt, fuelRemark, "Fuel Remarks");
		if((callCharges != null)&&(callCharges != ""))
			type(AddStorePageLocators.callCharges_txt, callCharges, "Call Charges");
		if((secretKey != null)&&(secretKey != ""))
			type(AddStorePageLocators.secretKey_txt, secretKey, "Secret Key");
		if((documentRequired != null)&&(documentRequired != "")){
			if(documentRequired.equalsIgnoreCase("Y"))
				click(AddStorePageLocators.documentRequired_Yes_btn, "Document Required - Yes");
			else
				click(AddStorePageLocators.documentRequired_No_btn, "Document Required - No");
		}
		if((documentPending != null)&&(documentPending != "")){
			if(documentPending.equalsIgnoreCase("Y"))
				click(AddStorePageLocators.documentPending_Yes_btn, "Document Pending - Yes");
			else
				click(AddStorePageLocators.documentPending_No_btn, "Document Pending - No");
		}
		if((merchReimbursement != null)&&(merchReimbursement != ""))
			type(AddStorePageLocators.merchantReimbursement_txt, merchReimbursement, "Merchant Reimbursement");
		if((customerId != null)&&(customerId != ""))
			type(AddStorePageLocators.customerId_txt, customerId, "Customer ID");
		
		//PCPOS
		HtmlReportSupport.reportStep("Acquiring Bank - PCPOS Section");
		if((tccDescriptor != null)&&(tccDescriptor != ""))
			selectByVisibleText(AddStorePageLocators.tccDescriptor_select, tccDescriptor, "TCC Descriptor");
		if((projectedAvgTicketSize != null)&&(projectedAvgTicketSize != ""))
			type(AddStorePageLocators.projectedAvgTicketSize_txt, projectedAvgTicketSize, "Projected Average Ticket Size");
		if((newPayAdviceValue != null)&&(newPayAdviceValue.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.nwPaymentAdvice_Yes, "New Payment Advice - Yes");
		else if((newPayAdviceValue != null)&&(newPayAdviceValue.equalsIgnoreCase("N")))
			click(AddStorePageLocators.nwPaymentAdvice_No, "New Payment Advice - No");
		if((rental != null)&&(rental.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.rental_yes, "Rental - Yes");
		else if((rental != null)&&(rental.equalsIgnoreCase("N")))
			click(AddStorePageLocators.rental_no, "Rental - No");
		if((rentalFrequencyValue != null)&&(rentalFrequencyValue != ""))
			selectByVisibleText(AddStorePageLocators.rentalFrequency_select, rentalFrequencyValue, "Rental Frequency Value");
		if((advanceRent != null)&&(advanceRent.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.advRent_yes, "Advance Rent - Yes");
		else if((advanceRent != null)&&(advanceRent.equalsIgnoreCase("N")))
			click(AddStorePageLocators.advRent_no, "Advance Rent - No");
		if((advanceRentalFrequency != null)&&(advanceRentalFrequency != ""))
			type(AddStorePageLocators.advRentalFrequency_txt, advanceRentalFrequency, "advanceRentalFrequency");
		if((advanceRentalAmount != null)&&(advanceRentalAmount != ""))
			type(AddStorePageLocators.advRentalAmt_txt, advanceRentalAmount, "advanceRentalAmount");
		if((advanceSetup != null)&&(advanceSetup.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.advSetup_yes, "Advance Setup - Yes");
		else if((advanceSetup != null)&&(advanceSetup.equalsIgnoreCase("N")))
			click(AddStorePageLocators.advSetup_no, "Advance Setup - No");
		if((advanceSetupFee != null)&&(advanceSetupFee != ""))
			type(AddStorePageLocators.advSetupFee_txt, advanceSetupFee, "advanceSetupFee");
		if((msfIncentive != null)&&(msfIncentive != ""))
			type(AddStorePageLocators.msfIncentive_txt, msfIncentive, "msfIncentive");
		if((merchantIncentive != null)&&(merchantIncentive != ""))
			type(AddStorePageLocators.merchIncentive_txt, merchantIncentive, "merchantIncentive");
		if((tipPercent != null)&&(tipPercent != ""))
			type(AddStorePageLocators.tipPercent_txt, tipPercent, "tipPercent");
		if((cashPOS != null)&&(cashPOS.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.cashPos_yes, "cashPOS - Yes");
		else if((cashPOS != null)&&(cashPOS.equalsIgnoreCase("N")))
			click(AddStorePageLocators.cashPos_no, "cashPOS - No");
		if((saleWithCashBack != null)&&(saleWithCashBack.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.cashBackPur_yes, "saleWithCashBack - Yes");
		else if((saleWithCashBack != null)&&(saleWithCashBack.equalsIgnoreCase("N")))
			click(AddStorePageLocators.cashBackPur_no, "saleWithCashBack - No");
		
		//MID SETUP
		HtmlReportSupport.reportStep("MID SETUP");
		selectByVisibleText(AddStorePageLocators.merchIdType_select, merchIdType, "Merchant ID Type");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.currency_select, currency, "Currency");
		if((mid != null)&&(mid != "")){
			mid = mid + RandomTextUtils.getRandomNumberInRange(111111111, 999999999);
			type(AddStorePageLocators.mid_txt, mid, "MID");
		}
		if((tid != null)&&(tid != ""))
			type(AddStorePageLocators.tid_txt, tid, "TID");
		type(AddStorePageLocators.amexMaId_txt, amexMaId, "Amex MA ID");
		type(AddStorePageLocators.amexMaPwd_txt, amexMaPassword, "Amex MA Password");
		type(AddStorePageLocators.amexAmaId_txt, amexAmaId, "Amex AMA ID");
		type(AddStorePageLocators.amexAmaPassword_txt, amexAmaPassword, "Amex AMA Password");
		type(AddStorePageLocators.amexAccessCode_txt, amexAccessCode, "Amex Access Code");
		type(AddStorePageLocators.amexSecureSecret_txt, amexSecureSecret, "Amex Secure Secret");
		click(AddStorePageLocators.add_btn, "Add MID - button");
		Thread.sleep(3000);
		click(AddStorePageLocators.save_btn, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Add Acquiring Bank Success Message");
		
		//ROUND 2 - Add WLI bank
		/*HtmlReportSupport.reportStep("Add Acquiring Bank 2 Page");
		click(AddStorePageLocators.acquiringBank_lnk, "Acquiring Bank Link");
		waitForElementPresent(AddStorePageLocators.addNewAcqBank_btn, "Add New Acquiring Bank");
		click(AddStorePageLocators.addNewAcqBank_btn, "Add New Acquiring Bank - button");
		waitForElementPresent(AddStorePageLocators.legalVehicleName_select, "Acquiring Bank Setup");
		selectByVisibleText(AddStorePageLocators.legalVehicleName_select, "Worldline", "Legal Vehicle - Select");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.acqBankName_select, "WLI", "Bank Name - Select");
		Thread.sleep(1000);
		if((zone != null)&&(zone != ""))
			selectByVisibleText(AddStorePageLocators.acqBankZone_select, zone, "Zone - Select");
		Thread.sleep(1000);
		if((branch != null)&&(branch != ""))
			selectByVisibleText(AddStorePageLocators.acqBranch_select, branch, "Branch - Select");
		
		//MERCHANT ACCOUNT DETAILS
		if((merchAccNumber != null)&&(merchAccNumber != "")){
			HtmlReportSupport.reportStep("Merchant Account Details Section");
			type(AddStorePageLocators.merchAccNo_txt, merchAccNumber, "ME Account Number");
			if((merchAccOpenDate != null)&&(merchAccOpenDate != "")){
				js_type(AddStorePageLocators.accOpenDate_txt, merchAccOpenDate, "Account Open Date");
			}else if(merchAccOpenDate != null){
				click(AddStorePageLocators.accOpenDate_txt, "ME Account Open Date");
				Thread.sleep(2000);
				hitKey(AddStorePageLocators.accOpenDate_txt, Keys.ENTER,"ME Account Open Date");
			}
			type(AddStorePageLocators.merchBankName_txt, merchBankName, "ME Bank Name");
			if((merchAccState != null)&&(merchAccState != ""))
				selectByVisibleText(AddStorePageLocators.meBankState_select, merchAccState, "ME Bank State");
			Thread.sleep(2000);
			if((merchAccCity != null)&&(merchAccCity != ""))
				selectByVisibleText(AddStorePageLocators.meBankCity_select, merchAccCity, "ME Bank City");
			if((merchAccPhone != null)&&(merchAccPhone != ""))
				type(AddStorePageLocators.meAccPhone_txt, merchAccPhone, "ME Account Phone");
			if((merchAccMobile != null)&&(merchAccMobile != ""))
				type(AddStorePageLocators.meAccMobile_txt, merchAccMobile, "ME Account Mobile");
			if((merchAccAddress1 != null)&&(merchAccAddress1 != ""))
				type(AddStorePageLocators.meAccAddress1_txt, merchAccAddress1, "ME Account Address1");
			if((merchAccAddress2 != null)&&(merchAccAddress2 != ""))
				type(AddStorePageLocators.meAccAddress2_txt, merchAccAddress2, "ME Account Address2");
		}
		
		//FEE SETUP
		if((amcAmount != null)&&(amcAmount != "")){
			HtmlReportSupport.reportStep("Fee Setup Section");
			type(AddStorePageLocators.oneTimeFixedFee_txt, oneTimeFixedFee, "One Time Fixed Fee");
			type(AddStorePageLocators.statementFee_txt, statementFee, "Statement Fee");
			type(AddStorePageLocators.terminalFee_txt, terminalFee, "Terminal Fee");
			type(AddStorePageLocators.minimumUsage_txt, minimumUsage, "Minimum Usage");
			type(AddStorePageLocators.minTransAmt_txt, minTransAmt, "Minimum Transaction Amount");
			type(AddStorePageLocators.minUsageFee_txt, minUsageFee, "Minimum Usage Fee");
			selectByVisibleText(AddStorePageLocators.amcType_select, amcType, "AMC Type");
			type(AddStorePageLocators.amcAmount_txt, amcAmount, "AMC Amount");
			type(AddStorePageLocators.nonUsage_txt, nonUsage, "Non Usage");
			type(AddStorePageLocators.nonUsageFee_txt, nonUsageFee, "Non Usage Fee");
			if((securityAmount != null)&&(securityAmount != ""))
				type(AddStorePageLocators.securityAmt_txt, "666", "Security Amount");
		}
		//Settlement Setup
		HtmlReportSupport.reportStep("Settlement Setup Section");
		if(settlementType.equalsIgnoreCase("manual"))
			click(AddStorePageLocators.settlementTypeManual_btn, "Settlement Type - Manual");
		if(settlementType.equalsIgnoreCase("automatic")){
			click(AddStorePageLocators.settlementTypeAuto_btn, "Settlement Type - Automatic");
			selectByVisibleText(AddStorePageLocators.settleCycle_select, "Daily", "Statement Cycle");
		}
		if((paymentBy != null)&&(paymentBy != "")){
			selectByVisibleText(AddStorePageLocators.paymentBy_select, paymentBy, "Payment By");
			Thread.sleep(1000);
		}
		if((paymentAdvice != null)&&(paymentAdvice != "")){
			selectByVisibleText(AddStorePageLocators.paymentAdvice_select, paymentAdvice, "Payment Advice");
		}
		//Miscellaneous
		HtmlReportSupport.reportStep("Miscellaneous Section");
		type(AddStorePageLocators.dailyTransLimit_txt, dailyTransLimit, "Daily Transaction Limit");
		if(firc.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.firc_yes_radio, "FIRC - Yes - button");
		else if(firc.equalsIgnoreCase("N"))
			click(AddStorePageLocators.firc_no_radio, "FIRC - No - button");
		if((applicationMode != null)&&(applicationMode != ""))
			selectByVisibleText(AddStorePageLocators.applicationMode_select, applicationMode, "Application Mode");
		if((transactionMode != null)&&(transactionMode != ""))
			selectByVisibleText(AddStorePageLocators.transactionMode_select, transactionMode, "Transaction Mode");
		if((fircFrequency != null)&&(fircFrequency != ""))
			selectByVisibleText(AddStorePageLocators.fircFrequency_select, fircFrequency, "FIRC Frequency");
		if((fuelAssociation != null)&&(fuelAssociation != ""))
			selectByVisibleText(AddStorePageLocators.fuelAssociation_select, fuelAssociation, "Fuel Association");
		if((fuelRemark != null)&&(fuelRemark != ""))
			type(AddStorePageLocators.fuelRemarks_txt, fuelRemark, "Fuel Remarks");
		if((callCharges != null)&&(callCharges != ""))
			type(AddStorePageLocators.callCharges_txt, callCharges, "Call Charges");
		if((secretKey != null)&&(secretKey != ""))
			type(AddStorePageLocators.secretKey_txt, secretKey, "Secret Key");
		if((documentRequired != null)&&(documentRequired != "")){
			if(documentRequired.equalsIgnoreCase("Y"))
				click(AddStorePageLocators.documentRequired_Yes_btn, "Document Required - Yes");
			else
				click(AddStorePageLocators.documentRequired_No_btn, "Document Required - No");
		}
		if((documentPending != null)&&(documentPending != "")){
			if(documentPending.equalsIgnoreCase("Y"))
				click(AddStorePageLocators.documentPending_Yes_btn, "Document Pending - Yes");
			else
				click(AddStorePageLocators.documentPending_No_btn, "Document Pending - No");
		}
		if((merchReimbursement != null)&&(merchReimbursement != ""))
			type(AddStorePageLocators.merchantReimbursement_txt, merchReimbursement, "Merchant Reimbursement");
		if((customerId != null)&&(customerId != ""))
			type(AddStorePageLocators.customerId_txt, customerId, "Customer ID");
		
		//PCPOS
		HtmlReportSupport.reportStep("Acquiring Bank - PCPOS Section");
		if((tccDescriptor != null)&&(tccDescriptor != ""))
			selectByVisibleText(AddStorePageLocators.tccDescriptor_select, tccDescriptor, "TCC Descriptor");
		if((projectedAvgTicketSize != null)&&(projectedAvgTicketSize != ""))
			type(AddStorePageLocators.projectedAvgTicketSize_txt, projectedAvgTicketSize, "Projected Average Ticket Size");
		if((newPayAdviceValue != null)&&(newPayAdviceValue.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.nwPaymentAdvice_Yes, "New Payment Advice - Yes");
		else if((newPayAdviceValue != null)&&(newPayAdviceValue.equalsIgnoreCase("N")))
			click(AddStorePageLocators.nwPaymentAdvice_No, "New Payment Advice - No");
		if((rental != null)&&(rental.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.rental_yes, "Rental - Yes");
		else if((rental != null)&&(rental.equalsIgnoreCase("N")))
			click(AddStorePageLocators.rental_no, "Rental - No");
		if((rentalFrequencyValue != null)&&(rentalFrequencyValue != ""))
			selectByVisibleText(AddStorePageLocators.rentalFrequency_select, rentalFrequencyValue, "Rental Frequency Value");
		if((advanceRent != null)&&(advanceRent.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.advRent_yes, "Advance Rent - Yes");
		else if((advanceRent != null)&&(advanceRent.equalsIgnoreCase("N")))
			click(AddStorePageLocators.advRent_no, "Advance Rent - No");
		if((advanceRentalFrequency != null)&&(advanceRentalFrequency != ""))
			type(AddStorePageLocators.advRentalFrequency_txt, advanceRentalFrequency, "advanceRentalFrequency");
		if((advanceRentalAmount != null)&&(advanceRentalAmount != ""))
			type(AddStorePageLocators.advRentalAmt_txt, advanceRentalAmount, "advanceRentalAmount");
		if((advanceSetup != null)&&(advanceSetup.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.advSetup_yes, "Advance Setup - Yes");
		else if((advanceSetup != null)&&(advanceSetup.equalsIgnoreCase("N")))
			click(AddStorePageLocators.advSetup_no, "Advance Setup - No");
		if((advanceSetupFee != null)&&(advanceSetupFee != ""))
			type(AddStorePageLocators.advSetupFee_txt, advanceSetupFee, "advanceSetupFee");
		if((msfIncentive != null)&&(msfIncentive != ""))
			type(AddStorePageLocators.msfIncentive_txt, msfIncentive, "msfIncentive");
		if((merchantIncentive != null)&&(merchantIncentive != ""))
			type(AddStorePageLocators.merchIncentive_txt, merchantIncentive, "merchantIncentive");
		if((tipPercent != null)&&(tipPercent != ""))
			type(AddStorePageLocators.tipPercent_txt, tipPercent, "tipPercent");
		if((cashPOS != null)&&(cashPOS.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.cashPos_yes, "cashPOS - Yes");
		else if((cashPOS != null)&&(cashPOS.equalsIgnoreCase("N")))
			click(AddStorePageLocators.cashPos_no, "cashPOS - No");
		if((saleWithCashBack != null)&&(saleWithCashBack.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.cashBackPur_yes, "saleWithCashBack - Yes");
		else if((saleWithCashBack != null)&&(saleWithCashBack.equalsIgnoreCase("N")))
			click(AddStorePageLocators.cashBackPur_no, "saleWithCashBack - No");
		
		Thread.sleep(3000);
		click(AddStorePageLocators.save_btn, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Add Acquiring Bank Success Message");*/
		
		result = true;
		return result;
	}
	
	public boolean addAcquiringBankForAggregatorMerch(String pgMerchantId) throws Throwable{
		boolean result = false;
		//ROUND 1
		HtmlReportSupport.reportStep("Add Acquiring Bank 1 Page");
		click(AddStorePageLocators.acquiringBank_lnk, "Acquiring Bank Link");
		waitForElementPresent(AddStorePageLocators.addNewAcqBank_btn, "Add New Acquiring Bank");
		click(AddStorePageLocators.addNewAcqBank_btn, "Add New Acquiring Bank - button");
		waitForElementPresent(AddStorePageLocators.legalVehicleName_select, "Acquiring Bank Setup");
		selectByVisibleText(AddStorePageLocators.legalVehicleName_select, lvId, "Legal Vehicle - Select");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.acqBankName_select, bankName, "Bank Name - Select");
		Thread.sleep(1000);
		if((zone != null)&&(zone != ""))
			selectByVisibleText(AddStorePageLocators.acqBankZone_select, zone, "Zone - Select");
		Thread.sleep(1000);
		if((branch != null)&&(branch != ""))
			selectByVisibleText(AddStorePageLocators.acqBranch_select, branch, "Branch - Select");
		
		//Miscellaneous
		HtmlReportSupport.reportStep("Miscellaneous Section");
		type(AddStorePageLocators.dailyTransLimit_txt, dailyTransLimit, "Daily Transaction Limit");
		if(firc.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.firc_yes_radio, "FIRC - Yes - button");
		else if(firc.equalsIgnoreCase("N"))
			click(AddStorePageLocators.firc_no_radio, "FIRC - No - button");
		if((applicationMode != null)&&(applicationMode != ""))
			selectByVisibleText(AddStorePageLocators.applicationMode_select, applicationMode, "Application Mode");
		if((transactionMode != null)&&(transactionMode != ""))
			selectByVisibleText(AddStorePageLocators.transactionMode_select, transactionMode, "Transaction Mode");
		if((fircFrequency != null)&&(fircFrequency != ""))
			selectByVisibleText(AddStorePageLocators.fircFrequency_select, fircFrequency, "FIRC Frequency");
		if((fuelAssociation != null)&&(fuelAssociation != ""))
			selectByVisibleText(AddStorePageLocators.fuelAssociation_select, fuelAssociation, "Fuel Association");
		if((fuelRemark != null)&&(fuelRemark != ""))
			type(AddStorePageLocators.fuelRemarks_txt, fuelRemark, "Fuel Remarks");
		if((callCharges != null)&&(callCharges != ""))
			type(AddStorePageLocators.callCharges_txt, callCharges, "Call Charges");
		if((secretKey != null)&&(secretKey != ""))
			type(AddStorePageLocators.secretKey_txt, secretKey, "Secret Key");
		if((documentRequired != null)&&(documentRequired != "")){
			if(documentRequired.equalsIgnoreCase("Y"))
				click(AddStorePageLocators.documentRequired_Yes_btn, "Document Required - Yes");
			else
				click(AddStorePageLocators.documentRequired_No_btn, "Document Required - No");
		}
		if((documentPending != null)&&(documentPending != "")){
			if(documentPending.equalsIgnoreCase("Y"))
				click(AddStorePageLocators.documentPending_Yes_btn, "Document Pending - Yes");
			else
				click(AddStorePageLocators.documentPending_No_btn, "Document Pending - No");
		}
		if((merchReimbursement != null)&&(merchReimbursement != ""))
			type(AddStorePageLocators.merchantReimbursement_txt, merchReimbursement, "Merchant Reimbursement");
		if((customerId != null)&&(customerId != ""))
			type(AddStorePageLocators.customerId_txt, customerId, "Customer ID");
		
		//PCPOS
		HtmlReportSupport.reportStep("Acquiring Bank - PCPOS Section");
		if((tccDescriptor != null)&&(tccDescriptor != ""))
			selectByVisibleText(AddStorePageLocators.tccDescriptor_select, tccDescriptor, "TCC Descriptor");
		if((projectedAvgTicketSize != null)&&(projectedAvgTicketSize != ""))
			type(AddStorePageLocators.projectedAvgTicketSize_txt, projectedAvgTicketSize, "Projected Average Ticket Size");
		if((newPayAdviceValue != null)&&(newPayAdviceValue.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.nwPaymentAdvice_Yes, "New Payment Advice - Yes");
		else if((newPayAdviceValue != null)&&(newPayAdviceValue.equalsIgnoreCase("N")))
			click(AddStorePageLocators.nwPaymentAdvice_No, "New Payment Advice - No");
		if((rental != null)&&(rental.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.rental_yes, "Rental - Yes");
		else if((rental != null)&&(rental.equalsIgnoreCase("N")))
			click(AddStorePageLocators.rental_no, "Rental - No");
		if((rentalFrequencyValue != null)&&(rentalFrequencyValue != ""))
			selectByVisibleText(AddStorePageLocators.rentalFrequency_select, rentalFrequencyValue, "Rental Frequency Value");
		if((advanceRent != null)&&(advanceRent.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.advRent_yes, "Advance Rent - Yes");
		else if((advanceRent != null)&&(advanceRent.equalsIgnoreCase("N")))
			click(AddStorePageLocators.advRent_no, "Advance Rent - No");
		if((advanceRentalFrequency != null)&&(advanceRentalFrequency != ""))
			type(AddStorePageLocators.advRentalFrequency_txt, advanceRentalFrequency, "advanceRentalFrequency");
		if((advanceRentalAmount != null)&&(advanceRentalAmount != ""))
			type(AddStorePageLocators.advRentalAmt_txt, advanceRentalAmount, "advanceRentalAmount");
		if((advanceSetup != null)&&(advanceSetup.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.advSetup_yes, "Advance Setup - Yes");
		else if((advanceSetup != null)&&(advanceSetup.equalsIgnoreCase("N")))
			click(AddStorePageLocators.advSetup_no, "Advance Setup - No");
		if((advanceSetupFee != null)&&(advanceSetupFee != ""))
			type(AddStorePageLocators.advSetupFee_txt, advanceSetupFee, "advanceSetupFee");
		if((msfIncentive != null)&&(msfIncentive != ""))
			type(AddStorePageLocators.msfIncentive_txt, msfIncentive, "msfIncentive");
		if((merchantIncentive != null)&&(merchantIncentive != ""))
			type(AddStorePageLocators.merchIncentive_txt, merchantIncentive, "merchantIncentive");
		if((tipPercent != null)&&(tipPercent != ""))
			type(AddStorePageLocators.tipPercent_txt, tipPercent, "tipPercent");
		if((cashPOS != null)&&(cashPOS.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.cashPos_yes, "cashPOS - Yes");
		else if((cashPOS != null)&&(cashPOS.equalsIgnoreCase("N")))
			click(AddStorePageLocators.cashPos_no, "cashPOS - No");
		if((saleWithCashBack != null)&&(saleWithCashBack.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.cashBackPur_yes, "saleWithCashBack - Yes");
		else if((saleWithCashBack != null)&&(saleWithCashBack.equalsIgnoreCase("N")))
			click(AddStorePageLocators.cashBackPur_no, "saleWithCashBack - No");
		
		//MID SETUP
		HtmlReportSupport.reportStep("MID SETUP");
		selectByVisibleText(AddStorePageLocators.merchIdType_select, merchIdType, "Merchant ID Type");
		Thread.sleep(1000);
		selectByVisibleText(AddStorePageLocators.currency_select, currency, "Currency");
		
		type(AddStorePageLocators.mid_txt, pgMerchantId, "MID");
		
		if((tid != null)&&(tid != ""))
			type(AddStorePageLocators.tid_txt, tid, "TID");
		type(AddStorePageLocators.amexMaId_txt, amexMaId, "Amex MA ID");
		type(AddStorePageLocators.amexMaPwd_txt, amexMaPassword, "Amex MA Password");
		type(AddStorePageLocators.amexAmaId_txt, amexAmaId, "Amex AMA ID");
		type(AddStorePageLocators.amexAmaPassword_txt, amexAmaPassword, "Amex AMA Password");
		type(AddStorePageLocators.amexAccessCode_txt, amexAccessCode, "Amex Access Code");
		type(AddStorePageLocators.amexSecureSecret_txt, amexSecureSecret, "Amex Secure Secret");
		click(AddStorePageLocators.add_btn, "Add MID - button");
		Thread.sleep(3000);
		click(AddStorePageLocators.save_btn, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Add Acquiring Bank Success Message");
		
		
		//ROUND 2 - Add WLI bank
				HtmlReportSupport.reportStep("Add Acquiring Bank 2 Page");
				click(AddStorePageLocators.acquiringBank_lnk, "Acquiring Bank Link");
				waitForElementPresent(AddStorePageLocators.addNewAcqBank_btn, "Add New Acquiring Bank");
				click(AddStorePageLocators.addNewAcqBank_btn, "Add New Acquiring Bank - button");
				waitForElementPresent(AddStorePageLocators.legalVehicleName_select, "Acquiring Bank Setup");
				selectByVisibleText(AddStorePageLocators.legalVehicleName_select, lvId, "Legal Vehicle - Select");
				Thread.sleep(1000);
				selectByVisibleText(AddStorePageLocators.acqBankName_select, "WLI", "Bank Name - Select");
				Thread.sleep(1000);
				if((zone != null)&&(zone != ""))
					selectByVisibleText(AddStorePageLocators.acqBankZone_select, zone, "Zone - Select");
				Thread.sleep(1000);
				if((branch != null)&&(branch != ""))
					selectByVisibleText(AddStorePageLocators.acqBranch_select, branch, "Branch - Select");
				
				//MERCHANT ACCOUNT DETAILS
				if((merchAccNumber != null)&&(merchAccNumber != "")){
					HtmlReportSupport.reportStep("Merchant Account Details Section");
					type(AddStorePageLocators.merchAccNo_txt, merchAccNumber, "ME Account Number");
					if((merchAccOpenDate != null)&&(merchAccOpenDate != "")){
						js_type(AddStorePageLocators.accOpenDate_txt, merchAccOpenDate, "Account Open Date");
					}else if(merchAccOpenDate != null){
						click(AddStorePageLocators.accOpenDate_txt, "ME Account Open Date");
						Thread.sleep(2000);
						hitKey(AddStorePageLocators.accOpenDate_txt, Keys.ENTER,"ME Account Open Date");
					}
					type(AddStorePageLocators.merchBankName_txt, merchBankName, "ME Bank Name");
					if((merchAccState != null)&&(merchAccState != ""))
						selectByVisibleText(AddStorePageLocators.meBankState_select, merchAccState, "ME Bank State");
					Thread.sleep(2000);
					if((merchAccCity != null)&&(merchAccCity != ""))
						selectByVisibleText(AddStorePageLocators.meBankCity_select, merchAccCity, "ME Bank City");
					if((merchAccPhone != null)&&(merchAccPhone != ""))
						type(AddStorePageLocators.meAccPhone_txt, merchAccPhone, "ME Account Phone");
					if((merchAccMobile != null)&&(merchAccMobile != ""))
						type(AddStorePageLocators.meAccMobile_txt, merchAccMobile, "ME Account Mobile");
					if((merchAccAddress1 != null)&&(merchAccAddress1 != ""))
						type(AddStorePageLocators.meAccAddress1_txt, merchAccAddress1, "ME Account Address1");
					if((merchAccAddress2 != null)&&(merchAccAddress2 != ""))
						type(AddStorePageLocators.meAccAddress2_txt, merchAccAddress2, "ME Account Address2");
				}
				
				//FEE SETUP
				if((amcAmount != null)&&(amcAmount != "")){
					HtmlReportSupport.reportStep("Fee Setup Section");
					type(AddStorePageLocators.oneTimeFixedFee_txt, oneTimeFixedFee, "One Time Fixed Fee");
					type(AddStorePageLocators.statementFee_txt, statementFee, "Statement Fee");
					type(AddStorePageLocators.terminalFee_txt, terminalFee, "Terminal Fee");
					type(AddStorePageLocators.minimumUsage_txt, minimumUsage, "Minimum Usage");
					type(AddStorePageLocators.minTransAmt_txt, minTransAmt, "Minimum Transaction Amount");
					type(AddStorePageLocators.minUsageFee_txt, minUsageFee, "Minimum Usage Fee");
					selectByVisibleText(AddStorePageLocators.amcType_select, amcType, "AMC Type");
					type(AddStorePageLocators.amcAmount_txt, amcAmount, "AMC Amount");
					type(AddStorePageLocators.nonUsage_txt, nonUsage, "Non Usage");
					type(AddStorePageLocators.nonUsageFee_txt, nonUsageFee, "Non Usage Fee");
					if((securityAmount != null)&&(securityAmount != ""))
						type(AddStorePageLocators.securityAmt_txt, securityAmount, "Security Amount");
				}
				//Settlement Setup
				HtmlReportSupport.reportStep("Settlement Setup Section");
				if(settlementType.equalsIgnoreCase("manual"))
					click(AddStorePageLocators.settlementTypeManual_btn, "Settlement Type - Manual");
				if(settlementType.equalsIgnoreCase("automatic")){
					click(AddStorePageLocators.settlementTypeAuto_btn, "Settlement Type - Automatic");
					selectByVisibleText(AddStorePageLocators.settleCycle_select, "Daily", "Statement Cycle");
				}
				if((paymentBy != null)&&(paymentBy != "")){
					selectByVisibleText(AddStorePageLocators.paymentBy_select, paymentBy, "Payment By");
					Thread.sleep(1000);
				}
				if((paymentAdvice != null)&&(paymentAdvice != "")){
					selectByVisibleText(AddStorePageLocators.paymentAdvice_select, paymentAdvice, "Payment Advice");
				}
				//suresh
				if((NodalAccount != null)&&(NodalAccount != "")){
					selectByVisibleText(AddStorePageLocators.NodalAccount_select, NodalAccount, "Nodal Account");
				}
				//Miscellaneous
				HtmlReportSupport.reportStep("Miscellaneous Section");
				type(AddStorePageLocators.dailyTransLimit_txt, dailyTransLimit, "Daily Transaction Limit");
				if(firc.equalsIgnoreCase("Y"))
					click(AddStorePageLocators.firc_yes_radio, "FIRC - Yes - button");
				else if(firc.equalsIgnoreCase("N"))
					click(AddStorePageLocators.firc_no_radio, "FIRC - No - button");
				if((applicationMode != null)&&(applicationMode != ""))
					selectByVisibleText(AddStorePageLocators.applicationMode_select, applicationMode, "Application Mode");
				if((transactionMode != null)&&(transactionMode != ""))
					selectByVisibleText(AddStorePageLocators.transactionMode_select, transactionMode, "Transaction Mode");
				if((fircFrequency != null)&&(fircFrequency != ""))
					selectByVisibleText(AddStorePageLocators.fircFrequency_select, fircFrequency, "FIRC Frequency");
				if((fuelAssociation != null)&&(fuelAssociation != ""))
					selectByVisibleText(AddStorePageLocators.fuelAssociation_select, fuelAssociation, "Fuel Association");
				if((fuelRemark != null)&&(fuelRemark != ""))
					type(AddStorePageLocators.fuelRemarks_txt, fuelRemark, "Fuel Remarks");
				if((callCharges != null)&&(callCharges != ""))
					type(AddStorePageLocators.callCharges_txt, callCharges, "Call Charges");
				if((secretKey != null)&&(secretKey != ""))
					type(AddStorePageLocators.secretKey_txt, secretKey, "Secret Key");
				if((documentRequired != null)&&(documentRequired != "")){
					if(documentRequired.equalsIgnoreCase("Y"))
						click(AddStorePageLocators.documentRequired_Yes_btn, "Document Required - Yes");
					else
						click(AddStorePageLocators.documentRequired_No_btn, "Document Required - No");
				}
				if((documentPending != null)&&(documentPending != "")){
					if(documentPending.equalsIgnoreCase("Y"))
						click(AddStorePageLocators.documentPending_Yes_btn, "Document Pending - Yes");
					else
						click(AddStorePageLocators.documentPending_No_btn, "Document Pending - No");
				}
				if((merchReimbursement != null)&&(merchReimbursement != ""))
					type(AddStorePageLocators.merchantReimbursement_txt, merchReimbursement, "Merchant Reimbursement");
				if((customerId != null)&&(customerId != ""))
					type(AddStorePageLocators.customerId_txt, customerId, "Customer ID");
				
				//PCPOS
				HtmlReportSupport.reportStep("Acquiring Bank - PCPOS Section");
				if((tccDescriptor != null)&&(tccDescriptor != ""))
					selectByVisibleText(AddStorePageLocators.tccDescriptor_select, tccDescriptor, "TCC Descriptor");
				if((projectedAvgTicketSize != null)&&(projectedAvgTicketSize != ""))
					type(AddStorePageLocators.projectedAvgTicketSize_txt, projectedAvgTicketSize, "Projected Average Ticket Size");
				if((newPayAdviceValue != null)&&(newPayAdviceValue.equalsIgnoreCase("Y")))
					click(AddStorePageLocators.nwPaymentAdvice_Yes, "New Payment Advice - Yes");
				else if((newPayAdviceValue != null)&&(newPayAdviceValue.equalsIgnoreCase("N")))
					click(AddStorePageLocators.nwPaymentAdvice_No, "New Payment Advice - No");
				if((rental != null)&&(rental.equalsIgnoreCase("Y")))
					click(AddStorePageLocators.rental_yes, "Rental - Yes");
				else if((rental != null)&&(rental.equalsIgnoreCase("N")))
					click(AddStorePageLocators.rental_no, "Rental - No");
				if((rentalFrequencyValue != null)&&(rentalFrequencyValue != ""))
					selectByVisibleText(AddStorePageLocators.rentalFrequency_select, rentalFrequencyValue, "Rental Frequency Value");
				if((advanceRent != null)&&(advanceRent.equalsIgnoreCase("Y")))
					click(AddStorePageLocators.advRent_yes, "Advance Rent - Yes");
				else if((advanceRent != null)&&(advanceRent.equalsIgnoreCase("N")))
					click(AddStorePageLocators.advRent_no, "Advance Rent - No");
				if((advanceRentalFrequency != null)&&(advanceRentalFrequency != ""))
					type(AddStorePageLocators.advRentalFrequency_txt, advanceRentalFrequency, "advanceRentalFrequency");
				if((advanceRentalAmount != null)&&(advanceRentalAmount != ""))
					type(AddStorePageLocators.advRentalAmt_txt, advanceRentalAmount, "advanceRentalAmount");
				if((advanceSetup != null)&&(advanceSetup.equalsIgnoreCase("Y")))
					click(AddStorePageLocators.advSetup_yes, "Advance Setup - Yes");
				else if((advanceSetup != null)&&(advanceSetup.equalsIgnoreCase("N")))
					click(AddStorePageLocators.advSetup_no, "Advance Setup - No");
				if((advanceSetupFee != null)&&(advanceSetupFee != ""))
					type(AddStorePageLocators.advSetupFee_txt, advanceSetupFee, "advanceSetupFee");
				if((msfIncentive != null)&&(msfIncentive != ""))
					type(AddStorePageLocators.msfIncentive_txt, msfIncentive, "msfIncentive");
				if((merchantIncentive != null)&&(merchantIncentive != ""))
					type(AddStorePageLocators.merchIncentive_txt, merchantIncentive, "merchantIncentive");
				if((tipPercent != null)&&(tipPercent != ""))
					type(AddStorePageLocators.tipPercent_txt, tipPercent, "tipPercent");
				if((cashPOS != null)&&(cashPOS.equalsIgnoreCase("Y")))
					click(AddStorePageLocators.cashPos_yes, "cashPOS - Yes");
				else if((cashPOS != null)&&(cashPOS.equalsIgnoreCase("N")))
					click(AddStorePageLocators.cashPos_no, "cashPOS - No");
				if((saleWithCashBack != null)&&(saleWithCashBack.equalsIgnoreCase("Y")))
					click(AddStorePageLocators.cashBackPur_yes, "saleWithCashBack - Yes");
				else if((saleWithCashBack != null)&&(saleWithCashBack.equalsIgnoreCase("N")))
					click(AddStorePageLocators.cashBackPur_no, "saleWithCashBack - No");
				
				Thread.sleep(3000);
				click(AddStorePageLocators.save_btn, "Save - button");
				waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Add Acquiring Bank Success Message");
		result = true;
		return result;
	}
	public boolean addPaymentType() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Add Payment Type Page");
		click(AddStorePageLocators.paymentType_lnk, "Payment Type");
		waitForElementPresent(AddStorePageLocators.payTypeCreditCard_chkbox, "Payment Type Page");
		if((paymentTypeCreditCard != null)&&(paymentTypeCreditCard.equalsIgnoreCase("Y"))){
			
			click(AddStorePageLocators.payTypeCreditCard_chkbox, "Payment Type - Credit Card");
			if((amexDomesticCc != null)&&(amexDomesticCc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.payTypeCreditCardDomestic_chkbox, "Payment Type - Credit Card - Domestic");
			if((amexInternationalCc != null)&&(amexInternationalCc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.payTypeCreditCardInternational_chkbox, "Payment Type - Credit Card - International");
			if((mastDomCc != null)&&(mastDomCc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.masterCardDomestic_chk, "Mastercard - CreditCard - Domestic - Checkbox");
			if((mastIntCc != null)&&(mastIntCc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.masterCardInternational_chk, "Mastercard - CreditCard - International - Checkbox");
			if((rupayDomCc != null)&&(rupayDomCc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.rupayCardDomestic_chk, "Rupay - CreditCard - Domestic - Checkbox");
			if((rupayIntCc != null)&&(rupayIntCc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.rupayCardInternational_chk, "Rupay - CreditCard - International - Checkbox");
			if((visaDomCc != null)&&(visaDomCc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.visaDomestic_chk, "Visa - CreditCard - Domestic - Checkbox");
			if((visaIntCc != null)&&(visaIntCc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.visaInternational_chk, "Visa - CreditCard - International - Checkbox");
		}
		if((paymentTypeDebitCard != null)&&(paymentTypeDebitCard.equalsIgnoreCase("Y"))){
			click(AddStorePageLocators.debitCard_chk, "Debit Card - Tab - Checkbox");
			waitForElementPresent(AddStorePageLocators.visaDbDom_chk, "Visa - Debit - Domestic - Checkbox");
			if((mastDomDc != null)&&(mastDomDc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.mastDbDom_chk, "MasterCard - Debit - Domestic - Checkbox");
			if((mastIntDc != null)&&(mastIntDc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.mastDbInt_chk, "MasterCard - Debit - International - Checkbox");
			if((rupayDomDc != null)&&(rupayDomDc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.rupayDbDom_chk, "Rupay - Debit - Domestic - Checkbox");
			if((rupayIntDc != null)&&(rupayIntDc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.rupayDbInt_chk, "Rupay - Debit - International - Checkbox");
			if((visaDomDc != null)&&(visaDomDc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.visaDbDom_chk, "Visa - Debit - Domestic - Checkbox");
			if((visaIntDc != null)&&(visaIntDc.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.visaDbInt_chk, "Visa - Debit - International - Checkbox");
			
		}
		if((paymentTypeInternetBank != null)&&(paymentTypeInternetBank.equalsIgnoreCase("Y"))){
			click(AddStorePageLocators.netbank_chk, "Internet Bank - Tab - Checkbox");
			if((internetBankLv != null)&&(internetBankLv != ""))
				selectByVisibleText(AddStorePageLocators.internetBankLv_select, internetBankLv, "Legal Vehicle - Select");
			if((internetBankSelectBank != null)&&(internetBankSelectBank != ""))
				selectByVisibleText(AddStorePageLocators.internetBankSelectBank_select, internetBankSelectBank, "Select Bank");
			if((internetBankEffectDate != null)&&(internetBankEffectDate != ""))
				js_type(AddStorePageLocators.internetBankEffDate_txt, internetBankEffectDate, "Effective Date");
			if((internetBankStatus != null)&&(internetBankStatus != ""))	
				selectByVisibleText(AddStorePageLocators.internetBankStatus_select, internetBankStatus, "Status");
			if((internetBankSortOrder != null)&&(internetBankSortOrder != ""))
				type(AddStorePageLocators.internetBankSortOrder_txt, internetBankSortOrder, "Sort Order");
			if((internetBankNetBankAccId != null)&&(internetBankNetBankAccId != ""))
				type(AddStorePageLocators.internetBankAccId_txt, internetBankNetBankAccId, "Netbank Account ID");
			if((internetBankSecretKey != null)&&(internetBankSecretKey != ""))
				type(AddStorePageLocators.internetBankSecretKey_txt, internetBankSecretKey, "Secret Key");
			type(AddStorePageLocators.internetBankTransLimit_txt, internetBankPerTransLimit, "Per Transaction Limit");
			click(AddStorePageLocators.internetBankAddNetbank_btn, "Add New Netbank - button");
			waitForElementPresent(AddStorePageLocators.internetBankRemove_btn, "Internet Bank Added in Table");
		}
		if((paymentTypeCug != null)&&(paymentTypeCug.equalsIgnoreCase("Y"))){
			click(AddStorePageLocators.cugFlag_chk, "CUG - Tab - Checkbox");
			type(AddStorePageLocators.cugFromBin_txt, cugFromBin, "CUG - From Bin");
			type(AddStorePageLocators.cugToBin_txt, cugToBin, "CUG - To Bin");			
		}
		/*if((paymentTypeImps != null)&&(paymentTypeImps.equalsIgnoreCase("Y"))){
			click(AddStorePageLocators.impsFlag_chk, "IMPS - Tab - Checkbox");
			type(AddStorePageLocators.impsMmid_txt, impsMmid, "IMPS - MMID");
			type(AddStorePageLocators.impsMobileNo_txt, impsMobileNo, "IMPS - Mobile Number");
		}*/
		if((ipgRefund != null)&&(ipgRefund.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ipgRefund_chk, "IPG - Refund");
		if((ipgCancellation != null)&&(ipgCancellation.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ipgCancel_chk, "IPG - Cancellation");
		if((ipgRecurPayUpload != null)&&(ipgRecurPayUpload.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ipgRecPayUpload_chk, "IPG - Recurring Pay Upload");
		if((ipgRecurPayOnline != null)&&(ipgRecurPayOnline.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ipgRecPayOnline_chk, "IPG - Recurring Pay Online");
		if((ipgPreauth != null)&&(ipgPreauth.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ipgPreauth_chk, "IPG - Preauth");
		if((ipgHostedPages != null)&&(ipgHostedPages.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ipgHostPages_chk, "IPG - Hosted Pages");
		if((ipgEmailInvoice != null)&&(ipgEmailInvoice.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ipgEmailInvoice_chk, "IPG - Email Invoices");
		if((ipgSmsInvoice != null)&&(ipgSmsInvoice.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ipgSmsInvoice_chk, "IPG - SMS Invoice");
		
		click(AddStorePageLocators.saveButton_txt, "Save - button");
		waitForPageLoaded();
		
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Save Payment Type Success Message");
		
		result = true;
//		waitForPageLoaded();
		return result;
	}	
	
	public boolean addMsfConvDetails() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("MSF/Convenience Fee Details");
		waitForElementPresent(AddStorePageLocators.msfConvenience_lnk, "MSF/Convenience Fee");
		click(AddStorePageLocators.msfConvenience_lnk, "MSF/Convenience Fee");
		Thread.sleep(2000);
		//CREDIT CARD
		//Round 1
		waitForElementPresent(AddStorePageLocators.msfAcqBankName_select, "MSF/Convenience Fee Details Page");
		/*
		//if((msfAcqBankNameCc != null)&&(msfAcqBankNameCc != ""))
			//selectByVisibleText(AddStorePageLocators.msfAcqBankName_select, msfAcqBankNameCc, "Acquirer Bank - MSF/Conv Details");
		if((msfMidCc != null)&&(msfMidCc != ""))
			selectByVisibleText(AddStorePageLocators.msfMidCc_select, msfMidCc, "MID");
		
		if((msfSchemeCc != null)&&(msfSchemeCc != ""))
			selectByVisibleText(AddStorePageLocators.msfSchemeCc_select, msfSchemeCc, "Scheme");
		
		type(AddStorePageLocators.slabUpto_txt, slabUptoCc, "Slab Upto");
		click(AddStorePageLocators.effectiveFrom, "Effective From");
		waitForElementPresent(AddStorePageLocators.currentDay, "Current Day");
		click(AddStorePageLocators.currentDay, "Current Day");
		type(AddStorePageLocators.internationalFixed_txt, interFixedCc, "International Fixed");
		type(AddStorePageLocators.internationalPer_txt, interPerCc, "International Per");
		type(AddStorePageLocators.DomesticOnusFixed_txt, domesticOnusFixedCc, "Domestic Onus Fixed");
		type(AddStorePageLocators.DomesticOnusPer_txt, domesticOnusPerCc, "Domestic Onus Per");
		type(AddStorePageLocators.ccDomesticOffusFixed_txt, domesticOffusFixedCc, "Domestic Offus Fixed");
		type(AddStorePageLocators.DomesticOffusPer_txt, domesticOffusPerCc, "Domestic Offus Per");
		if((chargeTypeCc != null)&&(chargeTypeCc != ""))
			selectByVisibleText(AddStorePageLocators.ccChargeType_select, chargeTypeCc, "Change Type");
		click(AddStorePageLocators.addNew_btn, "Add New");
		waitForElementPresent(AddStorePageLocators.msfRemove_lnk, "New row in Table - MSF Conv Details");
		*/
		//Round 2
		if((msfAcqBankNameCc != null)&&(msfAcqBankNameCc != ""))
			selectBySendkeys(AddStorePageLocators.msfAcqBankName_select, msfAcqBankNameCc, "Acquirer Bank - MSF/Conv Details");
		if((msfMidCc != null)&&(msfMidCc != ""))
			selectBySendkeys(AddStorePageLocators.msfMidCc_select, msfMidCc, "MID");
		if((msfSchemeCc != null)&&(msfSchemeCc != ""))
			selectBySendkeys(AddStorePageLocators.msfSchemeCc_select, msfSchemeCc, "Scheme");		
		type(AddStorePageLocators.slabUpto_txt, slabUptoCc, "Slab Upto");
		click(AddStorePageLocators.effectiveFrom, "Effective From");
		waitForElementPresent(AddStorePageLocators.currentDay, "Current Day");
		click(AddStorePageLocators.currentDay, "Current Day");
		type(AddStorePageLocators.internationalFixed_txt, interFixedCc, "International Fixed");
		type(AddStorePageLocators.internationalPer_txt, interPerCc, "International Per");
		type(AddStorePageLocators.DomesticOnusFixed_txt, domesticOnusFixedCc, "Domestic Onus Fixed");
		type(AddStorePageLocators.DomesticOnusPer_txt, domesticOnusPerCc, "Domestic Onus Per");
		type(AddStorePageLocators.ccDomesticOffusFixed_txt, domesticOffusFixedCc, "Domestic Offus Fixed");
		type(AddStorePageLocators.DomesticOffusPer_txt, domesticOffusPerCc, "Domestic Offus Per");
		if((chargeTypeCc != null)&&(chargeTypeCc != ""))
			selectBySendkeys(AddStorePageLocators.ccChargeType_select, chargeTypeCc, "Change Type");
		
		//============================================BSF Changes=================================
		
		if((manageBSFCc != null)&&(manageBSFCc != ""))
			//selectByVisibleText(AddStorePageLocators.ccmanageBSF_select, manageBSFCc, "Manage BSF");
			selectBySendkeys(AddStorePageLocators.ccmanageBSF_select, manageBSFCc, "Manage BSF");
		
		selectBySendkeys(AddStorePageLocators.ccselectCategory, SelectCategory_cc, "Manage BSF");
		
		
		type(AddStorePageLocators.slabUpto_txt_bsf, slabUptoCc, "Slab UptoBSF");
		//click(AddStorePageLocators.effectiveFrom_bsf, "Effective From BSF");
		//waitForElementPresent(AddStorePageLocators.currentDay_bsf, "Current Day");
		//click(AddStorePageLocators.currentDay_bsf, "Current Day");
		//type(AddStorePageLocators.internationalFixed_txt_bsf, interFixedCc, "International Fixed");
		//type(AddStorePageLocators.internationalPer_txt_bsf, interPerCc, "International Per");
		//type(AddStorePageLocators.DomesticOnusFixed_txt_bsf, domesticOnusFixedCc, "Domestic Onus Fixed");
		//type(AddStorePageLocators.DomesticOnusPer_txt_bsf, domesticOnusPerCc, "Domestic Onus Per");
		type(AddStorePageLocators.ccDomesticOffusFixed_txt_bsf, domesticOffusFixedCc, "Domestic Offus Fixed");
		type(AddStorePageLocators.DomesticOffusPer_txt_bsf, domesticOffusPerCc, "Domestic Offus Per");
		if((chargeTypeCc != null)&&(chargeTypeCc != ""))
		selectBySendkeys(AddStorePageLocators.ccChargeType_select_bsf, chargeTypeCc, "Change Type");
		
		
		
		//=============================================================================
		click(AddStorePageLocators.addNew_btn, "Add New");
		Thread.sleep(2000);
		
		//Round 3
		if((msfAcqBankNameCc != null)&&(msfAcqBankNameCc != ""))
			selectByVisibleText(AddStorePageLocators.msfAcqBankName_select, msfAcqBankNameCc, "Acquirer Bank - MSF/Conv Details");
		if((msfMidCc != null)&&(msfMidCc != ""))
			selectByVisibleText(AddStorePageLocators.msfMidCc_select, msfMidCc, "MID");
		if((msfSchemeCc != null)&&(msfSchemeCc != ""))
			selectByVisibleText(AddStorePageLocators.msfSchemeCc_select, msfSchemeCc, "Scheme");		
		type(AddStorePageLocators.slabUpto_txt, "99999", "Slab Upto");
		click(AddStorePageLocators.effectiveFrom, "Effective From");
		waitForElementPresent(AddStorePageLocators.currentDay, "Current Day");
		click(AddStorePageLocators.currentDay, "Current Day");
		type(AddStorePageLocators.internationalFixed_txt, interFixedCc, "International Fixed");
		type(AddStorePageLocators.internationalPer_txt, interPerCc, "International Per");
		type(AddStorePageLocators.DomesticOnusFixed_txt, domesticOnusFixedCc, "Domestic Onus Fixed");
		type(AddStorePageLocators.DomesticOnusPer_txt, domesticOnusPerCc, "Domestic Onus Per");
		type(AddStorePageLocators.ccDomesticOffusFixed_txt, domesticOffusFixedCc, "Domestic Offus Fixed");
		type(AddStorePageLocators.DomesticOffusPer_txt, domesticOffusPerCc, "Domestic Offus Per");
		if((chargeTypeCc != null)&&(chargeTypeCc != ""))
			selectByVisibleText(AddStorePageLocators.ccChargeType_select, chargeTypeCc, "Change Type");
		//selectByVisibleText(AddStorePageLocators.ccmanageBSF_select, manageBSFCc, "Manage BSF");
		click(AddStorePageLocators.addNew_btn, "Add New");
		Thread.sleep(2000);
		
		click(AddStorePageLocators.saveMsf_btn, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Save MSF/Convenience Details Success Message");
		
		//DEBIT CARD
		//Round 1
		
		waitForElementPresent(AddStorePageLocators.debitTab_btn, "MSF/Convenience - DebitCard Tab");
		
		if((slabUptoDc != null)&&(slabUptoDc != "")){
			click(AddStorePageLocators.debitTab_btn, "MSF/Convenience - DebitCard Tab");
			waitForElementPresent(AddStorePageLocators.dcSlabUpto_txt, "Debit Card Page");
			/*
			if((msfMidDc != null)&&(msfMidDc != ""))
				selectByVisibleText(AddStorePageLocators.dcMsfMid_select, msfMidDc, "MID");
			if((msfSchemeDc != null)&&(msfSchemeDc != ""))
				selectByVisibleText(AddStorePageLocators.dcMsfScheme_select, msfSchemeDc, "Scheme");	
			type(AddStorePageLocators.dcSlabUpto_txt, slabUptoDc, "Slab Upto");			
			click(AddStorePageLocators.dcEffectiveFrom, "Effective From");
			hitKey(AddStorePageLocators.dcEffectiveFrom, Keys.ENTER,"Effective From");
			type(AddStorePageLocators.dcInternationalFixed_txt, interFixedDc, "International Fixed");
			type(AddStorePageLocators.dcInternationalPer_txt, interPerDc, "International Per");
			type(AddStorePageLocators.dcDomesticOnusFixed_txt, domesticOnusFixedDc, "Domestic Onus Fixed");
			type(AddStorePageLocators.dcDomesticOnusPer_txt, domesticOnusPerDc, "Domestic Onus Per");
			type(AddStorePageLocators.dcDomesticOffusFixed_txt, domesticOffusFixedDc, "Domestic Offus Fixed");
			type(AddStorePageLocators.dcDomesticOffusPer_txt, domesticOffusPerDc, "Domestic Offus Per");
			if((chargeTypeDc != null)&&(chargeTypeDc != ""))
				selectByVisibleText(AddStorePageLocators.dcChargeType_select, chargeTypeDc, "Change Type");
			click(AddStorePageLocators.dcAddNew_btn, "Add New");
			*/
			Thread.sleep(2000);
			
		
		//Round 2x
			if((msfAcqBankNameDc != null)&&(msfAcqBankNameDc != ""))
			selectByVisibleText(AddStorePageLocators.dcMsfAcqBankName_select, msfAcqBankNameDc, "Acquirer Bank - MSF/Conv Details");
			if((msfMidDc != null)&&(msfMidDc != ""))
				selectByVisibleText(AddStorePageLocators.dcMsfMid_select, msfMidDc, "MID");
			if((msfSchemeDc != null)&&(msfSchemeDc != ""))
				selectByVisibleText(AddStorePageLocators.dcMsfScheme_select, msfSchemeDc, "Scheme");	
			type(AddStorePageLocators.dcSlabUpto_txt, slabUptoDc, "Slab Upto");			
			click(AddStorePageLocators.dcEffectiveFrom, "Effective From");
			hitKey(AddStorePageLocators.dcEffectiveFrom, Keys.ENTER,"Effective From");
			type(AddStorePageLocators.dcInternationalFixed_txt, interFixedDc, "International Fixed");
			type(AddStorePageLocators.dcInternationalPer_txt, interPerDc, "International Per");
			type(AddStorePageLocators.dcDomesticOnusFixed_txt, domesticOnusFixedDc, "Domestic Onus Fixed");
			type(AddStorePageLocators.dcDomesticOnusPer_txt, domesticOnusPerDc, "Domestic Onus Per");
			type(AddStorePageLocators.dcDomesticOffusFixed_txt, domesticOffusFixedDc, "Domestic Offus Fixed");
			type(AddStorePageLocators.dcDomesticOffusPer_txt, domesticOffusPerDc, "Domestic Offus Per");
			if((chargeTypeDc != null)&&(chargeTypeDc != ""))
				selectByVisibleText(AddStorePageLocators.dcChargeType_select, chargeTypeDc, "Change Type");
			click(AddStorePageLocators.dcAddNew_btn, "Add New");
			Thread.sleep(2000);
			
		
		//Round 3
			if((msfAcqBankNameDc != null)&&(msfAcqBankNameDc != ""))
				selectByVisibleText(AddStorePageLocators.dcMsfAcqBankName_select, msfAcqBankNameDc, "Acquirer Bank - MSF/Conv Details");
				if((msfMidDc != null)&&(msfMidDc != ""))
					selectByVisibleText(AddStorePageLocators.dcMsfMid_select, msfMidDc, "MID");
				if((msfSchemeDc != null)&&(msfSchemeDc != ""))
					selectByVisibleText(AddStorePageLocators.dcMsfScheme_select, msfSchemeDc, "Scheme");	
				type(AddStorePageLocators.dcSlabUpto_txt, "99999", "Slab Upto");			
				click(AddStorePageLocators.dcEffectiveFrom, "Effective From");
				hitKey(AddStorePageLocators.dcEffectiveFrom, Keys.ENTER,"Effective From");
				type(AddStorePageLocators.dcInternationalFixed_txt, interFixedDc, "International Fixed");
				type(AddStorePageLocators.dcInternationalPer_txt, interPerDc, "International Per");
				type(AddStorePageLocators.dcDomesticOnusFixed_txt, domesticOnusFixedDc, "Domestic Onus Fixed");
				type(AddStorePageLocators.dcDomesticOnusPer_txt, domesticOnusPerDc, "Domestic Onus Per");
				type(AddStorePageLocators.dcDomesticOffusFixed_txt, domesticOffusFixedDc, "Domestic Offus Fixed");
				type(AddStorePageLocators.dcDomesticOffusPer_txt, domesticOffusPerDc, "Domestic Offus Per");
				if((chargeTypeDc != null)&&(chargeTypeDc != ""))
					selectByVisibleText(AddStorePageLocators.dcChargeType_select, chargeTypeDc, "Change Type");
				click(AddStorePageLocators.dcAddNew_btn, "Add New");
				Thread.sleep(2000);
				
		click(AddStorePageLocators.dbSaveMsf_btn, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Save MSF/Convenience Details Success Message");
		}
		//INTERNET BANKING
		if((intBankSlabUpto != null)&&(intBankSlabUpto != "")){
			waitForElementPresent(AddStorePageLocators.intBank_Tab, "MSF/Convenience - Internet Banking Tab");
			click(AddStorePageLocators.intBank_Tab, "MSF/Convenience - Internet Banking Tab");
			waitForElementPresent(AddStorePageLocators.intBank_bankName_select, "Internet Banking Tab - Page");
			if((intBankBankName != null)&&(intBankBankName != ""))
				selectByVisibleText(AddStorePageLocators.intBank_bankName_select, intBankBankName, "intBank_bankName_select");
			type(AddStorePageLocators.intBank_slabUpto_txt, intBankSlabUpto, "intBankSlabUpto");
			type(AddStorePageLocators.intBank_fixed_txt, intBankFixed, "intBankFixed");
			type(AddStorePageLocators.intBank_Percent_txt, intBankPercent, "intBankPercent");
			if((intBankEffectiveFrom != null)&&(intBankEffectiveFrom != ""))
				js_type(AddStorePageLocators.intBank_effFrom_txt, intBankEffectiveFrom, "intBankEffectiveFrom");
			else{
				click(AddStorePageLocators.intBank_effFrom_txt, "intBankEffectiveFrom");
				hitKey(AddStorePageLocators.intBank_effFrom_txt, Keys.ENTER, "intBankEffectiveFrom");
			}
			if((intBankChargeType != null)&&(intBankChargeType != ""))
				selectByVisibleText(AddStorePageLocators.intBank_chargeType_select, intBankChargeType, "intBankChargeType_select");
			click(AddStorePageLocators.intBank_addNew_btn, "Internet Banking - Add New Button");
			waitForElementPresent(AddStorePageLocators.intBank_Remove_lnk, "Internet Banking - Remove Link");
			click(AddStorePageLocators.intBank_Save_btn, "Internet Banking - Save Button");
			waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Merchant Service Fee Details Insert Success Message");
		}
		
		//CUG
		if((cugSlabUpto != null)&&(cugSlabUpto != "")){
			waitForElementPresent(AddStorePageLocators.cugTab, "MSF/Convenience - CUG Tab");
			click(AddStorePageLocators.cugTab, "MSF/Convenience - CUG Tab");
			waitForElementPresent(AddStorePageLocators.cugBank_Select, "CUG Tab - Page");
			if((cugBankName != null)&&(cugBankName != ""))
				selectByContainsVisibleText(AddStorePageLocators.cugBank_Select, cugBankName, "CUG_bankName_select");
			type(AddStorePageLocators.cugSlabUpto_txt, cugSlabUpto, "cugSlabUpto");
			type(AddStorePageLocators.cugFixed_txt, cugFixed, "cugFixed");
			type(AddStorePageLocators.cugPercent_txt, cugPercent, "cugPercent");
			if((cugEffectiveFrom != null)&&(cugEffectiveFrom != ""))
				js_type(AddStorePageLocators.cugEffFrom_txt, cugEffectiveFrom, "cugEffectiveFrom");
			else{
				click(AddStorePageLocators.cugEffFrom_txt, "cugEffectiveFrom");
				hitKey(AddStorePageLocators.cugEffFrom_txt, Keys.ENTER, "cugEffectiveFrom");
			}
			if((cugChargeType != null)&&(cugChargeType != ""))
				selectByVisibleText(AddStorePageLocators.cugchargeType_select, cugChargeType, "cugChargeType_select");
			click(AddStorePageLocators.addCUGDetails_btn, "CUG - Add New Button");
			waitForElementPresent(AddStorePageLocators.cug_Remove_lnk, "CUG - Remove Link");
			click(AddStorePageLocators.cugSaveBtn_btn, "CUG - Save Button");
			waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "CUG Details - Insert Success Message");
		}
		
		//IMPS
		/*if((impsSlabUpto != null)&&(impsSlabUpto != "")){
			waitForElementPresent(AddStorePageLocators.impsTab, "MSF/Convenience - IMPS Tab");
			click(AddStorePageLocators.impsTab, "MSF/Convenience - IMPS Tab");
			waitForElementPresent(AddStorePageLocators.impsSlabUpto_txt, "IMPS Tab - Page");
			type(AddStorePageLocators.impsSlabUpto_txt, impsSlabUpto, "impsSlabUpto");
			type(AddStorePageLocators.impsFixed_txt, impsFixed, "impsFixed");
			type(AddStorePageLocators.impsPercent_txt, impsPercent, "impsPercent");
			if((impsEffectiveFrom != null)&&(impsEffectiveFrom != ""))
				js_type(AddStorePageLocators.impsEffFrom_txt, impsEffectiveFrom, "impsEffectiveFrom");
			else{
				click(AddStorePageLocators.impsEffFrom_txt, "impsEffectiveFrom");
				hitKey(AddStorePageLocators.impsEffFrom_txt, Keys.ENTER, "impsEffectiveFrom");
			}
			if((impsChargeType != null)&&(impsChargeType != ""))
				selectByVisibleText(AddStorePageLocators.impsChargeType_select, impsChargeType, "impsChargeType_select");
			click(AddStorePageLocators.addIMPSDetails_btn, "IMPS - Add New Button");
			waitForElementPresent(AddStorePageLocators.imps_Remove_lnk, "IMPS - Remove Link");
			click(AddStorePageLocators.impsSaveBtn_btn, "IMPS - Save Button");
			waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "IMPS Details - Insert Success Message");
		}		*/
		
		result = true;
		return result;
	}
	
	public boolean addAcquiringRule() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Add Acquiring Rule Page");
		waitForElementPresent(AddStorePageLocators.acqRule_lnk, "Acquiring Rule");
		click(AddStorePageLocators.acqRule_lnk, "Acquiring Rule");
		waitForElementPresent(AddStorePageLocators.lv_select, "Legal Vehicle");
		selectByVisibleText(AddStorePageLocators.lv_select, lvId, "Legal Vehicle");
		selectByVisibleText(AddStorePageLocators.acqBank_select, bankName, "Acquirer Bank");
		selectByVisibleText(AddStorePageLocators.payType_select, "CREDIT CARD", "Pay Type - Select");
		click(AddStorePageLocators.effectiveFrom, "Effective From");
		waitForElementPresent(AddStorePageLocators.currentDay, "Current Day");
		click(AddStorePageLocators.currentDay, "Current Day");
		click(AddStorePageLocators.datepicker_done_btn, "Date Picker - Done button");
		waitForElementPresent(AddStorePageLocators.priority_select, "Priority - Select");
		selectByVisibleText(AddStorePageLocators.priority_select, "1", "Priority");
		waitForElementPresent(AddStorePageLocators.addAcqBankRule_btn, "Add button");
		click(AddStorePageLocators.addAcqBankRule_btn, "Add button");
		waitForElementPresent(AddStorePageLocators.msfRemove_lnk, "New row in Table - Acquiring Rule");
		
		//Add Rule #2
		waitForElementPresent(AddStorePageLocators.lv_select, "Legal Vehicle");
		selectByVisibleText(AddStorePageLocators.lv_select, lvId, "Legal Vehicle");
		Thread.sleep(2000);
		selectByVisibleText(AddStorePageLocators.acqBank_select, bankName, "Acquirer Bank");
		selectByVisibleText(AddStorePageLocators.payType_select, "DEBIT CARD", "Pay Type - Select");
		click(AddStorePageLocators.effectiveFrom, "Effective From");
		waitForElementPresent(AddStorePageLocators.currentDay, "Current Day");
		click(AddStorePageLocators.currentDay, "Current Day");
		click(AddStorePageLocators.datepicker_done_btn, "Date Picker - Done button");
		waitForElementPresent(AddStorePageLocators.priority_select, "Priority - Select");
		selectByVisibleText(AddStorePageLocators.priority_select, "2", "Priority");
		waitForElementPresent(AddStorePageLocators.addAcqBankRule_btn, "Add button");
		click(AddStorePageLocators.addAcqBankRule_btn, "Add button");
		waitForElementPresent(AddStorePageLocators.msfRemove_lnk, "New row in Table - Acquiring Rule");
		
		click(AddStorePageLocators.saveButton_txt, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Save Acquiring Rule Success Message");
		result = true;
		return result;
	}
	
	public boolean fillBlackList() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Blacklist/Whitelist Page");
		waitForElementPresent(AddStorePageLocators.blackList_lnk, "Blacklist Link");
		click(AddStorePageLocators.blackList_lnk, "BlackList Link");
		waitForElementPresent(AddStorePageLocators.listType_select, "BlackList Page");
		if((blListType != null)&&(blListType != ""))
			selectByVisibleText(AddStorePageLocators.listType_select, blListType, "List Type");
		if((blSchemeName != null)&&(blSchemeName != ""))
			selectByVisibleText(AddStorePageLocators.blackListSchemeName_select, blSchemeName, "Scheme Name");
		if((blFromBin != null)&&(blFromBin != ""))
			type(AddStorePageLocators.fromBinBL_txt, blFromBin, "From Bin");
		if((blToBin != null)&&(blToBin != ""))
			type(AddStorePageLocators.toBinBL_txt, blToBin, "To Bin");
		click(AddStorePageLocators.addButtonBL_btn, "Add button");
		waitForElementPresent(AddStorePageLocators.blackList_removeTag_lnk, "Add New List - Verification");
		click(AddStorePageLocators.saveButton_txt, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Bin List has been successfully updated - Message");
		
		result = true;
		return result;
	}
	
	public boolean fillChecklist() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("CheckList Page");
		waitForElementPresent(AddStorePageLocators.checkList_lnk, "CheckList Link");
		click(AddStorePageLocators.checkList_lnk, "CheckList Link");
		waitForElementPresent(AddStorePageLocators.relation_btn, "CheckList Page");
		if((existingRelationship != null)&&(existingRelationship.equalsIgnoreCase("N")))
			click(AddStorePageLocators.relation_btn, "Relationship - New");
		if((paymentHoldover != null)&&(paymentHoldover.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.paymentHold_btn, "Payment Hold over - Yes");
		if((checklistMsf != null)&&(checklistMsf.equalsIgnoreCase("N")))
			click(AddStorePageLocators.msfchk_btn, "MSF - No");
		if((crossborderTransaction != null)&&(crossborderTransaction.equalsIgnoreCase("N")))
			click(AddStorePageLocators.crossBorderTransChk_btn, "Cross border transactions - No");
		if((secure3D != null)&&(secure3D.equalsIgnoreCase("N")))
			click(AddStorePageLocators.dSecureChk_btn, "3D Secure - No");		
		type(AddStorePageLocators.domUserTransLimit_txt, domesticUserTransLimit, "Domestic User Transactions Limit");
		if((secureCrossborderLimit != null)&&(secureCrossborderLimit != ""))
			type(AddStorePageLocators.secCrossBorderLimit_txt, secureCrossborderLimit, "Secured Cross Border Limit");
		type(AddStorePageLocators.unsecuredTransLimit_txt, unsecureTransLimit, "Unsecured Transactions Limit");
		if(chargeBackRecover.contains("Instant"))
			click(AddStorePageLocators.chgBackRecoverInstant_btn, "Charge Backs Recover - Instant");
		else if(chargeBackRecover.contains("Instant"))
			click(AddStorePageLocators.chgBackRecoverCryst_btn, "Charge Backs Recover - Crystallization");
		
		//Merchant CheckList
		if(financialStatementSubmit.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.statement_status_Yes_btn, "Financial Statements Status - Yes");
		else
			click(AddStorePageLocators.statement_status_No_btn, "Financial Statements Status - No");
		type(AddStorePageLocators.statement_remarks_txt, financialStatementSubmitRemark, "Financial Statements - Remarks");
		if(websiteCheck.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.web_status_Yes_btn, "Website Checks Status - Yes");
		else
			click(AddStorePageLocators.web_status_No_btn, "Website Checks Status - No");		
		type(AddStorePageLocators.web_remarks_txt, "Test", "Website Checks - Remarks");
		if(merchantRating.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.rate_status_Yes_btn, "Merchant Rating Status - Yes");
		else
			click(AddStorePageLocators.rate_status_No_btn, "Merchant Rating Status - No");
		type(AddStorePageLocators.rate_remarks_txt, "Test", "Merchant Rating - Remarks");
		if(siteInspection.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.site_status_Yes_btn, "Site Inspection Status - Yes");
		else
			click(AddStorePageLocators.site_status_No_btn, "Site Inspection Status - No");
		type(AddStorePageLocators.site_remarks_txt, "Test", "Site Inspection - Remarks");
		if(businessApproval.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.business_status_Yes_btn, "Business Approval Status - Yes");
		else
			click(AddStorePageLocators.business_status_No_btn, "Business Approval Status - No");
		type(AddStorePageLocators.business_remarks_txt, "Test", "Business Approval - Remarks");
		if(cibilChecks.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.mvc_status_Yes_btn, "MVC Status - Yes");
		else
			click(AddStorePageLocators.mvc_status_No_btn, "MVC Status - No");
		type(AddStorePageLocators.mvc_remarks_txt, "Test", "MVC - Remarks");
		if(kycDocVerify.equalsIgnoreCase("Y"))
			click(AddStorePageLocators.kyc_status_Yes_btn, "KYC Status - Yes");
		else
			click(AddStorePageLocators.kyc_status_No_btn, "KYC Status - No");
		type(AddStorePageLocators.kyc_remarks_txt, "Test", "KYC - Remarks");		
		click(AddStorePageLocators.saveButton_txt, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Save Checklist Success Message");
		result = true;
		return result;
	}
	
	public boolean fillMerchantRating() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Merchant Rating Page");
		Thread.sleep(2000);
		waitForElementPresent(AddStorePageLocators.merchantRating_lnk, "Merchant Rating Link");
		click(AddStorePageLocators.merchantRating_lnk, "Merchant Rating Link");
		waitForElementPresent(AddStorePageLocators.vmts_Verified_btn, "Merchant Rating Page");
		selectByVisibleText(AddStorePageLocators.mcRateLoc_select, merchRatingLocation, "Location - Select");
		selectByVisibleText(AddStorePageLocators.mcRateFinancial_select, merchRatingFinancial, "Financial - Select");
		selectByVisibleText(AddStorePageLocators.mcRateMcCategory_select, merchRatingMCategory, "Merchant Category - Select");
		selectByVisibleText(AddStorePageLocators.mcRateDelTimeLine_select, merchRatingDeliveryTimeline, "Delivery TimeLine - Select");
		selectByVisibleText(AddStorePageLocators.mcRateMcOpsId_select, merchRatingOpsSecurity, "Merchant OPS and Security - Select");
		selectByVisibleText(AddStorePageLocators.mcRateWebSecId_select, merchRatingWebSecurity, "Web Security - Select");
		if(merchRatingVmts.equalsIgnoreCase("V"))
			click(AddStorePageLocators.vmts_Verified_btn, "VMTS - Verified");
		else if(merchRatingVmts.equalsIgnoreCase("R"))
			click(AddStorePageLocators.vmts_Rejected_btn, "VMTS - Rejected");
		else if(merchRatingVmts.equalsIgnoreCase("N"))
			click(AddStorePageLocators.vmts_NotVerified_btn, "VMTS - Not Verified");
		if(merchRatingMatch.equalsIgnoreCase("V"))
			click(AddStorePageLocators.match_Verified_btn, "MATCH - Verified");
		else if(merchRatingMatch.equalsIgnoreCase("R"))
			click(AddStorePageLocators.match_Rejected_btn, "MATCH - Rejected");
		else if(merchRatingMatch.equalsIgnoreCase("N"))
			click(AddStorePageLocators.match_NotVerified_btn, "MATCH - Not Verified");
		if(merchRatingCibil.equalsIgnoreCase("V"))
			click(AddStorePageLocators.cibil_Verified_btn, "Cibil - Verified");
		else if(merchRatingCibil.equalsIgnoreCase("R"))
			click(AddStorePageLocators.cibil_Rejected_btn, "Cibil - Rejected");
		else if(merchRatingCibil.equalsIgnoreCase("N"))
			click(AddStorePageLocators.cibil_NotVerified_btn, "Cibil - Not Verified");
		if((merchRatingVmtsCheckbox != null)&&(merchRatingVmtsCheckbox.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.merchRating_vmts_chk, "VMTS checkbox");
		if((merchRatingMatchCheckbox != null)&&(merchRatingMatchCheckbox.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.merchRating_match_chk, "MATCH checkbox");
		if((merchRatingPostFacto != null)&&(merchRatingPostFacto.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.merchRating_postFacto_chk, "POST FACTO checkbox");
		if((merchRatingWaiver != null)&&(merchRatingWaiver.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.merchRating_waiver_chk, "Waiver checkbox");
		if((merchRatingEnterRemark != null)&&(merchRatingEnterRemark != ""))
			type(AddStorePageLocators.merchRatingEnterRemark_txt, merchRatingEnterRemark, "Enter Remark");
		click(AddStorePageLocators.saveButton_txt, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Save Merchant Rating Success Message");
		
		result = true;
		return result;
	}
	
	
	public boolean fillUploadDocuments() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Upload Documents Page");
		waitForElementPresent(AddStorePageLocators.uploadDocument_lnk, "Upload Documents Link");
		click(AddStorePageLocators.uploadDocument_lnk, "Upload Documents Link");
		waitForElementPresent(AddStorePageLocators.validLicense_No_btn, "Upload Documents Page");
		if((uploadValidLicense != null)&&(uploadValidLicense.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.validLicense_Yes_btn, "Valid License - Yes");
		else if (uploadValidLicense.equalsIgnoreCase("N"))
			click(AddStorePageLocators.validLicense_No_btn, "Valid License - No");
		//click(AddStorePageLocators.resolOfDirectors_No_btn, "Resolution of Directors - No");
		if((uploadValidLicenseRemark != null)&&(uploadValidLicenseRemark != ""))
			type(AddStorePageLocators.validLicenseRemarks_txt, uploadValidLicenseRemark, "Valid License Remarks");
		if((uploadPancard != null)&&(uploadPancard.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.copyOfPan_Yes_btn, "Copy of PAN - Yes");
		else if (uploadPancard.equalsIgnoreCase("N"))
			click(AddStorePageLocators.copyOfPan_No_btn, "Copy of PAN - No");
		if((uploadPancardRemark != null)&&(uploadPancardRemark != ""))
			type(AddStorePageLocators.copyOfPanRemarks_txt, uploadPancardRemark, "Pancard Remarks");
		if((uploadAddressProof != null)&&(uploadAddressProof.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.addressProof_Yes_btn, "Address Proof - Yes");
		else if (uploadAddressProof.equalsIgnoreCase("N"))
			click(AddStorePageLocators.addressProof_No_btn, "Address Proof - No");
		if((uploadAddressProofRemark != null)&&(uploadAddressProofRemark != ""))
			type(AddStorePageLocators.addressProofRemarks_btn, uploadAddressProofRemark, "Address Proof Remarks");
		//click(AddStorePageLocators.copyOfTel_btn, "Copy of Telephone - No");
		if((uploadIncomeTax != null)&&(uploadIncomeTax.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.incomeTax_Yes_btn, "Income Tax - Yes");
		else if(uploadIncomeTax.equalsIgnoreCase("N"))
			click(AddStorePageLocators.incomeTax_No_btn, "Income Tax - No");
		if((uploadIncomeTaxRemark != null)&&(uploadIncomeTaxRemark != ""))
			type(AddStorePageLocators.incomeTaxRemarks_txt, uploadIncomeTaxRemark, "Income Tax Remarks");		
		if((uploadStatementOfAcc != null)&&(uploadStatementOfAcc.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.stmtOfAcc_Yes_btn, "Statement of Account - Yes");
		else if(uploadStatementOfAcc.equalsIgnoreCase("N"))
			click(AddStorePageLocators.stmtOfAcc_No_btn, "Statement of Account - No");
		if((uploadStatementOfAccRemark != null)&&(uploadStatementOfAccRemark != ""))
			type(AddStorePageLocators.stmtOfAccRemarks_txt, uploadStatementOfAccRemark, "Statement of Account Remarks");
		//click(AddStorePageLocators.existingPosTerminal_btn, "Existing POS terminal - Yes");
		if((uploadCancelChq != null)&&(uploadCancelChq.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.cancelChq_Yes_btn, "Cancel Cheque - Yes");
		else if((uploadCancelChq != null)&&(uploadCancelChq.equalsIgnoreCase("N")))
			click(AddStorePageLocators.cancelChq_No_btn, "Cancel Cheque - No");
		if((uploadCancelChqRemark != null)&&(uploadCancelChqRemark != ""))
			type(AddStorePageLocators.cancelChqRemarks_txt, uploadCancelChqRemark, "Cancel Cheque Remarks");		
		if((uploadMerchEstAgg != null)&&(uploadMerchEstAgg.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.merchEstab_Yes_btn, "Merchant Establishment - Yes");
		else if((uploadMerchEstAgg != null)&&(uploadMerchEstAgg.equalsIgnoreCase("N")))
			click(AddStorePageLocators.merchEstab_No_btn, "Merchant Establishment - No");
		if((uploadMerchEstAggRemark != null)&&(uploadMerchEstAggRemark != ""))
			type(AddStorePageLocators.merchEstabRemarks_txt, uploadMerchEstAggRemark, "Merchant Establishment Agreement");		
		if((uploadCpLicenseShops != null)&&(uploadCpLicenseShops.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.copyOfLicense_Yes_btn, "Copy of License - Yes");
		else if((uploadCpLicenseShops != null)&&(uploadCpLicenseShops.equalsIgnoreCase("N")))
			click(AddStorePageLocators.copyOfLicense_No_btn, "Copy of License - No");
		if((uploadCpLicenseShopsRemark != null)&&(uploadCpLicenseShopsRemark != ""))
			type(AddStorePageLocators.copyOfLicenseRemarks_txt, uploadCpLicenseShopsRemark, "Copy of Shop License");
		if(isElementDisplayed(AddStorePageLocators.idProof_Yes_btn, "ID Proof")){
			if((uploadIDproof != null)&&(uploadIDproof.equalsIgnoreCase("Y")))
				click(AddStorePageLocators.idProof_Yes_btn, "ID Proof - Yes");
			else if((uploadIDproof != null)&&(uploadIDproof.equalsIgnoreCase("N")))
				click(AddStorePageLocators.idProof_Yes_btn, "ID Proof - No");
			if((uploadIDproofRemark != null)&&(uploadIDproofRemark != ""))
				type(AddStorePageLocators.idProofRemarks_txt, uploadIDproofRemark, "ID Proof Remarks");
		}
		click(AddStorePageLocators.saveButton_txt, "Save - button");
		Thread.sleep(1000);
		waitForElementPresent(AddStorePageLocators.fileUploadSuccess_msg, "Save Upload Documents Success Message");
		
		result = true;
		return result;
	}
	
	public boolean fillUrlsPage() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("URLs Page");
		waitForElementPresent(AddStorePageLocators.urls_lnk, "URLs Link");
		click(AddStorePageLocators.urls_lnk, "URLs Link");
		waitForElementPresent(AddStorePageLocators.outsourced_no_btn, "URLs Page");
		if((isWebsiteOnInternet != null)&&(isWebsiteOnInternet.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.isWebAvailable_Yes_btn, "Website Already on Internet - Yes");
		else if((isWebsiteOnInternet != null)&&(isWebsiteOnInternet.equalsIgnoreCase("N")))
			click(AddStorePageLocators.isWebAvailable_No_btn, "Website Already on Internet - No");
		if((merchWebsiteUrl != null)&&(merchWebsiteUrl != ""))
			type(AddStorePageLocators.merchWebSiteUrl_txt, merchWebsiteUrl, "Merchant Website URL");
		if((privacyPolicy != null)&&(privacyPolicy != ""))
			type(AddStorePageLocators.privacyPolicy_txt, privacyPolicy, "Privacy Policy");
		if((cancelRefundPolicy != null)&&(cancelRefundPolicy != ""))
			type(AddStorePageLocators.cancelRefPolicy_txt, cancelRefundPolicy, "Cancellation/Refund Policy");
		if((termsCondPolicy != null)&&(termsCondPolicy != ""))
			type(AddStorePageLocators.termsCondPolicy_txt, termsCondPolicy, "Terms & Conditions Policy");
		if((contactUsInfo != null)&&(contactUsInfo != ""))
			type(AddStorePageLocators.contactUsInfo_txt, contactUsInfo, "Contact Us Info");
		if((faqPage != null)&&(faqPage != ""))
			type(AddStorePageLocators.faqUrl_txt, faqPage, "FAQ Page URL");
		if((oneProdPage != null)&&(oneProdPage != ""))
			type(AddStorePageLocators.oneProdUrl_txt, oneProdPage, "Page that shows one product");
		if((aboutUs != null)&&(aboutUs != ""))
			type(AddStorePageLocators.aboutUs_txt, aboutUs, "About Us");
		if((howWebsiteManaged != null)&&(howWebsiteManaged != ""))
			type(AddStorePageLocators.webManagedUrl_txt, howWebsiteManaged, "How is the website managed?");
		if((whichCompOwnsWebsite != null)&&(whichCompOwnsWebsite != ""))
			type(AddStorePageLocators.comNameUrl_txt, whichCompOwnsWebsite, "Which company owns your website?");
		if((outsourcedForSolution != null)&&(outsourcedForSolution.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.outsourced_yes_btn, "Outsourced For Solution - Yes");
		else if((outsourcedForSolution != null)&&(outsourcedForSolution.equalsIgnoreCase("N")))
			click(AddStorePageLocators.outsourced_no_btn, "Outsourced For Solution - No");
		if((whichSolutionWebsiteOn != null)&&(whichSolutionWebsiteOn != ""))
			type(AddStorePageLocators.solutionUrl_txt, whichSolutionWebsiteOn, "Which solution the website is on?");
		if((ecommStrategy != null)&&(ecommStrategy != ""))
			type(AddStorePageLocators.ecommStrategy_txt, ecommStrategy, "E-comm Strategy");
		if((ecommTargetUtility != null)&&(ecommTargetUtility.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ecommTarget_Utility_chk, "Ecomm Target - Utility");
		if((ecommTargetTravel != null)&&(ecommTargetTravel.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ecommTarget_Travel_chk, "Ecomm Target - Travel");
		if((ecommTargetRetail != null)&&(ecommTargetRetail.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ecommTarget_Retail_chk, "Ecomm Target - Retail");
		if((ecommTargetEducation != null)&&(ecommTargetEducation.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ecommTarget_Edu_chk, "Ecomm Target - Education");
		if((charityOrg != null)&&(charityOrg.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ecommTarget_Charity_chk, "Ecomm Target - Charity");
		if((hostelsMotels != null)&&(hostelsMotels.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ecommTarget_Hotels_chk, "Ecomm Target - Hotels");
		if((other != null)&&(other.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.ecommTarget_Other_chk, "Ecomm Target - Other");
		if((pleaseSpecify != null)&&(pleaseSpecify != ""))
			type(AddStorePageLocators.specifyUrl_txt, pleaseSpecify, "Please Specify");
		click(AddStorePageLocators.saveButton_txt, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Save URLs Page Success Message");
		result = true;
		return result;
	}
	
	public boolean fillIpgPage() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("IPG Page");
		waitForElementPresent(AddStorePageLocators.ipgTab_lnk, "IPG Tab - Link");
		click(AddStorePageLocators.ipgTab_lnk, "IPG Tab - Link");
		waitForElementPresent(AddStorePageLocators.integApp_select, "IPG Tab Page");
		if((eciValueVisa != null)&&(eciValueVisa != ""))
			type(AddStorePageLocators.eciVisa_txt, eciValueVisa, "ECI Value - Visa");
		if((eciValueMaster != null)&&(eciValueMaster != ""))
			type(AddStorePageLocators.eciMaster_txt, eciValueMaster, "ECI Value - Master");
		if((eciValueMaestro != null)&&(eciValueMaestro != ""))
			type(AddStorePageLocators.eciMaestro_txt, eciValueMaestro, "ECI Value - Maestro");
		selectByVisibleText(AddStorePageLocators.integApp_select, integrationApproach,"Integration Approach - Select");
		Thread.sleep(2000);		
		if((pciDssCertificate != null)&&(pciDssCertificate != ""))
			type(AddStorePageLocators.pcIdss_txt, pciDssCertificate, "PCI DSS Certificate");
		if((pciDssExpDate != null)&&(pciDssExpDate != ""))
			js_type(AddStorePageLocators.pcIdssExpiryDate_txt, pciDssExpDate, "PCI DSS Exp Date");
		if((ebsChecksumKey != null)&&(ebsChecksumKey != ""))
			type(AddStorePageLocators.ebsKey_txt, ebsChecksumKey, "EBS Checksum Key");		
		selectByVisibleText(AddStorePageLocators.mpiIntegration_select, mpiIntegration,"MPI Integration - Select");
		if((mpiChecksumKey != null)&&(mpiChecksumKey != ""))
			type(AddStorePageLocators.mpiKey_txt, mpiChecksumKey, "MPI Checksum Key");
		if((lyraCertificate != null)&&(lyraCertificate != ""))
			type(AddStorePageLocators.lyraCertificate_txt, lyraCertificate, "Lyra Certificate");
		if((lyraShopId != null)&&(lyraShopId != ""))
			type(AddStorePageLocators.lyraShopId_txt, lyraShopId, "Lyra Shop ID");
		if((convFeeMsfCheckValue != null)&&(convFeeMsfCheckValue != ""))
			type(AddStorePageLocators.msfConvChkVal_txt, convFeeMsfCheckValue, "Conv Fee/MSF Check Value");
		if((merchEmailConfirmForTrans != null)&&(merchEmailConfirmForTrans.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.merchEmailConfirm_yes_btn, "Merchant Email Confirmation - Yes");
		else if((merchEmailConfirmForTrans != null)&&(merchEmailConfirmForTrans.equalsIgnoreCase("N")))
			click(AddStorePageLocators.merchEmailConfirm_no_btn, "Merchant Email Confirmation - No");
		click(AddStorePageLocators.requestUrl1_txt, "Request URL1");
		type(AddStorePageLocators.requestUrl1_txt, reqUrl1, "Request URL1");
		js_type(AddStorePageLocators.requestUrl1_txt, reqUrl1, "Request URL1");
		
		if((reqUrl2 != null)&&(reqUrl2 != ""))
			js_type(AddStorePageLocators.requestUrl2_txt, reqUrl2, "Request URL2");
		
		click(AddStorePageLocators.saveButton_txt, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Save URLs Page Success Message");
		result = true;
		return result;
	}
	
	public boolean fillPcPos() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("PCPOS Page");
		click(AddStorePageLocators.pcpos_lnk, "PCPOS Link");
		waitForElementPresent(AddStorePageLocators.trainingSchedule_select, "PCPOS Page");
		if((trainingSchedule != null)&&(trainingSchedule != ""))
			selectByVisibleText(AddStorePageLocators.trainingSchedule_select, "Half Yearly", "Training Schedule");
		if((seId != null)&&(seId != ""))
			type(AddStorePageLocators.seId_txt, seId, "SEID");
		if((seRemarks != null)&&(seRemarks != ""))
			type(AddStorePageLocators.seRemarks_txt, seRemarks, "SE Remarks");
		if((ownership != null)&&(ownership != ""))
			selectByVisibleText(AddStorePageLocators.ownership_select, "LV IDBI", "Ownership");
		if((meChargeSlipName != null)&&(meChargeSlipName != ""))
		type(AddStorePageLocators.merchChargSlip, meChargeSlipName, "Merchant Charge Slip Print Name");		
		selectByVisibleText(AddStorePageLocators.pcposVersion_select, pcposVersion, "PCPOS Version");
		if((promptProcessFlag != null)&&(promptProcessFlag.equalsIgnoreCase("N")))
			click(AddStorePageLocators.promptFlag_No, "Prompt & Process Flag - No");
		else if((promptProcessFlag != null)&&(promptProcessFlag.equalsIgnoreCase("Y")))
			click(AddStorePageLocators.promptFlag_Yes, "Prompt & Process Flag - Yes");
		type(AddStorePageLocators.maxCash, maxCashPos,"Maximum Cash@POS");		
		type(AddStorePageLocators.maxPreauthPer, maxPreauthPercent,"Maximum Preauth Percentage");
		if((contentDisclaimer != null)&&(contentDisclaimer != ""))
			type(AddStorePageLocators.contentDisclaimer_txt, contentDisclaimer, "Content Disclaimer");
		if((instrumentDisclaimer != null)&&(instrumentDisclaimer != ""))
			type(AddStorePageLocators.instrumentDisclaimer_txt, instrumentDisclaimer, "Instrument Disclaimer");
		if((programDisclaimer != null)&&(programDisclaimer != ""))
			type(AddStorePageLocators.programDisclaimer_txt, programDisclaimer, "Program Disclaimer");		
		type(AddStorePageLocators.totalNoOfTerminal, totalNoOfTerminals,"Total Number of Terminals");
		selectByVisibleText(AddStorePageLocators.modelNo_select, modelNo, "Model No - Select");
		selectByVisibleText(AddStorePageLocators.edcVersion_select, edcVersion, "EDC Version - Select");
		type(AddStorePageLocators.noOfTerminals_txt, noOfTerminals,"Number of Terminals");
		click(AddStorePageLocators.addAcqBankRule_btn, "Add button");
		waitForElementPresent(AddStorePageLocators.msfRemove_lnk, "Insert Table row - New Terminal Details - Verification");
		click(AddStorePageLocators.saveButton_txt, "Save - button");
		waitForElementPresent(AddStorePageLocators.approvalSuccess_msg, "Save URLs Page Success Message");
		result = true;
		return result;
	}
	
	public void setSourcingChannel(String sourcingChannel) {
		this.sourcingChannel = sourcingChannel;
	}
	public void setStoreType_web(String storeType_web) {
		this.storeType_web = storeType_web;
	}
	
	public void setTurnover_category(String Turnover_category) {
		this.Turnover_category = Turnover_category;
	}
	
	public void setStoreInfo_Channel_webpos(String storeInfo_Channel_webpos) {
		this.storeInfo_Channel_webpos = storeInfo_Channel_webpos;
	}
	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}
	
	public void setLOR(String LOR) {
		this.LOR = LOR;
	}
	
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setAwlMcc(String awlMcc) {
		this.awlMcc = awlMcc;
	}
	public void setPremisesType(String premisesType) {
		this.premisesType = premisesType;
	}
	public void setVintageType(String vintageType) {
		this.vintageType = vintageType;
	}
	public void setMerchantBusinessType(String merchantBusinessType) {
		this.merchantBusinessType = merchantBusinessType;
	}
	public void setMerchantWebUrl(String merchantWebUrl) {
		this.merchantWebUrl = merchantWebUrl;
	}
	public void setApplicationNo(String applicationNo) {
		this.applicationNo = applicationNo;
	}
	public void setCorpId(String corpId) {
		this.corpId = corpId;
	}
	public void setYearsInBusiness(String yearsInBusiness) {
		this.yearsInBusiness = yearsInBusiness;
	}
	public void setBusinessCompetitor(String businessCompetitor) {
		this.businessCompetitor = businessCompetitor;
	}
	public void setTotalShops(String totalShops) {
		this.totalShops = totalShops;
	}
	public void setAvgTicketSize(String avgTicketSize) {
		this.avgTicketSize = avgTicketSize;
	}
	public void setDefineBusinessMature(String defineBusinessMature) {
		this.defineBusinessMature = defineBusinessMature;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public void setAddress3(String address3) {
		this.address3 = address3;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public void setSubregion(String subregion) {
		this.subregion = subregion;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	public void setTitle(String Title) {
		this.Title = Title;
	}
	public void setDOB(String DOB) {
		this.DOB = DOB;
	}
	public void setBillingAddress_Same(String billingAddress_Same) {
		this.billingAddress_Same = billingAddress_Same;
	}
	public void setRmName(String rmName) {
		this.rmName = rmName;
	}
	public void setRmMobile(String rmMobile) {
		this.rmMobile = rmMobile;
	}
	public void setRmEmailId(String rmEmailId) {
		this.rmEmailId = rmEmailId;
	}
	public void setHoldPayment(String holdPayment) {
		this.holdPayment = holdPayment;
	}
	public void setPartialSettlement(String partialSettlement) {
		this.partialSettlement = partialSettlement;
	}
	public void setSettlementAgainstDelivery(String settlementAgainstDelivery) {
		this.settlementAgainstDelivery = settlementAgainstDelivery;
	}
	public void setAgreementDate(String agreementDate) {
		this.agreementDate = agreementDate;
	}
	public void setAgreementExpiryDate(String agreementExpiryDate) {
		this.agreementExpiryDate = agreementExpiryDate;
	}
	public void setAgreementNo(String agreementNo) {
		this.agreementNo = agreementNo;
	}
	public void setMerchantClassification(String merchantClassification) {
		this.merchantClassification = merchantClassification;
	}
	public void setMerchantSegment(String merchantSegment) {
		this.merchantSegment = merchantSegment;
	}
	public void setBranchOffDesg(String branchOffDesg) {
		this.branchOffDesg = branchOffDesg;
	}
	public void setBranchOffMobile(String branchOffMobile) {
		this.branchOffMobile = branchOffMobile;
	}
	public void setBranchOffName(String branchOffName) {
		this.branchOffName = branchOffName;
	}
	public void setBranchSolId(String branchSolId) {
		this.branchSolId = branchSolId;
	}
	public void setBranchStaffName(String branchStaffName) {
		this.branchStaffName = branchStaffName;
	}
	public void setBranchStaffPfi(String branchStaffPfi) {
		this.branchStaffPfi = branchStaffPfi;
	}
	public void setBranchStaffSv(String branchStaffSv) {
		this.branchStaffSv = branchStaffSv;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public void setChqDate(String chqDate) {
		this.chqDate = chqDate;
	}
	public void setChqAmount(String chqAmount) {
		this.chqAmount = chqAmount;
	}
	public void setChqRemarks(String chqRemarks) {
		this.chqRemarks = chqRemarks;
	}
	
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

	public void setContactMobile(String contactMobile) {
		this.contactMobile = contactMobile;
	}

	public void setContactAddress1(String contactAddress1) {
		this.contactAddress1 = contactAddress1;
	}

	public void setContactCountry(String contactCountry) {
		this.contactCountry = contactCountry;
	}

	public void setContactState(String contactState) {
		this.contactState = contactState;
	}

	public void setContactCity(String contactCity) {
		this.contactCity = contactCity;
	}

	public void setContactZipcode(String contactZipcode) {
		this.contactZipcode = contactZipcode;
	}
	
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}


	public void setLvId(String lvId) {
		this.lvId = lvId;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public void setOneTimeFixedFee(String oneTimeFixedFee) {
		this.oneTimeFixedFee = oneTimeFixedFee;
	}

	public void setStatementFee(String statementFee) {
		this.statementFee = statementFee;
	}

	public void setTerminalFee(String terminalFee) {
		this.terminalFee = terminalFee;
	}

	public void setMinimumUsage(String minimumUsage) {
		this.minimumUsage = minimumUsage;
	}

	public void setMinTransAmt(String minTransAmt) {
		this.minTransAmt = minTransAmt;
	}

	public void setMinUsageFee(String minUsageFee) {
		this.minUsageFee = minUsageFee;
	}

	public void setAmcType(String amcType) {
		this.amcType = amcType;
	}

	public void setAmcAmount(String amcAmount) {
		this.amcAmount = amcAmount;
	}

	public void setNonUsage(String nonUsage) {
		this.nonUsage = nonUsage;
	}

	public void setNonUsageFee(String nonUsageFee) {
		this.nonUsageFee = nonUsageFee;
	}
	
	//suresh
	public void setSecurityAmount1(String SecurityAmount) {
		this.SecurityAmount = SecurityAmount;
	}
	//------------------------------------

	public void setSettlementType(String settlementType) {
		this.settlementType = settlementType;
	}

	public void setPaymentBy(String paymentBy) {
		this.paymentBy = paymentBy;
	}

	public void setPaymentAdvice(String paymentAdvice) {
		this.paymentAdvice = paymentAdvice;
	}
	
	//suresh
	public void setNodalAccount(String NodalAccount) {
		this.NodalAccount = NodalAccount;
	}

	public void setMerchAccNumber(String merchAccNumber) {
		this.merchAccNumber = merchAccNumber;
	}

	public void setMerchBankName(String merchBankName) {
		this.merchBankName = merchBankName;
	}

	public void setDailyTransLimit(String dailyTransLimit) {
		this.dailyTransLimit = dailyTransLimit;
	}

	public void setFirc(String firc) {
		this.firc = firc;
	}

	public void setTccDescriptor(String tccDescriptor) {
		this.tccDescriptor = tccDescriptor;
	}

	public void setMerchIdType(String merchIdType) {
		this.merchIdType = merchIdType;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public void setFacilitator(String facilitator) {
		this.facilitator = facilitator;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public void setBillingAddress1(String billingAddress1) {
		this.billingAddress1 = billingAddress1;
	}

	public void setBillingAddress2(String billingAddress2) {
		this.billingAddress2 = billingAddress2;
	}

	public void setBillingAddress3(String billingAddress3) {
		this.billingAddress3 = billingAddress3;
	}

	public void setBillingCountry(String billingCountry) {
		this.billingCountry = billingCountry;
	}

	public void setBillingState(String billingState) {
		this.billingState = billingState;
	}

	public void setBillingCity(String billingCity) {
		this.billingCity = billingCity;
	}

	public void setBillingPhone1(String billingPhone1) {
		this.billingPhone1 = billingPhone1;
	}

	public void setBillingMobile(String billingMobile) {
		this.billingMobile = billingMobile;
	}

	public void setBillingFax(String billingFax) {
		this.billingFax = billingFax;
	}

	public void setBillingZipcode(String billingZipcode) {
		this.billingZipcode = billingZipcode;
	}

	public void setPrimaryOwnerFirstName(String primaryOwnerFirstName) {
		this.primaryOwnerFirstName = primaryOwnerFirstName;
	}

	public void setPrimaryOwnerMiddleName(String primaryOwnerMiddleName) {
		this.primaryOwnerMiddleName = primaryOwnerMiddleName;
	}

	public void setPrimaryOwnerLastName(String primaryOwnerLastName) {
		this.primaryOwnerLastName = primaryOwnerLastName;
	}

	public void setPrimaryOwnerPhone(String primaryOwnerPhone) {
		this.primaryOwnerPhone = primaryOwnerPhone;
	}

	public void setPrimaryOwnerMobile(String primaryOwnerMobile) {
		this.primaryOwnerMobile = primaryOwnerMobile;
	}

	public void setPrimaryOwnerZipcode(String primaryOwnerZipcode) {
		this.primaryOwnerZipcode = primaryOwnerZipcode;
	}

	public void setPrimaryOwnerAddress1(String primaryOwnerAddress1) {
		this.primaryOwnerAddress1 = primaryOwnerAddress1;
	}

	public void setPrimaryOwnerAddress2(String primaryOwnerAddress2) {
		this.primaryOwnerAddress2 = primaryOwnerAddress2;
	}

	public void setPrimaryOwnerFax(String primaryOwnerFax) {
		this.primaryOwnerFax = primaryOwnerFax;
	}

	public void setSecondaryOwnerFirstName(String secondaryOwnerFirstName) {
		this.secondaryOwnerFirstName = secondaryOwnerFirstName;
	}

	public void setSecondaryOwnerMiddleName(String secondaryOwnerMiddleName) {
		this.secondaryOwnerMiddleName = secondaryOwnerMiddleName;
	}

	public void setSecondaryOwnerLastName(String secondaryOwnerLastName) {
		this.secondaryOwnerLastName = secondaryOwnerLastName;
	}

	public void setSecondaryOwnerPhone(String secondaryOwnerPhone) {
		this.secondaryOwnerPhone = secondaryOwnerPhone;
	}

	public void setSecondaryOwnerMobile(String secondaryOwnerMobile) {
		this.secondaryOwnerMobile = secondaryOwnerMobile;
	}

	public void setSecondaryOwnerZipcode(String secondaryOwnerZipcode) {
		this.secondaryOwnerZipcode = secondaryOwnerZipcode;
	}

	public void setSecondaryOwnerAddress1(String secondaryOwnerAddress1) {
		this.secondaryOwnerAddress1 = secondaryOwnerAddress1;
	}

	public void setSecondaryOwnerAddress2(String secondaryOwnerAddress2) {
		this.secondaryOwnerAddress2 = secondaryOwnerAddress2;
	}

	public void setSecondaryOwnerFax(String secondaryOwnerFax) {
		this.secondaryOwnerFax = secondaryOwnerFax;
	}

	public void setCorporateInfo(String corporateInfo) {
		this.corporateInfo = corporateInfo;
	}

	public void setComprehensiveBackground(String comprehensiveBackground) {
		this.comprehensiveBackground = comprehensiveBackground;
	}

	public void setMeBusinessModelDesc(String meBusinessModelDesc) {
		this.meBusinessModelDesc = meBusinessModelDesc;
	}

	public void setGoodsServicesDesc(String goodsServicesDesc) {
		this.goodsServicesDesc = goodsServicesDesc;
	}

	public void setReturnPolicies(String returnPolicies) {
		this.returnPolicies = returnPolicies;
	}

	public void setMeCustServiceContactInfo(String meCustServiceContactInfo) {
		this.meCustServiceContactInfo = meCustServiceContactInfo;
	}

	public void setTransactionCurrency(String transactionCurrency) {
		this.transactionCurrency = transactionCurrency;
	}

	public void setDeliveryPolicy(String deliveryPolicy) {
		this.deliveryPolicy = deliveryPolicy;
	}

	public void setDataPrivacyPolicy(String dataPrivacyPolicy) {
		this.dataPrivacyPolicy = dataPrivacyPolicy;
	}

	public void setRecurringTransDetails(String recurringTransDetails) {
		this.recurringTransDetails = recurringTransDetails;
	}

	public void setShipDetails(String shipDetails) {
		this.shipDetails = shipDetails;
	}

	public void setInfoMethodTransSecurity(String infoMethodTransSecurity) {
		this.infoMethodTransSecurity = infoMethodTransSecurity;
	}

	public void setTransTermsConditions(String transTermsConditions) {
		this.transTermsConditions = transTermsConditions;
	}

	public void setMerchWebsite(String merchWebsite) {
		this.merchWebsite = merchWebsite;
	}

	public void setBriefSummaryGoods(String briefSummaryGoods) {
		this.briefSummaryGoods = briefSummaryGoods;
	}

	public void setNeedInternCardAcceptance(String needInternCardAcceptance) {
		this.needInternCardAcceptance = needInternCardAcceptance;
	}

	public void setPayChannelsVolumeSplit_Internet(
			String payChannelsVolumeSplit_Internet) {
		this.payChannelsVolumeSplit_Internet = payChannelsVolumeSplit_Internet;
	}

	public void setPayChannelsVolumeSplit_Mail(String payChannelsVolumeSplit_Mail) {
		this.payChannelsVolumeSplit_Mail = payChannelsVolumeSplit_Mail;
	}

	public void setPayChannelsVolumeSplit_PosCC(String payChannelsVolumeSplit_PosCC) {
		this.payChannelsVolumeSplit_PosCC = payChannelsVolumeSplit_PosCC;
	}

	public void setPayChannelsVolumeSplit_PosDC(String payChannelsVolumeSplit_PosDC) {
		this.payChannelsVolumeSplit_PosDC = payChannelsVolumeSplit_PosDC;
	}

	public void setBusChannelPayVolSplit_B2B(String busChannelPayVolSplit_B2B) {
		this.busChannelPayVolSplit_B2B = busChannelPayVolSplit_B2B;
	}

	public void setBusChannelPayVolSplit_B2C(String busChannelPayVolSplit_B2C) {
		this.busChannelPayVolSplit_B2C = busChannelPayVolSplit_B2C;
	}

	public void setAcceptONlinePay(String acceptONlinePay) {
		this.acceptONlinePay = acceptONlinePay;
	}

	public void setProcessorBankName(String processorBankName) {
		this.processorBankName = processorBankName;
	}

	public void setHowLongWithProcess(String howLongWithProcess) {
		this.howLongWithProcess = howLongWithProcess;
	}

	public void setAnnualOnlineTurnover(String annualOnlineTurnover) {
		this.annualOnlineTurnover = annualOnlineTurnover;
	}

	public void setAnnualOfflineTurnover(String annualOfflineTurnover) {
		this.annualOfflineTurnover = annualOfflineTurnover;
	}

	public void setMinTicketSize(String minTicketSize) {
		this.minTicketSize = minTicketSize;
	}

	public void setMaxTicketSize(String maxTicketSize) {
		this.maxTicketSize = maxTicketSize;
	}

	public void setTimeFrames0(String timeFrames0) {
		this.timeFrames0 = timeFrames0;
	}

	public void setTimeFrames1_3(String timeFrames1_3) {
		this.timeFrames1_3 = timeFrames1_3;
	}

	public void setTimeFrames4_7(String timeFrames4_7) {
		this.timeFrames4_7 = timeFrames4_7;
	}

	public void setTimeFrames8_14(String timeFrames8_14) {
		this.timeFrames8_14 = timeFrames8_14;
	}

	public void setTimeFrames15_30(String timeFrames15_30) {
		this.timeFrames15_30 = timeFrames15_30;
	}

	public void setDeposite(String deposite) {
		this.deposite = deposite;
	}

	public void setAutoRenewals(String autoRenewals) {
		this.autoRenewals = autoRenewals;
	}

	public void setRefundPolicyFull(String refundPolicyFull) {
		this.refundPolicyFull = refundPolicyFull;
	}

	public void setRefundDays(String refundDays) {
		this.refundDays = refundDays;
	}

	public void setRiskChecks(String riskChecks) {
		this.riskChecks = riskChecks;
	}

	public void setSendEmail(String sendEmail) {
		this.sendEmail = sendEmail;
	}

	public void setTimeBtwnPayDelivery(String timeBtwnPayDelivery) {
		this.timeBtwnPayDelivery = timeBtwnPayDelivery;
	}

	public void setDiwali(String diwali) {
		this.diwali = diwali;
	}

	public void setChristmas(String christmas) {
		this.christmas = christmas;
	}

	public void setEaster(String easter) {
		this.easter = easter;
	}

	public void setSummerSales(String summerSales) {
		this.summerSales = summerSales;
	}

	public void setChargeBackVol(String chargeBackVol) {
		this.chargeBackVol = chargeBackVol;
	}

	public void setNoOfFunds(String noOfFunds) {
		NoOfFunds = noOfFunds;
	}

	public void setNoOfTrans(String noOfTrans) {
		NoOfTrans = noOfTrans;
	}

	public void setRefundVolume(String refundVolume) {
		this.refundVolume = refundVolume;
	}

	public void setSalesVolume(String salesVolume) {
		this.salesVolume = salesVolume;
	}

	public void setApplicationMode(String applicationMode) {
		this.applicationMode = applicationMode;
	}

	public void setTransactionMode(String transactionMode) {
		this.transactionMode = transactionMode;
	}

	public void setFircFrequency(String fircFrequency) {
		this.fircFrequency = fircFrequency;
	}

	public void setFuelAssociation(String fuelAssociation) {
		this.fuelAssociation = fuelAssociation;
	}

	public void setFuelRemark(String fuelRemark) {
		this.fuelRemark = fuelRemark;
	}

	public void setCallCharges(String callCharges) {
		this.callCharges = callCharges;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}

	public void setDocumentRequired(String documentRequired) {
		this.documentRequired = documentRequired;
	}

	public void setDocumentPending(String documentPending) {
		this.documentPending = documentPending;
	}

	public void setMerchReimbursement(String merchReimbursement) {
		this.merchReimbursement = merchReimbursement;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public void setAmexMaId(String amexMaId) {
		this.amexMaId = amexMaId;
	}

	public void setAmexMaPassword(String amexMaPassword) {
		this.amexMaPassword = amexMaPassword;
	}

	public void setAmexAmaId(String amexAmaId) {
		this.amexAmaId = amexAmaId;
	}

	public void setAmexAmaPassword(String amexAmaPassword) {
		this.amexAmaPassword = amexAmaPassword;
	}

	public void setAmexAccessCode(String amexAccessCode) {
		this.amexAccessCode = amexAccessCode;
	}

	public void setAmexSecureSecret(String amexSecureSecret) {
		this.amexSecureSecret = amexSecureSecret;
	}

	public void setAmexDomesticCc(String amexDomesticCc) {
		this.amexDomesticCc = amexDomesticCc;
	}

	public void setAmexInternationalCc(String amexInternationalCc) {
		this.amexInternationalCc = amexInternationalCc;
	}

	public void setMastDomCc(String mastDomCc) {
		this.mastDomCc = mastDomCc;
	}

	public void setMastIntCc(String mastIntCc) {
		this.mastIntCc = mastIntCc;
	}

	public void setRupayDomCc(String rupayDomCc) {
		this.rupayDomCc = rupayDomCc;
	}

	public void setRupayIntCc(String rupayIntCc) {
		this.rupayIntCc = rupayIntCc;
	}

	public void setVisaDomCc(String visaDomCc) {
		this.visaDomCc = visaDomCc;
	}

	public void setVisaIntCc(String visaIntCc) {
		this.visaIntCc = visaIntCc;
	}

	public void setMastDomDc(String mastDomDc) {
		this.mastDomDc = mastDomDc;
	}

	public void setMastIntDc(String mastIntDc) {
		this.mastIntDc = mastIntDc;
	}

	public void setVisaDomDc(String visaDomDc) {
		this.visaDomDc = visaDomDc;
	}

	public void setVisaIntDc(String visaIntDc) {
		this.visaIntDc = visaIntDc;
	}

	public void setRupayDomDc(String rupayDomDc) {
		this.rupayDomDc = rupayDomDc;
	}

	public void setRupayIntDc(String rupayIntDc) {
		this.rupayIntDc = rupayIntDc;
	}

	public void setInternetBankLv(String internetBankLv) {
		this.internetBankLv = internetBankLv;
	}

	public void setInternetBankSelectBank(String internetBankSelectBank) {
		this.internetBankSelectBank = internetBankSelectBank;
	}

	public void setInternetBankEffectDate(String internetBankEffectDate) {
		this.internetBankEffectDate = internetBankEffectDate;
	}

	public void setInternetBankStatus(String internetBankStatus) {
		this.internetBankStatus = internetBankStatus;
	}

	public void setInternetBankSortOrder(String internetBankSortOrder) {
		this.internetBankSortOrder = internetBankSortOrder;
	}

	public void setInternetBankNetBankAccId(String internetBankNetBankAccId) {
		this.internetBankNetBankAccId = internetBankNetBankAccId;
	}

	public void setInternetBankSecretKey(String internetBankSecretKey) {
		this.internetBankSecretKey = internetBankSecretKey;
	}

	public void setInternetBankPerTransLimit(String internetBankPerTransLimit) {
		this.internetBankPerTransLimit = internetBankPerTransLimit;
	}

	public void setCugFromBin(String cugFromBin) {
		this.cugFromBin = cugFromBin;
	}

	public void setCugToBin(String cugToBin) {
		this.cugToBin = cugToBin;
	}

	public void setImpsMmid(String impsMmid) {
		this.impsMmid = impsMmid;
	}

	public void setImpsMobileNo(String impsMobileNo) {
		this.impsMobileNo = impsMobileNo;
	}

	public void setIpgRefund(String ipgRefund) {
		this.ipgRefund = ipgRefund;
	}

	public void setIpgCancellation(String ipgCancellation) {
		this.ipgCancellation = ipgCancellation;
	}

	public void setIpgRecurPayUpload(String ipgRecurPayUpload) {
		this.ipgRecurPayUpload = ipgRecurPayUpload;
	}

	public void setIpgRecurPayOnline(String ipgRecurPayOnline) {
		this.ipgRecurPayOnline = ipgRecurPayOnline;
	}

	public void setIpgPreauth(String ipgPreauth) {
		this.ipgPreauth = ipgPreauth;
	}

	public void setIpgHostedPages(String ipgHostedPages) {
		this.ipgHostedPages = ipgHostedPages;
	}

	public void setIpgEmailInvoice(String ipgEmailInvoice) {
		this.ipgEmailInvoice = ipgEmailInvoice;
	}

	public void setIpgSmsInvoice(String ipgSmsInvoice) {
		this.ipgSmsInvoice = ipgSmsInvoice;
	}

	public void setPaymentTypeCreditCard(String paymentTypeCreditCard) {
		this.paymentTypeCreditCard = paymentTypeCreditCard;
	}

	public void setPaymentTypeDebitCard(String paymentTypeDebitCard) {
		this.paymentTypeDebitCard = paymentTypeDebitCard;
	}

	public void setPaymentTypeInternetBank(String paymentTypeInternetBank) {
		this.paymentTypeInternetBank = paymentTypeInternetBank;
	}

	public void setPaymentTypeCug(String paymentTypeCug) {
		this.paymentTypeCug = paymentTypeCug;
	}

	public void setPaymentTypeImps(String paymentTypeImps) {
		this.paymentTypeImps = paymentTypeImps;
	}

	public void setMsfAcqBankNameCc(String msfAcqBankNameCc) {
		this.msfAcqBankNameCc = msfAcqBankNameCc;
	}

	public void setMsfMidCc(String msfMidCc) {
		this.msfMidCc = msfMidCc;
	}

	public void setMsfSchemeCc(String msfSchemeCc) {
		this.msfSchemeCc = msfSchemeCc;
	}

	public void setSlabUptoCc(String slabUptoCc) {
		this.slabUptoCc = slabUptoCc;
	}

	public void setInterFixedCc(String interFixedCc) {
		this.interFixedCc = interFixedCc;
	}

	public void setInterPerCc(String interPerCc) {
		this.interPerCc = interPerCc;
	}

	public void setDomesticOnusFixedCc(String domesticOnusFixedCc) {
		this.domesticOnusFixedCc = domesticOnusFixedCc;
	}

	public void setDomesticOnusPerCc(String domesticOnusPerCc) {
		this.domesticOnusPerCc = domesticOnusPerCc;
	}

	public void setDomesticOffusFixedCc(String domesticOffusFixedCc) {
		this.domesticOffusFixedCc = domesticOffusFixedCc;
	}

	public void setDomesticOffusPerCc(String domesticOffusPerCc) {
		this.domesticOffusPerCc = domesticOffusPerCc;
	}

	public void setChargeTypeCc(String chargeTypeCc) {
		this.chargeTypeCc = chargeTypeCc;
	}
	
	public void setManageBSFCc(String manageBSFCc) {
		this.manageBSFCc = manageBSFCc;
	}
	

	public void setMsfAcqBankNameDc(String msfAcqBankNameDc) {
		this.msfAcqBankNameDc = msfAcqBankNameDc;
	}

	public void setMsfMidDc(String msfMidDc) {
		this.msfMidDc = msfMidDc;
	}

	public void setMsfSchemeDc(String msfSchemeDc) {
		this.msfSchemeDc = msfSchemeDc;
	}

	public void setSlabUptoDc(String slabUptoDc) {
		this.slabUptoDc = slabUptoDc;
	}

	public void setInterFixedDc(String interFixedDc) {
		this.interFixedDc = interFixedDc;
	}

	public void setInterPerDc(String interPerDc) {
		this.interPerDc = interPerDc;
	}

	public void setDomesticOnusFixedDc(String domesticOnusFixedDc) {
		this.domesticOnusFixedDc = domesticOnusFixedDc;
	}

	public void setDomesticOnusPerDc(String domesticOnusPerDc) {
		this.domesticOnusPerDc = domesticOnusPerDc;
	}

	public void setDomesticOffusFixedDc(String domesticOffusFixedDc) {
		this.domesticOffusFixedDc = domesticOffusFixedDc;
	}

	public void setDomesticOffusPerDc(String domesticOffusPerDc) {
		this.domesticOffusPerDc = domesticOffusPerDc;
	}

	public void setChargeTypeDc(String chargeTypeDc) {
		this.chargeTypeDc = chargeTypeDc;
	}

	public void setExistingRelationship(String existingRelationship) {
		this.existingRelationship = existingRelationship;
	}

	public void setPaymentHoldover(String paymentHoldover) {
		this.paymentHoldover = paymentHoldover;
	}

	public void setChecklistMsf(String checklistMsf) {
		this.checklistMsf = checklistMsf;
	}

	public void setCrossborderTransaction(String crossborderTransaction) {
		this.crossborderTransaction = crossborderTransaction;
	}

	public void setSecure3D(String secure3d) {
		secure3D = secure3d;
	}

	public void setDomesticUserTransLimit(String domesticUserTransLimit) {
		this.domesticUserTransLimit = domesticUserTransLimit;
	}

	public void setSecureCrossborderLimit(String secureCrossborderLimit) {
		this.secureCrossborderLimit = secureCrossborderLimit;
	}

	public void setUnsecureTransLimit(String unsecureTransLimit) {
		this.unsecureTransLimit = unsecureTransLimit;
	}

	public void setChargeBackRecover(String chargeBackRecover) {
		this.chargeBackRecover = chargeBackRecover;
	}

	public void setFinancialStatementSubmit(String financialStatementSubmit) {
		this.financialStatementSubmit = financialStatementSubmit;
	}

	public void setFinancialStatementSubmitRemark(
			String financialStatementSubmitRemark) {
		this.financialStatementSubmitRemark = financialStatementSubmitRemark;
	}

	public void setWebsiteCheck(String websiteCheck) {
		this.websiteCheck = websiteCheck;
	}

	public void setWebsiteCheckRemark(String websiteCheckRemark) {
		this.websiteCheckRemark = websiteCheckRemark;
	}

	public void setMerchantRating(String merchantRating) {
		this.merchantRating = merchantRating;
	}

	public void setMerchantRatingRemark(String merchantRatingRemark) {
		this.merchantRatingRemark = merchantRatingRemark;
	}

	public void setSiteInspection(String siteInspection) {
		this.siteInspection = siteInspection;
	}

	public void setSiteInspectionRemark(String siteInspectionRemark) {
		this.siteInspectionRemark = siteInspectionRemark;
	}

	public void setBusinessApproval(String businessApproval) {
		this.businessApproval = businessApproval;
	}

	public void setBusinessApprovalRemark(String businessApprovalRemark) {
		this.businessApprovalRemark = businessApprovalRemark;
	}

	public void setCibilChecks(String cibilChecks) {
		this.cibilChecks = cibilChecks;
	}

	public void setCibilChecksRemark(String cibilChecksRemark) {
		this.cibilChecksRemark = cibilChecksRemark;
	}

	public void setKycDocVerify(String kycDocVerify) {
		this.kycDocVerify = kycDocVerify;
	}

	public void setKycDocVerifyRemark(String kycDocVerifyRemark) {
		this.kycDocVerifyRemark = kycDocVerifyRemark;
	}

	public void setMerchRatingLocation(String merchRatingLocation) {
		this.merchRatingLocation = merchRatingLocation;
	}

	public void setMerchRatingFinancial(String merchRatingFinancial) {
		this.merchRatingFinancial = merchRatingFinancial;
	}

	public void setMerchRatingMCategory(String merchRatingMCategory) {
		this.merchRatingMCategory = merchRatingMCategory;
	}

	public void setMerchRatingDeliveryTimeline(String merchRatingDeliveryTimeline) {
		this.merchRatingDeliveryTimeline = merchRatingDeliveryTimeline;
	}

	public void setMerchRatingOpsSecurity(String merchRatingOpsSecurity) {
		this.merchRatingOpsSecurity = merchRatingOpsSecurity;
	}

	public void setMerchRatingWebSecurity(String merchRatingWebSecurity) {
		this.merchRatingWebSecurity = merchRatingWebSecurity;
	}

	public void setMerchRatingVmts(String merchRatingVmts) {
		this.merchRatingVmts = merchRatingVmts;
	}

	public void setMerchRatingMatch(String merchRatingMatch) {
		this.merchRatingMatch = merchRatingMatch;
	}

	public void setMerchRatingCibil(String merchRatingCibil) {
		this.merchRatingCibil = merchRatingCibil;
	}

	public void setMerchRatingVmtsCheckbox(String merchRatingVmtsCheckbox) {
		this.merchRatingVmtsCheckbox = merchRatingVmtsCheckbox;
	}

	public void setMerchRatingMatchCheckbox(String merchRatingMatchCheckbox) {
		this.merchRatingMatchCheckbox = merchRatingMatchCheckbox;
	}

	public void setMerchRatingPostFacto(String merchRatingPostFacto) {
		this.merchRatingPostFacto = merchRatingPostFacto;
	}

	public void setMerchRatingWaiver(String merchRatingWaiver) {
		this.merchRatingWaiver = merchRatingWaiver;
	}

	public void setMerchRatingEnterRemark(String merchRatingEnterRemark) {
		this.merchRatingEnterRemark = merchRatingEnterRemark;
	}

	public void setUploadValidLicense(String uploadValidLicense) {
		this.uploadValidLicense = uploadValidLicense;
	}

	public void setUploadValidLicenseRemark(String uploadValidLicenseRemark) {
		this.uploadValidLicenseRemark = uploadValidLicenseRemark;
	}

	public void setUploadPancard(String uploadPancard) {
		this.uploadPancard = uploadPancard;
	}

	public void setUploadPancardRemark(String uploadPancardRemark) {
		this.uploadPancardRemark = uploadPancardRemark;
	}

	public void setUploadAddressProof(String uploadAddressProof) {
		this.uploadAddressProof = uploadAddressProof;
	}

	public void setUploadAddressProofRemark(String uploadAddressProofRemark) {
		this.uploadAddressProofRemark = uploadAddressProofRemark;
	}

	public void setUploadIncomeTax(String uploadIncomeTax) {
		this.uploadIncomeTax = uploadIncomeTax;
	}

	public void setUploadIncomeTaxRemark(String uploadIncomeTaxRemark) {
		this.uploadIncomeTaxRemark = uploadIncomeTaxRemark;
	}

	public void setUploadStatementOfAcc(String uploadStatementOfAcc) {
		this.uploadStatementOfAcc = uploadStatementOfAcc;
	}

	public void setUploadStatementOfAccRemark(String uploadStatementOfAccRemark) {
		this.uploadStatementOfAccRemark = uploadStatementOfAccRemark;
	}

	public void setUploadCancelChq(String uploadCancelChq) {
		this.uploadCancelChq = uploadCancelChq;
	}

	public void setUploadCancelChqRemark(String uploadCancelChqRemark) {
		this.uploadCancelChqRemark = uploadCancelChqRemark;
	}

	public void setUploadMerchEstAgg(String uploadMerchEstAgg) {
		this.uploadMerchEstAgg = uploadMerchEstAgg;
	}

	public void setUploadMerchEstAggRemark(String uploadMerchEstAggRemark) {
		this.uploadMerchEstAggRemark = uploadMerchEstAggRemark;
	}

	public void setUploadCpLicenseShops(String uploadCpLicenseShops) {
		this.uploadCpLicenseShops = uploadCpLicenseShops;
	}

	public void setUploadCpLicenseShopsRemark(String uploadCpLicenseShopsRemark) {
		this.uploadCpLicenseShopsRemark = uploadCpLicenseShopsRemark;
	}

	public void setUploadIDproof(String uploadIDproof) {
		this.uploadIDproof = uploadIDproof;
	}

	public void setUploadIDproofRemark(String uploadIDproofRemark) {
		this.uploadIDproofRemark = uploadIDproofRemark;
	}

	public void setIsWebsiteOnInternet(String isWebsiteOnInternet) {
		this.isWebsiteOnInternet = isWebsiteOnInternet;
	}

	public void setMerchWebsiteUrl(String merchWebsiteUrl) {
		this.merchWebsiteUrl = merchWebsiteUrl;
	}

	public void setPrivacyPolicy(String privacyPolicy) {
		this.privacyPolicy = privacyPolicy;
	}

	public void setTermsCondPolicy(String termsCondPolicy) {
		this.termsCondPolicy = termsCondPolicy;
	}

	public void setContactUsInfo(String contactUsInfo) {
		this.contactUsInfo = contactUsInfo;
	}

	public void setFaqPage(String faqPage) {
		this.faqPage = faqPage;
	}

	public void setOneProdPage(String oneProdPage) {
		this.oneProdPage = oneProdPage;
	}

	public void setAboutUs(String aboutUs) {
		this.aboutUs = aboutUs;
	}

	public void setHowWebsiteManaged(String howWebsiteManaged) {
		this.howWebsiteManaged = howWebsiteManaged;
	}

	public void setWhichCompOwnsWebsite(String whichCompOwnsWebsite) {
		this.whichCompOwnsWebsite = whichCompOwnsWebsite;
	}

	public void setOutsourcedForSolution(String outsourcedForSolution) {
		this.outsourcedForSolution = outsourcedForSolution;
	}

	public void setWhichSolutionWebsiteOn(String whichSolutionWebsiteOn) {
		this.whichSolutionWebsiteOn = whichSolutionWebsiteOn;
	}

	public void setEcommStrategy(String ecommStrategy) {
		this.ecommStrategy = ecommStrategy;
	}
	
	public void setCharityOrg(String charityOrg) {
		this.charityOrg = charityOrg;
	}

	public void setHostelsMotels(String hostelsMotels) {
		this.hostelsMotels = hostelsMotels;
	}

	public void setOther(String other) {
		this.other = other;
	}

	public void setPleaseSpecify(String pleaseSpecify) {
		this.pleaseSpecify = pleaseSpecify;
	}

	public void setCancelRefundPolicy(String cancelRefundPolicy) {
		this.cancelRefundPolicy = cancelRefundPolicy;
	}

	public void setEcommTargetUtility(String ecommTargetUtility) {
		this.ecommTargetUtility = ecommTargetUtility;
	}

	public void setEcommTargetTravel(String ecommTargetTravel) {
		this.ecommTargetTravel = ecommTargetTravel;
	}

	public void setEcommTargetRetail(String ecommTargetRetail) {
		this.ecommTargetRetail = ecommTargetRetail;
	}

	public void setEcommTargetEducation(String ecommTargetEducation) {
		this.ecommTargetEducation = ecommTargetEducation;
	}

	public void setBlListType(String blListType) {
		this.blListType = blListType;
	}

	public void setBlSchemeName(String blSchemeName) {
		this.blSchemeName = blSchemeName;
	}

	public void setBlFromBin(String blFromBin) {
		this.blFromBin = blFromBin;
	}

	public void setBlToBin(String blToBin) {
		this.blToBin = blToBin;
	}

	public void setEciValueVisa(String eciValueVisa) {
		this.eciValueVisa = eciValueVisa;
	}

	public void setEciValueMaster(String eciValueMaster) {
		this.eciValueMaster = eciValueMaster;
	}

	public void setEciValueMaestro(String eciValueMaestro) {
		this.eciValueMaestro = eciValueMaestro;
	}

	public void setIntegrationApproach(String integrationApproach) {
		this.integrationApproach = integrationApproach;
	}

	public void setPciDssCertificate(String pciDssCertificate) {
		this.pciDssCertificate = pciDssCertificate;
	}

	public void setPciDssExpDate(String pciDssExpDate) {
		this.pciDssExpDate = pciDssExpDate;
	}

	public void setEbsChecksumKey(String ebsChecksumKey) {
		this.ebsChecksumKey = ebsChecksumKey;
	}

	public void setMpiIntegration(String mpiIntegration) {
		this.mpiIntegration = mpiIntegration;
	}

	public void setMpiChecksumKey(String mpiChecksumKey) {
		this.mpiChecksumKey = mpiChecksumKey;
	}

	public void setLyraCertificate(String lyraCertificate) {
		this.lyraCertificate = lyraCertificate;
	}

	public void setLyraShopId(String lyraShopId) {
		this.lyraShopId = lyraShopId;
	}

	public void setConvFeeMsfCheckValue(String convFeeMsfCheckValue) {
		this.convFeeMsfCheckValue = convFeeMsfCheckValue;
	}

	public void setMerchEmailConfirmForTrans(String merchEmailConfirmForTrans) {
		this.merchEmailConfirmForTrans = merchEmailConfirmForTrans;
	}

	public void setReqUrl1(String reqUrl1) {
		this.reqUrl1 = reqUrl1;
	}

	public void setReqUrl2(String reqUrl2) {
		this.reqUrl2 = reqUrl2;
	}

	public void setTrainingSchedule(String trainingSchedule) {
		this.trainingSchedule = trainingSchedule;
	}

	public void setSeId(String seId) {
		this.seId = seId;
	}

	public void setSeRemarks(String seRemarks) {
		this.seRemarks = seRemarks;
	}

	public void setOwnership(String ownership) {
		this.ownership = ownership;
	}

	public void setMeChargeSlipName(String meChargeSlipName) {
		this.meChargeSlipName = meChargeSlipName;
	}

	public void setPcposVersion(String pcposVersion) {
		this.pcposVersion = pcposVersion;
	}

	public void setPromptProcessFlag(String promptProcessFlag) {
		this.promptProcessFlag = promptProcessFlag;
	}

	public void setMaxCashPos(String maxCashPos) {
		this.maxCashPos = maxCashPos;
	}

	public void setMaxPreauthPercent(String maxPreauthPercent) {
		this.maxPreauthPercent = maxPreauthPercent;
	}

	public void setContentDisclaimer(String contentDisclaimer) {
		this.contentDisclaimer = contentDisclaimer;
	}

	public void setInstrumentDisclaimer(String instrumentDisclaimer) {
		this.instrumentDisclaimer = instrumentDisclaimer;
	}

	public void setProgramDisclaimer(String programDisclaimer) {
		this.programDisclaimer = programDisclaimer;
	}

	public void setTotalNoOfTerminals(String totalNoOfTerminals) {
		this.totalNoOfTerminals = totalNoOfTerminals;
	}

	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}

	public void setEdcVersion(String edcVersion) {
		this.edcVersion = edcVersion;
	}

	public void setNoOfTerminals(String noOfTerminals) {
		this.noOfTerminals = noOfTerminals;
	}

	public void setContactAddress2(String contactAddress2) {
		this.contactAddress2 = contactAddress2;
	}

	public void setContactAddress3(String contactAddress3) {
		this.contactAddress3 = contactAddress3;
	}

	public void setProjectedAvgTicketSize(String projectedAvgTicketSize) {
		this.projectedAvgTicketSize = projectedAvgTicketSize;
	}

	public void setNewPayAdviceValue(String newPayAdviceValue) {
		this.newPayAdviceValue = newPayAdviceValue;
	}

	public void setRental(String rental) {
		this.rental = rental;
	}

	public void setRentalFrequencyValue(String rentalFrequencyValue) {
		this.rentalFrequencyValue = rentalFrequencyValue;
	}

	public void setAdvanceRent(String advanceRent) {
		this.advanceRent = advanceRent;
	}

	public void setAdvanceRentalFrequency(String advanceRentalFrequency) {
		this.advanceRentalFrequency = advanceRentalFrequency;
	}

	public void setAdvanceRentalAmount(String advanceRentalAmount) {
		this.advanceRentalAmount = advanceRentalAmount;
	}

	public void setAdvanceSetup(String advanceSetup) {
		this.advanceSetup = advanceSetup;
	}

	public void setAdvanceSetupFee(String advanceSetupFee) {
		this.advanceSetupFee = advanceSetupFee;
	}

	public void setMsfIncentive(String msfIncentive) {
		this.msfIncentive = msfIncentive;
	}

	public void setMerchantIncentive(String merchantIncentive) {
		this.merchantIncentive = merchantIncentive;
	}

	public void setTipPercent(String tipPercent) {
		this.tipPercent = tipPercent;
	}

	public void setCashPOS(String cashPOS) {
		this.cashPOS = cashPOS;
	}

	public void setSaleWithCashBack(String saleWithCashBack) {
		this.saleWithCashBack = saleWithCashBack;
	}

	public void setMerchAccOpenDate(String merchAccOpenDate) {
		this.merchAccOpenDate = merchAccOpenDate;
	}

	public void setMerchAccState(String merchAccState) {
		this.merchAccState = merchAccState;
	}

	public void setMerchAccCity(String merchAccCity) {
		this.merchAccCity = merchAccCity;
	}

	public void setMerchAccPhone(String merchAccPhone) {
		this.merchAccPhone = merchAccPhone;
	}

	public void setMerchAccMobile(String merchAccMobile) {
		this.merchAccMobile = merchAccMobile;
	}

	public void setMerchAccAddress1(String merchAccAddress1) {
		this.merchAccAddress1 = merchAccAddress1;
	}

	public void setMerchAccAddress2(String merchAccAddress2) {
		this.merchAccAddress2 = merchAccAddress2;
	}

	public void setIntBankBankName(String intBankBankName) {
		this.intBankBankName = intBankBankName;
	}

	public void setIntBankSlabUpto(String intBankSlabUpto) {
		this.intBankSlabUpto = intBankSlabUpto;
	}

	public void setIntBankFixed(String intBankFixed) {
		this.intBankFixed = intBankFixed;
	}

	public void setIntBankEffectiveFrom(String intBankEffectiveFrom) {
		this.intBankEffectiveFrom = intBankEffectiveFrom;
	}

	public void setIntBankChargeType(String intBankChargeType) {
		this.intBankChargeType = intBankChargeType;
	}

	public void setCugBankName(String cugBankName) {
		this.cugBankName = cugBankName;
	}

	public void setCugSlabUpto(String cugSlabUpto) {
		this.cugSlabUpto = cugSlabUpto;
	}

	public void setCugFixed(String cugFixed) {
		this.cugFixed = cugFixed;
	}

	public void setCugPercent(String cugPercent) {
		this.cugPercent = cugPercent;
	}

	public void setCugEffectiveFrom(String cugEffectiveFrom) {
		this.cugEffectiveFrom = cugEffectiveFrom;
	}

	public void setCugChargeType(String cugChargeType) {
		this.cugChargeType = cugChargeType;
	}

	public void setImpsSlabUpto(String impsSlabUpto) {
		this.impsSlabUpto = impsSlabUpto;
	}

	public void setImpsFixed(String impsFixed) {
		this.impsFixed = impsFixed;
	}

	public void setImpsPercent(String impsPercent) {
		this.impsPercent = impsPercent;
	}

	public void setImpsEffectiveFrom(String impsEffectiveFrom) {
		this.impsEffectiveFrom = impsEffectiveFrom;
	}

	public void setImpsChargeType(String impsChargeType) {
		this.impsChargeType = impsChargeType;
	}

	public void setIntBankPercent(String intBankPercent) {
		this.intBankPercent = intBankPercent;
	}

	public void setSettlementCycle(String settlementCycle) {
		this.settlementCycle = settlementCycle;
	}

	public void setSecurityAmount(String securityAmount) {
		this.securityAmount = securityAmount;
	}
	
	
	
}