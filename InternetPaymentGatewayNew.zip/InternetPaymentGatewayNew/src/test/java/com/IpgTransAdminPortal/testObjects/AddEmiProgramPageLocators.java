package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class AddEmiProgramPageLocators {
	
	public static By lvName_select = By.id("lvId");
	public static By programCode_txt = By.id("prgmCode");
	public static By programDescription_txt = By.id("prgmDesc");
	public static By interestRate_txt = By.id("intRate");
	public static By processFeePercent_txt = By.id("procFeePer");
	public static By processFeeFix_txt = By.id("procFeeFix");
	public static By validFrom_txt = By.id("validFrom");
	public static By validFromToday_lnk = By.xpath("//td[contains(@class,'ui-datepicker-today')]//a");
	public static By datePickerYear_select = By.xpath("//select[contains(@class,'ui-datepicker-year')]");
	public static By datePickerDay_link = By.xpath("//td[contains(@data-handler,'selectDay')]//a");
	public static By validTo_txt = By.id("validTo");
	public static By minAmount_txt = By.id("minAmt");
	public static By maxAmount_txt = By.id("maxAmt");
	public static By emiDiscountType_txt = By.id("emiDiscType");
	public static By emiDiscPercentFixed_txt = By.id("emiDiscPerAmt");
	public static By emiAddDiscAmount_txt = By.id("emiAddlDiscAmt");
	public static By maxCapAmount_txt = By.id("emiCapAmt");
	public static By taxCode_select = By.id("taxCode");
	public static By taxFor_select = By.id("taxFor");
	public static By add_btn = By.xpath("//button[contains(text(),'Add')]");
	public static By tenure_txt = By.id("tenure");
	public static By tenureAdd_btn = By.xpath("//div[contains(@itemname,'optionTenureList')]//button");
	public static By proMapChannel_select = By.id("chnId");
	public static By issuerBank_select = By.id("issueBnkCode");
	public static By acqBank_select = By.id("acqBankId");
	public static By merchName_txt = By.id("merchantId");
	public static By manufacturerName_txt = By.id("manuFactId");
	public static By prodName_select = By.id("emiProdId");
	public static By programMapAdd_btn = By.xpath("//div[contains(@itemname,'optionPgmList')]//button");
	public static By submit_btn = By.id("submit");
	public static By emiSuccessful_msg = By.xpath("//div[contains(text(),'EMI has been successfully created')]");
	
	public static By approval_tab = By.xpath("//a[contains(@data-value,'getPendingEmiList')]/span");
	public static By viewEmiProgram_lnk = By.xpath("//a[@class='viewEmi']");
	public static By emiInfoScreen_lbl = By.xpath("//span[contains(text(),'EMI Information')]");
	public static By approval_submit_btn = By.xpath("//button[contains(text(),'Submit')]");
	public static By approveEmiProgramSuccess_mg = By.xpath("//div[contains(@class,'alert alert-success')]");
	public static By deactivateEmiProgram_btn = By.xpath("//input[@id='actDeactEmi']");
	
}
