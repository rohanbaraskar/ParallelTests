package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class NetbankReconUploadPageLocators {
	
	public static By netbankReconUploadList = By.xpath("//span[contains(text(),'NetBank Reconciliation Upload List')]");
	public static By upload_btn = By.xpath("//button[contains(text(),'Upload')]");
	public static By lvId_select = By.id("lvId");
	public static By netbankName_select = By.id("netBankId");
	public static By inputFilePath = By.xpath("//input[contains(@id,'file') and contains(@type,'file')]");
	public static By uploadFile_btn = By.xpath("//input[contains(@value,'Upload')]");
	public static By uploadFileSuccessConfirm_msg = By.xpath("//div[contains(text(),'Netbank Reconciliation File Uploaded Successfully')]");
	public static By fileGenSuccess_row = By.xpath("//tbody/tr[1]/td[contains(text(),'SUCCESS')]");
	public static By fileGenPending_row = By.xpath("//tbody/tr[1]/td[contains(text(),'PENDING')]");
	public static By fileGenInProgress_row = By.xpath("//tbody/tr[1]/td[contains(text(),'In Progress')]");
	public static By fileGenFailed_row = By.xpath("//tbody/tr[1]/td[contains(text(),'FAILED')]");
	public static By refresh_btn = By.xpath("//button[@value='Refresh']");
	public static By firstRow_batchRunId = By.xpath("//tbody/tr/td[@class='sorting_1']");
	public static By search_txt = By.xpath("//input[@type='search']");
	
}

