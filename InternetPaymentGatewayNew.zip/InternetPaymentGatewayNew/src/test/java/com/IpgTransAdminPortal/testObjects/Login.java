package com.IpgTransAdminPortal.testObjects;

public class Login {

}
