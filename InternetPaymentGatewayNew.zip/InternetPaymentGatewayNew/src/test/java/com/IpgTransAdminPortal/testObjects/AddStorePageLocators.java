package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class AddStorePageLocators {
	
	public static By sourcingChannel_select = By.id("srcChnId");
	public static By facilitator_select = By.id("fclId");
	public static By Turnover_category_select = By.id("turnoverCategory");
	//STORE INFORMATION
	public static By storeType_web_btn = By.id("strWeb");
	public static By storeInfo_Channel_webpos = By.id("WBPOS");
	public static By feeType_select = By.id("feeType");
	public static By storeName_txt = By.id("mebussname");
	public static By legalName_txt = By.id("legalStrName");
	//BASIC DETAILS
	public static By basicDetails_lnk = By.xpath("//a[contains(@onclick,'viewBasicDetails')]");
	
	public static By LOR = By.id("lor");
	public static By panNo_txt = By.id("panNo");
	public static By category_select = By.id("segment");
	public static By awlMcc_select = By.id("awlmcc");
	public static By premisesType_select = By.id("premisesId");
	public static By vintageType_select = By.id("vintageId");
	public static By merchantBusinessType_select = By.id("constitutionId");
	public static By merchantWebUrl_txt = By.id("merUrl");
	public static By registrationDate_txt = By.id("regDate");
	public static By applicationNo_txt = By.id("applicationNo");
	public static By corpId_txt = By.id("corpId");
	public static By yearsInBusiness_txt = By.id("bussExp");
	public static By businessCompetitor_txt = By.id("bussCompet");
	public static By totalShops_txt = By.id("totShop");
	public static By avgTicketSize_select = By.id("ticketSizeId");
	public static By defineBusinessMature_radiobutton = By.xpath("//input[@value='M']");
	//STORE ADDRESS
	public static By address1_txt = By.id("stAdd1");
	public static By address2_txt = By.id("stAdd2");
	public static By address3_txt = By.id("stAdd3");
	public static By country_select = By.id("stCountry");
	public static By state_select = By.id("stState");
	public static By city_select = By.id("stCity");
	public static By locationId_select = By.id("locationId");
	public static By region_select = By.id("regionId");
	public static By subregion_select = By.id("subRegionId");
	public static By zipCode_txt = By.id("stPincode");
	
	//CONTACT PERSON DETAILS
	public static By fullName_txt = By.id("cntName");
	public static By phone_txt = By.id("cntPhone");
	public static By mobile_txt = By.id("cntMobile");
	public static By fax_txt = By.id("cntFax");
	public static By emailId_txt = By.id("cntEmail");
	
	public static By Title = By.id("cntTitle");
	
	
	//BILLING ADDRESS DETAILS
	public static By billingAddress_Same_checkbox = By.id("copyAdd");
	public static By billingAddress1_txt = By.id("billingAddress1");
	public static By billingAddress2_txt = By.id("billingAddress2");
	public static By billingAddress3_txt = By.id("billingAddress3");
	public static By billingCountry_select = By.id("billingCountry");
	public static By billingState_select = By.id("billingState");
	public static By billingCity_select = By.id("billingCity");
	public static By billingPhone1_txt = By.id("billingPhone1");
	public static By billingMobile_txt = By.id("billingPhone2");
	public static By billingFax_txt = By.id("billingFax");
	public static By billingZipcode_txt = By.id("billingPincode");
	
	//RELATIONSHIP MANAGER DETAILS
	public static By rmName_select = By.id("rm_name");
	public static By rmMobile_txt = By.id("rm_mobilenumber");
	public static By rmEmailId_txt = By.id("rm_emailid");
	//MISCELLANEOUS DETAILS
	public static By holdPayment_checkbox = By.id("holdPayFlagId");
	public static By partialSettlement_checkbox = By.id("partialFlag");
	public static By settlementAgainstDelivery_chk = By.id("settleAgdelFlag");
	public static By agreementDate_txt = By.id("agreementDate");
	public static By agreementExpiryDate_txt = By.id("agreementExpiryDate");
	public static By agreementNo_txt = By.id("agreementNo");
	public static By merchantClassification_select = By.id("merchant_classification");
	public static By merchantSegment_select = By.id("meSegment");
	public static By branchOffDesg_txt = By.id("branch_official_desg");
	public static By branchOffMobile_txt = By.id("branch_official_mobile");
	public static By branchOffName_txt = By.id("branch_official_name");
	public static By branchSolId_txt = By.id("branch_sol_id");
	public static By branchStaffName_txt = By.id("branch_staff_name");
	public static By branchStaffPfi_txt = By.id("branch_staff_pfi");
	public static By branchStaffSv_txt = By.id("branch_staff_sv");
	//CHEQUE DETAILS
	public static By chequeNo_txt = By.id("chqno");
	public static By chqDate_txt = By.id("chqDate");
	public static By chqDate_Now_btn = By.xpath("//button[contains(@data-handler,'today')]");
	public static By chqDate_Done_btn = By.xpath("//button[contains(text(),'Done')]");
	public static By chqAmount_txt = By.id("chqAmt");
	public static By chqRemarks_txt = By.id("chqReamrks");
	//SUBMIT
	public static By saveButton_txt = By.id("submitBtn");
	public static By successAlert_msg = By.xpath("//div[contains(text(),'Store added successfully')]");
	public static By viewStore_lnk = By.xpath("//a[contains(@onclick,'opsAppList')]");
	public static By viewStoreForApproval_lnk = By.xpath("//a[@class='viewStore']");
	public static By viewBusinStore_lnk = By.xpath("//a[contains(@onclick, 'busAppList')]");
	public static By viewFinAppList_lnk = By.xpath("//a[contains(@onclick, 'finAppList')]");
	
	public static By viewStoreForRiskApproval_lnk = By.xpath("//a[contains(@onclick, 'riskAppList')]");
	public static By actionSelect = By.id("select11");
	public static By businessApprovActionSelect = By.id("select12");
	public static By riskApprovActionSelect = By.id("select13");
	
	//Risk Approval Page
	public static By riskApprovalDailyTransCount_txt = By.id("dailyTransCnt");
	public static By riskApprovalDailyTransAmt_txt = By.id("dailyTransAmt");
	public static By riskApprovalPerTransLimit_txt = By.id("perTranLimit");
	
	public static By financeApprovActionSelect = By.id("select15");
	
	public static By remark_txtarea = By.xpath("//textarea[contains(@id, 'remark')]");
	public static By submit_btn = By.id("submit11");
	public static By businessApproval_submit_btn = By.id("submit12");
	public static By riskApproval_submit_btn = By.id("submit13");
	public static By financeApproval_submit_btn = By.id("submit15");
	
	
	public static By approvalSuccess_msg = By.xpath("//div[contains(@class,'alert alert-success')]");
	public static By sendForApproval_btn = By.xpath("//button[contains(text(),'Send For Approval')]");
	
	//GROUP DETAILS
	public static By groupDetails_lnk = By.xpath("//a[contains(@onclick,'getGroupDetails')]/span");
	public static By groupName_txt = By.id("meName");
	public static By contactName_txt = By.id("cntName");
	public static By contactAdd1_txt = By.id("cntAdd1");
	public static By contactAdd2_txt = By.id("cntAdd2");
	public static By contactAdd3_txt = By.id("cntAdd3");
	public static By contactCountry_select = By.id("cntCountry");
	public static By contactState_select = By.id("cntState");
	public static By contactCity_select = By.id("cntCity");
	public static By contactZip_txt = By.id("cntPincode");
	public static By contactEmail_txt = By.id("cntEmail");
	public static By save_btn = By.id("saveBtn");
	
	public static By primaryOwnerFname_txt = By.id("prinOwner1fname");
	public static By primaryOwnerMname_txt = By.id("prinOwner1mname");
	public static By primaryOwnerLname_txt = By.id("prinOwner1lname");
	public static By primaryOwnerPhone_txt = By.id("prinOwner1Phone1");
	public static By primaryOwnerMobile_txt = By.id("prinOwner1Phone2");
	public static By primaryOwnerZipcode_txt = By.id("prinOwner1Pincode");
	public static By primaryOwnerAdd1_txt = By.id("prinOwner1Address1");
	public static By primaryOwnerAdd2_txt = By.id("prinOwner1Address2");
	public static By primaryOwnerFax_txt = By.id("prinOwner1Fax");
	
	public static By secondaryOwnerFname_txt = By.id("prinOwner2fname");
	public static By secondaryOwnerMname_txt = By.id("prinOwner2mname");
	public static By secondaryOwnerLname_txt = By.id("prinOwner2lname");
	public static By secondaryOwnerPhone_txt = By.id("prinOwner2Phone1");
	public static By secondaryOwnerMobile_txt = By.id("prinOwner2Phone2");
	public static By secondaryOwnerZipcode_txt = By.id("prinOwner2Pincode");
	public static By secondaryOwnerAdd1_txt = By.id("prinOwner2Address1");
	public static By secondaryOwnerAdd2_txt = By.id("prinOwner2Address2");
	public static By secondaryOwnerFax_txt = By.id("prinOwner2Fax");
	
	//WEBSITE SUMMARY
	
	public static By websiteSummary_lnk = By.xpath("//a[contains(@onclick,'getPaymentSummary')]/span");
	public static By corBussName_txt = By.id("corBussName");
	public static By corOwner_txt = By.id("corOwner");
	public static By busModel_txt = By.id("busModel");
	public static By goodsServiceOff_txt = By.id("goodsServiceOff");
	public static By rtReFrPCanPol_txt = By.id("rtReFrPCanPol");
	public static By srvcNo_txt = By.id("srvcNo");
	public static By trnCurr_txt = By.id("trnCurr");
	public static By delPol_txt = By.id("delPol");
	public static By dataPrivPol_txt = By.id("dataPrivPol");
	public static By recTrnDet_txt = By.id("recTrnDet");
	public static By shpCostDet_txt = By.id("shpCostDet");
	public static By secMethod_txt = By.id("secMethod");
	
	public static By briefSummary_txt = By.id("breifSummary");
	
	public static By intCard_txt = By.id("intCard");
	public static By ipgPayVol_txt = By.id("ipgPayVol");
	public static By phyOrderVol_txt = By.id("phyOrderVol");
	public static By posCcVol_txt = By.id("posCcVol");
	public static By posDcVol_txt = By.id("posDcVol");
	public static By b2bVol_txt = By.id("b2bVol");
	public static By b2cVol_txt = By.id("b2cVol");
	public static By onlinePayment_Yes_btn = By.xpath("//input[contains(@value,'Y') and contains(@name,'onlinePayFlag')]");
	public static By gatewayName_txt = By.id("gatewayName");
	public static By procusedMnths_select = By.id("procusedMnths");
	public static By annualTurnOver_txt = By.id("annualTurnOver");
	public static By offLineTurnOver_txt = By.id("offLineTurnOver");
	public static By minTcktSize_txt = By.id("minTcktSize");
	public static By maxTcktSize_txt = By.id("maxTcktSize");
	public static By delper1_txt = By.id("delper1");
	public static By delper2_txt = By.id("delper2");
	public static By delper3_txt = By.id("delper3");
	public static By delper4_txt = By.id("delper4");
	public static By delper5_txt = By.id("delper5");
	public static By riskCheck_txt = By.id("riskCheck");
	public static By turnAroundTime_txt = By.id("turnAroundTime");
	public static By diwali_chkbox = By.xpath("//input[@placeholder='Diwali' and @id='D']");
	public static By christmas_chkbox = By.xpath("//input[@placeholder='Diwali' and @id='C']");
	public static By easter_chkbox = By.xpath("//input[@placeholder='Diwali' and @id='E']");
	public static By summerSale_chkbox = By.xpath("//input[@placeholder='Diwali' and @id='S']");
	
	
	public static By transactionTnC_Yes_btn = By.xpath("//input[contains(@name,'trmConFlag') and contains(@value,'Y')]");
	public static By websiteCond_Yes_btn = By.xpath("//input[contains(@name,'engnPolFlag') and contains(@value,'Y')]");
	
	public static By onlinePayment_No_btn = By.xpath("//input[contains(@value,'N') and contains(@name,'onlinePayFlag')]");
	public static By depositFlag_No_btn = By.xpath("//input[contains(@value,'N') and contains(@name,'depoFlag')]");
	public static By depositFlag_Yes_btn = By.xpath("//input[contains(@value,'Y') and contains(@name,'depoFlag')]");
	public static By autoRenewalFlag_Yes_btn = By.xpath("//input[contains(@value,'Y') and contains(@name,'autoRenWalFlag')]");
	public static By autoRenewalFlag_No_btn = By.xpath("//input[contains(@value,'N') and contains(@name,'autoRenWalFlag')]");
	public static By refundPolicy_Full_btn = By.xpath("//input[contains(@name,'refundPolicy') and contains(@value,'F')]");
	public static By refundPolicy_Exchange_btn = By.xpath("//input[contains(@name,'refundPolicy') and contains(@value,'E')]");
	public static By refundPolicy_No_btn = By.xpath("//input[contains(@name,'refundPolicy') and contains(@value,'N')]");
	
	public static By refundProcDays_3_btn = By.xpath("//input[contains(@value,'3') and contains(@name,'refundProcDays')]");
	public static By refundProcDays_4_btn = By.xpath("//input[contains(@value,'4') and contains(@name,'refundProcDays')]");
	public static By refundProcDays_8_btn = By.xpath("//input[contains(@value,'14') and contains(@name,'refundProcDays')]");
	public static By refundProcDays_15_btn = By.xpath("//input[contains(@value,'15') and contains(@name,'refundProcDays')]");
	
	public static By mailConfirmationFlag_Yes_btn = By.xpath("//input[contains(@value,'Y') and contains(@name,'mailConFlag')]");
	public static By mailConfirmationFlag_No_btn = By.xpath("//input[contains(@value,'N') and contains(@name,'mailConFlag')]");
	
	public static By chargebackVol_txt = By.xpath("//table[@id='example']/tbody/tr[1]/td[2]/input");
	public static By numberOfRefunds_txt = By.xpath("//table[@id='example']/tbody/tr[2]/td[2]/input");
	public static By numberOfTxns_txt = By.xpath("//table[@id='example']/tbody/tr[3]/td[2]/input");
	public static By refundVol_txt = By.xpath("//table[@id='example']/tbody/tr[4]/td[2]/input");
	public static By salesVol_txt = By.xpath("//table[@id='example']/tbody/tr[5]/td[2]/input");
	public static By saveWebSummary_btn = By.id("submitBtn");
	
	//ADD ACQUIRING BANK
	public static By acquiringBank_lnk = By.xpath("//a[contains(@onclick,'getAcqbnkList')]/span");
	public static By addNewAcqBank_btn = By.id("addNewMerchant");
	public static By legalVehicleName_select = By.id("lvehicleId");
	public static By acqBankName_select = By.id("merBankName");
	public static By acqBankZone_select = By.id("zoneId");
	public static By acqBranch_select = By.id("BranchId");
	
	//Merch Account Details
	public static By merchAccNo_txt = By.id("merAccNo");
	public static By accOpenDate_txt = By.id("accOpenDate");
	public static By merchBankName_txt = By.id("meBnkName");
	public static By meBankState_select = By.id("merBankState");
	public static By meBankCity_select = By.id("merBankCity");
	public static By meAccPhone_txt = By.id("merBankPhone1");
	public static By meAccMobile_txt = By.id("merBankPhone2");
	public static By meAccAddress1_txt = By.id("merBranchAdd1");
	public static By meAccAddress2_txt = By.id("merBranchAdd2");
	
	//fee setup
	public static By oneTimeFixedFee_txt = By.id("oneTimeFee");
	public static By statementFee_txt = By.id("stmtFee");
	public static By terminalFee_txt = By.id("terminalFee");		
	public static By minimumUsage_txt = By.id("minUseFeeDays");		
	public static By minTransAmt_txt = By.id("minTrnAmt");
	public static By minUsageFee_txt = By.id("minUseFee");
	public static By amcType_select = By.id("amcFeeType");
	public static By amcAmount_txt = By.id("amcFee");
	public static By nonUsage_txt = By.id("nonUseFeeDays");
	public static By nonUsageFee_txt = By.id("nonUseFee");
	public static By securityAmt_txt = By.id("secuAmt");
	//Settlement Setup
	public static By settlementTypeManual_btn = By.id("settleType1");
	public static By settlementTypeAuto_btn = By.id("settleType2");
	public static By settleCycle_select = By.id("settleCycle");
	public static By paymentBy_select = By.id("paymentBy");
	public static By paymentAdvice_select = By.id("payment_Advice");
	//suresh
	public static By NodalAccount_select = By.id("nodal_Account_Id");
	//Beneficiary Account Details
	public static By benAccName_txt = By.id("beneficiary_AccountName");
	public static By benAccNo_txt = By.id("beneficiary_AccountNumber");
	public static By benBankCode_txt = By.id("beneficiary_BankCode");
	public static By benBankName_txt = By.id("beneficiary_BankName");
	public static By benBranchName_txt = By.id("beneficiary_BranchName");
	public static By benBranchCode_txt = By.id("beneficiary_BranchCode");
	public static By benIfscCode_txt = By.id("beneficiary_IfscCode");
	//Miscellaneous
	public static By dailyTransLimit_txt = By.id("daily_Tran_Limit");
	public static By firc_no_radio = By.xpath("//input[@name='firc' and @value='N']");
	public static By firc_yes_radio = By.xpath("//input[@name='firc' and @value='Y']");
	public static By applicationMode_select = By.id("applicationMode");
	public static By transactionMode_select = By.id("transactionMode");
	public static By fircFrequency_select = By.id("fircFrequency");
	public static By fuelAssociation_select = By.id("fuel_Association");
	public static By fuelRemarks_txt = By.id("fuel_Remarks");
	public static By callCharges_txt = By.id("callCharges");
	public static By secretKey_txt = By.id("secretKey");
	public static By documentRequired_Yes_btn = By.xpath("//input[@name='docRequire' and @value='Y']");
	public static By documentRequired_No_btn = By.xpath("//input[@name='docRequire' and @value='N']");
	public static By documentPending_Yes_btn = By.xpath("//input[@name='documentPending' and @value='Y']");
	public static By documentPending_No_btn = By.xpath("//input[@name='documentPending' and @value='N']");
	public static By merchantReimbursement_txt = By.id("merchantReimbursement");
	public static By customerId_txt = By.id("customerId");
	
	
	//MID Setup
	public static By merchIdType_select = By.id("mIdType");
	public static By currency_select = By.id("currencyCode");
	public static By mid_txt = By.id("mId");
	public static By tid_txt = By.id("tId");
	public static By add_btn = By.id("addProduct");
	public static By amexMaId_txt = By.id("amexMaId");
	public static By amexMaPwd_txt = By.id("amexMaPassword");
	public static By amexAmaId_txt = By.id("amexAmaId");
	public static By amexAmaPassword_txt = By.id("amexAmaPassword");
	public static By amexAccessCode_txt = By.id("amexAccessCode");
	public static By amexSecureSecret_txt = By.id("amexSecureSecret");
	
	//PCPOS
	public static By tccDescriptor_select = By.id("tccDescriptor");
	public static By projectedAvgTicketSize_txt = By.id("projectedAvgTicketSize");
	public static By nwPaymentAdvice_Yes = By.xpath("//input[@id='nwPaymentAdvice' and @value='Y']");
	public static By nwPaymentAdvice_No = By.xpath("//input[@id='nwPaymentAdvice' and @value='N']");
	public static By rental_yes = By.xpath("//input[@name='rental' and @value='Y']");
	public static By rental_no = By.xpath("//input[@name='rental' and @value='N']");
	public static By rentalFrequency_select = By.id("rentalFreq");
	public static By advRent_yes = By.xpath("//input[@name='advRent' and @value='Y']");
	public static By advRent_no = By.xpath("//input[@name='advRent' and @value='N']");
	public static By advRentalFrequency_txt = By.id("advfreqRental");
	public static By advRentalAmt_txt = By.id("advanceRental");
	public static By advSetup_yes = By.xpath("//input[@name='advSetup' and @value='Y']");
	public static By advSetup_no = By.xpath("//input[@name='advSetup' and @value='N']");
	public static By advSetupFee_txt = By.id("advStupFee");
	public static By msfIncentive_txt = By.id("msf_Incentive");
	public static By merchIncentive_txt = By.id("merc_Incentive");
	public static By tipPercent_txt = By.id("tipPercent");
	public static By cashPos_yes = By.xpath("//input[@id='cashBackOnly' and @value='Y']");
	public static By cashPos_no = By.xpath("//input[@id='cashBackOnly' and @value='N']");
	public static By cashBackPur_yes = By.xpath("//input[@id='cashBackPur' and @value='Y']");
	public static By cashBackPur_no = By.xpath("//input[@id='cashBackPur' and @value='N']");
	
	//Payment Type
	public static By paymentType_lnk = By.xpath("//a[contains(@onclick,'getPaymentType')]/span");
	public static By payTypeCreditCard_chkbox = By.id("creditbox");
	public static By payTypeCreditCardDomestic_chkbox = By.id("checkbox1");
	public static By payTypeCreditCardInternational_chkbox = By.id("checkbox2");
	public static By masterCardDomestic_chk = By.xpath("//td[contains(text(),'MASTERCARD')]/..//input[@id='checkbox1']");
	public static By masterCardInternational_chk = By.xpath("//td[contains(text(),'MASTERCARD')]/..//input[@id='checkbox2']");
	public static By rupayCardDomestic_chk = By.xpath("//td[contains(text(),'RUPAY')]/..//input[@id='checkbox1']");
	public static By rupayCardInternational_chk = By.xpath("//td[contains(text(),'RUPAY')]/..//input[@id='checkbox2']");
	
	public static By visaDomestic_chk = By.xpath("//td[contains(text(),'VISA')]/..//input[@id='checkbox1']");
	public static By visaInternational_chk = By.xpath("//td[contains(text(),'VISA')]/..//input[@id='checkbox2']");
	public static By debitCard_chk = By.id("debitbox");
	public static By mastDbDom_chk = By.xpath("//td[@code='MAST']/..//input[@id='checkbox3']");
	public static By mastDbInt_chk = By.xpath("//td[@code='MAST']/..//input[@id='checkbox4']");
	public static By rupayDbDom_chk = By.xpath("//td[@code='RUPY']/..//input[@id='checkbox3']");
	public static By rupayDbInt_chk = By.xpath("//td[@code='RUPY']/..//input[@id='checkbox4']");
	public static By visaDbDom_chk = By.xpath("//td[@code='VISA']/..//input[@id='checkbox3']");
	public static By visaDbInt_chk = By.xpath("//td[@code='VISA']/..//input[@id='checkbox4']");
	
	public static By netbank_chk = By.id("netbankbox");
	public static By internetBankLv_select = By.id("lvId");
	public static By internetBankSelectBank_select = By.id("netbankselect");
	public static By internetBankEffDate_txt = By.id("effDate");
	public static By internetBankStatus_select = By.id("netbankstatus");
	public static By internetBankSortOrder_txt = By.id("sortorder");
	public static By internetBankAccId_txt = By.id("nbmeSpecificId");
	public static By internetBankSecretKey_txt = By.id("secretKey");
	public static By internetBankTransLimit_txt = By.id("perTransLimit");
	public static By internetBankAddNetbank_btn = By.id("netbnkBtn");
	public static By internetBankRemove_btn = By.xpath("//td[@class='removeTag']");
	
	public static By cugFlag_chk = By.id("cugFlag");
	public static By cugFromBin_txt = By.id("frmBinNo");
	public static By cugToBin_txt = By.id("toBinNo");
	
	/*public static By impsFlag_chk = By.id("impsbox");
	public static By impsMmid_txt = By.id("mmid");
	public static By impsMobileNo_txt = By.id("mobileNumber");*/
	
	public static By ipgRefund_chk = By.xpath("//input[@id='refund1']");
	public static By ipgCancel_chk = By.id("cancel1");
	public static By ipgRecPayUpload_chk = By.id("uplRecurPay");
	public static By ipgRecPayOnline_chk = By.id("recurPay");
	public static By ipgPreauth_chk = By.id("preAuth");
	public static By ipgHostPages_chk = By.id("meHost");
	public static By ipgEmailInvoice_chk = By.id("emailInvFlag");
	public static By ipgSmsInvoice_chk = By.id("emailInvFlag");
	
	
	//MSF/Convenience
	public static By msfConvenience_lnk = By.xpath("//a[contains(@onclick,'getMSFDetails')]/span");
	public static By msfAcqBankName_select = By.xpath("//select[contains(@id,'cqBank')]");
	public static By msfMidCc_select = By.id("merchantId");
	public static By msfSchemeCc_select = By.id("ccSchemeId");
	public static By slabUpto_txt = By.xpath("//input[contains(@id,'SlabUpto')]");
	public static By effectiveFrom = By.xpath("//input[contains(@id,'effFrom')]");
	public static By currentDay = By.xpath("//td[contains(@class,'datepicker-today')]/a");
	public static By datepicker_done_btn = By.xpath("//button[contains(@class,'datepicker-close') and contains(text(),'Done')]");
	public static By internationalFixed_txt = By.xpath("//input[contains(@id,'InfiXAmt')]");
	public static By internationalPer_txt = By.xpath("//input[contains(@id,'InPer')]");
	public static By DomesticOnusFixed_txt = By.xpath("//input[contains(@id,'DmFiXAmt_Onus')]");
	public static By DomesticOnusPer_txt = By.xpath("//input[contains(@id,'DmPer_Onus')]");
	public static By ccDomesticOffusFixed_txt = By.id("ccDmFiXAmt_Offus");
	public static By dcDomesticOffusFixed_txt = By.id("dcDmFiXAmt_Offus");	
	public static By DomesticOffusPer_txt = By.xpath("//input[contains(@id,'DmPer_Offus')]");
	public static By ccChargeType_select = By.id("ccChargeType");
	
	public static By ccmanageBSF_select = By.id("ccBsfType");
	public static By ccselectCategory = By.id("ccSegment");
	
	//==============================================================BSF Changes=============
	public static By slabUpto_txt_bsf = By.xpath(".//*[@id='ccBsfSlabUpto']");
	//public static By effectiveFrom_bsf = By.xpath("//input[contains(@id,'effFrom')]");
	//public static By currentDay_bsf = By.xpath("//td[contains(@class,'datepicker-today')]/a");
	//public static By datepicker_done_btn_bsf = By.xpath("//button[contains(@class,'datepicker-close') and contains(text(),'Done')]");
	//public static By internationalFixed_txt_bsf = By.xpath("//input[contains(@id,'InfiXAmt')]");
	//public static By internationalPer_txt_bsf = By.xpath("//input[contains(@id,'InPer')]");
	//public static By DomesticOnusFixed_txt_bsf = By.xpath("//input[contains(@id,'DmFiXAmt_Onus')]");
	//public static By DomesticOnusPer_txt_bsf = By.xpath("//input[contains(@id,'DmPer_Onus')]");
	public static By ccDomesticOffusFixed_txt_bsf = By.id("ccBsfDmFixAmt_Offus");
	//public static By dcDomesticOffusFixed_txt_bsf = By.id("ccBsfDmPer_Offus");	
	public static By DomesticOffusPer_txt_bsf = By.id("ccBsfDmPer_Offus");
	public static By ccChargeType_select_bsf = By.id("ccBsfChargeType");
	
	//==============================================================BSF Changes=============
	
	
	public static By addNew_btn = By.xpath("//button[contains(@id,'CDetails')]");
	public static By msfRemove_lnk = By.xpath("//td[@class='removeTag']");
	public static By saveMsf_btn = By.id("creditSaveBtn");
	
	public static By debitTab_btn = By.id("actDebit");
	
	public static By intBank_Tab = By.id("intBank");
	public static By intBank_bankName_select = By.xpath("//div[@id='int_banking']//select[@id='ibBank']");
	public static By intBank_slabUpto_txt = By.xpath("//div[@id='int_banking']//input[@id='ibSlabUpto']");
	public static By intBank_fixed_txt = By.xpath("//div[@id='int_banking']//input[@id='ibFixed']");
	public static By intBank_Percent_txt = By.xpath("//div[@id='int_banking']//input[@id='ibPercent']");
	public static By intBank_effFrom_txt = By.xpath("//div[@id='int_banking']//input[@id='ibEffFrom']");
	public static By intBank_effTo_txt = By.xpath("//div[@id='int_banking']//input[@id='ibEffTo']");
	public static By intBank_chargeType_select = By.xpath("//div[@id='int_banking']//select[@id='ibchargeType']");
	public static By intBank_addNew_btn = By.id("addIBDetails");
	public static By intBank_Remove_lnk = By.xpath("//div[@id='int_banking']//td[@class='removeTag']");
	public static By intBank_Save_btn = By.id("ibSaveBtn");
	
	//==================================BSF DEBIT===============================
	
	
	//==========================================================================
	
	//Debit Card
	public static By dcMsfAcqBankName_select = By.id("dcAcqBank");
	public static By dcMsfMid_select = By.id("dcMerchantId");
	public static By dcMsfScheme_select = By.id("dcSchemeId");
	public static By dcSlabUpto_txt = By.id("dcSlabUpto");
	public static By dcEffectiveFrom = By.id("dcEffFrom");
	//public static By dcCurrentDay = By.id("//td[contains(@class,'datepicker-today')]/a");
	//public static By dcDatepicker_done_btn = By.xpath("//button[contains(@class,'datepicker-close') and contains(text(),'Done')]");
	public static By dcInternationalFixed_txt = By.id("dcInfiXAmt");
	public static By dcInternationalPer_txt = By.id("dcInPer");
	public static By dcDomesticOnusFixed_txt = By.id("dcDmFiXAmt_Onus");
	public static By dcDomesticOnusPer_txt = By.id("dcDmPer_Onus");
	public static By dcDomesticOffusPer_txt = By.id("dcDmPer_Offus");
	public static By dcChargeType_select = By.id("dcchargeType");
	
	public static By dcmanageBSF_select = By.id("ccBsfType");
	
	
	public static By dcAddNew_btn = By.id("addDCDetails");
	public static By dcMsfRemove_lnk = By.xpath("//td[@class='removeTag']");
	public static By dbSaveMsf_btn = By.id("debitSaveBtn");
	
	//cug
	public static By cugTab = By.id("actCug");
	public static By cugBank_Select = By.id("cugBank");
	public static By cugSlabUpto_txt = By.id("cugSlabUpto");
	public static By cugFixed_txt = By.id("cugFixed");
	public static By cugPercent_txt = By.id("cugPercent");
	public static By cugEffFrom_txt = By.id("cugEffFrom");
	public static By cugchargeType_select = By.id("cugchargeType");
	
	public static By manageBSF_select = By.id("ccBsfType");
	
	public static By addCUGDetails_btn = By.id("addCUGDetails");
	public static By cug_Remove_lnk = By.xpath("//div[@id='cug']//td[@class='removeTag']");
	public static By cugSaveBtn_btn = By.id("cugSaveBtn");
	
	//IMPS
	/*public static By impsTab = By.id("actImps");
	public static By impsSlabUpto_txt = By.id("impsSlabUpto");
	public static By impsFixed_txt = By.id("impsFixed");
	public static By impsPercent_txt = By.id("impsPercent");
	public static By impsEffFrom_txt = By.id("impsEffFrom");
	public static By impsChargeType_select = By.id("impschargeType");
	public static By addIMPSDetails_btn = By.id("addIMPSDetails");
	public static By imps_Remove_lnk = By.xpath("//div[@id='imps']//td[@class='removeTag']");
	public static By impsSaveBtn_btn = By.id("impsSaveBtn");*/
	
	//ACQUIRING RULE
	public static By acqRule_lnk = By.xpath("//a[contains(@onclick,'getAcqBnkRule')]/span");
	public static By lv_select = By.id("lvId");
	public static By acqBank_select = By.id("acqBankId");
	public static By payType_select = By.id("payTypeId");
	public static By priority_select = By.id("priority");
	public static By addAcqBankRule_btn = By.id("add");
	
	//BLACKLIST WHITELIST
	public static By blackList_lnk = By.xpath("//a[contains(@onclick,'getBlackList')]/span");
	public static By listType_select = By.id("listTypeId");
	public static By blackListSchemeName_select = By.id("schemeIdBL");
	public static By fromBinBL_txt = By.id("fromBinBL");
	public static By toBinBL_txt = By.id("toBinBL");
	public static By addButtonBL_btn = By.id("addButton");
	public static By blackList_removeTag_lnk = By.xpath("//td[@class='removeTag']");
	
	//CHECKLIST
	public static By checkList_lnk = By.xpath("//a[contains(@onclick,'getCheckList')]/span");
	public static By relation_btn = By.xpath("//input[@name='relationFlag' and @value='N']");
	public static By paymentHold_btn = By.xpath("//input[@name='payHoldOverChk' and @value='Y']");
	public static By msfchk_btn = By.xpath("//input[@name='msfChk' and @value='N']");
	public static By crossBorderTransChk_btn = By.xpath("//input[@name='borderTranChk' and @value='N']");
	public static By dSecureChk_btn = By.xpath("//input[@name='dSecureChk' and @value='N']");
	public static By domUserTransLimit_txt = By.id("domTrnLimit");
	public static By secCrossBorderLimit_txt = By.id("intDomTrnLimit");
	public static By unsecuredTransLimit_txt = By.id("unSecTrnLimit");
	public static By chgBackRecoverInstant_btn = By.name("chgBckRecoverChk");
	public static By chgBackRecoverCryst_btn = By.xpath("//input[@name='chgBckRecoverChk' and @id='define2']");
	
	//merchant checklist
	public static By statement_status_Yes_btn = By.xpath("//td[@data-value='STATEMENT']/following-sibling::td//input[@value='Y']");
	public static By statement_status_No_btn = By.xpath("//td[@data-value='STATEMENT']/following-sibling::td//input[@value='N']");
	public static By statement_remarks_txt = By.xpath("//td[@data-value='STATEMENT']/following-sibling::td//input[@type='text']");
	public static By web_status_Yes_btn = By.xpath("//td[@data-value='WEB']/following-sibling::td//input[@value='Y']");
	public static By web_status_No_btn = By.xpath("//td[@data-value='WEB']/following-sibling::td//input[@value='N']");
	public static By web_remarks_txt = By.xpath("//td[@data-value='WEB']/following-sibling::td//input[@type='text']");
	public static By rate_status_Yes_btn = By.xpath("//td[@data-value='RATE']/following-sibling::td//input[@value='Y']");
	public static By rate_status_No_btn = By.xpath("//td[@data-value='RATE']/following-sibling::td//input[@value='N']");
	public static By rate_remarks_txt = By.xpath("//td[@data-value='RATE']/following-sibling::td//input[@type='text']");
	public static By site_status_Yes_btn = By.xpath("//td[@data-value='SITE']/following-sibling::td//input[@value='Y']");
	public static By site_status_No_btn = By.xpath("//td[@data-value='SITE']/following-sibling::td//input[@value='N']");
	public static By site_remarks_txt = By.xpath("//td[@data-value='SITE']/following-sibling::td//input[@type='text']");
	public static By business_status_Yes_btn = By.xpath("//td[@data-value='BUSI']/following-sibling::td//input[@value='Y']");
	public static By business_status_No_btn = By.xpath("//td[@data-value='BUSI']/following-sibling::td//input[@value='N']");
	public static By business_remarks_txt = By.xpath("//td[@data-value='BUSI']/following-sibling::td//input[@type='text']");
	public static By mvc_status_Yes_btn = By.xpath("//td[@data-value='MVC']/following-sibling::td//input[@value='Y']");
	public static By mvc_status_No_btn = By.xpath("//td[@data-value='MVC']/following-sibling::td//input[@value='N']");
	public static By mvc_remarks_txt = By.xpath("//td[@data-value='MVC']/following-sibling::td//input[@type='text']");
	public static By kyc_status_Yes_btn = By.xpath("//td[@data-value='KYC']/following-sibling::td//input[@value='Y']");
	public static By kyc_status_No_btn = By.xpath("//td[@data-value='KYC']/following-sibling::td//input[@value='N']");
	public static By kyc_remarks_txt = By.xpath("//td[@data-value='KYC']/following-sibling::td//input[@type='text']");
	
	//MERCHANT RATING
	public static By merchantRating_lnk = By.xpath("//a[contains(@onclick,'getMerchRatingForm')]");
	public static By mcRateLoc_select = By.id("rateLocationId");
	public static By mcRateFinancial_select = By.id("financialId");
	public static By mcRateMcCategory_select = By.id("merchantCatId");
	public static By mcRateDelTimeLine_select = By.id("deliveryTimeLineId");
	public static By mcRateMcOpsId_select = By.id("merchantOpsId");
	public static By mcRateWebSecId_select = By.id("webSecurityId");
	public static By vmts_Verified_btn = By.xpath("//input[@name='visa_Verification' and @value='V']");
	public static By vmts_Rejected_btn = By.xpath("//input[@name='visa_Verification' and @value='R']");
	public static By vmts_NotVerified_btn = By.xpath("//input[@name='visa_Verification' and @value='N']");
	public static By match_Verified_btn = By.xpath("//input[@name='master_Verification' and @value='V']");
	public static By match_Rejected_btn = By.xpath("//input[@name='master_Verification' and @value='R']");
	public static By match_NotVerified_btn = By.xpath("//input[@name='master_Verification' and @value='N']");
	public static By cibil_Verified_btn = By.xpath("//input[@name='cibilFlag' and @value='V']");
	public static By cibil_Rejected_btn = By.xpath("//input[@name='cibilFlag' and @value='R']");
	public static By cibil_NotVerified_btn = By.xpath("//input[@name='cibilFlag' and @value='N']");
	public static By merchRating_vmts_chk = By.xpath("//input[@type='checkbox' and @name='vmts']");
	public static By merchRating_match_chk = By.xpath("//input[@type='checkbox' and @name='match']");
	public static By merchRating_postFacto_chk = By.xpath("//input[@type='checkbox' and @name='post_Facto']");
	public static By merchRating_waiver_chk = By.xpath("//input[@type='checkbox' and @name='waiver']");
	public static By merchRatingEnterRemark_txt = By.id("waiverRmRk");
	
	//UPLOAD DOCUMENTS
	public static By uploadDocument_lnk = By.xpath("//a[contains(@onclick,'getMerchantDocuments')]/span");
	public static By validLicense_No_btn = By.xpath("//input[@name='verflag1' and @value='N']");
	public static By validLicense_Yes_btn = By.xpath("//input[@name='verflag1' and @value='Y']");
	public static By validLicenseRemarks_txt = By.id("rem0");
	public static By copyOfPan_No_btn = By.xpath("//input[@name='verflag2' and @value='N']");
	public static By copyOfPan_Yes_btn = By.xpath("//input[@name='verflag2' and @value='Y']");
	public static By copyOfPanRemarks_txt = By.id("rem1");
	public static By addressProof_No_btn = By.xpath("//input[@name='verflag3' and @value='N']");
	public static By addressProof_Yes_btn = By.xpath("//input[@name='verflag3' and @value='Y']");
	public static By addressProofRemarks_btn = By.id("rem2");
	public static By incomeTax_Yes_btn = By.xpath("//input[@name='verflag4' and @value='Y']");
	public static By incomeTax_No_btn = By.xpath("//input[@name='verflag4' and @value='N']");
	public static By incomeTaxRemarks_txt = By.id("rem3");
	public static By stmtOfAcc_Yes_btn = By.xpath("//input[@name='verflag5' and @value='Y']");
	public static By stmtOfAcc_No_btn = By.xpath("//input[@name='verflag5' and @value='N']");
	public static By stmtOfAccRemarks_txt = By.id("rem4");
	public static By cancelChq_Yes_btn = By.xpath("//input[@name='verflag6' and @value='Y']");	
	public static By cancelChq_No_btn = By.xpath("//input[@name='verflag6' and @value='N']");
	public static By cancelChqRemarks_txt = By.id("rem5");
	public static By merchEstab_Yes_btn = By.xpath("//input[@name='verflag7' and @value='Y']");
	public static By merchEstab_No_btn = By.xpath("//input[@name='verflag7' and @value='N']");
	public static By merchEstabRemarks_txt = By.id("rem6");
	public static By copyOfLicense_Yes_btn = By.xpath("//input[@name='verflag8' and @value='Y']");
	public static By copyOfLicense_No_btn = By.xpath("//input[@name='verflag8' and @value='Y']");
	public static By copyOfLicenseRemarks_txt = By.id("rem7");
	public static By idProof_Yes_btn = By.xpath("//input[@name='verflag9' and @value='Y']");
	public static By idProof_No_btn = By.xpath("//input[@name='verflag9' and @value='Y']");
	public static By idProofRemarks_txt = By.id("rem8");
	
	public static By fileUploadSuccess_msg = By.xpath("//form[@id='merchantDocument']//div[contains(text(),'Files Successfully Uploaded')]");
	
	//URLs
	public static By urls_lnk = By.xpath("//a[contains(@onclick,'getMerchantUrls')]");
	public static By isWebAvailable_Yes_btn = By.xpath("//input[@name='webAval' and @value='Y']");
	public static By isWebAvailable_No_btn = By.xpath("//input[@name='webAval' and @value='N']");
	public static By merchWebSiteUrl_txt = By.id("webUrl");
	public static By privacyPolicy_txt = By.id("privPol");
	public static By cancelRefPolicy_txt = By.id("canRefPol");
	public static By termsCondPolicy_txt = By.id("terCondPol");
	public static By contactUsInfo_txt = By.id("contactUs");
	public static By faqUrl_txt = By.id("faqUrl");
	public static By oneProdUrl_txt = By.id("prodUrl");
	public static By aboutUs_txt = By.id("abtUs");
	public static By webManagedUrl_txt = By.id("webManageUrl");
	public static By comNameUrl_txt = By.id("comNameUrl");
	public static By outsourced_yes_btn = By.xpath("//input[@name='hostUrl' and @value='Y']");
	public static By outsourced_no_btn = By.xpath("//input[@name='hostUrl' and @value='N']");
	public static By solutionUrl_txt = By.id("solUrl");
	public static By ecommStrategy_txt = By.id("e_comUrl");
	public static By ecommTarget_Utility_chk = By.xpath("//input[@name='e_comValUrl' and @id='U']");
	public static By ecommTarget_Travel_chk = By.xpath("//input[@name='e_comValUrl' and @id='T']");
	public static By ecommTarget_Retail_chk = By.xpath("//input[@name='e_comValUrl' and @id='R']");
	public static By ecommTarget_Edu_chk = By.xpath("//input[@name='e_comValUrl' and @id='E']");
	public static By ecommTarget_Charity_chk = By.xpath("//input[@name='e_comValUrl' and @id='CS']");
	public static By ecommTarget_Hotels_chk = By.xpath("//input[@name='e_comValUrl' and @id='HMR']");
	public static By ecommTarget_Other_chk = By.xpath("//input[@name='e_comValUrl' and @id='O']");	
	public static By specifyUrl_txt = By.id("specifyUrl");
			
	
	//IPG
	public static By ipgTab_lnk = By.xpath("//a[contains(@onclick,'getIpgDetails')]");
	public static By eciVisa_txt = By.id("eciVisa");
	public static By eciMaster_txt = By.id("eciMaster");
	public static By eciMaestro_txt = By.id("eciMaestro");
	public static By pcIdss_txt = By.id("pcIdss");
	public static By pcIdssExpiryDate_txt = By.id("pcIdssExpiryDate");
	public static By ebsKey_txt = By.id("ebsKey");
	
	public static By integApp_select = By.id("meIntegApp");
	public static By mpiIntegration_select = By.id("mpiIntegration");
	public static By mpiKey_txt = By.id("mpiKey");
	public static By lyraCertificate_txt = By.id("lyraCertificate");
	public static By lyraShopId_txt = By.id("lyraShopId");
	public static By msfConvChkVal_txt = By.id("msfConvChkVal");
	public static By requestUrl1_txt = By.xpath("//form[@id='ipgForm']//input[@id='requestUrl1']");
	public static By requestUrl2_txt = By.xpath("//form[@id='ipgForm']//input[@id='requestUrl2']");
	public static By merchEmailConfirm_yes_btn = By.xpath("//input[@name='merchantEmailFlag' and @value='Y']");
	public static By merchEmailConfirm_no_btn = By.xpath("//input[@name='merchantEmailFlag' and @value='N']");
	
	//PCPOS
	public static By pcpos_lnk = By.xpath("//a[contains(@onclick,'getPcPos')]");
	public static By trainingSchedule_select = By.id("trainingSched");
	public static By seId_txt = By.id("seId");
	public static By seRemarks_txt = By.id("seIdRemarks");
	public static By ownership_select = By.id("ownership");
	public static By merchChargSlip = By.id("chrgSlipName");
	public static By pcposVersion_select = By.id("pcPosVersion");
	public static By promptFlag_No = By.xpath("//input[@name='dccPrompt' and @value='N']");
	public static By promptFlag_Yes = By.xpath("//input[@name='dccPrompt' and @value='Y']");
	public static By maxCash = By.id("maxCashBakAmt");
	public static By maxPreauthPer = By.id("maxPreAuth");
	public static By contentDisclaimer_txt = By.id("cntDisclmr");
	public static By instrumentDisclaimer_txt = By.id("instDisclmr");
	public static By programDisclaimer_txt = By.id("progDisclmr");
	public static By totalNoOfTerminal = By.id("noOfTerminals");
	public static By modelNo_select = By.id("modelId");
	public static By edcVersion_select = By.id("edcVersion");
	public static By noOfTerminals_txt = By.id("terminals");
	
	//MERCHANT VALIDATION
	public static By statusOnAcqBankList = By.xpath("//form[@id='acbBankList']//table[@id='example']//tr/td[8]");
	public static By viewLinkOnAcqBankList = By.xpath("//form[@id='acbBankList']//table[@id='example']//tr//a[contains(text(),'View')]");
	public static By acquiringBankVerification_lnk = By.xpath("//a[contains(@onclick,'viewAcquringbankList')]//span");
	public static By acqBankListPage = By.xpath("//table[@id='productTable']");
	public static By midOnAcqBankPage = By.xpath("//table[@id='productTable']//tr/td[3]");
	public static By tidOnAcqBankPage = By.xpath("//table[@id='productTable']//tr/td[4]");
	public static By cntTitle;
	public static By dateofbirth=By.id("cntdob");
	public static By ccselectCategory1=By.id("ccSegment");
	
}
