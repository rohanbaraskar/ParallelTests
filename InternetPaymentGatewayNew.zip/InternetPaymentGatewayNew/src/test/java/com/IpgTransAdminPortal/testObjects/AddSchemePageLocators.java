package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class AddSchemePageLocators {
	
	public static By schemeName = By.id("vSchemeName");
	public static By schemeCode = By.id("vSchemeCode");
	public static By ccSaleWithCashbackLimit = By.id("vCcMaxCashBakLimit");
	public static By dcSaleWithCashbackLimit = By.id("vDcMaxCashBakLimit");
	public static By dccDisclaimer = By.id("vDccDisclaimer");
	public static By schemeTypeCC_chk = By.id("vIsCredit");
	public static By schemeTypeDC_chk = By.id("vIsDebit");
	public static By schemeTypeCUG_chk = By.id("vIsCug");
	public static By schemeTypeLoyaltyC_chk = By.id("vIsLoyalty");
	public static By submit_btn = By.id("submit");
	public static By schemeSuccessMessage = By.xpath("//div[contains(@class,'alert alert-success')]");
	public static By editScheme_btn = By.xpath("//input[@id='editScheme']");
	public static By deactivateScheme_btn = By.xpath("//input[@id='actDeactScheme']");
	public static By schemeRegistration = By.xpath("//span[contains(text(),'Scheme Registration')]");
	public static By schemeInformation = By.xpath("//span[contains(text(),'Scheme Information')]");
	public static By approveSchemeSuccess_mg = By.xpath("//div[contains(@class,'alert alert-success')]");
	public static By approval_tab = By.xpath("//a[@class='schemeactive']/span[contains(text(),'Approval')]");
	public static By viewScheme_lnk = By.xpath("//a[@class='viewScheme']");
	public static By approval_submit_btn = By.xpath("//button[contains(text(),'Submit')]");
	
}
