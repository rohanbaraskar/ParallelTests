package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class AddManufacturerPageLocators {
	
	public static By manufactName_txt = By.id("manufactName");
	public static By manufactCode_txt = By.id("manufactCode");
	public static By prodName_txt = By.id("prodName");
	public static By emiProdCode_txt = By.id("emiProdCode");
	public static By itemCode_txt = By.id("itemCode");
	public static By add_btn = By.id("add");
	public static By submit_btn = By.id("addEditManu");
	public static By manufactSuccessful_mg = By.xpath("//div[contains(text(),'Manufucturer has been successfully created')]");
}
