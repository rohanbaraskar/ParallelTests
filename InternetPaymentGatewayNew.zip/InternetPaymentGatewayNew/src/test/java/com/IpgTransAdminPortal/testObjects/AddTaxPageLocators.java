package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class AddTaxPageLocators {
	
	public static By lv_select = By.id("vLvID");
	public static By taxCode_txt = By.id("vTAXCODE");
	public static By taxName_txt = By.id("vTAXNAME");
	public static By taxPercent_txt = By.id("vTAXPER");
	public static By effectFrom_txt = By.id("vEFFROM");
	public static By todayDate_txt = By.xpath("//td[contains(@class,'today')]/a");
	public static By submit_btn = By.xpath("//button[@type='submit']");
	public static By taxSuccess_msg = By.xpath("//div[contains(text(),'Tax has been successfully created')]");

}
