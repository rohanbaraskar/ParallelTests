package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class AddLegalVehiclePageLocators {
	
	public static By legalVehicleName_txt = By.id("lvName");
	public static By legalVehicleCode_txt = By.id("lvCode");
	public static By legalVehicleType_select = By.id("lvType");
	public static By channelsAvailableIPG_chk = By.id("IPG");
	public static By channelsAvailablePCPOS_chk = By.id("PC POS");
	public static By vehicleSchemeMappingChannel_select = By.id("chnName");
	public static By vehicleSchemeMappingScheme_select = By.id("schemeId");
	public static By vehicleSchemeMappingAdd_btn = By.id("add1");
	public static By vehiclePaymentMappingChannel_select = By.id("PaymentChnName");
	public static By vehiclePaymentMappingPayType_select = By.id("payTypeId");
	public static By vehiclePayMappingAdd_btn = By.id("add2");
	public static By prodTypeRecurrPayUpload_chk = By.id("uplRecurPayFlag1");
	public static By prodTypePreAuth_chk = By.id("preauthFlag1");
	public static By emailInvoice_chk = By.id("emailInvFlag1");
	public static By recurrPayOnline_chk = By.id("recurPayflag1");
	public static By hostedPages_chk = By.id("meHostFlag1");
	public static By smsInvoice_chk = By.id("smsInvFlag1");	
	public static By submit_btn = By.id("submit");
	public static By addVehicleSuccess_msg = By.xpath("//div[contains(@class,'alert alert-success')]");
	public static By approval_tab = By.xpath("//a[contains(@data-value,'getPendingLegalVehicleList')]/span");
	public static By viewLegalVehicle_lnk = By.xpath("//a[@class='viewLegalVehicle']");
	public static By legalVehicleInfoScreen_lbl = By.xpath("//span[contains(text(),'Legal Vehicle Information')]");
	public static By approval_submit_btn = By.xpath("//button[contains(text(),'Submit')]");
	public static By approveLegalVehicleSuccess_mg = By.xpath("//div[contains(@class,'alert alert-success')]");
	public static By deactivateLegalVehicle_btn = By.xpath("//input[contains(@id,'actDeactLegalVehicle')]");
	public static By deactivateConfirmationYes_btn = By.xpath("//input[@type='button' and @value='Yes']");
	public static By addNetBankingLegalVehicle_btn = By.xpath("//input[contains(@id,'addNetBanking')]");
	public static By netBankName_txt = By.xpath("//input[@id='vBankName']");
	public static By netBankCode_txt = By.xpath("//input[@id='vBankCode']");
	public static By netBankMeId_txt = By.xpath("//input[@id='vNetBankMeId']");
	public static By transactionUrl_txt = By.xpath("//input[@id='vTrnUrl']");
	public static By statusUrl_txt = By.xpath("//input[@id='vStatusUrl']");
	public static By netBankKey_txt = By.xpath("//input[@id='vNbKey']");
	public static By partnerChannel_txt = By.xpath("//select[@id='vPartnerChnId']");
	public static By netBankingSuccess_msg = By.xpath("//div[@class='alert alert-success']");
	
	
}
