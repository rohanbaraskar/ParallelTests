package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class DisputeManagementPageLocators {
	
	public static By fromDate_txt = By.id("fromDate");
	public static By toDate_txt = By.id("toDate");
	public static By category_select = By.id("category");
	public static By status_select = By.id("status");
	public static By submit_btn = By.xpath("//button[@type='submit']");
	public static By viewDispute_lnk = By.xpath("//a[contains(text(),'View') and contains(@class,'disDet')]");
	public static By dispDetail_lbl = By.xpath("//strong[@id='disputeId']");
	public static By addComment_txtarea = By.id("responseDesc");
	public static By respond_btn = By.id("addResBtn");
}
