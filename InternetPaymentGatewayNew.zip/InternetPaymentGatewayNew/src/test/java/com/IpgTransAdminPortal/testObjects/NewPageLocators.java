package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class NewPageLocators {
	
	public static By reports_menu = By.xpath("//li[@id='Reports']/a");
	
	//TRANSACTION SEARCH REPORT
	public static By transactionSearch_menu = By.xpath("//a[contains(@onclick,'getTransSearch')]");
	public static By pgMerchId_txt = By.id("MID");
	public static By orderId_txt = By.id("orderId");
	public static By rrn_txt = By.id("rrn");
	public static By trnRefNo_txt = By.id("trnRefNo");
	public static By fromDate_txt = By.id("fromDate");
	public static By toDate_txt = By.id("toDate");
	public static By channel_select = By.id("chnId");
	public static By showReport_btn = By.id("getReport");
	public static By transactionSearchResults = By.xpath("//thead/tr/th[contains(text(),'Transaction Ref No')]");
	
	//ALL TRANSACTION
	public static By allTrans_pgMerchId_txt = By.xpath("//form[contains(@action, 'getSettlement')]//input[@id='pgMerchantId']");
	public static By allTransaction_menu = By.xpath("//a[contains(@onclick,'getSettlement') and contains(text(),'All Transaction')]");
	public static By lv_select = By.id("lvId");
	public static By legalName_txt = By.id("legalName");
	public static By dbaName_txt = By.id("dbaName");
	public static By status_select = By.id("status");
	public static By downloadReport_btn = By.id("downloadReport");
	
	//MERCHANT VOLUME REPORT
	public static By merchVolume_pgMerchId_txt = By.xpath("//form[contains(@action, 'getMerchantVol')]//input[@id='pgMerchantId']");
	public static By merchVolumentReport_menu = By.xpath("//a[contains(@onclick,'getMerchantVol') and contains(text(),'Merchant Volume')]");
	public static By merchVol_mid_txt = By.id("mId");
	public static By merchVolReportSearchResults = By.xpath("//thead/tr/th[contains(text(),'PG Merchant ID')]");
	
}
 