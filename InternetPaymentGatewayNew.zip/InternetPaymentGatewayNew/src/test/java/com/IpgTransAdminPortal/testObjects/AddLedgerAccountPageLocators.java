package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class AddLedgerAccountPageLocators {
	
	public static By lvName_select = By.id("lvId");
	public static By ledgerAcNo_txt = By.id("vAccNo");
	public static By accHead_txt = By.id("vAccHead");
	public static By accPurpose_txt = By.id("vAccPurpose");
	public static By remarks_txt = By.id("vRemarks");
	public static By accFor_select = By.id("accFor");
	public static By accRefNo_select = By.id("accRefId");
	public static By nessieGlCode_txt = By.id("vNessieGLcode");
	public static By accName_txt = By.id("vAccName");
	public static By submit_btn = By.id("submit");
	public static By ledgerAccSuccess_msg = By.xpath("//div[contains(text(),'Ledger Account has been successfully created')]");
	
}
