package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class NetbankCancelDownloadPageLocators {
	
	public static By lvId_select = By.id("lvId");
	public static By netbankName_select = By.id("netBankId");
	public static By generate_btn = By.xpath("//input[contains(@value,'Generate')]");
	public static By netbankCancelDownloadSuccessConfirm_msg = By.xpath("//div[contains(text(),'Netbank file request generated successfully')]");
	public static By fileGenSuccess_row = By.xpath("//tbody/tr[1]/td[contains(text(),'SUCCESS')]");
	public static By fileGenPending_row = By.xpath("//tbody/tr[1]/td[contains(text(),'PENDING')]");
	public static By fileGenInProgress_row = By.xpath("//tbody/tr[1]/td[contains(text(),'In Progress')]");
	public static By fileGenFailed_row = By.xpath("//tbody/tr[1]/td[contains(text(),'FAILED')]");
	public static By refresh_btn = By.xpath("//button[@value='Refresh']");
	public static By firstRow_batchRunId = By.xpath("//tbody/tr/td[@class='sorting_1']");
	public static By search_txt = By.xpath("//input[@type='search']");
	
}
