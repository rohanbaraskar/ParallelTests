package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class SettlementRefundCancelUploadPageLocators {
	
	public static By upload_btn = By.xpath("//button[contains(@type,'submit')]");
	public static By meBusinessName = By.id("meBussName");
	public static By uploadType_select = By.id("batchId");
	public static By uploadFile = By.id("file");
	public static By uploadSubmitBtn = By.id("refSettleSubmit");
	public static By confirmYes_btn = By.id("btnYes"); 
	public static By uploadSuccess_msg = By.xpath("//div[contains(text(),'Netbank Reconciliation File Uploaded Successfully.')]");
	public static By fileGenSuccess_row = By.xpath("//tbody/tr[1]/td[contains(text(),'SUCCESS')]");
	public static By fileGenPending_row = By.xpath("//tbody/tr[1]/td[contains(text(),'PENDING')]");
	public static By fileGenInProgress_row = By.xpath("//tbody/tr[1]/td[contains(text(),'In Progress')]");
	public static By fileGenFailed_row = By.xpath("//tbody/tr[1]/td[contains(text(),'FAILED')]");
	public static By refresh_btn = By.xpath("//button[@value='Refresh']");
	public static By firstRow_batchRunId = By.xpath("//tbody/tr/td[@class='sorting_1']");
	public static By search_txt = By.xpath("//input[@type='search']");
}
