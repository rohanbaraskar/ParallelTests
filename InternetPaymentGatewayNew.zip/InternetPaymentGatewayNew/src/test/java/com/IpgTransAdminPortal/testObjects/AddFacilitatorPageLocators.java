package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class AddFacilitatorPageLocators {
	
	public static By facilitatorName_txt = By.id("fclName");
	public static By facilitatorCode_txt = By.id("fclCode");
	public static By scheme_select = By.id("schemeId");
	public static By assCode_txt = By.id("assCode");
	public static By assFclCode_txt = By.id("assFclCode");
	public static By add_btn = By.id("add1");
	public static By submit_btn = By.id("submit");
	public static By facilitatorSuccessful_mg = By.xpath("//div[contains(text(),'Facilitator has been successfully created')]");
}
