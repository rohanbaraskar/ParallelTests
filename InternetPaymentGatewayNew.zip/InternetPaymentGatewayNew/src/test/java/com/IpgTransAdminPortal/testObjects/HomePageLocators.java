package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class HomePageLocators {
	
	public static By merchManagement_mnu = By.xpath("//li[@id='Merchant Management']/a");
	public static By loggedInAs_lnk = By.xpath("//a[contains(@data-toggle,'dropdown')]");
	public static By logout_lnk = By.xpath("//span[contains(text(),'Logout')]");
	public static By merchOnboarding_mnu = By.linkText("Merchant Onboarding");
	public static By merchViewEdit_mnu = By.xpath("//a[contains(@onclick,'getGroupList') and contains(text(),'Merchant View')]");
	public static By storeType_select = By.id("list");
	public static By addStore_btn = By.id("addStore");
	public static By cgMasters_mnu = By.linkText("CG Masters");
	public static By scheme_mnu = By.linkText("Scheme");
	public static By addScheme_btn = By.xpath("//a[contains(@data-value,'createScheme')]");
	public static By legalVehicle_mnu = By.linkText("Legal Vehicle");
	public static By addLegalVehicle_btn = By.xpath("//a[contains(@data-value,'createLegalVehicle')]");
	public static By acquirerBank_mnu = By.linkText("Acquirer Bank");
	public static By addacquirer_btn = By.xpath("//a[contains(@data-value,'createAcquirer')]");
	public static By emiProgram_mnu = By.linkText("EMI Program");
	public static By addEmi_btn = By.xpath("//a[contains(@data-value,'createEmi')]");
	public static By manufacturer_mnu = By.linkText("Manufacturer");
	public static By addManufacturer_btn = By.xpath("//a[contains(@url,'createManufacturer')]");
	public static By facilitator_mnu = By.linkText("Facilitator");
	public static By addFacilitator_btn = By.xpath("//a[contains(@data-value,'createFacilitator')]");
	public static By finance_mnu = By.linkText("Finance");
	public static By tax_submnu = By.linkText("Tax");
	public static By addTax_btn = By.xpath("//a[contains(@data-value,'createTax')]");
	public static By ledgerAccount_submnu = By.linkText("Ledger Account");
	public static By addLedgerAccount_btn = By.xpath("//a[contains(@data-value,'createLedgerAccount')]");
	public static By search_txt = By.xpath("//input[@type='search']");
	public static By viewScheme_lnk = By.xpath("//a[@id='viewScheme']");
	public static By editAcquirer_lnk = By.xpath("//a[@class='editAcquirer']");
	public static By viewAcquirer_lnk = By.xpath("//a[@class='viewAcquirer']");
	public static By editLegalVehicle_lnk = By.xpath("//a[@class='editLegalVehicle']");
	
	public static By appReject_select = By.xpath("//select[@id='apprej']");
	public static By remarks_txtarea = By.xpath("//textarea[@id='rejectReason']");
	
	public static By operationsApproval_mnu = By.linkText("Operations Approval");
	//BUSINESS APPROVER SEARCH LIST
	public static By businessApproval_mnu = By.linkText("Business Approval");
	public static By businessApproverStoreList = By.xpath("//form[contains(@action, 'getBusAppList')]");
	
	//RISK APPROVER LIST
	public static By riskApproval_mnu = By.linkText("Risk Approval");
	public static By riskApprovalStoreList = By.xpath("//form[contains(@action, 'getRiskAppList')]");
	
	//FINANCE APPROVER LIST
	public static By financeApproval_mnu = By.linkText("Finance Approval");
	public static By financeApprovalStoreList = By.xpath("//form[contains(@action, 'getFinAppList')]");
		
	//DISPUTE MANAGEMENT
	public static By disputeManagement_mnu = By.linkText("Disputes Management");
	public static By disputesList = By.xpath("//form[contains(@action, 'getDisputeList')]");
	
	//SETTLEMENT
	public static By settlement_mnu = By.linkText("Settlement");
	public static By settleFileGen_mnu = By.xpath("//a[contains(@onclick,'magStlmtFileGen')]");
	public static By settleFileRecon_mnu = By.xpath("//a[contains(@onclick,'magSettlementFileRecon')]");
	
	//NET BANK RECONCILIATION UPLOAD
	public static By netbankFileRecon_mnu = By.xpath("//a[contains(@onclick,'uploadNbRecon')]");
	
	//MERCHANT PAYMENT ADVICE
	public static By merchPayAdvice_mnu = By.xpath("//a[contains(@onclick,'mrchtPayAdvcGen')]");
	
	//NETBANK CANCEL/REFUND DOWNLOAD
	public static By netbankCancelDownload_mnu = By.xpath("//a[contains(@onclick,'NbRefundCancelDwnld')]");
	
	//SETTLEMENT MARKING
	public static By settlementMarking_mnu = By.xpath("//a[contains(@onclick,'getSettlementMark')]");
	
	//CANCEL/REFUND MARKING  getRefCancel
	public static By cancelMarking_mnu = By.xpath("//a[contains(@onclick,'getRefCancel')]");
	
	//SETTLEMENT/REFUND/CANCEL UPLOAD
	public static By settlementRefundCancelUpload_mnu = By.xpath("//a[contains(@onclick,'settlementUplLst')]");
	
}
