package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class AddAcquirerPageLocators {
	
	public static By legalVehicleName_select = By.id("lvId");
	public static By acqBankName_txt = By.id("acqBankName");
	public static By acqBankCode_txt = By.id("acqBankCode");
	public static By acqBankFor_txt = By.id("acqBankFor");
	public static By bankAggFlag_select = By.id("bankAggFlag");
	public static By acqBankType_select = By.id("acqBankType");
	public static By partnerLvId_select = By.id("partnerLVID");
	public static By merchIdGenBy_select = By.id("midGenBy");
	public static By merchIdType_select = By.id("mIDType");
	public static By superMerchMid_txt = By.id("smID");
	public static By superMerchTid_txt = By.id("stID");
	public static By superMerchMidCurrCode_select = By.id("smIDCurrCode");
	public static By superMerchDccMid_txt = By.id("sdccMID");
	public static By superMerchDccTid_txt = By.id("sdccTID");
	public static By superMerchDccCode_select = By.id("sdccMIDCurrCode");
	public static By acqBankUserName_txt = By.id("acqUsrName");
	public static By acqPassword_txt = By.id("vAcqPwd");
	public static By dailyTransCount_txt = By.id("dailyTotTicketLimit"); 
	public static By dailyTransVolume_txt = By.id("dailyTotAmtLimit");
	public static By perTransLimit_txt = By.id("perTranLimit");
	public static By annualCharges_txt = By.id("acqAnnChrg");
	public static By maxRetryCount_txt = By.id("retryCnt");
	public static By settlementFlag_txt = By.id("settleResFlag");
	public static By dccAcceptFlag_chk = By.id("dccAcceptFlag");
	public static By ica_txt = By.id("ica");
	public static By acqDisclaimer_txt = By.id("disclaimer");
	public static By inrDisclaimer_txt = By.id("vInrDisclaimer");
	public static By preauthDisclaimer_txt = By.id("vPreauthDisclaimer");
	public static By channelsAvailableIPG_chk = By.id("IPG");
	public static By channelsAvailablePCPOS_chk = By.id("vPayTypeID");
	public static By acqSchemeMapChannel_select = By.id("chnName");
	public static By acqSchemeMapPayType_select = By.id("vPayTypeID");
	public static By acqSchemeMapScheme_select = By.id("vSchemeID");
	public static By acqAuthenticationType_select = By.id("vAuthnType");
	public static By acqAuthorizationType_select = By.id("vAuthzType");
	public static By settlementType_select = By.id("settleType");
	public static By accessCode_txt = By.id("vAccessCode");
	public static By secureSecret_txt = By.id("vSecureSecret");
	public static By authenticationURL_txt = By.id("vAuthnUrl");
	public static By authorizationURL_txt = By.id("vAuthzUrl");
	public static By add_btn = By.xpath("//button[contains(text(),'Add')]");
	public static By submit_btn = By.id("submit");
	public static By addAcquirerSuccess_msg = By.xpath("//div[contains(text(),'Acquirer has been successfully')]");
	public static By manageBsf_btn = By.xpath("//input[@id='addNewBsf']");
	public static By manageBsf_lbl = By.xpath("//.[contains(text(),'Manage BSF')]");
	public static By ratioMap_rbtn = By.xpath("//input[@id='ratiobtn']");
	public static By normalSlabMap_rbtn = By.xpath("//input[@id='slabbtn']");
	public static By acqInfo_lbl = By.xpath("//span[contains(text(),'Acquirer Information')]");
	//public static By acqBasicDetails = By.xpath("//.[contains(text(),'Acquiring Bank Basic Details')]");
	public static By approval_tab = By.xpath("//a[contains(@data-value,'getPendingAcquirerList')]/span");
	public static By viewAcquirer_lnk = By.xpath("//a[@class='viewAcquirer']");
	public static By acquirerInformation = By.xpath("//span[contains(text(),'Acquirer Information')]");
	public static By approveAcquirerSuccess_mg = By.xpath("//div[contains(@class,'alert alert-success')]");
	public static By approval_submit_btn = By.xpath("//button[contains(text(),'Submit')]");
	public static By editAcquirer_lnk = By.xpath("//a[@class='editAcquirer']");
	public static By deactivateAcquirer_btn = By.xpath("//input[@id='actDeactAcquirer']");
	
}
