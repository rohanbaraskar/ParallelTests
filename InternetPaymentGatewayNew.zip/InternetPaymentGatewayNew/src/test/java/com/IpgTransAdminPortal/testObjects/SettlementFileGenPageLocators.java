package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class SettlementFileGenPageLocators {
	
	public static By settleLv = By.id("mLVID");
	public static By search_txt = By.xpath("//input[@type='search']");
	public static By settleAcqBank = By.id("vACQBANKID");
	public static By fromDate = By.id("fromDate");
	public static By toDate = By.id("toDate");
	public static By datepickerPrev = By.xpath("//a[contains(@class,'ui-datepicker-prev')]/span");
	public static By datepickerSelectDay = By.xpath("//td[contains(@data-handler,'selectDay')]/a[contains(text(),'1')]");
	public static By generate_btn = By.xpath("//input[contains(@data-value,'submitSetlmtFileGen')]");
	public static By batchRunId = By.xpath("//a[contains(@class,'getCheckerFileDet')]");
	public static By fileGenSuccess_row = By.xpath("//tbody/tr[1]/td[contains(text(),'SUCCESS')]");
	public static By fileGenPending_row = By.xpath("//tbody/tr[1]/td[contains(text(),'PENDING')]");
	public static By fileGenInProgress_row = By.xpath("//tbody/tr[1]/td[contains(text(),'In Progress')]");
	public static By fileGenFailed_row = By.xpath("//tbody/tr[1]/td[contains(text(),'FAILED')]");
	public static By refresh_btn = By.xpath("//button[@value='Refresh']");
	public static By submitSuccess_msg = By.xpath("//div[contains(text(),'Settlement file generated Request Submitted successfully')]");
	
}
