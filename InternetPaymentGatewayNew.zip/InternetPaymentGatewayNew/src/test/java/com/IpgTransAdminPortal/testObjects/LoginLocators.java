package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class LoginLocators {
	
	public static By userId_txt = By.id("loginIDText");
	public static By password = By.id("passwordText");
	public static By login_btn = By.id("loginBtn");
	
}
