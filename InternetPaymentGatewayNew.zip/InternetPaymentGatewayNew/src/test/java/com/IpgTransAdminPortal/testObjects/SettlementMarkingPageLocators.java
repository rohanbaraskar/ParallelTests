package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class SettlementMarkingPageLocators {
	
	public static By legalMerchantName = By.id("meBussName");
	public static By dateFrom = By.id("effFrom");
	public static By dateTo = By.id("effTo");
	public static By search_btn = By.xpath("//input[contains(@data-value,'submitSettlementMrk')]");
	public static By submit_btn = By.xpath("//input[contains(@value,'Submit')]");
	public static By confirm_btn = By.id("procSettleReqSubmit");
	public static By select_chkbox = By.xpath("//input[@type='checkbox' and @class='canCheck']");
	
	//CANCEL MARKING
	public static By settleReqSubmitSuccess_msg = By.xpath("//div[contains(text(),'Settlement request submitted')]");
	public static By filter_select = By.id("reqType");
	public static By dateFrom2 = By.id("effrom");
	public static By dateTo2 = By.id("efTo");
	public static By searchBtn = By.id("search");
	public static By cancelMarking_confirmBtn = By.id("submitRefCancelConf");
	public static By cancelMarking_SuccessMsg = By.xpath("//div[contains(text(),'Cancel request submitted')]");
	
}
