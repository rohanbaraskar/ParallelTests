package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class SettlementFileReconPageLocators {
	
	public static By search_txt = By.xpath("//input[@type='search']");
	public static By settleFileReconDetails_lbl = By.xpath("//span[contains(text(),'Settlement File Reconciliation Details')]");
	public static By confirm_btn = By.xpath("//input[@value='Confirm']");
	public static By settleFileConfirm_msg = By.xpath("//div[contains(text(),'Settlement File confirmed successfully')]");
	
}
