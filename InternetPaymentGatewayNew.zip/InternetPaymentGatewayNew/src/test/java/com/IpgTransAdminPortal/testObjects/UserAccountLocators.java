package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class UserAccountLocators {
	
	public static By userAccount_menu=By.xpath("//a[contains(text(),'User Account')]");
	
//CREATE NEW USER
	public static By user_menu=By.xpath("//a[text()='User']");
	public static By addUser_btn=By.xpath("//a[contains(@onclick,'userCreation')]");
	public static By userRegistration_Text=By.xpath("//span[text()='User Registration']");
	public static By loginId_txt=By.id("loginId");
	public static By firstName_txt=By.id("firstName");
	public static By lastName_txt=By.id("lastName");
	public static By displayName_txt=By.id("displayName");
	public static By emailId_txt=By.id("emailId");
	public static By mobileNo_txt=By.id("mobileNo");
	public static By landlineNo_txt=By.id("contactNo");
	public static By streetAddress_txt=By.id("streetAddress");
	public static By city_txt=By.id("city");
	public static By state_txt=By.id("state");
	public static By zipCode_txt=By.id("pinNo");
	public static By employeeId_txt=By.id("empId");
	public static By entityType_select=By.id("vEntityType");
	public static By submit_btn=By.xpath("//button[text()='Submit']");
	public static By worldline_Text=By.xpath("//td[text()='Worldline']");
	public static By worldline_btn=By.xpath("(//i[contains(@onclick,'Worldline')])[2]");
	public static By approvalMessage_Text=By.xpath("//div[text()='User is sent for approval.']");

	//APPROVE NEW USER
	public static By approve_btn=By.xpath("//a[contains(@onclick,'pendingForApproval')]");
	public static By approveLoginId=By.xpath("//*[@id='tabnew1']/tbody/tr[1]/td[2]");
	//public static By view_lnk=By.xpath("(//a[text()='View'][1]");
	public static By view_lnk=By.linkText("View");
	public static By approveORReject_select=By.id("apprej");
	public static By remarks_txt=By.id("rejectReason"); 
	public static By approveSubmit_btn=By.id("approveUser");
	public static By approvedMessage_Text=By.xpath("//div[text()='User has been successfully approved.']");
	public static By search_txt = By.xpath("//input[@type='search']");
	
	//EDIT ACTIVATED USER
	
	public static By accountStatus_Text=By.xpath("//td[contains(.,'Active')]");
	public static By editUser_btn=By.id("editUser");
	public static By update_btn=By.xpath("//button[text()='Update']");
	public static By updatedMsg_Text=By.xpath("//div[text()='User has been successfully updated.']");
	public static By approvedLoginId=By.xpath("//*[@id='tabnew']/tbody/tr[1]/td[1]");
	
	// RESET PASSWORD 
	public static By resetPassword_btn=By.id("resetPassword");
	public static By resetPasswordMsg_Text=By.xpath("//div[text()='Password is reset for user.']");
	
	//DEACTIVATE USER
	public static By deactivateUser_btn=By.id("actDeactUser");
	public static By deactivateUserMsg_Text=By.xpath("//div[text()='User account deactivation request sent for approval.']");
	
	//CREATE ROLE 
	public static By role_menu=By.xpath("//a[text()='Role']");
	public static By addRole_btn=By.xpath("//a[contains(@onclick,'/roleCreation')]");
	public static By roleName_txt=By.id("vRoleName");
	public static By roleDescription_txt=By.id("vRoleDesc");
	public static By roleSubmit_btn=By.xpath("//button[text()='Submit']");
	public static By roleMsg_Text=By.xpath("//div[text()='Request sent for approval.']");
	
	//APPROVE ROLE
	public static By roleApprove_btn=By.xpath("//a[contains(@onclick,'/rolePendingForApproval')]");
	public static By roleName_column=By.xpath("//*[@id='tabnew']/tbody/tr[1]/td[3]");
	public static By approveRole_btn=By.id("approveRole");
	public static By sucessRoleMsg_Text=By.xpath("//div[contains(text(),'Role approved successfully.')]");	
//USER TO ROLE MAP
  public static By userToRoleMap_btn=By.id("roleToUser");
  public static By roleNameTable=By.xpath("(//table[@id='tabnew']/tbody/tr/td[1])");
  public static String roleNameTables="(//table[@id='tabnew']/tbody/tr/td[1])";
  public static String roleAdd_btns="(//table[@id='tabnew']/tbody/tr/td[2]/i)";
  public static By userToRoleMap_Text=By.xpath("//span[text()='User To Role Mapping']");
  public static By selectedRoleName=By.xpath("(//tr[@class='selectedRoles']/td)[1]");
  public static By roleMapSubmit_btn=By.xpath("//input[@value='Submit']");
  public static By roleMapMsg_Text=By.xpath("//div[text()='Request submitted for approval.']");
  
  //CHANGE PASSWORD
  public static By changePassword=By.xpath("//span[contains(text(),'Change Password')]");
  public static By changePassword_Text=By.xpath("//span[text()='Change Password']");
  public static By oldPassword_txt=By.id("oldPassword");
  public static By newPassword_txt=By.id("newPassword");
  public static By confirmNewPassword_txt=By.id("confirmPassword");
  public static By chngPwdSubmit_btn=By.id("chnPassword");

}
