package com.IpgTransAdminPortal.testObjects;

import org.openqa.selenium.By;

public class ReportsLocators {
	
	public static By reports_menu = By.xpath("//li[@id='Reports']/a");
	public static By noRecordFound_msg = By.xpath("//div[contains(text(),'No record found')]");
	
	//TRANSACTION SEARCH REPORT
	public static By transactionSearch_menu = By.xpath("//a[contains(@onclick,'getTransSearch')]");
	public static By pgMerchId_txt = By.id("MID");
	public static By orderId_txt = By.id("orderId");
	public static By rrn_txt = By.id("rrn");
	public static By trnRefNo_txt = By.id("trnRefNo");
	public static By fromDate_txt = By.id("fromDate");
	public static By toDate_txt = By.id("toDate");
	public static By channel_select = By.id("chnId");
	public static By showReport_btn = By.id("getReport");
	public static By transactionSearchResults = By.xpath("//thead/tr/th[contains(text(),'Transaction Ref No')]");
	public static By ts_viewDetails_lnk = By.xpath("//td/a[contains(@onclick,'viewDetails')]");
	public static By meRequestDetails_lbl = By.xpath("//span[contains(text(),'Merchant Request Details')]");
	
	//ALL TRANSACTION
	public static By allTrans_pgMerchId_txt = By.xpath("//form[contains(@action, 'getSettlement')]//input[@id='pgMerchantId']");
	public static By allTransaction_menu = By.xpath("//a[contains(@onclick,'getSettlement') and contains(text(),'All Transaction')]");
	public static By lv_select = By.id("lvId");
	public static By legalName_txt = By.id("legalName");
	public static By dbaName_txt = By.id("dbaName");
	public static By status_select = By.id("status");
	public static By downloadReport_btn = By.id("downloadReport");
	
	//MERCHANT VOLUME REPORT
	public static By merchVolume_pgMerchId_txt = By.xpath("//form[contains(@action, 'getMerchantVol')]//input[@id='pgMerchantId']");
	public static By merchVolumentReport_menu = By.xpath("//a[contains(@onclick,'getMerchantVol') and contains(text(),'Merchant Volume')]");
	public static By merchVol_mid_txt = By.id("mId");
	public static By merchVolReportSearchResults = By.xpath("//thead/tr/th[contains(text(),'PG Merchant ID')]");
	
	//ACQ BANK WISE UNSETTLED TRANSACTION
	public static By acqBankwiseUnsettledTransReport_menu = By.xpath("//a[contains(@onclick,'getAcqUnsettledTxn')]");
	public static By acqBankName_select = By.id("acqBankName");
	public static By pgMerchantId_txt = By.id("pgMerchantId");
	public static By acqBankUnsetTrans_pgMerchId_txt = By.xpath("//form[contains(@action, 'getAcqUnsettledTxn')]//input[@id='pgMerchantId']");
	
	//ACQ BANKWISE SALE SUMMARY
	public static By acqBankwiseSaleSummaryReport_menu = By.xpath("//a[contains(@onclick,'getAcqSaleSummary')]");
	public static By acqBankwiseSaleSummaryReportSearchResults = By.xpath("//thead/tr/th[contains(text(),'Acquiring Bank Name')]");
	
	//FRM ALERT REPORT
	public static By frmAlertReport_menu = By.xpath("//a[contains(@onclick,'getFRMAlert')]");
	
	//MERCHANT PAYMENT ADVICE
	public static By mePaymentAdviceReport_menu = By.xpath("//a[contains(@onclick,'getPaymtAdvice')]");
	
	//MONTHLY INVOICING REPORT
	public static By monthlyInvoicingReport_menu = By.xpath("//a[contains(@onclick,'getMonthlyInvc')]");
	public static By monthYear_txt = By.id("trnDate");
	
	//MERCHANT WISE MIS REPORT
	public static By merchantWiseMisReport_menu = By.xpath("//a[contains(@onclick,'getMerchantMIS')]");
	
	//MIS TRANSACTION REPORT
	public static By misTransReport_menu = By.xpath("//a[contains(@onclick,'getMISTxn')]");
	public static By cardType_select = By.id("payTypeId");
	public static By misTransReportSearchResults_success = By.xpath("//thead/tr/th[contains(text(),'Type')]");
	
	//PROFIT & LOSS ACCOUNT REPORT
	public static By profitLossAccReport_menu = By.xpath("//a[contains(@onclick,'getProfitLossAcc')]");
	
	//CHARGEBACKS TO SALES RATIO REPORT
	public static By chargebackSalesRatioReport_menu = By.xpath("//a[contains(@onclick,'getChargebckSales')]");
	
	//CHARGEBACKS - DAILY AGING REPORT
	public static By chargebackDailyAgingReport_menu = By.xpath("//a[contains(@onclick,'getChargebckAging')]");
	
	//CHARGEBACKS - DETAILED TRANSACTION REPORT
	public static By chargebackDetailTransReport_menu = By.xpath("//a[contains(@onclick,'getChargebckTxn')]");
	
	//PROFITABILITY REPORT
	public static By profitabilityReport_menu = By.xpath("//a[contains(@onclick,'getProfitability')]");
	public static By profitabilityReportSearchResults_success = By.xpath("//thead/tr/th[contains(text(),'Pay Type')]");
	
	//MERCHANT DETAILS REPORT
	public static By meDetailsReport_menu = By.xpath("//a[contains(@onclick,'getMerchantDetails')]");
	public static By meDetailsSearchResults_success = By.id("tabnew");
	
	//DEACTIVE MERCHANT DETAILS
	public static By deactiveMerchantReport_menu = By.xpath("//a[contains(@onclick,'getInMeList')]");
	public static By deactiveMerchantReportSearchResults_success = By.xpath("//thead/tr//th[contains(text(),'Deactivation Date')]");
	
	//SELF REGISTRATION REPORT
	public static By selfRegistrationReport_menu = By.xpath("//a[contains(@onclick,'getSelfReg')]");
	public static By selfRegistrationReportSearchResults_success = By.xpath("//thead/tr//th[contains(text(),'Registration ID')]");
	
	//VARIANCE REPORT
	public static By varianceReport_menu = By.xpath("//a[contains(@onclick,'getVariance')]");
	
	//DAILY SALES REPORT
	public static By dsrReport_menu = By.xpath("//a[contains(@onclick,'getDSR')]");
	
	//TRIAL BALANCE REPORT
	public static By trialBalanceReport_menu = By.xpath("//a[contains(@onclick,'getTrialBal')]");
	
	//MERCHANT STATUS REPORT
	public static By meStatusReport_menu = By.xpath("//a[contains(@onclick,'merStatusRpt')]");
	
	//RISK SCORING REPORT
	public static By riskScoringReport_menu=By.xpath("//a[contains(@onclick,'riskScoringRpt')]");
	public static By riskScoringReport_Text=By.xpath("//span[text()='Risk Scoring Report']");

	//MERCHANT OUSTANDING REPORT
	public static By merchantOutstandingReport_menu=By.xpath("//a[contains(@onclick,'getMeOutstandReport')]");
	public static By merchantOutstandingReport_Text=By.xpath("//span[text()='Merchant Outstand Report']");
	public static By reportType_select=By.id("searchType");

	//EMI REGISTRATION REPORT
	public static By emiRegistrationReport_menu=By.xpath("//a[contains(@onclick,'emiRegistrationRpt')]");
	public static By emiRegistrationReport_Text=By.xpath("//span[text()='Emi Registration Report']");
		
	// SMART CHECKOUT REPORT
	public static By smartCheckoutReport_menu=By.xpath("//a[contains(@onclick,'smartChkOutRpt')]");
	public static By smartCheckoutReport_Text=By.xpath("//span[text()='Smart Checkout Report']");

}
 