package com.IpgTransactionPortal.workflows;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeOptions;

import com.IpgTransactionPortal.testObjects.TransactionPortalLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.RobotUtils;

public class TransactionPortalWorkflows extends ActionEngine{

	ExcelReader bufferxls = new ExcelReader(configProps.getProperty("TempData"), "buffer");
	
	public String merchId;
	public String encryptKey;
	public String ccNumber;
	public String vcExpDateMonth;
	public String vcExpDateYear;
	public String vcCvv;
	public String vcNameOnCard;
	public String vcEmailId;
	public String vcMobile;
	public String smartCheckout;
	public String transType;
	public String currencyName;
	public String emailId;
	public String password;
	public String emiScheme;
	public String transAmount;
	public String orderId;
	public String transactionRemarks;
	public String recurringPeriod;
	public String recurringDay;
	public String noOfRecurring;
	public String responseUrl;
	public String additionalField1;
	public String additionalField2;
	public String dcc;
	public String payWithDcc;
	public String payWithEmi;
	
	static Logger logger = Logger.getLogger(TransactionPortalWorkflows.class.getName());
	
	public boolean creditNormalTransaction() throws Throwable{
		boolean result = false;
		ImplicitWait();		
		HtmlReportSupport.reportStep("Transaction Request Page");
		waitForElementPresent(TransactionPortalLocators.normalTransaction_lnk, "Transaction Portal - Landing Page");
		click(TransactionPortalLocators.normalTransaction_lnk, "Normal Transaction - Link");
		waitForElementPresent(TransactionPortalLocators.merchId_txt, "Transaction Portal Page");
		type(TransactionPortalLocators.merchId_txt, merchId, "Merchant ID Text");
		type(TransactionPortalLocators.encryptKey_txt, encryptKey, "Encryption Key");
		
		if((orderId != null)&&(orderId != ""))
			type(TransactionPortalLocators.orderId_txt, orderId, "Order ID");
		if((transAmount != null)&&(transAmount != ""))
			type(TransactionPortalLocators.transAmt_txt, transAmount, "Transaction Amount");
		if((currencyName != null)&&(currencyName != ""))
				type(TransactionPortalLocators.currencyName_txt, currencyName, "Currency Name");
		if((transType != null)&&(transType != ""))
				type(TransactionPortalLocators.transType_txt, transType, "Transaction Type");
		if((transactionRemarks != null)&&(transactionRemarks != ""))
			type(TransactionPortalLocators.transRemarks_txt, transactionRemarks, "Transaction Remarks");
		if((recurringPeriod != null)&&(recurringPeriod != ""))
			type(TransactionPortalLocators.recurringPeriod_txt, recurringPeriod, "Recurring Period");
		if((recurringDay != null)&&(recurringDay != ""))
			type(TransactionPortalLocators.recurringDay_txt, recurringDay, "Recurring Day");
		if((noOfRecurring != null)&&(noOfRecurring != ""))
			type(TransactionPortalLocators.noOfRecurring_txt, noOfRecurring, "Number of Recurring");
		if((responseUrl != null)&&(responseUrl != ""))
			type(TransactionPortalLocators.responseUrl_txt, responseUrl, "Response URL");
		if((additionalField1 != null)&&(additionalField1 != ""))
			type(TransactionPortalLocators.addField1_txt, additionalField1, "Additional Field1");
		if((additionalField2 != null)&&(additionalField2 != ""))
			type(TransactionPortalLocators.addField2_txt, additionalField2, "Additional Field2");
		
		click(TransactionPortalLocators.checkout_btn, "Checkout Button");		
		
		HtmlReportSupport.reportStep("Payment Details Page");
		waitForElementPresent(TransactionPortalLocators.vcCardNumber_txt, "Payment Details Page - CREDIT CARD");
		type(TransactionPortalLocators.vcCardNumber_txt, ccNumber, "Card Number");
		selectByVisibleText(TransactionPortalLocators.vcExpiryDateMonth_select, vcExpDateMonth, "Expiry Date - Month");
		selectByVisibleText(TransactionPortalLocators.vcExpDateYear_select, vcExpDateYear, "Expiry Date - Year");
		type(TransactionPortalLocators.vcCvv_txt, vcCvv, "CVV");
		type(TransactionPortalLocators.vcNameOnCard_txt, vcNameOnCard, "Name on Card");
		
		if(vcEmailId != null)
			if(vcEmailId != "")
				type(TransactionPortalLocators.vcEmailId_txt, vcEmailId, "Email ID");
		
		if(vcMobile != null)
			if(vcMobile != "")
				type(TransactionPortalLocators.vcMobile_txt, vcMobile, "Mobile");
		
		if(smartCheckout != null)
			if(smartCheckout.equalsIgnoreCase("Y"))
				click(TransactionPortalLocators.vcSmartCheckout, "Smart Checkout");
		
		RobotUtils.initRobot();
		RobotUtils.pressTabs(1);
		
		click(TransactionPortalLocators.vcPay_btn, "Pay button");
		

		//Changed by Suresh 05-06-2017 for save pop up handling=========
		

		
		//=====================================
		if((dcc != null)&&(dcc != "")){			
			HtmlReportSupport.reportStep("Pay With/Without DCC Page");
			waitForElementPresent(TransactionPortalLocators.payWithDcc_btn, "Pay With/Without DCC Page");
			if(payWithDcc.equalsIgnoreCase("Y"))
				click(TransactionPortalLocators.payWithDcc_btn, "Pay in Home Currency - button");
			else
				click(TransactionPortalLocators.payWithOutDcc_btn, "Pay in Merchant Currency - button");
		}
			
		HtmlReportSupport.reportStep("Merchant Response Page");
		waitForElementPresent(TransactionPortalLocators.merchResponse_txt, "Merchant Response Page");
		type(TransactionPortalLocators.encKey_txt, encryptKey, "Encrypt Key");
		click(TransactionPortalLocators.submit_btn, "Submit button");
		
		HtmlReportSupport.reportStep("Transaction Status Page");
		waitForElementPresent(TransactionPortalLocators.transactionSuccess_msg, "Transaction Successful Message");
		
		result = true;		
		return result;
	}
	
	public boolean ccNormalTransactionWithTransRefNoBackup(String bufferFieldName) throws Throwable{
		boolean result = false;
		ImplicitWait();		
		HtmlReportSupport.reportStep("Transaction Request Page");
		waitForElementPresent(TransactionPortalLocators.normalTransaction_lnk, "Transaction Portal - Landing Page");
		click(TransactionPortalLocators.normalTransaction_lnk, "Normal Transaction - Link");
		waitForElementPresent(TransactionPortalLocators.merchId_txt, "Transaction Portal Page");
		type(TransactionPortalLocators.merchId_txt, merchId, "Merchant ID Text");
		type(TransactionPortalLocators.encryptKey_txt, encryptKey, "Encryption Key");
		
		if((orderId != null)&&(orderId != ""))
			type(TransactionPortalLocators.orderId_txt, orderId, "Order ID");
		if((transAmount != null)&&(transAmount != ""))
			type(TransactionPortalLocators.transAmt_txt, transAmount, "Transaction Amount");
		if((currencyName != null)&&(currencyName != ""))
				type(TransactionPortalLocators.currencyName_txt, currencyName, "Currency Name");
		if((transType != null)&&(transType != ""))
				type(TransactionPortalLocators.transType_txt, transType, "Transaction Type");
		if((transactionRemarks != null)&&(transactionRemarks != ""))
			type(TransactionPortalLocators.transRemarks_txt, transactionRemarks, "Transaction Remarks");
		if((recurringPeriod != null)&&(recurringPeriod != ""))
			type(TransactionPortalLocators.recurringPeriod_txt, recurringPeriod, "Recurring Period");
		if((recurringDay != null)&&(recurringDay != ""))
			type(TransactionPortalLocators.recurringDay_txt, recurringDay, "Recurring Day");
		if((noOfRecurring != null)&&(noOfRecurring != ""))
			type(TransactionPortalLocators.noOfRecurring_txt, noOfRecurring, "Number of Recurring");
		if((responseUrl != null)&&(responseUrl != ""))
			type(TransactionPortalLocators.responseUrl_txt, responseUrl, "Response URL");
		if((additionalField1 != null)&&(additionalField1 != ""))
			type(TransactionPortalLocators.addField1_txt, additionalField1, "Additional Field1");
		if((additionalField2 != null)&&(additionalField2 != ""))
			type(TransactionPortalLocators.addField2_txt, additionalField2, "Additional Field2");
		
		click(TransactionPortalLocators.checkout_btn, "Checkout Button");		
		
		HtmlReportSupport.reportStep("Payment Details Page");
		waitForElementPresent(TransactionPortalLocators.vcCardNumber_txt, "Payment Details Page - CREDIT CARD");
		type(TransactionPortalLocators.vcCardNumber_txt, ccNumber, "Card Number");
		selectByVisibleText(TransactionPortalLocators.vcExpiryDateMonth_select, vcExpDateMonth, "Expiry Date - Month");
		selectByVisibleText(TransactionPortalLocators.vcExpDateYear_select, vcExpDateYear, "Expiry Date - Year");
		type(TransactionPortalLocators.vcCvv_txt, vcCvv, "CVV");
		type(TransactionPortalLocators.vcNameOnCard_txt, vcNameOnCard, "Name on Card");
		
		RobotUtils.initRobot();
		RobotUtils.pressTabs(1);
		//click(TransactionPortalLocators.vcNameOnCard_txt, "Email Click");
		Thread.sleep(2000);
		if(vcEmailId != null)
			if(vcEmailId != "")
				type(TransactionPortalLocators.vcEmailId_txt, vcEmailId, "Email ID");
		
		if(vcMobile != null)
			if(vcMobile != "")
				type(TransactionPortalLocators.vcMobile_txt, vcMobile, "Mobile");
		
		if(smartCheckout != null)
			if(smartCheckout.equalsIgnoreCase("Y"))
				click(TransactionPortalLocators.vcSmartCheckout, "Smart Checkout");
		
		//JSClick(TransactionPortalLocators.vcNameOnCard_txt, "Email Click");
		
		//click(TransactionPortalLocators.vcEmailId_txt, "c button");
		//RobotUtils.pressTabs(1);
		//Thread.sleep(9000);
		click(TransactionPortalLocators.vcPay_btn, "Pay button");
		//Thread.sleep(3000);
		//Changed By Suresh================
		System.out.println("Hi Suresh");
		
		//Alert();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		options.addArguments("--disable-web-security");
		options.addArguments("--no-proxy-server");

		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);

		options.setExperimentalOption("prefs", prefs);	
		
		/*Alert();
		RobotUtils.initRobot();                   
		RobotUtils.pressEnterKey()*/;
		//==========================================
		
		
		if((dcc != null)&&(dcc != "")){			
			HtmlReportSupport.reportStep("Pay With/Without DCC Page");
			waitForElementPresent(TransactionPortalLocators.payWithDcc_btn, "Pay With/Without DCC Page");
			if(payWithDcc.equalsIgnoreCase("Y"))
				click(TransactionPortalLocators.payWithDcc_btn, "Pay in Home Currency - button");
			else
				click(TransactionPortalLocators.payWithOutDcc_btn, "Pay in Merchant Currency - button");
		}
		Thread.sleep(3000);	
		HtmlReportSupport.reportStep("Merchant Response Page");
		waitForElementPresent(TransactionPortalLocators.merchResponse_txt, "Merchant Response Page");
		type(TransactionPortalLocators.encKey_txt, encryptKey, "Encrypt Key");
		//click(TransactionPortalLocators.vcEmailId_txt, "Email Click");
		Thread.sleep(500);
		JSClick(TransactionPortalLocators.submit_btn, "Submit button");
		Thread.sleep(3000);
		HtmlReportSupport.reportStep("Transaction Status Page");
		waitForElementPresent(TransactionPortalLocators.transactionSuccess_msg, "Transaction Successful Message");
		String transactionRefNo = getText(By.xpath("//label[contains(text(),'Transaction Ref No')]/../following-sibling::td/label"), "Transaction Reference Number");
		transactionRefNo = transactionRefNo.split(":")[1];
		transactionRefNo = transactionRefNo.trim();
		result = bufferxls.setCellData("buffer", bufferFieldName, 2, transactionRefNo);	//Writing the Transaction Reference No to TempData.xls file
		
		return result;
	}
	public boolean debitNormalTransaction() throws Throwable{
		boolean result = false;
		ImplicitWait();		
		HtmlReportSupport.reportStep("Transaction Request Page");
		waitForElementPresent(TransactionPortalLocators.normalTransaction_lnk, "Transaction Portal - Landing Page");
		click(TransactionPortalLocators.normalTransaction_lnk, "Normal Transaction - Link");
		waitForElementPresent(TransactionPortalLocators.merchId_txt, "Transaction Portal Page");
		type(TransactionPortalLocators.merchId_txt, merchId, "Merchant ID Text");
		type(TransactionPortalLocators.encryptKey_txt, encryptKey, "Encryption Key");
		if((orderId != null)&&(orderId != ""))
			type(TransactionPortalLocators.orderId_txt, orderId, "Order ID");
		if((transAmount != null)&&(transAmount != ""))
			type(TransactionPortalLocators.transAmt_txt, transAmount, "Transaction Amount");
		if((currencyName != null)&&(currencyName != ""))
				type(TransactionPortalLocators.currencyName_txt, currencyName, "Currency Name");
		if((transType != null)&&(transType != ""))
				type(TransactionPortalLocators.transType_txt, transType, "Transaction Type");
		if((transactionRemarks != null)&&(transactionRemarks != ""))
			type(TransactionPortalLocators.transRemarks_txt, transactionRemarks, "Transaction Remarks");
		if((recurringPeriod != null)&&(recurringPeriod != ""))
			type(TransactionPortalLocators.recurringPeriod_txt, recurringPeriod, "Recurring Period");
		if((recurringDay != null)&&(recurringDay != ""))
			type(TransactionPortalLocators.recurringDay_txt, recurringDay, "Recurring Day");
		if((noOfRecurring != null)&&(noOfRecurring != ""))
			type(TransactionPortalLocators.noOfRecurring_txt, noOfRecurring, "Number of Recurring");
		if((responseUrl != null)&&(responseUrl != ""))
			type(TransactionPortalLocators.responseUrl_txt, responseUrl, "Response URL");
		if((additionalField1 != null)&&(additionalField1 != ""))
			type(TransactionPortalLocators.addField1_txt, additionalField1, "Additional Field1");
		if((additionalField2 != null)&&(additionalField2 != ""))
			type(TransactionPortalLocators.addField2_txt, additionalField2, "Additional Field2");
		
		click(TransactionPortalLocators.checkout_btn, "Checkout Button");		
		
		HtmlReportSupport.reportStep("Payment Details Page");
		waitForElementPresent(TransactionPortalLocators.vcCardNumber_txt, "Payment Details Page - CREDIT CARD");
		click(TransactionPortalLocators.debitTab, "Debit Tab");		
		waitForElementPresent(TransactionPortalLocators.dcCardNumber_txt, "Payment Details Page - DEBIT CARD");
		
		type(TransactionPortalLocators.dcCardNumber_txt, ccNumber, "Card Number");
		selectByVisibleText(TransactionPortalLocators.dcExpiryDateMonth_select, vcExpDateMonth, "Expiry Date - Month");
		selectByVisibleText(TransactionPortalLocators.dcExpDateYear_select, vcExpDateYear, "Expiry Date - Year");
		type(TransactionPortalLocators.dcCvv_txt, vcCvv, "CVV");
		type(TransactionPortalLocators.dcNameOnCard_txt, vcNameOnCard, "Name on Card");
		
		if(vcEmailId != null)
			if(vcEmailId != "")
				type(TransactionPortalLocators.dcEmailId_txt, vcEmailId, "Email ID");
		
		if(vcMobile != null)
			if(vcMobile != "")
				type(TransactionPortalLocators.dcMobile_txt, vcMobile, "Mobile");
		
		if(smartCheckout != null)
			if(smartCheckout.equalsIgnoreCase("Y"))
				click(TransactionPortalLocators.vcSmartCheckout, "Smart Checkout");
		RobotUtils.initRobot();
		RobotUtils.pressTabs(1);
		click(TransactionPortalLocators.dcPay_btn, "Payment button");
		
		HtmlReportSupport.reportStep("Merchant Response Page");
		waitForElementPresent(TransactionPortalLocators.merchResponse_txt, "Merchant Response Page");
		type(TransactionPortalLocators.encKey_txt, encryptKey, "Encrypt Key");
		click(TransactionPortalLocators.submit_btn, "Submit button");
		
		HtmlReportSupport.reportStep("Transaction Status Page");
		waitForElementPresent(TransactionPortalLocators.transactionSuccess_msg, "Transaction Successful Message");
		
		result = true;		
		return result;
	}
	
	public boolean smartCheckoutNormalTransaction() throws Throwable{
		boolean result = false;
		ImplicitWait();		
		HtmlReportSupport.reportStep("Transaction Request Page");
		waitForElementPresent(TransactionPortalLocators.normalTransaction_lnk, "Transaction Portal - Landing Page");
		click(TransactionPortalLocators.normalTransaction_lnk, "Normal Transaction - Link");
		waitForElementPresent(TransactionPortalLocators.merchId_txt, "Transaction Portal Page");
		type(TransactionPortalLocators.merchId_txt, merchId, "Merchant ID Text");
		type(TransactionPortalLocators.encryptKey_txt, encryptKey, "Encryption Key");
		if((orderId != null)&&(orderId != ""))
			type(TransactionPortalLocators.orderId_txt, orderId, "Order ID");
		if((transAmount != null)&&(transAmount != ""))
			type(TransactionPortalLocators.transAmt_txt, transAmount, "Transaction Amount");
		if((currencyName != null)&&(currencyName != ""))
				type(TransactionPortalLocators.currencyName_txt, currencyName, "Currency Name");
		if((transType != null)&&(transType != ""))
				type(TransactionPortalLocators.transType_txt, transType, "Transaction Type");
		if((transactionRemarks != null)&&(transactionRemarks != ""))
			type(TransactionPortalLocators.transRemarks_txt, transactionRemarks, "Transaction Remarks");
		if((recurringPeriod != null)&&(recurringPeriod != ""))
			type(TransactionPortalLocators.recurringPeriod_txt, recurringPeriod, "Recurring Period");
		if((recurringDay != null)&&(recurringDay != ""))
			type(TransactionPortalLocators.recurringDay_txt, recurringDay, "Recurring Day");
		if((noOfRecurring != null)&&(noOfRecurring != ""))
			type(TransactionPortalLocators.noOfRecurring_txt, noOfRecurring, "Number of Recurring");
		if((responseUrl != null)&&(responseUrl != ""))
			type(TransactionPortalLocators.responseUrl_txt, responseUrl, "Response URL");
		if((additionalField1 != null)&&(additionalField1 != ""))
			type(TransactionPortalLocators.addField1_txt, additionalField1, "Additional Field1");
		if((additionalField2 != null)&&(additionalField2 != ""))
			type(TransactionPortalLocators.addField2_txt, additionalField2, "Additional Field2");
		
		click(TransactionPortalLocators.checkout_btn, "Checkout Button");				
		HtmlReportSupport.reportStep("Payment Details Page");
		waitForElementPresent(TransactionPortalLocators.vcCardNumber_txt, "Payment Details Page - CREDIT CARD");
		click(TransactionPortalLocators.smartCheckout_tab, "Smart Checkout Tab");		
		waitForElementPresent(TransactionPortalLocators.emailId_txt, "Smart Checkout Tab");
		type(TransactionPortalLocators.emailId_txt, emailId, "Email ID Text");
		type(TransactionPortalLocators.password_txt, password, "Password Text");
		click(TransactionPortalLocators.login_btn, "Login Button");
		waitForElementPresent(TransactionPortalLocators.card_selection, "Card Selection");
		click(TransactionPortalLocators.card_selection, "Card Selection");
		waitForElementPresent(TransactionPortalLocators.vQcvv_txt, "CVV");
		type(TransactionPortalLocators.vQcvv_txt, vcCvv, "CVV Text");
		
		RobotUtils.initRobot();
		RobotUtils.pressTabs(1);
		
		click(TransactionPortalLocators.submitPay_btn, "Pay Button");
		
		HtmlReportSupport.reportStep("Merchant Response Page");
		waitForElementPresent(TransactionPortalLocators.merchResponse_txt, "Merchant Response Page");
		type(TransactionPortalLocators.encKey_txt, encryptKey, "Encrypt Key");
		click(TransactionPortalLocators.submit_btn, "Submit button");
		
		HtmlReportSupport.reportStep("Transaction Status Page");
		waitForElementPresent(TransactionPortalLocators.transactionSuccess_msg, "Transaction Successful Message");
		
		
		result = true;
		return result;
	}
	
	public boolean saleEmiCreditNormalTransaction() throws Throwable{
		boolean result = false;
		ImplicitWait();		
		HtmlReportSupport.reportStep("Transaction Request Page");
		waitForElementPresent(TransactionPortalLocators.normalTransaction_lnk, "Transaction Portal - Landing Page");
		click(TransactionPortalLocators.normalTransaction_lnk, "Normal Transaction - Link");
		waitForElementPresent(TransactionPortalLocators.merchId_txt, "Transaction Portal Page");
		type(TransactionPortalLocators.merchId_txt, merchId, "Merchant ID Text");
		type(TransactionPortalLocators.encryptKey_txt, encryptKey, "Encryption Key");
		if((orderId != null)&&(orderId != ""))
			type(TransactionPortalLocators.orderId_txt, orderId, "Order ID");
		if((transAmount != null)&&(transAmount != ""))
			type(TransactionPortalLocators.transAmt_txt, transAmount, "Transaction Amount");
		if((currencyName != null)&&(currencyName != ""))
				type(TransactionPortalLocators.currencyName_txt, currencyName, "Currency Name");
		if((transType != null)&&(transType != ""))
				type(TransactionPortalLocators.transType_txt, transType, "Transaction Type");
		if((transactionRemarks != null)&&(transactionRemarks != ""))
			type(TransactionPortalLocators.transRemarks_txt, transactionRemarks, "Transaction Remarks");
		if((recurringPeriod != null)&&(recurringPeriod != ""))
			type(TransactionPortalLocators.recurringPeriod_txt, recurringPeriod, "Recurring Period");
		if((recurringDay != null)&&(recurringDay != ""))
			type(TransactionPortalLocators.recurringDay_txt, recurringDay, "Recurring Day");
		if((noOfRecurring != null)&&(noOfRecurring != ""))
			type(TransactionPortalLocators.noOfRecurring_txt, noOfRecurring, "Number of Recurring");
		if((responseUrl != null)&&(responseUrl != ""))
			type(TransactionPortalLocators.responseUrl_txt, responseUrl, "Response URL");
		if((additionalField1 != null)&&(additionalField1 != ""))
			type(TransactionPortalLocators.addField1_txt, additionalField1, "Additional Field1");
		if((additionalField2 != null)&&(additionalField2 != ""))
			type(TransactionPortalLocators.addField2_txt, additionalField2, "Additional Field2");
		
		click(TransactionPortalLocators.checkout_btn, "Checkout Button");		
		
		HtmlReportSupport.reportStep("Payment Details Page");
		waitForElementPresent(TransactionPortalLocators.vcCardNumber_txt, "Payment Details Page - CREDIT CARD");
		type(TransactionPortalLocators.vcCardNumber_txt, ccNumber, "Card Number");
		selectByVisibleText(TransactionPortalLocators.vcExpiryDateMonth_select, vcExpDateMonth, "Expiry Date - Month");
		selectByVisibleText(TransactionPortalLocators.vcExpDateYear_select, vcExpDateYear, "Expiry Date - Year");
		type(TransactionPortalLocators.vcCvv_txt, vcCvv, "CVV");
		type(TransactionPortalLocators.vcNameOnCard_txt, vcNameOnCard, "Name on Card");
		
		if(vcEmailId != null)
			if(vcEmailId != "")
				type(TransactionPortalLocators.vcEmailId_txt, vcEmailId, "Email ID");
		
		if(vcMobile != null)
			if(vcMobile != "")
				type(TransactionPortalLocators.vcMobile_txt, vcMobile, "Mobile");
		
		if(smartCheckout != null)
			if(smartCheckout.equalsIgnoreCase("Y"))
				click(TransactionPortalLocators.vcSmartCheckout, "Smart Checkout");
		
		RobotUtils.initRobot();
		RobotUtils.pressTabs(1);
		
		click(TransactionPortalLocators.vcPay_btn, "Pay button");
		
		HtmlReportSupport.reportStep("EMI Scheme Page");
		waitForElementPresent(TransactionPortalLocators.emiScheme3_btn, "EMI Scheme Selection Page");
		if(emiScheme.contentEquals("3"))
			click(TransactionPortalLocators.emiScheme3_btn, "EMI Scheme - 3 months");
		else if(emiScheme.contentEquals("6"))
			click(TransactionPortalLocators.emiScheme6_btn, "EMI Scheme - 6 months");
		else if(emiScheme.contentEquals("9"))
			click(TransactionPortalLocators.emiScheme9_btn, "EMI Scheme - 9 months");
		
		if((payWithEmi != null)&&(payWithEmi.equalsIgnoreCase("Y")))
			click(TransactionPortalLocators.payWithEmi_btn, "Pay with EMI button");
		else if((payWithEmi != null)&&(payWithEmi.equalsIgnoreCase("N")))
			click(TransactionPortalLocators.payWithoutEmi_btn, "Pay without EMI button");
		
		HtmlReportSupport.reportStep("Merchant Response Page");
		waitForElementPresent(TransactionPortalLocators.merchResponse_txt, "Merchant Response Page");
		type(TransactionPortalLocators.encKey_txt, encryptKey, "Encrypt Key");
		click(TransactionPortalLocators.submit_btn, "Submit button");
		
		HtmlReportSupport.reportStep("Transaction Status Page");
		waitForElementPresent(TransactionPortalLocators.transactionSuccess_msg, "Transaction Successful Message");
		
		result = true;		
		return result;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setMerchId(String merchId) {
		this.merchId = merchId;
	}

	public void setEncryptKey(String encryptKey) {
		this.encryptKey = encryptKey;
	}

	public void setCcNumber(String ccNumber) {
		this.ccNumber = ccNumber;
	}

	public void setVcExpDateMonth(String vcExpDateMonth) {
		this.vcExpDateMonth = vcExpDateMonth;
	}

	public void setVcExpDateYear(String vcExpDateYear) {
		this.vcExpDateYear = vcExpDateYear;
	}

	public void setVcCvv(String vcCvv) {
		this.vcCvv = vcCvv;
	}

	public void setVcNameOnCard(String vcNameOnCard) {
		this.vcNameOnCard = vcNameOnCard;
	}

	public void setVcEmailId(String vcEmailId) {
		this.vcEmailId = vcEmailId;
	}

	public void setVcMobile(String vcMobile) {
		this.vcMobile = vcMobile;
	}

	public void setSmartCheckout(String smartCheckout) {
		this.smartCheckout = smartCheckout;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	public void setEmiScheme(String emiScheme) {
		this.emiScheme = emiScheme;
	}

	public void setTransAmount(String transAmount) {
		this.transAmount = transAmount;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public void setTransactionRemarks(String transactionRemarks) {
		this.transactionRemarks = transactionRemarks;
	}

	public void setRecurringPeriod(String recurringPeriod) {
		this.recurringPeriod = recurringPeriod;
	}

	public void setRecurringDay(String recurringDay) {
		this.recurringDay = recurringDay;
	}

	public void setNoOfRecurring(String noOfRecurring) {
		this.noOfRecurring = noOfRecurring;
	}

	public void setResponseUrl(String responseUrl) {
		this.responseUrl = responseUrl;
	}

	public void setAdditionalField1(String additionalField1) {
		this.additionalField1 = additionalField1;
	}

	public void setAdditionalField2(String additionalField2) {
		this.additionalField2 = additionalField2;
	}


	public void setDcc(String dcc) {
		this.dcc = dcc;
	}


	public void setPayWithDcc(String payWithDcc) {
		this.payWithDcc = payWithDcc;
	}


	public void setPayWithEmi(String payWithEmi) {
		this.payWithEmi = payWithEmi;
	}	

	
}