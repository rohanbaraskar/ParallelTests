package com.IpgTransactionPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.IpgTransactionPortal.workflows.TransactionPortalWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class SaleInrSmartCheckoutCc_Test extends TransactionPortalWorkflows{
	
	Logger logger = Logger.getLogger(TransactionPortalWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TransactionTestData"), "SaleInrSmartCheckout");
	
	
	@Test(groups= {"smoke", "functional"})
	public void SaleINR_SmartCheckoutCC_Test() throws Throwable 
	{
		url=configProps.getProperty("TransactionURL");
		driver.get(url);
		setMerchId(xls.getCellValue("merchId", "value"));
		setEncryptKey(xls.getCellValue("encryptKey", "value"));
		setVcCvv(xls.getCellValue("vcCvv", "value"));
		setEmailId(xls.getCellValue("emailId", "value"));
		setPassword(xls.getCellValue("password", "value"));
		
		setTransAmount(xls.getCellValue("transactionAmount", "value"));
		setOrderId(xls.getCellValue("orderId", "value"));
		setCurrencyName(xls.getCellValue("currencyName", "value"));
		setTransType(xls.getCellValue("transactionType", "value"));
		setTransactionRemarks(xls.getCellValue("transactionRemarks", "value"));
		setRecurringPeriod(xls.getCellValue("recurringPeriod", "value"));
		setRecurringDay(xls.getCellValue("recurringDay", "value"));
		setNoOfRecurring(xls.getCellValue("noOfRecurring", "value"));
		setResponseUrl(xls.getCellValue("responseUrl", "value"));
		setAdditionalField1(xls.getCellValue("additionalField1", "value"));
		setAdditionalField2(xls.getCellValue("additionalField2", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Sale INR - Smart Checkout Credit Card");
			result = smartCheckoutNormalTransaction();			
		
		} catch (Exception e) {
			Reporter.failureReport("Sale INR - Smart Checkout Credit Card", "Test Failed");
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Sale INR - Smart Checkout Credit Card Test","Successful");
			} 
			else{
				Assert.assertTrue(result == false, "Sale INR - Smart Checkout Credit Card Test Failed");
			}
	}
}