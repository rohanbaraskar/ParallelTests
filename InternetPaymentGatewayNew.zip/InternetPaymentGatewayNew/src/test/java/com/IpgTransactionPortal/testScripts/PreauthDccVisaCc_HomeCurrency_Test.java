package com.IpgTransactionPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.IpgTransactionPortal.workflows.TransactionPortalWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class PreauthDccVisaCc_HomeCurrency_Test extends TransactionPortalWorkflows{
	
	Logger logger = Logger.getLogger(TransactionPortalWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TransactionTestData"), "PreauthDccVisaCcHomeCurrency");
	
	
	@Test(groups= {"smoke", "functional"})
	public void PreauthDCC_VisaCC_HomeCurrency_Test() throws Throwable 
	{
		url=configProps.getProperty("TransactionURL");
		driver.get(url);
		setMerchId(xls.getCellValue("merchId", "value"));
		setEncryptKey(xls.getCellValue("encryptKey", "value"));
		setCcNumber(xls.getCellValue("ccNumber", "value"));
		setVcExpDateMonth(xls.getCellValue("vcExpDateMonth", "value"));
		setVcExpDateYear(xls.getCellValue("vcExpDateYear", "value"));
		setVcCvv(xls.getCellValue("vcCvv", "value"));
		setVcNameOnCard(xls.getCellValue("vcNameOnCard", "value"));
		setVcEmailId(xls.getCellValue("vcEmailId", "value"));
		setVcMobile(xls.getCellValue("vcMobile", "value"));
		setSmartCheckout(xls.getCellValue("smartCheckout", "value"));
		setTransType(xls.getCellValue("transactionType", "value"));
		setCurrencyName(xls.getCellValue("currencyName", "value"));
		
		setTransAmount(xls.getCellValue("transactionAmount", "value"));
		setOrderId(xls.getCellValue("orderId", "value"));
		setTransactionRemarks(xls.getCellValue("transactionRemarks", "value"));
		setRecurringPeriod(xls.getCellValue("recurringPeriod", "value"));
		setRecurringDay(xls.getCellValue("recurringDay", "value"));
		setNoOfRecurring(xls.getCellValue("noOfRecurring", "value"));
		setResponseUrl(xls.getCellValue("responseUrl", "value"));
		setAdditionalField1(xls.getCellValue("additionalField1", "value"));
		setAdditionalField2(xls.getCellValue("additionalField2", "value"));
		setDcc(xls.getCellValue("dcc", "value"));
		setPayWithDcc(xls.getCellValue("payWithDcc", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Preauth DCC - Visa Credit Card - Home Currency");
			result = creditNormalTransaction();			
		
		} catch (Exception e) {
			Reporter.failureReport("Preauth DCC - Visa Credit Card - Home Currency", "Test Failed");
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Preauth DCC - Visa Credit Card - Home Currency Test","Successful");
			} 
			else{
				Assert.assertTrue(result == false, "Preauth DCC - Visa Credit Card - Home Currency Test Failed");
			}
	}
}