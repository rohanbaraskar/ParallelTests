package com.IpgTransactionPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.IpgTransactionPortal.workflows.TransactionPortalWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class PreauthInrVisaCc_Test extends TransactionPortalWorkflows{
	
	Logger logger = Logger.getLogger(TransactionPortalWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("TransactionTestData"), "PreauthInrVisaCc");
	
	
	@Test(groups= {"smoke", "functional"})
	public void PreauthINR_VisaCC_Test() throws Throwable 
	{
		url=configProps.getProperty("TransactionURL");
		driver.get(url);
		setMerchId(xls.getCellValue("merchId", "value"));
		setEncryptKey(xls.getCellValue("encryptKey", "value"));
		setCcNumber(xls.getCellValue("ccNumber", "value"));
		setVcExpDateMonth(xls.getCellValue("vcExpDateMonth", "value"));
		setVcExpDateYear(xls.getCellValue("vcExpDateYear", "value"));
		setVcCvv(xls.getCellValue("vcCvv", "value"));
		setVcNameOnCard(xls.getCellValue("vcNameOnCard", "value"));
		setVcEmailId(xls.getCellValue("vcEmailId", "value"));
		setVcMobile(xls.getCellValue("vcMobile", "value"));
		setSmartCheckout(xls.getCellValue("smartCheckout", "value"));
		setTransType(xls.getCellValue("transactionType", "value"));
		
		setTransAmount(xls.getCellValue("transactionAmount", "value"));
		setOrderId(xls.getCellValue("orderId", "value"));
		setCurrencyName(xls.getCellValue("currencyName", "value"));
		setTransactionRemarks(xls.getCellValue("transactionRemarks", "value"));
		setRecurringPeriod(xls.getCellValue("recurringPeriod", "value"));
		setRecurringDay(xls.getCellValue("recurringDay", "value"));
		setNoOfRecurring(xls.getCellValue("noOfRecurring", "value"));
		setResponseUrl(xls.getCellValue("responseUrl", "value"));
		setAdditionalField1(xls.getCellValue("additionalField1", "value"));
		setAdditionalField2(xls.getCellValue("additionalField2", "value"));
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Preauth INR - Visa Credit Card");
			result = creditNormalTransaction();			
		
		} catch (Exception e) {
			Reporter.failureReport("Preauth INR - Visa Credit Card", "Test Failed");
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Preauth INR - Visa Credit Card Test","Successful");
			} 
			else{
				Assert.assertTrue(result == false, "Preauth INR - Visa Credit Card Test Failed");
			}
	}
}