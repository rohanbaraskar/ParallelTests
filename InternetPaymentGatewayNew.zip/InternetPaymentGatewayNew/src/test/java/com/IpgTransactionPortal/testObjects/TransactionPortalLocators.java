package com.IpgTransactionPortal.testObjects;

import org.openqa.selenium.By;
import com.MainFrameWork.support.HtmlReportSupport;

public class TransactionPortalLocators {
	
	//LANDING PAGE
	public static By normalTransaction_lnk = By.xpath("//h3[contains(text(),'Normal Transaction')]");
	public static By cardCapTransaction_lnk = By.xpath("//h3[contains(text(),'Card Capture Transaction')]");
	public static By transactionStatus_lnk = By.xpath("//h3[contains(text(),'Transaction Status')]");
	public static By cancelTransReq_lnk = By.xpath("//h3[contains(text(),'Cancel Transaction Request')]");
	public static By refundTransReq_lnk = By.xpath("//h3[contains(text(),'Refund Transaction Request')]");
	
	//TRANSACTION REQUEST
	public static By merchId_txt = By.id("mid");
	public static By encryptKey_txt = By.id("encKey");
	public static By orderId_txt = By.id("hdnOrderID");
	public static By transAmt_txt = By.id("trnAmt");
	public static By currencyName_txt = By.id("currency");
	public static By transType_txt = By.id("meTransReqType");
	public static By transRemarks_txt = By.id("trnRemarks");
	public static By recurringPeriod_txt = By.id("recPeriod");
	public static By recurringDay_txt = By.id("recDay");
	public static By noOfRecurring_txt = By.id("noOfRec");
	public static By responseUrl_txt = By.id("resUrl");
	public static By addField1_txt = By.id("addField1");
	public static By addField2_txt = By.id("addField2");
	public static By checkout_btn = By.xpath("//input[contains(@name,'CHECKOUT')]");
	
	//PAYMENT PAGE - CREDIT CARD
	public static By vcRupayRadio_btn = By.id("rupaycrcardradio");
	public static By vcCardNumber_txt = By.id("vCCardNumber");
	public static By vcExpiryDateMonth_select = By.id("vCMmExpiryDate1");
	public static By vcExpDateYear_select = By.id("vCYyyyExpiryDate");
	public static By vcCvv_txt = By.id("vCCvv");
	public static By vcNameOnCard_txt = By.id("vCNameOnCard");
	public static By vcEmailId_txt = By.id("vCEmail");
	public static By vcMobile_txt = By.id("vCMobno");
	public static By vcSmartCheckout = By.xpath("//input[contains(@name,'vQcheckBox')]");
	public static By vcPay_btn = By.id("paybtn");
	
	
	//PAYMENT PAGE - DEBIT CARD
	public static By debitTab = By.id("debit-tab");
	public static By dcCardNumber_txt = By.id("vDCardNumber");
	public static By dcExpiryDateMonth_select = By.id("vDMmExpiryDate");
	public static By dcExpDateYear_select = By.id("vDYyyyExpiryDate");
	public static By dcCvv_txt = By.id("vDCvv");
	public static By dcNameOnCard_txt = By.id("vDNameOnCard");
	public static By dcEmailId_txt = By.id("vDEmail");
	public static By dcMobile_txt = By.id("vDMobno");
	public static By dcPay_btn = By.xpath("//button[contains(@onclick, 'return drPage')]");
	
	//PAYMENT WITH/WITHOUT DCC PAGE
	public static By payWithDcc_btn = By.id("payWithDcc");
	public static By payWithOutDcc_btn = By.id("payWithOutDcc");
	
	//MERCHANT RESPONSE
	public static By merchResponse_txt = By.id("merchantResponse");
	public static By encKey_txt = By.id("enc_key");
	public static By submit_btn = By.xpath("//input[@type='submit']");
	public static By transactionSuccess_msg = By.xpath("//label[contains(text(),'Transaction Status')]/../following-sibling::td/label[contains(text(),'Success')]");
	
	//SMART CHECKOUT
	public static By smartCheckout_tab = By.xpath("//span[contains(text(),'SmartCheckout')]");
	public static By emailId_txt = By.id("wloginId");
	public static By password_txt = By.id("password");
	public static By login_btn = By.xpath("//button[contains(@type,'submit') and contains(text(),'Login')]");
	public static By card_selection = By.xpath("//div[contains(@class,'digitCredit')]");
	public static By vQcvv_txt = By.id("vQcvv");
	public static By submitPay_btn = By.id("submitQuickPayDetails");
	
	//EMI CHECKOUT
	public static By emiScheme3_btn = By.xpath("//input[@id='emiTenure' and @value='3']");
	public static By emiScheme6_btn = By.xpath("//input[@id='emiTenure' and @value='6']");
	public static By emiScheme9_btn = By.xpath("//input[@id='emiTenure' and @value='9']");
	public static By payWithEmi_btn = By.id("payWithEMI");
	public static By payWithoutEmi_btn = By.id("payWithoutEMI");
	
	
}
