package com.IpgMerchantPortal.testObjects;

import org.openqa.selenium.By;

public class MerchantHomePageLocators {

public static By loggedInAs_lnk=By.xpath("//a[@class='dropdown-toggle user' and @data-toggle='dropdown']/i[@class='fa fa-user fa-lg']");
public static By signOut_btn=By.id("/logout");
}
