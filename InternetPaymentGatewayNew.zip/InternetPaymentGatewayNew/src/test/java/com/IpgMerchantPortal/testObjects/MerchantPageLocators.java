package com.IpgMerchantPortal.testObjects;

import org.openqa.selenium.By;

public class MerchantPageLocators {
	
	//DASHBOARD TAB
		public static By dashboard_tab=By.id("/getDashBoard");
		public static By transactionscount_numb=By.xpath("(//div[@class='number'])[1]");
		public static By transactionscount_Text=By.xpath("//div[contains(text(),'Transactions Count')]");
		public static By transactionsamount_numb=By.xpath("(//div[@class='number'])[2]");
		public static By transactionsamount_Text=By.xpath("//div[contains(text(),'Transactions Amount')]");
		public static By chargebackamount_numb=By.xpath("(//div[@class='number'])[3]");
		public static By chargebackamount_Text=By.xpath("//div[contains(text(),'Chargeback Amount')]");
		public static By settledamount_numb=By.xpath("(//div[@class='number'])[4]");
		public static By settledamount_Text=By.xpath("//div[contains(text(),'Settled Amount')]");
	   //SETTLEMENT TAB
		public static By settlement_tab=By.id("/getSettlement");
		public static By fromDate_txt=By.id("fromDate");
		public static By month=By.xpath("//select[@data-handler='selectMonth']");
		public static By year=By.xpath("//select[@data-handler='selectYear']");
		public static By Date_values=By.xpath("//table[@class='ui-datepicker-calendar']//td");
		public static By toDate_txt=By.id("toDate");
		//public static By toDate_value=By.xpath("//a[text()='25']");
		public static By search_btn=By.xpath("//i[@class='fa fa-search']");
		public static By checkbox=By.xpath("(//input[@type='checkbox'])[2]");
		public static By preauth_checkbox=By.xpath("(//input[@type='checkbox'])[1]");
		public static By submit_btn=By.xpath("//i[@class='fa fa-check-circle-o']");
		public static By confirm_btn=By.id("submitBtn");
		public static By sucessMsg=By.id("success");
		public static By settlementMsg_Text=By.xpath("//div[contains(text(),'Settlement initiated for 1 records')]");
        //PRE-AUTHORIZATION
		public static By search_txt = By.xpath("//input[@type='search']");
		public static By preauthorization_tab=By.id("/getPreAuth");
		public static By popUpMsg_Text=By.xpath("//label[text()='Are you sure you want to proceed with selected transaction ?']");
		public static By yes_btn=By.id("confBtn");
		public static By preAuthMsg_Text=By.xpath("//div[contains(text(),'Pre-Authorization Transaction has been successfully completed')]");
		//CANCELLATION/REFUND
		public static By cancelRefund_tab=By.id("/getRefCancel");
		public static By filter_select=By.id("repType");
		public static By refundMsg_Text=By.xpath("//div[contains(text(),'Refund request has been successfully initiated for 1 transaction')]");
		public static By cancelMsg_Text=By.xpath("//div[contains(text(),'Cancellation request has been successfully initiated for 1 transactions')]");
		//REPORTS
		public static By reports_tab=By.id("/getJasRep");
		public static By channel_select=By.id("chnId");
		public static By orderId_txt=By.id("orderId");
		public static By transactionno_txt=By.id("pgMeTrnRefNo");
		public static By status_select=By.id("repType");
		public static By downloadAsExcel_btn = By.id("dwnBtn");
		//CHANGE PASSWORD
		public static By changePassword=By.id("/changePassword");
		public static By changePassword_Text=By.xpath("//span[text()='Change Password']");
		public static By oldPassword_txt=By.id("oldPassword");
		public static By newPassword_txt=By.id("newPassword");
		public static By confrmNewPassword_txt=By.id("confirmPassword");
		public static By chngPaswdSubmit_btn=By.xpath("//button[@type='submit']");
	
}
