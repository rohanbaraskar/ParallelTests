package com.IpgMerchantPortal.testObjects;

import org.openqa.selenium.By;

public class MerchantLoginLocators {

	public static By userId_txt=By.id("loginIDText"); 
	public static By password=By.id("passwordText");
	public static By login_btn=By.id("submitBtn");
}
