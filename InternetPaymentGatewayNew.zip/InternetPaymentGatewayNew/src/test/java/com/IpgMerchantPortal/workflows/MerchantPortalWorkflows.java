package com.IpgMerchantPortal.workflows;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.IpgMerchantPortal.testObjects.MerchantHomePageLocators;
import com.IpgMerchantPortal.testObjects.MerchantPageLocators;
import com.IpgTransAdminPortal.testObjects.ReportsLocators;
import com.IpgTransAdminPortal.testObjects.SettlementMarkingPageLocators;
import com.IpgTransAdminPortal.workflows.SettlementMarkingPage;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class MerchantPortalWorkflows extends ActionEngine {
	public String fromDate;
    public String toDate;
   public String orderId;
   public String transactionRef;
   public String status;
   public String oldPassword;
   public String newPassword;
   public String confrmNewPassword;
   public String channel;

   ExcelReader bufferxls = new ExcelReader(configProps.getProperty("TempData"), "buffer");
	
	
static Logger logger = Logger.getLogger(SettlementMarkingPage.class.getName());
	
	public boolean dashboardTab() throws Throwable {
		boolean result = false;
		HtmlReportSupport.reportStep("Merchant Portal");
		
		HtmlReportSupport.reportStep("Navigate to Dashboard Page");
		waitForElementPresent(MerchantPageLocators.dashboard_tab,"Dashboard Tab");
		verifyText(MerchantPageLocators.dashboard_tab, "Dashboard", "Dashboard Tab");
		click(MerchantPageLocators.dashboard_tab,"Dashboard Tab");
	    waitForElementPresent(MerchantPageLocators.transactionscount_numb, "Transaction Count Number");
	    getText(MerchantPageLocators.transactionscount_numb, "Transactions Count Number");
	    verifyText(MerchantPageLocators.transactionscount_Text, "Transactions Count", "Transaction Count Text");
	    getText(MerchantPageLocators.transactionsamount_numb, "Transactions Amount Number");
	    verifyText(MerchantPageLocators.transactionsamount_Text, "Transactions Amount", "Transaction Amount Text");
	    getText(MerchantPageLocators.chargebackamount_numb, "Chargeback Amount Number");
	    verifyText(MerchantPageLocators.chargebackamount_Text, "Chargeback Amount", "Chargeback Amount Text");
	    getText(MerchantPageLocators.settledamount_numb, "Settled Amount Number");
	    verifyText(MerchantPageLocators.settledamount_Text, "Settled Amount", "Settled Amount Number");
	    
		result = true;
		return result;
	}
	
	public boolean settlementTab() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Merchant Portal");
		
		HtmlReportSupport.reportStep("Navigate to Settlement Page");
		waitForElementPresent(MerchantPageLocators.settlement_tab,"Settlement Tab");
		verifyText(MerchantPageLocators.settlement_tab, "Settlement", "Settlement Tab");
		click(MerchantPageLocators.settlement_tab,"Settlement Tab");
		if((fromDate!=null)&&(fromDate!=""))
			js_type(MerchantPageLocators.fromDate_txt, fromDate, "From Date");
		if((toDate!=null)&&(toDate!=""))
			js_type(MerchantPageLocators.toDate_txt, toDate, "To Date");

	click(MerchantPageLocators.search_btn, "Search Icon");
	waitForElementPresent(MerchantPageLocators.checkbox, "Check Box");
	click(MerchantPageLocators.checkbox, "Check Box");
	waitForElementPresent(MerchantPageLocators.submit_btn, "Submit Button");
	click(MerchantPageLocators.submit_btn, "Submit Button");
	waitForElementPresent(MerchantPageLocators.confirm_btn, "Confirm Button");
	click(MerchantPageLocators.confirm_btn, "Confirm Button");
	waitForElementPresent(MerchantPageLocators.sucessMsg, "Settlement Sucess Message");
	//verifyText(MerchantPageLocators.settlementMsg_Text,"Settlement initiated for 1 records", "Settlement Message");
		
	result = true;
		return result;
	}
	public boolean preAuthorizationTab() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Merchant Portal");
		String transRefNo = bufferxls.getCellData("buffer", "preauthMasterTransRefNo", 2);
		
		HtmlReportSupport.reportStep("Navigate to Pre-Authorization Page");
		waitForElementPresent(MerchantPageLocators.preauthorization_tab,"Pre-Authorization Tab");
		verifyText(MerchantPageLocators.preauthorization_tab, "Pre-Authorization", "Pre-Authorization Tab");
		click(MerchantPageLocators.preauthorization_tab,"Pre-Authorization Tab");
		if((fromDate!=null)&&(fromDate!=""))
			js_type(MerchantPageLocators.fromDate_txt, fromDate, "From Date");
		if((toDate!=null)&&(toDate!=""))
			js_type(MerchantPageLocators.toDate_txt, toDate, "To Date");
		
		type(MerchantPageLocators.search_txt, transRefNo, "Search");
	click(MerchantPageLocators.search_btn, "Search Icon");
	waitForElementPresent(MerchantPageLocators.checkbox, "Check Box");
	click(MerchantPageLocators.preauth_checkbox, "Check Box");
	waitForElementPresent(MerchantPageLocators.confirm_btn, "Submit Button");
	click(MerchantPageLocators.confirm_btn, "Submit Button");
	waitForElementVisibility(MerchantPageLocators.yes_btn, "Yes Button");
	click(MerchantPageLocators.yes_btn, "Yes Button");
	verifyText(MerchantPageLocators.popUpMsg_Text, "Are you sure you want to proceed with selected transaction ?", "Pop Up Message");
	waitForElementPresent(MerchantPageLocators.sucessMsg, "Pre-Authorization Sucess Message");
	verifyText(MerchantPageLocators.preAuthMsg_Text,"Pre-Authorization initiated for 1 records", "Success Message");
		
	result = true;
		return result;
	}
	
	
	public boolean refundTab() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Merchant Portal");
		//String transRefNo = bufferxls.getCellData("buffer", "saleInrVisaCcTransRefNo", 2);
		HtmlReportSupport.reportStep("Navigate to Refund Page");
		waitForElementPresent(MerchantPageLocators.cancelRefund_tab,"Cancel or Refund Tab");
		verifyText(MerchantPageLocators.cancelRefund_tab, "Cancellation / Refund", "Cancel or Refund Tab");
		click(MerchantPageLocators.cancelRefund_tab,"Cancel or Refund Tab");
		if((fromDate!=null)&&(fromDate!=""))
			js_type(MerchantPageLocators.fromDate_txt, fromDate, "From Date");
		if((toDate!=null)&&(toDate!=""))
			js_type(MerchantPageLocators.toDate_txt, toDate, "To Date");
	
		waitForElementVisibility(MerchantPageLocators.filter_select, "Filter");
		selectByVisibleText(MerchantPageLocators.filter_select, "Refund", "Refund");
		//type(MerchantPageLocators.search_txt, transRefNo, "Search");
		click(MerchantPageLocators.search_btn, "Search Icon");
		waitForElementPresent(MerchantPageLocators.checkbox, "Check Box");
		//type(MerchantPageLocators.search_txt, transRefNo, "Search");
		//waitForElementPresent(MerchantPageLocators.checkbox, "Check Box");
		click(MerchantPageLocators.checkbox, "Check Box");
		waitForElementPresent(MerchantPageLocators.confirm_btn, "Submit Button");
		click(MerchantPageLocators.confirm_btn, "Submit Button");
		waitForElementVisibility(MerchantPageLocators.confirm_btn, "Submit Button");
		click(MerchantPageLocators.confirm_btn, "Submit Button");
		waitForElementPresent(MerchantPageLocators.sucessMsg, "Refund Message");
		verifyText(MerchantPageLocators.refundMsg_Text,"Refund request has been successfully initiated for 1 transaction", "Refund Message");
		
	result = true;
		return result;
	}
	public boolean cancellationTab() throws Throwable{
		boolean result = false;
		HtmlReportSupport.reportStep("Merchant Portal");
		String transRefNo = bufferxls.getCellData("buffer", "saleInrMastCcTransRefNo", 2);
		
		HtmlReportSupport.reportStep("Navigate to Cancellation Page");
		waitForElementPresent(MerchantPageLocators.cancelRefund_tab,"Cancel or Refund Tab");
		verifyText(MerchantPageLocators.cancelRefund_tab, "Cancellation / Refund", "Cancel or Refund Tab");
		click(MerchantPageLocators.cancelRefund_tab,"Cancel or Refund Tab");
		if((fromDate!=null)&&(fromDate!=""))
			js_type(MerchantPageLocators.fromDate_txt, fromDate, "From Date");
		if((toDate!=null)&&(toDate!=""))
			js_type(MerchantPageLocators.toDate_txt, toDate, "To Date");
		selectByVisibleText(MerchantPageLocators.filter_select, "Cancellation", "Cancellation");
		type(MerchantPageLocators.search_txt, transRefNo, "Search");
		
		click(MerchantPageLocators.search_btn, "Search Icon");
		waitForElementPresent(MerchantPageLocators.checkbox, "Check Box");
		type(MerchantPageLocators.search_txt, transRefNo, "Search");
		waitForElementPresent(MerchantPageLocators.checkbox, "Check Box");
		click(MerchantPageLocators.checkbox, "Check Box");
		waitForElementPresent(MerchantPageLocators.confirm_btn, "Submit Button");
		click(MerchantPageLocators.confirm_btn, "Submit Button");
		waitForElementVisibility(MerchantPageLocators.confirm_btn, "Submit Button");
		click(MerchantPageLocators.confirm_btn, "Submit Button");
		waitForElementPresent(MerchantPageLocators.sucessMsg, "Cancellation Sucess Message");
		verifyText(MerchantPageLocators.cancelMsg_Text,"Cancellation request has been successfully initiated for 1 transactions", "Cancellation Message");
		
	result = true;
		return result;
	}
	
	public boolean successfulTransactionsReports() throws Throwable{
		
		boolean result = false;
		HtmlReportSupport.reportStep("Reports tab from Merchant Portal");
		waitForElementPresent(MerchantPageLocators.reports_tab,"Reports Tab");
		verifyText(MerchantPageLocators.reports_tab, "Reports", "Reports Tab");
		click(MerchantPageLocators.reports_tab,"Reports Tab");
		HtmlReportSupport.reportStep("Navigate to Reports Page for Successful Transactions");
		click(MerchantPageLocators.fromDate_txt,"From Date");
		calendarPicker(MerchantPageLocators.Date_values, "1", "Date Value");
		click(MerchantPageLocators.toDate_txt,"To Date");
		calendarPicker(MerchantPageLocators.Date_values, "25", "Date Velue");
		click(MerchantPageLocators.channel_select, "Channel");
		selectByVisibleText(MerchantPageLocators.channel_select, "All", "Channel");
		
	if((orderId!=null)&&(orderId!="")){
	type(MerchantPageLocators.orderId_txt, orderId, "Order Id");
	if((transactionRef!=null)&&(transactionRef!=""))
		type(MerchantPageLocators.transactionno_txt,"transactionRef","Transaction Ref No");
	}
	click(MerchantPageLocators.status_select, "Status Dropdown");
	selectByVisibleText(MerchantPageLocators.status_select, status, "Status Value");
	click(MerchantPageLocators.downloadAsExcel_btn, "Download As Excel ");
	captureNetworkPanel();
	result = true;
	return result;
	}
	public boolean pendingForSettlementMarkingReports() throws Throwable{
		
		boolean result = false;
		HtmlReportSupport.reportStep("Reports tab from Merchant Portal");
		waitForElementPresent(MerchantPageLocators.reports_tab,"Reports Tab");
		verifyText(MerchantPageLocators.reports_tab, "Reports", "Reports Tab");
		click(MerchantPageLocators.reports_tab,"Reports Tab");
		HtmlReportSupport.reportStep("Navigate to Reports Page for Pending For Settlement Marking");
		click(MerchantPageLocators.fromDate_txt,"From Date");
		calendarPicker(MerchantPageLocators.Date_values, "1", "Date Value");
		click(MerchantPageLocators.toDate_txt,"To Date");
		calendarPicker(MerchantPageLocators.Date_values, "25", "Date Velue");
		click(MerchantPageLocators.channel_select, "Channel");
		selectByVisibleText(MerchantPageLocators.channel_select, "All", "Channel");
		
	if((orderId!=null)&&(orderId!="")){
	type(MerchantPageLocators.orderId_txt, orderId, "Order Id");
	if((transactionRef!=null)&&(transactionRef!=""))
		type(MerchantPageLocators.transactionno_txt,"transactionRef","Transaction Ref No");
	}
	click(MerchantPageLocators.status_select, "Status Dropdown");
	selectByVisibleText(MerchantPageLocators.status_select, status, "Status Value");
	click(MerchantPageLocators.downloadAsExcel_btn, "Download As Excel ");
	captureNetworkPanel();
	result = true;
	return result;
	}
	public boolean settlementInProgressOrCompletedReports() throws Throwable{
		
		boolean result = false;
		HtmlReportSupport.reportStep("Reports tab from Merchant Portal");
		waitForElementPresent(MerchantPageLocators.reports_tab,"Reports Tab");
		verifyText(MerchantPageLocators.reports_tab, "Reports", "Reports Tab");
		click(MerchantPageLocators.reports_tab,"Reports Tab");
		HtmlReportSupport.reportStep("Navigate to Reports Page for Settlement In-Progress/Completed");
		click(MerchantPageLocators.fromDate_txt,"From Date");
		calendarPicker(MerchantPageLocators.Date_values, "1", "Date Value");
		click(MerchantPageLocators.toDate_txt,"To Date");
		calendarPicker(MerchantPageLocators.Date_values, "25", "Date Velue");
		click(MerchantPageLocators.channel_select, "Channel");
		selectByVisibleText(MerchantPageLocators.channel_select, "All", "Channel");
		
	if((orderId!=null)&&(orderId!="")){
	type(MerchantPageLocators.orderId_txt, orderId, "Order Id");
	if((transactionRef!=null)&&(transactionRef!=""))
		type(MerchantPageLocators.transactionno_txt,"transactionRef","Transaction Ref No");
	}
	click(MerchantPageLocators.status_select, "Status Dropdown");
	selectByVisibleText(MerchantPageLocators.status_select, status, "Status Value");
	click(MerchantPageLocators.downloadAsExcel_btn, "Download As Excel ");
	captureNetworkPanel();
	result = true;
	return result;
	}
	
public boolean merchantPaymentPendingReports() throws Throwable{
		
		boolean result = false;
		HtmlReportSupport.reportStep("Reports tab from Merchant Portal");
		waitForElementPresent(MerchantPageLocators.reports_tab,"Reports Tab");
		verifyText(MerchantPageLocators.reports_tab, "Reports", "Reports Tab");
		click(MerchantPageLocators.reports_tab,"Reports Tab");
		HtmlReportSupport.reportStep("Navigate to Reports Page for Merchant�Payment�Pending");
		click(MerchantPageLocators.fromDate_txt,"From Date");
		calendarPicker(MerchantPageLocators.Date_values, "1", "Date Value");
		click(MerchantPageLocators.toDate_txt,"To Date");
		calendarPicker(MerchantPageLocators.Date_values, "25", "Date Velue");
		click(MerchantPageLocators.channel_select, "Channel");
		selectByVisibleText(MerchantPageLocators.channel_select, "All", "Channel");
		
	if((orderId!=null)&&(orderId!="")){
	type(MerchantPageLocators.orderId_txt, orderId, "Order Id");
	if((transactionRef!=null)&&(transactionRef!=""))
		type(MerchantPageLocators.transactionno_txt,"transactionRef","Transaction Ref No");
	}
	click(MerchantPageLocators.status_select, "Status Dropdown");
	selectByVisibleText(MerchantPageLocators.status_select, status, "Status Value");
	click(MerchantPageLocators.downloadAsExcel_btn, "Download As Excel ");
	captureNetworkPanel();
	result = true;
	return result;
	}

public boolean merchantPaymentCompletedReports() throws Throwable{
	
	boolean result = false;
	HtmlReportSupport.reportStep("Reports tab from Merchant Portal");
	waitForElementPresent(MerchantPageLocators.reports_tab,"Reports Tab");
	verifyText(MerchantPageLocators.reports_tab, "Reports", "Reports Tab");
	click(MerchantPageLocators.reports_tab,"Reports Tab");
	HtmlReportSupport.reportStep("Navigate to Reports Page for Merchant Payment Completed");
	click(MerchantPageLocators.fromDate_txt,"From Date");
	calendarPicker(MerchantPageLocators.Date_values, "1", "Date Value");
	click(MerchantPageLocators.toDate_txt,"To Date");
	calendarPicker(MerchantPageLocators.Date_values, "25", "Date Velue");
	click(MerchantPageLocators.channel_select, "Channel");
	selectByVisibleText(MerchantPageLocators.channel_select, "All", "Channel");
	
if((orderId!=null)&&(orderId!="")){
type(MerchantPageLocators.orderId_txt, orderId, "Order Id");
if((transactionRef!=null)&&(transactionRef!=""))
	type(MerchantPageLocators.transactionno_txt,"transactionRef","Transaction Ref No");
}
click(MerchantPageLocators.status_select, "Status Dropdown");
selectByVisibleText(MerchantPageLocators.status_select, status, "Status Value");
click(MerchantPageLocators.downloadAsExcel_btn, "Download As Excel ");
captureNetworkPanel();
result = true;
return result;
}

public boolean refundInProgressOrCompletedReports() throws Throwable{
	
	boolean result = false;
	HtmlReportSupport.reportStep("Reports tab from Merchant Portal");
	waitForElementPresent(MerchantPageLocators.reports_tab,"Reports Tab");
	verifyText(MerchantPageLocators.reports_tab, "Reports", "Reports Tab");
	click(MerchantPageLocators.reports_tab,"Reports Tab");
	HtmlReportSupport.reportStep("Navigate to Reports Page for Refund In-Progress/Completed");
	click(MerchantPageLocators.fromDate_txt,"From Date");
	calendarPicker(MerchantPageLocators.Date_values, "1", "Date Value");
	click(MerchantPageLocators.toDate_txt,"To Date");
	calendarPicker(MerchantPageLocators.Date_values, "25", "Date Velue");
	click(MerchantPageLocators.channel_select, "Channel");
	selectByVisibleText(MerchantPageLocators.channel_select, "All", "Channel");
	
if((orderId!=null)&&(orderId!="")){
type(MerchantPageLocators.orderId_txt, orderId, "Order Id");
if((transactionRef!=null)&&(transactionRef!=""))
	type(MerchantPageLocators.transactionno_txt,"transactionRef","Transaction Ref No");
}
click(MerchantPageLocators.status_select, "Status Dropdown");
selectByVisibleText(MerchantPageLocators.status_select, status, "Status Value");
click(MerchantPageLocators.downloadAsExcel_btn, "Download As Excel ");
captureNetworkPanel();
result = true;
return result;
}

public boolean onHoldTransactionsReports() throws Throwable{
	
	boolean result = false;
	HtmlReportSupport.reportStep("Reports tab from Merchant Portal");
	waitForElementPresent(MerchantPageLocators.reports_tab,"Reports Tab");
	verifyText(MerchantPageLocators.reports_tab, "Reports", "Reports Tab");
	click(MerchantPageLocators.reports_tab,"Reports Tab");
	HtmlReportSupport.reportStep("Navigate to Reports Page for On Hold Transactions");
	click(MerchantPageLocators.fromDate_txt,"From Date");
	calendarPicker(MerchantPageLocators.Date_values, "1", "Date Value");
	click(MerchantPageLocators.toDate_txt,"To Date");
	calendarPicker(MerchantPageLocators.Date_values, "25", "Date Velue");
	click(MerchantPageLocators.channel_select, "Channel");
	selectByVisibleText(MerchantPageLocators.channel_select, "All", "Channel");
	
if((orderId!=null)&&(orderId!="")){
type(MerchantPageLocators.orderId_txt, orderId, "Order Id");
if((transactionRef!=null)&&(transactionRef!=""))
	type(MerchantPageLocators.transactionno_txt,"transactionRef","Transaction Ref No");
}
click(MerchantPageLocators.status_select, "Status Dropdown");
selectByVisibleText(MerchantPageLocators.status_select, status, "Status Value");
click(MerchantPageLocators.downloadAsExcel_btn, "Download As Excel ");
captureNetworkPanel();
result = true;
return result;
}

public boolean cancellationInProgressOrCompletedReports() throws Throwable{
	
	boolean result = false;
	HtmlReportSupport.reportStep("Reports tab from Merchant Portal");
	waitForElementPresent(MerchantPageLocators.reports_tab,"Reports Tab");
	verifyText(MerchantPageLocators.reports_tab, "Reports", "Reports Tab");
	click(MerchantPageLocators.reports_tab,"Reports Tab");
	HtmlReportSupport.reportStep("Navigate to Reports Page for Cancellation In-Progress/Completed");
	click(MerchantPageLocators.fromDate_txt,"From Date");
	calendarPicker(MerchantPageLocators.Date_values, "1", "Date Value");
	click(MerchantPageLocators.toDate_txt,"To Date");
	calendarPicker(MerchantPageLocators.Date_values, "25", "Date Velue");
	click(MerchantPageLocators.channel_select, "Channel");
	selectByVisibleText(MerchantPageLocators.channel_select, "All", "Channel");
	
if((orderId!=null)&&(orderId!="")){
type(MerchantPageLocators.orderId_txt, orderId, "Order Id");
if((transactionRef!=null)&&(transactionRef!=""))
	type(MerchantPageLocators.transactionno_txt,"transactionRef","Transaction Ref No");
}
click(MerchantPageLocators.status_select, "Status Dropdown");
selectByVisibleText(MerchantPageLocators.status_select, status, "Status Value");
click(MerchantPageLocators.downloadAsExcel_btn, "Download As Excel ");
captureNetworkPanel();
result = true;
return result;
}

public boolean failedTransactionsReports() throws Throwable{
	
	boolean result = false;
	HtmlReportSupport.reportStep("Reports tab from Merchant Portal");
	waitForElementPresent(MerchantPageLocators.reports_tab,"Reports Tab");
	verifyText(MerchantPageLocators.reports_tab, "Reports", "Reports Tab");
	click(MerchantPageLocators.reports_tab,"Reports Tab");
	HtmlReportSupport.reportStep("Navigate to Reports Page for Failed Transactions");
	click(MerchantPageLocators.fromDate_txt,"From Date");
	calendarPicker(MerchantPageLocators.Date_values, "1", "Date Value");
	click(MerchantPageLocators.toDate_txt,"To Date");
	calendarPicker(MerchantPageLocators.Date_values, "25", "Date Velue");
	click(MerchantPageLocators.channel_select, "Channel");
	selectByVisibleText(MerchantPageLocators.channel_select, "All", "Channel");
	
if((orderId!=null)&&(orderId!="")){
type(MerchantPageLocators.orderId_txt, orderId, "Order Id");
if((transactionRef!=null)&&(transactionRef!=""))
	type(MerchantPageLocators.transactionno_txt,"transactionRef","Transaction Ref No");
}
click(MerchantPageLocators.status_select, "Status Dropdown");
selectByVisibleText(MerchantPageLocators.status_select, status, "Status Value");
click(MerchantPageLocators.downloadAsExcel_btn, "Download As Excel ");
captureNetworkPanel();
result = true;
return result;
}

public boolean chargebackReports() throws Throwable{
	
	boolean result = false;
	HtmlReportSupport.reportStep("Reports tab from Merchant Portal");
	waitForElementPresent(MerchantPageLocators.reports_tab,"Reports Tab");
	verifyText(MerchantPageLocators.reports_tab, "Reports", "Reports Tab");
	click(MerchantPageLocators.reports_tab,"Reports Tab");
	HtmlReportSupport.reportStep("Navigate to Reports Page for Chargeback");
	click(MerchantPageLocators.fromDate_txt,"From Date");
	calendarPicker(MerchantPageLocators.Date_values, "1", "Date Value");
	click(MerchantPageLocators.toDate_txt,"To Date");
	calendarPicker(MerchantPageLocators.Date_values, "25", "Date Velue");
	click(MerchantPageLocators.channel_select, "Channel");
	selectByVisibleText(MerchantPageLocators.channel_select, "All", "Channel");
	
if((orderId!=null)&&(orderId!="")){
type(MerchantPageLocators.orderId_txt, orderId, "Order Id");
if((transactionRef!=null)&&(transactionRef!=""))
	type(MerchantPageLocators.transactionno_txt,"transactionRef","Transaction Ref No");
}
click(MerchantPageLocators.status_select, "Status Dropdown");
selectByVisibleText(MerchantPageLocators.status_select, status, "Status Value");
click(MerchantPageLocators.downloadAsExcel_btn, "Download As Excel ");
captureNetworkPanel();
result = true;
return result;
}

public boolean generateReport(String reportType) throws Throwable{
	
	boolean result = false;
	HtmlReportSupport.reportStep(reportType);
	
	waitForElementPresent(MerchantPageLocators.reports_tab,"Reports Tab");
	verifyText(MerchantPageLocators.reports_tab, "Reports", "Reports Tab");
	click(MerchantPageLocators.reports_tab,"Reports Tab");
	
	HtmlReportSupport.reportStep("Navigate to Reports Page for " + reportType);
	if((fromDate!=null)&&(fromDate!=""))
		js_type(MerchantPageLocators.fromDate_txt, fromDate, "From Date");
	if((toDate!=null)&&(toDate!=""))
		js_type(MerchantPageLocators.toDate_txt, toDate, "To Date");
	if((channel!=null)&&(channel!=""))
		selectByVisibleText(MerchantPageLocators.channel_select, channel, "Channel");	
	if((orderId!=null)&&(orderId!=""))
		type(MerchantPageLocators.orderId_txt, orderId, "Order Id");
	if((transactionRef!=null)&&(transactionRef!=""))
		type(MerchantPageLocators.transactionno_txt,"transactionRef","Transaction Ref No");
	if((status!=null)&&(status!=""))
		selectByVisibleText(MerchantPageLocators.status_select, status, "Status Value");
	click(MerchantPageLocators.downloadAsExcel_btn, "Download As Excel ");
	captureNetworkPanel();
result = true;
return result;
}


public boolean changePassword() throws Throwable{
	boolean result = false;
	HtmlReportSupport.reportStep("Home Page of Merchant Portal");
	waitForElementVisibility(MerchantHomePageLocators.loggedInAs_lnk,"Logged In Link");
	click(MerchantHomePageLocators.loggedInAs_lnk, "Logged In Link");
	HtmlReportSupport.reportStep("Navigate to Change Password Page");
	waitForElementVisibility(MerchantPageLocators.changePassword, "Change Password");
	click(MerchantPageLocators.changePassword, "Change Password");
	waitForElementVisibility(MerchantPageLocators.changePassword_Text, "Change Password Text");
	verifyText(MerchantPageLocators.changePassword_Text, "Change Password", "Change Password Text");
	type(MerchantPageLocators.oldPassword_txt, oldPassword, "Old Password");
	type(MerchantPageLocators.newPassword_txt, newPassword, "New Password");
	type(MerchantPageLocators.confrmNewPassword_txt, confrmNewPassword, "Confrm New Password");
	
	//NEED TO WRITE SUBMIT BUTTON
	
	result = true;
	return result;
}
	public void setOrderId(String orderId){
		this.orderId=orderId;
	}
	public void setTransactionRef(String transactionRef){
		this.transactionRef=transactionRef;		
	}
	public void setStatus(String status){
		this.status=status;
	}
	public void setOldPassword(String oldPassword){
		this.oldPassword=oldPassword;
	}
	public void setNewPassword(String newPassword){
		this.newPassword=newPassword;
	}
	public void setConfrmNewPassword(String confrmNewPassword){
		this.confrmNewPassword=confrmNewPassword;
	}
	
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	
	
	}
