package com.IpgMerchantPortal.workflows;

import org.apache.log4j.Logger;

import com.IpgMerchantPortal.testObjects.MerchantHomePageLocators;
import com.IpgMerchantPortal.testObjects.MerchantLoginLocators;
import com.IpgTransAdminPortal.testObjects.HomePageLocators;
import com.IpgTransAdminPortal.testObjects.LoginLocators;
import com.IpgTransAdminPortal.workflows.HomePage;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;

public class MerchantHomePage extends ActionEngine {
static Logger logger = Logger.getLogger(MerchantHomePage.class.getName());
	
	/**
	 * Sign in to Merchant Portal
	 * @return
	 * @throws Throwable
	 */
	public boolean logOut() throws Throwable{
		boolean result = false;
		ImplicitWait();		
		HtmlReportSupport.reportStep("Logout");
		Thread.sleep(3000);
		//if(waitForElementPresent(HomePageLocators.loggedInAs_lnk, "Logout button"))
		if(isElementDisplayed(MerchantHomePageLocators.loggedInAs_lnk, "Logout button"))
		{
			click(MerchantHomePageLocators.loggedInAs_lnk, "Logged As Link");
			waitForElementPresent(MerchantHomePageLocators.signOut_btn, "Sign Out Button");
			click(MerchantHomePageLocators.signOut_btn, "Sign Out Button");
			waitForElementPresent(MerchantLoginLocators.userId_txt, "Logout Successful");
			result = true;
		}
		return result;
	}	
	
}
