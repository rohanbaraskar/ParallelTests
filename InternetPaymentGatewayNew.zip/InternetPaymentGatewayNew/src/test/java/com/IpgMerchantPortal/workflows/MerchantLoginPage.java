package com.IpgMerchantPortal.workflows;

import org.apache.log4j.Logger;

import com.IpgMerchantPortal.testObjects.MerchantLoginLocators;
import com.IpgMerchantPortal.testObjects.MerchantPageLocators;
import com.MainFrameWork.accelerators.ActionEngine;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class MerchantLoginPage extends ActionEngine {
	public String UserName;
	public String Password;
	
	public void setUserName(String userName) {
		UserName = userName;
	}
	public void setPassword(String password) {
		Password = password;
	}

	static Logger logger = Logger.getLogger(MerchantLoginPage.class.getName());
	
	/**
	 * Sign in to IPD Transaction Admin Portal
	 * @return
	 * @throws Throwable
	 */
	public boolean login() throws Throwable{
		boolean result = false;
		ImplicitWait();		
		HtmlReportSupport.reportStep("Login Credentials_Entry");
		
		if(waitForElementPresent(MerchantLoginLocators.userId_txt, "Login Page"))
		{
			Reporter.SuccessReport("IPG Merchant Portal","Login Page loaded succesfully");
			type(MerchantLoginLocators.userId_txt, UserName, "Username Field");
			type(MerchantLoginLocators.password,Password, "Password Field");
			click(MerchantLoginLocators.login_btn, "Login Button");
			waitForElementPresent(MerchantPageLocators.dashboard_tab, "Home Page");
			result = true;
		}
		return result;
	}	
}

