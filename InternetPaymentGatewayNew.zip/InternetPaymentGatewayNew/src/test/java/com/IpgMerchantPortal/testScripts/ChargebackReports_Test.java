package com.IpgMerchantPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgMerchantPortal.workflows.MerchantHomePage;
import com.IpgMerchantPortal.workflows.MerchantLoginPage;
import com.IpgMerchantPortal.workflows.MerchantPortalWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class ChargebackReports_Test extends MerchantPortalWorkflows{

	Logger logger = Logger.getLogger(MerchantPortalWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("MerchantTestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("MerchantTestData"), "Chargeback");
	@Test(groups= {"smoke", "functional"})
	public void chargebackReports_Test() throws Throwable 
	{
		url=configProps.getProperty("MerchantURL");
		driver.get(url);
		setOrderId(xlsrdr.getCellValue("orderId", "value"));
		setTransactionRef(xlsrdr.getCellValue("transactionsRef", "value"));
		setStatus(xlsrdr.getCellValue("status", "value"));
		setFromDate(xlsrdr.getCellValue("fromDate", "value"));
		setToDate(xlsrdr.getCellValue("toDate", "value"));
		setChannel(xlsrdr.getCellValue("channel", "value"));
		
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Chargeback Reports Page Verification From Merchant Portal");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            MerchantLoginPage login = new MerchantLoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			MerchantHomePage home=new MerchantHomePage();
			result = generateReport("Chargeback Report");
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Chargeback Reports Page", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Chargeback Reports page ","Successful for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Chargeback Reports Page Test Failed");
			}
	}

} 