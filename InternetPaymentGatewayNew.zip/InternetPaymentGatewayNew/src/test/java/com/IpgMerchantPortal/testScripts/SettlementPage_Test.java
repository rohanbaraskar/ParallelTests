package com.IpgMerchantPortal.testScripts;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.IpgMerchantPortal.workflows.MerchantHomePage;
import com.IpgMerchantPortal.workflows.MerchantLoginPage;
import com.IpgMerchantPortal.workflows.MerchantPortalWorkflows;
import com.MainFrameWork.accelerators.TestEngine;
import com.MainFrameWork.support.ExcelReader;
import com.MainFrameWork.support.HtmlReportSupport;
import com.MainFrameWork.utilities.Reporter;

public class SettlementPage_Test extends MerchantPortalWorkflows {
	

	Logger logger = Logger.getLogger(MerchantPortalWorkflows.class.getName());
	ExcelReader xls = new ExcelReader(configProps.getProperty("MerchantTestData"), "Signin");
	String UserName = xls.getCellValue("userid", "value");
	String Password = xls.getCellValue("password", "value");
	
	ExcelReader xlsrdr = new ExcelReader(configProps.getProperty("MerchantTestData"), "Settlement");
	@Test(groups= {"smoke", "functional"})
	public void settlementPage_Test() throws Throwable 
	{
		url=configProps.getProperty("MerchantURL");
		driver.get(url);
		setFromDate(xlsrdr.getCellValue("fromDate", "value"));
		setToDate(xlsrdr.getCellValue("toDate", "value"));
		boolean result = false;
		try
		{
			TestEngine.testDescription.put(HtmlReportSupport.tc_name, "Settlement Page Verification From Merchant Portal");
			logger.info("Username = " + UserName);
			logger.info("Password = " + Password);
            MerchantLoginPage login = new MerchantLoginPage();
			login.setUserName(UserName);
			login.setPassword(Password);
			login.login();
			
			MerchantHomePage home=new MerchantHomePage();
			result = settlementTab();
			home.logOut();
			
		
		} catch (Exception e) {
			Reporter.failureReport("Settlement Page", "Test Failed for"+ UserName);
			e.printStackTrace();
		}
		
			if (result){	
				Reporter.SuccessReport("Settlement page ","Successful for user: " + UserName);
			} 
			else{
				Assert.assertTrue(result == false, "Settlement Page Test Failed");
			}
	}
}
