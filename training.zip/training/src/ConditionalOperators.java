
public class ConditionalOperators {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sDay = "Saturday";
		int iDay = 6;
		
 
		if(sDay.equals("Sunday")){
			System.out.println("Today is Sunday");
		}else{
			System.out.println("Today is not Sunday");
		}
 
		if(iDay==6){
			System.out.println("Today is Sunday");
		}else{
			System.out.println("Today is not Sunday");
		}
	//}
	
	
	int iDay1 = 5;
	

		switch(iDay1){
			case 1:
				System.out.println("Today is Monday");
				break;
		case 3:
			System.out.println("Today is Tuesday");
			break;
		case 4:
			System.out.println("Today is Wednesday");
			break;
		case 5:
			System.out.println("Today is Thursday");
			break;
		case 6:
			System.out.println("Today is Friday");
			break;
		case 7:
			System.out.println("Today is Saturday");
			break;
		default:
			System.out.println("Today is Sunday");
			break;
				}
		
		
		
		String [] aMake = {"BMW","AUDI","TOYOTA","SUZUKI","HONDA"};
		 
		//This is to store the size of the Array
		int iLength = aMake.length;
		System.out.println("Length of the Array is ==> " + iLength);
 
		//This is to access the first element of an array directly with it's position
		String sBMW = aMake[0];
		System.out.println("First value of the Array is ==> " + sBMW);
 
		//This is to access the last element of an Array
		String sHonda = aMake[iLength-1];
		System.out.println("Last value of the Array is ==> " + sHonda);
 
		//This is to print all the element values of an Array
		for(int i = 0;i<=iLength-1;i++){
			System.out.println("The value stored at position "+i+" in aMake array is ==> " + aMake[i]);
		}
	}

}
