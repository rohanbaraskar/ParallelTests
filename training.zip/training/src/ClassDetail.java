

	//an object is an instance of a class. An object can be considered as a thing, which performs a set of activities

	//objects always share two characteristics, they all have state and they all have behaviors. For example a car have state (make, brand, color, model) and have behavior (braking, accelerating, slowing down, changing gears).

	//we can say that the object is a collection of methods ( behavior � braking, accelerating, slowing down, changing gears)  and variables (state � make, brand, color, model).


	// if we create a class �Car� and create an object �Toyota� from that car class, then we can say that the Toyota car object is an instance of the class of objects known as Car. Toyota car have some states and behavior. However each brand of car will have its own state and behaviors.
	//variables declared in the body of the class are called member variables
	//these member variables are called fields. The fields can be any type.
	//A car object can also perform some actions. These actions are referred as methods of a class.
	
	/**
	 * @param args
	 */
	
	class Car {
		//Class Member Variables & Fields
		String sModel;
	    int iGear;
	    int iHighestSpeed;
	    String sColor;
	    int iMake;
	    boolean bLeftHandDrive;
	    String sTransmission;
	    int iTyres;
	    int iDoors;
	 
	    public void DisplayCharacterstics(){
	    	System.out.println("Model of the Car: " +  sModel);
	    	System.out.println("Number of gears in the Car: " +  iGear);
	    	System.out.println("Max speed of the Car: " +  iHighestSpeed);
	    	System.out.println("Color of the Car: " +  sColor);
	    	System.out.println("Make of the Car: " +  iMake);
	    	System.out.println("Transmission of the Car: " +  sTransmission);
	 
	    }
	    
	    
	 
	}
	public class ClassDetail {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car Toyota = new Car();;
		 
		Toyota.bLeftHandDrive = true;
		Toyota.iDoors = 4;
		Toyota.iGear = 5;
		Toyota.iHighestSpeed = 200;
		Toyota.sModel = "Camry";
 
		//Using Car class method
		Toyota.DisplayCharacterstics();
		
		// 2nd object
		Car Nissan = new Car();;
		
		Nissan.bLeftHandDrive = false;
		Nissan.iDoors = 5;
		Nissan.iGear = 3;
		Nissan.iHighestSpeed = 300;
		Nissan.sModel = "Namry";
		
		Nissan.DisplayCharacterstics();
		
		}
	}

