
public class Varriables {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//A data type indicates what sort of value or the type of data the variable can represents, such as integer, floating-point numbers, character, boolean or an alphanumeric string.
		//variable is a reserved space or a memory location to store some sort of information. Information can be of any data type such as int, string, bool or float.
		boolean testResult;
		 
		//Initialize the boolean variable with value true or false, once boolean declaration is done
		testResult = true;

		//Print the value of boolean variable
		System.out.println("Test Result is: " +  testResult);

		//Change the value of boolean variable
		testResult = false;

		//Print the value of boolean variable
		System.out.println("Test Result is: " +  testResult);
		
		
		int carSpeed;
		 
		//Initialize the integer variable with value 20
        carSpeed = 20;
 
		//Print the value of integer variable
		System.out.println("Car is running at the speed of: " +  carSpeed);
 
		//Change the value of integer variable
		carSpeed = carSpeed + 20;
 
		//Print the value of integer variable
		System.out.println("Current speed of the car is: " +  carSpeed);
		
		char a;
		 
        //Initialize the char variable with value 'P'
        a = 'P';
 
        //Print the value of char variable
      	System.out.println("Value of char is : " +  a);
		
		double PI;
 
		//Initialize the double variable with value 'P'
        PI = 3.14159;
 
      //Print the value of double variable
        System.out.print("PI: " + PI);
	}

}
