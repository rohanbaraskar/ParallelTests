
public class Loops {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int Increment = 0;Increment<=5;Increment++){
			System.out.println("Count is  ==> " + Increment );
		}

		System.out.println("<==== for Loop increment ends ====>");
		// This will print -- 5,4,3,2,1,0
		for(int Decrement = 5;Decrement>=0;Decrement--){
			System.out.println("Count is ==> " + Decrement );
		}

		System.out.println("<==== for Loop increment ends ====>");
		// This will print -- 0,2,4
		for(int Increment = 0;Increment<=5;Increment+=2){
			System.out.println("Skip every one another  ==> " + Increment );
		}
		
		int Count = 0;
		 // This will print -- 5,10,15,20,25
		 while(Count < 25){
			 Count = Count + 5;
			 System.out.println("While :Count is ==> "+ Count);
			 }

		 int CountOnce = 25;
		 System.out.println("<==== Next Count ====>");
		 // This will not print count even once
		 while(CountOnce < 25){
			 CountOnce = CountOnce + 5;
			 System.out.println("Count is ==> "+ CountOnce);
			 }
		
		 char[] vowels = {'a', 'e', 'i', 'o', 'u'};
	      // foreach loop
	      for (char item: vowels) {
	         System.out.println(item);
	      }
	
		 
		 
		 
		 
		 
		 
	 
	}	 
	   
}


