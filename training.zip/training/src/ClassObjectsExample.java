
class Lamp {
	 // instance variable
  boolean isOn;
//method
  void turnOn() {
    isOn = true;
  }

  void turnOff() {
   isOn = false;
  }
  
  void displayLightStatus() {
     
     System.out.println("Light on? " + isOn);
  }
}


 class ClassObjectsExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Lamp led = new Lamp(); 
		Lamp cfl = new Lamp();
		   
			led.turnOn();
			cfl.turnOff();
		   
		   System.out.println("Status of led lamp");
		   led.displayLightStatus();
		   
		   System.out.println("Status of cfl lamp");
		   cfl.displayLightStatus();
		
	}

}
 //Lamp is class
 // led,cfl is an object
// It can be in on or off state.
 //You can turn on and turn off lamp (behavior).
