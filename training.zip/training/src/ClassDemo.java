 class Animal {
	public Animal() {
		System.out.println("An animal breaths oxygen");
	}
	
	public void eat() {
		System.out.println("An animal eats.");
	}
	
}
 class Bird extends Animal {
	public Bird() {
		super();
		System.out.println("A new bird has been created!");
	}
	/*
	@Override
	public void eat() {
		System.out.println("A bird eats seeds");
	}
	*/
	public void fly() {
		System.out.println("A bird is flying...");
	}
	
}

 class Dog extends Animal {
	public Dog() {
		super();
		System.out.println("A new dog has been created!");
	}
	public void bark() {
		System.out.println("A dog is barking...");
	}
	
	
	@Override
	public void eat() {
		System.out.println("A dog eats raw bones.");
	}
}

public class ClassDemo {
	public static void main(String[] args) {
		Animal animal = new Animal();
		animal.eat();
		System.out.println("******* Animal Section Ends*****");
		Bird bird = new Bird();
		bird.eat();   // 
		bird.fly();
		System.out.println("******* Bird Section Ends*****");
		Dog dog = new Dog();
		dog.eat();
		dog.bark();
	}
}