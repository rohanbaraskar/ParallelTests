package selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class BasicCommands {

	//1 
	@Test
	public void firstmethod() throws InterruptedException{
		WebDriver driver;
        
        //Setting webdriver.gecko.driver property    
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\atos.AWLIN-LT-12135\\Desktop\\chromedriver.exe");
        
        //Instantiating driver object and launching browser
        driver = new ChromeDriver();
        
        //Using get() method to open a webpage
        driver.get("http://www.google.com");

      //Initializing webelement searchBox
        WebElement searchBox = driver.findElement(By.name("q"));
        Thread.sleep(3000);
      //Writing a text "ArtOfTesting" in the search box
      searchBox.sendKeys("Worldline");
      Thread.sleep(7000);
        //Closing the browser
        driver.quit();
 
    }
	
	@Test
	public void test2fillform() throws InterruptedException{
		
WebDriver driver;
        
        //Setting webdriver.gecko.driver property
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\atos.AWLIN-LT-12135\\Desktop\\chromedriver.exe");
        
        //Instantiating driver object and launching browser
        driver = new ChromeDriver();
        
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        
        
        
        //Using get() method to open a webpage
        driver.get("http://toolsqa.com/automation-practice-form/");
        driver.manage().window().maximize();
        
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,700)");
        
        driver.findElement(By.name("firstname")).sendKeys("selenium");
        Thread.sleep(3000);
		
        driver.findElement(By.name("lastname")).sendKeys("Training");
        Thread.sleep(3000);
		
		//radio button   Xpath=//tagname[@attribute='value']
        driver.findElement(By.xpath("//input[@id='sex-0']")).click();
        
        Thread.sleep(3000);
        driver.findElement(By.xpath("//input[@id='exp-5']")).click();
		
        driver.findElement(By.id("profession-1")).click();
        
        // dropdown
        
        WebElement element = driver.findElement(By.id("continents"));
        Select oSelect = new Select(element);
        
        oSelect.selectByVisibleText("Antartica");
        Thread.sleep(3000);
        
        WebElement element1 = driver.findElement(By.id("selenium_commands"));
        Select oSelect1 = new Select(element1);
		
        oSelect1.selectByVisibleText("Navigation Commands");
        oSelect1.selectByVisibleText("Browser Commands");
        
        
        driver.findElement(By.id("submit")).click();
		
		
		
		
		
		
		
	}

}
